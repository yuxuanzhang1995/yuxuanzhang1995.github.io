"""Full-wedge interval certificate. A theorem is certified only when no box remains."""
from mpmath import iv
import math, time
from fractions import Fraction as F
iv.dps = 35
I = iv.mpf
ZERO = I(0)
ONE = I(1)
L2 = iv.log(I(2))
PI = iv.pi

def lo(a):
    f = float(a.a)
    return 0.0 if f == 0 and a.a == 0 else math.nextafter(f, -math.inf)

def hi(a):
    f = float(a.b)
    return 0.0 if f == 0 and a.b == 0 else math.nextafter(f, math.inf)

def clamp(a, l, h):
    return I([max(l, lo(a)), min(h, hi(a))])

def roots(e, D):
    v = I(1) / 9 - e / 3
    if lo(v) <= 0:
        raise ValueError('degenerate v')
    z = (I(1) / 27 - e / 6 + D / 2) / v ** I('1.5')
    z = clamp(z, -1, 1)
    w = clamp(1 - z * z, 0, 1)
    a = iv.atan2(iv.sqrt(w), z) / 3
    return [clamp(I(1) / 3 + 2 * iv.sqrt(v) * iv.cos(a - 2 * PI * k / 3), 0, 1) for k in range(3)]

def entropy(ls):
    out = I(0)
    for z in ls:
        a, b = (lo(z), hi(z))

        def h(t):
            if t == 0:
                return I(0)
            t = I(t)
            return -t * iv.log(t) / L2
        vals = [h(a), h(b)]
        if a <= hi(1 / iv.exp(1)) and b >= lo(1 / iv.exp(1)):
            vals.append(1 / (iv.exp(1) * L2))
        out += I([min((lo(v) for v in vals)), max((hi(v) for v in vals))])
    return out

def data(x, y, deriv=False, hess=False):
    r = [x, (1 - x + y) / 2, (1 - x - y) / 2]
    r = [clamp(z, 0, 1) for z in r]
    e = (1 + sum((z * z for z in r))) / 6
    t = r[0] ** I('1.5') - r[1] ** I('1.5') - r[2] ** I('1.5')
    tp = I([max(0, lo(t)), max(0, hi(t))])
    D = tp * tp / 27
    ls = roots(e, D)
    H = entropy(ls)
    if not deriv:
        return H
    vv = I(1) / 9 - e / 3
    zz = (I(1) / 27 - e / 6 + D / 2) / vv ** I('1.5')
    if not (-1 < lo(zz) and hi(zz) < 1):
        raise ValueError('uncertified derivative real-root domain')
    dr = [[I(1), I(0)], [I(-0.5), I(0.5)], [I(-0.5), I(-0.5)]]
    eg = [sum((r[k] * dr[k][i] for k in range(3))) / 3 for i in range(2)]
    tg = [I('1.5') * sum(((1 if k == 0 else -1) * iv.sqrt(r[k]) * dr[k][i] for k in range(3))) for i in range(2)]
    Dg = [2 * tp * tg[i] / 27 for i in range(2)]
    lg = []
    hg = [I(0), I(0)]
    for z in ls:
        if lo(z) <= 0:
            raise ValueError('zero eigenvalue')
        den = 3 * z * z - 2 * z + e
        if lo(den) <= 0 <= hi(den):
            raise ValueError('root collision')
        g = [(Dg[i] - eg[i] * z) / den for i in range(2)]
        lg.append(g)
        for i in range(2):
            hg[i] -= (iv.log(z) + 1) * g[i] / L2
    if not hess:
        return (H, hg)
    if lo(t) <= 0 or any((lo(z) <= 0 for z in r)):
        raise ValueError('hessian boundary')
    ee = [[sum((dr[k][i] * dr[k][j] for k in range(3))) / 3 for j in range(2)] for i in range(2)]
    tt = [[I('.75') * sum(((1 if k == 0 else -1) * dr[k][i] * dr[k][j] / iv.sqrt(r[k]) for k in range(3))) for j in range(2)] for i in range(2)]
    DD = [[2 * (tg[i] * tg[j] + t * tt[i][j]) / 27 for j in range(2)] for i in range(2)]
    hh = [[I(0) for j in range(2)] for i in range(2)]
    for z, g in zip(ls, lg):
        den = 3 * z * z - 2 * z + e
        for i in range(2):
            for j in range(2):
                zz = (DD[i][j] - ee[i][j] * z - eg[i] * g[j] - eg[j] * g[i] - (6 * z - 2) * g[i] * g[j]) / den
                hh[i][j] -= (g[i] * g[j] / z + (iv.log(z) + 1) * zz) / L2
    return (H, hg, hh)

import heapq

def terminal_gap_certificate():
    slope=I(1517)/1000
    L=iv.log(I(3))/L2
    u=I(3)/5
    eig=[(1-u)/3,(2+u)/6,(2+u)/6]
    edge=-sum(z*iv.log(z)/L2 for z in eig)
    ctest=10*(L-edge)
    assert F(lo(ctest-slope)) > F(1,1250)
    print('Slope margin > 1/1250 > 0: asserted')
    def admissible(b):
        a,c,u,v=b
        return F(u)<=1-F(a) and F(u)<=3*F(c)-1 and a<=c and u<=v
    def bound(b):
        a,c,u,v=b;x=I([a,c]);y=I([u,v])
        affine=L-slope*(1-x)
        r=[x,(1-x+y)/2,(1-x-y)/2];r=[clamp(z,0,1)for z in r]
        purity=(2-sum(z*z for z in r))/3
        ans=lo(-iv.log(purity)/L2-affine)
        try:ans=max(ans,lo(data(x,y)-affine))
        except (ValueError,ZeroDivisionError):pass
        if F(v)<=1-F(c) and F(v)<=3*F(a)-1:
            try:
                _,grad=data(x,y,True)
                xx=(a+c)/2;yy=(u+v)/2
                center=data(I(xx),I(yy))-L+slope*(1-I(xx))
                ans=max(ans,lo(center+(grad[0]-slope)*(x-I(xx))+grad[1]*(y-I(yy))))
            except (ValueError,ZeroDivisionError):pass
        return ans
    box=(math.nextafter(1/3,-math.inf),13/16,0.,.5)
    assert F(box[0]) <= F(1,3) and F(box[1]) == F(13,16)
    queue=[(bound(box),0,box)];serial=1;splits=0;floor=math.inf;accepted=0
    while queue:
        z,_,b=heapq.heappop(queue)
        if z>0:
            floor=min(floor,z);accepted+=1;continue
        assert splits<100000,'Incomplete; no theorem'
        a,c,u,v=b
        if c-a>=v-u:
            mid=(a+c)/2;assert a<mid<c
            children=[(a,mid,u,v),(mid,c,u,v)]
        else:
            mid=(u+v)/2;assert u<mid<v
            children=[(a,c,u,mid),(a,c,mid,v)]
        for child in children:
            if not admissible(child):continue
            zz=bound(child);heapq.heappush(queue,(zz,serial,child));serial+=1
        splits+=1
    assert not queue and accepted>0 and F(floor)>F(1,10000000)
    print('Closed sorted wedge 1/3 <= x <= 13/16 fully covered:',not queue)
    print('Wedge gap > 1/10000000 > 0: asserted')
    print('Splits:',splits,'accepted boxes:',accepted)
    print('TERMINAL AFFINE LOWER BOUND OVER REMAINING TRIANGLE: PASS')
    return {'status':'exact_certificate_passed_pending_analytic_audit','global_gap_lower_bound':floor,'splits':splits,'accepted_boxes':accepted,'slope':'1517/1000','scope':'Sorted maximum probability x<=13/16; combined with the native analytic high-x strip and coefficient sorting this is a proposed unrestricted terminal-support proof, not yet independently audited.'}


if __name__ == '__main__':
    assert F(13,16)**3-2*(1-F(13,16))*(2-F(13,16))**2 == F(31,4096) > 0
    print('High-strip polynomial at 13/16 = 31/4096 > 0: asserted')
    assert F(83349,83521) < 1
    assert F(250994068,250000000) > 1
    print('Contact signs: 83349/83521 < 1; 250994068/250000000 > 1: asserted')
    terminal_gap_certificate()
