All logarithms below are base two unless written ln.

1. Tensor-product measurement lower bound. Write each outcome as a pair of bits, with bit 0 denoting eigenvalue +1. For component i in {1,2}, declare a CHSH win when a_i XOR b_i=xy, and let K be the number of wins. Use uniform settings. On Phi_2 the specified observables give a win probability w=(2+sqrt(2))/4 in every context. Because the state and the bases factor across the two qubits, K has probabilities P_0=(3-2sqrt(2))/8, P_1=1/4, P_2=(3+2sqrt(2))/8, in every context.

For every deterministic local four-outcome strategy, its component-i output bits constitute an ordinary deterministic CHSH strategy, winning at most three of the four contexts. Thus E_local K<=3/2, also for every convex mixture of deterministic strategies: this assertion applies to the entire four-outcome local polytope, allowing arbitrary correlations between component bits. Define the strictly positive score f(K)=1+(K-3/2)/2. Its three values are 1/4, 3/4, 5/4, and E_local f<=1.

For joint distributions P(x,y,a,b)=p_T(a,b|x,y)/4 and Q(x,y,a,b)=ell(a,b|x,y)/4, the variational relative-entropy inequality gives D(P||Q)>=E_P log f-log E_Q f>=E_P log f. This follows directly by normalizing Qf and using nonnegativity of relative entropy; if Q vanishes on the support of P the inequality is immediate. Consequently
S*(p_T)>=S(p_T;uniform)>=L,
where L=-2P_0+(1/4)log(3/4)+P_2 log(5/4).
The exact-rational checker below establishes L>87/1000.

2. A local upper bound for CGLMP, simultaneously for every setting distribution. All output arithmetic in this paragraph is modulo four. Define the transformed differences
 t_00=a-b, t_01=-a+b-1, t_10=-a+b, t_11=a-b.
For the phases in Eq. (2), a direct geometric-sum evaluation of the Born probabilities yields, in each context,
 p_CGLMP(a,b|x,y)=q(t_xy)/4,
 q(t)=1/[32 sin^2(pi(t+1/4)/4)].
Indeed the original difference enters the amplitude as a-b+alpha_x+beta_y, and the transformations above change it to plus or minus (t+1/4), modulo four.

We now construct a local behavior ell with ell(a,b|x,y)=r(t_xy)/4 and r=(7/10,1/20,1/20,1/5). With probability 4/5 choose a uniformly random permutation of the tuple (0,0,0,3), and with probability 1/5 choose a uniformly random permutation of (0,0,1,2). Regard the resulting four entries as (t_00,t_01,t_10,t_11). Their sum is always 3 modulo four. Such a tuple is realizable by a deterministic local assignment: set a_0=0, b_0=-t_00, b_1=t_01+1, and a_1=t_11+b_1. The prescribed t_10 then agrees because the tuple sums to -1 modulo four. Finally add an independent uniform common shift to all four outputs a_0,a_1,b_0,b_1. This construction is explicitly a mixture of deterministic local strategies. Each tuple coordinate has marginal
 (4/5)(3/4,0,0,1/4)+(1/5)(1/2,1/4,1/4,0)=r.
The common shift makes the four outcome pairs with any given transformed difference equiprobable, proving the claimed formula for ell.

It follows that the divergence from this same local ell in every context is
 U=sum_{t=0}^3 q(t)log(q(t)/r(t)).
For every setting distribution mu, including boundary distributions, S(p_CGLMP;mu)<=U. Hence S*(p_CGLMP)<=U.

For an algebraic expression avoiding trigonometric evaluation, set u=sqrt(2+sqrt(2)), v=sqrt(2-sqrt(2)). Then
 (q(0),q(1),q(2),q(3))=(1/[8(2-u)],1/[8(2+v)],1/[8(2+u)],1/[8(2-v)]).
The checker establishes U<65/1000. Together the two bounds prove S*(p_T)-S*(p_CGLMP)>22/1000, disproving Eq. (3).

3. Certificate arithmetic. The attached checker uses only Python integer and Fraction arithmetic, not floating-point arithmetic or an optimization solver. Square roots are enclosed using integer square roots at denominator 10^18. Logarithms are enclosed by ln(x)=2 sum_{j>=0} z^(2j+1)/(2j+1), z=(x-1)/(x+1), using reciprocal symmetry when x<1. For x>=1, after n terms the omitted tail lies between zero and 2 z^(2n+1)/[(2n+1)(1-z^2)]. Monotonicity encloses the logarithm on an interval. Standard outward interval operations then enclose exactly L and U. Its assertions and printed rational comparisons certify both decisive bounds and their separation. No solver accuracy assumption is involved.