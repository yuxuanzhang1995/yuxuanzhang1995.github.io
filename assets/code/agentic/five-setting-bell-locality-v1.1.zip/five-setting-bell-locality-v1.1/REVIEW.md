# Independent review of the frozen v1 manuscript

Date: 2026-11-19. Reviewer: one separately delegated AI reviewer, with no further delegation. This is an independent adversarial review within the present workspace, not an external expert report or journal peer review.

## Decisions

| Item | Judgment |
| --- | --- |
| Mathematical validity | **Supported internally. No fatal error or unresolved load-bearing proof gap found.** |
| Exact source conjecture | **Complete coverage**, using the cited complete finite facet enumeration as an external mathematical input. |
| Original question Q066 | **Restricted asymmetric family only.** This is not a resolution of the whole original Bell-polytope question. |
| Source separation | **Substantial overlap; difference supported relative to the checked explicit results.** The bound is a direct application of standard Helly to an already known compatibility interface. Priority remains unconfirmed. |
| Frozen v1 release | **Repair attribution/positioning in a new version before release.** No repair to the mathematical argument is requested. |
| Revised release recommendation | **Release as a mathematical working draft after the specific revisions below.** This is not clearance for a claim of confirmed first discovery, external expert acceptance, or resolution of all Q066. |
| External status | At the frozen-input cutoff the source record says unsubmitted. This reviewer created no submission, publication, or external-review receipt. |

The source audit is sufficiently specific to support a cautiously attributed draft. It does not require an impossible proof that no unlocated antecedent exists. A release process that explicitly requires *confirmed priority* still has an unmet condition; this report does not certify that condition.

## Identity, inputs, and scope

The frozen candidate is `run/manuscripts/five-setting-bell-locality/v1/paper.tex`, SHA-256 `7365097f6cffa612ffbbc84f16fe102bd9fc54449c5cd18b9bd28b0436e077a7`. I read the entire TeX, including the setting-lifting appendix; the matching PDF and reproducibility package were hash-frozen. This is a mathematical and source review, not a PDF-layout certification.

The controlling source problem is `run/blocks/R330-R334-20261118/R332/qualification-v4/SOURCE-QUESTION.json`. Its exact target is the full conditional-probability local polytope for every integer $N\ge5$, with scenario $(N,3,2,2)$: positivity and all relabelings/setting liftings of CHSH, $I_{3322}$, the three $I_{4322}$ classes, and $I_{5322}$. No unbiased-marginal, correlation-only, quantum-realizability, or restricted-hidden-variable assumption is permitted.

The candidate proves this target, after exchanging the parties, from its general finite-setting criterion and the source finite classification. The broader record `op_ebee7d5c442d81a4` / Q066 has not been replaced by this asymmetric statement. The source-conjecture intake chronology and research-round credit are administrative matters, not altered by this review.

I used the scoped workspace instructions, the bundled verification skill, the supplied originals and frozen candidate, public primary sources, and the independent controls below. I did **not** use author REVIEW, REPORT, or SOURCE-COMPARISON verdicts, another research project, or another conversation as scientific evidence. No author manuscript or ledger was changed.

## Independent reconstruction of the proof

### 1. Affine fiber dimension

For Alice's deterministic assignments $\Omega=\prod_x A_x$, consider the functions $1$ and $1\{\alpha_x=a\}$, one for each nonreference outcome. Evaluating a linear relation first at the all-reference assignment and then at assignments with just one coordinate changed shows that these functions are linearly independent. Thus the fixed-marginal equations have rank
\[
1+\sum_x(a_x-1).
\]
They are consistent because the product of the observed Alice marginals is a solution. The affine solution set therefore has dimension
\[
D=\prod_x a_x-1-\sum_x(a_x-1)=t-1.
\]

This calculation concerns the affine solution set, not the dimension of its nonnegative part. Zero or deterministic observed marginals can lower the latter dimension; they do not invalidate the upper bound used by Helly. In the three-binary case $D=8-1-3=4$, rather than seven. The fixed one-party marginals are essential to the improvement. The manuscript handles this correctly at lines 94–115.

### 2. Compatibility sets and finite-output gluing

For each Bob setting $y$, the feasible nonnegative $q_y(\alpha,b)$ have total mass one. Their projection onto $\lambda_\alpha=\sum_bq_y(\alpha,b)$ is consequently a compact convex set $C_y\subseteq E_p$. The same Alice marginals occur for every $y$, as required.

A local model can be refined to deterministic Alice assignments, producing a common $\lambda$ and the arrays $q_y$. Conversely, choose $\lambda$ in an intersection and set $r_y(b\mid\alpha)=q_y(\alpha,b)/\lambda_\alpha$ when $\lambda_\alpha>0$. If $\lambda_\alpha=0$, nonnegativity forces the entire corresponding $q_y$ row to vanish. Any normalized $r_y$ can then be assigned to that row. It contributes zero to all observed probabilities.

The resulting weights
\[
w(\alpha,(b_y)_{y\in S})=\lambda_\alpha\prod_{y\in S}r_y(b_y\mid\alpha)
\]
are nonnegative, sum to one, and have the required $q_y$ marginals. This constructs one model for all settings in $S$; no equality between independently chosen local models was assumed. Conditional independence is a permissible construction, not an assumption on the observed behavior. All products and sums are finite. A one-outcome Bob setting and unequal outcome counts cause no problem.

Arbitrary shared randomness is preserved: any stochastic hidden-variable model induces finite weights on the finite deterministic-assignment set by integrating the finite product of response probabilities. The proof does not impose a restrictive hidden-variable cardinality.

### 3. Helly quantifiers

The hypothesis supplies a possibly different witness $\lambda_S$ for each subfamily with at most $D+1=t$ members. Finite Helly is exactly the theorem that turns these nonempty small intersections into one common point for the whole **finite** family. No common witness for all small subsets is presupposed. When $|Y|<t$, the full family is itself among the hypotheses. When $D=0$, checking singleton sets suffices.

The manuscript's Radon argument gives the standard finite Helly induction. It requires neither full-dimensional $C_y$ nor interior feasibility. There is no unjustified infinite-family or finite-to-infinite limit passage.

### 4. Membership implies facet support

This step was challenged separately; merely verifying locality of points would not alone justify a list of facets without the polyhedral argument.

Work in the normalized no-signalling affine hull. The local polytope is full-dimensional there, since the constant, single-party indicators, and products of one indicator from each party are independent on deterministic assignments. Pull back finite facet descriptions of all the tested restricted local polytopes. Their intersection equals the full local polytope: every pairwise probability is constrained by a tested restriction, so nonnegativity is also recovered.

At a relative-interior point $z$ of a full-polytope facet $G$, at least one of these defining halfspaces is tight. Its equality face contains $G$, because a proper face containing $z\in\operatorname{relint}G$ must contain $G$. Since $G$ already has codimension one, their supporting hyperplanes coincide. The restriction map is onto the restricted affine hull (and sends the full local polytope onto the restricted local polytope), so a pulled-back genuine facet inequality is not identically tight on the full ambient space. Thus it is a facet normal supported on at most $t$ Bob settings, modulo the affine identities. This establishes the required facet statement, not just membership.

### 5. Complete classification and setting lifting

For three binary Alice settings, the previous steps give support at most five on Bob. For $N\ge5$, locality of every five-setting restriction already entails locality of smaller restrictions. The finite five-setting facet list therefore yields a complete H-description in every larger scenario.

The converse assertion that each listed class remains a facet also holds. In the appendix, the Alice assignments of saturating deterministic vertices must affinely span the entire Alice cube space. Otherwise the facet hyperplane would depend only on Alice, forcing at least one fixed Alice bit and hence $n+1$ independent constraints (that bit and all its cross terms). This contradicts codimension one for $n\ge1$. Adding a Bob bit gives saturating differences $(1,a)$ spanning all $s+1$ new coordinate directions. The lifted face therefore has precisely the required facet dimension. The full-dimensionality and rank argument in the appendix are valid.

This proof is analytic for arbitrary $N$. Its only unproved case-specific input is the **published complete finite facet list**. The paper openly identifies that dependency at lines 236–240. The source audit checked that the cited enumeration concerns the full probability polytope, not a correlator projection.

### 6. Sharpness and the rational control

The geometric sharpness argument is sound. At a relative-interior point of a genuine five-setting facet, all other facet inequalities are strict. Finitely many four-setting inequalities cannot have this supporting hyperplane. A sufficiently small outward perturbation therefore violates that facet while retaining all four-setting inequalities, including positivity.

The explicit control establishes this without needing the completeness of the five-setting list. I separately evaluated the eight Alice-bit cases of
\[
3-a_2-2a_3+\sum_y\min(0,v_y(a)).
\]
Every minimum is zero. The numbers of saturating Bob assignments are $8,4,4,4,4,4,4,8$, totaling 40. All 256 vertices satisfy the inequality. The exact finite-field rank lower bounds, together with the explicit nonzero normal, prove full affine dimension 23 and facet dimension 22. Each Bob column of its unique normal is nonzero, so it genuinely uses five settings.

The displayed rational table has all 60 probabilities at least $99/2000$ and violates the facet by $-11/5000$. Each of the five deletion models has 20 nonnegative normalized rational weights. I reconstructed **all four outcome probabilities** for every retained setting pair: 240 exact equalities, all satisfied. This is a valid no-signalling example; no quantum realization is asserted or required.

## Reproduction and independence

| Control | Result and actual scope |
| --- | --- |
| Author `reproduce.py` | Passed its manifest and exact example/gluing/mutation checks. A replay alone was not used as the proof review. |
| `independent_control.py` | Passed. No author verifier imported; separately transcribed manuscript coefficients, exact probability reconstruction, independent modular rank calculation, a deliberately damaged weight rejected. |
| Mixed-output/null-mass control | Passed with Alice output sizes $(2,3)$, Bob sizes $(1,2,3,4,2,3)$, four zero-mass Alice atoms, 864 joint atoms including zeros, and 90 exact joint-marginal equalities. Includes a deterministic Alice marginal. |
| `source_facet_control.py` | Passed. Six primary-source representatives independently transcribed; every representative valid and facet-defining on the 256 vertices; full relabeling orbits disjoint. |
| Source identity of the sharpness facet | Passed. The manuscript's $F$ is exactly a relabeling of the source $I_{5322}$, not merely assigned that name because it uses five settings. |

The six nontrivial orbit sizes are 240, 5,760, 11,520, 15,360, 23,040, and 15,360. They total 71,280, or 71,340 including 60 positivity facets. These calculations verify the supplied six orbits, their distinctness, and their facet ranks. They **do not** establish that no other orbit exists. A full independent facet enumeration, coverage proof, or solver certificate is not part of this review. Its absence is a declared external dependency, not a discovered gap in a paper that explicitly invokes the published finite result.

The exact $I_{5322}$ mapping is stored in `source-facet-control-results.json`. After exchanging the source parties, flip old Bob outcomes at settings 1 and 2 and reorder Bob settings as $(4,3,5,1,2)$; leave Alice unchanged. The resulting lower-bound normal is precisely the manuscript's normal.

Re-run from the workspace with:
```sh
python3 run/manuscripts/five-setting-bell-locality/v1/reproduce.py
python3 run/reviews/bell-five-settings/independent-20261119/independent_control.py
python3 run/reviews/bell-five-settings/independent-20261119/source_facet_control.py
```

## Required revisions and release boundaries

1. Cite **Pironio, “All CHSH polytopes” (2014), Lemma 5**, where the finite-output common-Alice-marginal interface and gluing argument already appear. Identify its Theorem 1 as the known two-binary-Alice special case. The present v1 cites only Pironio's distinct 2005 lifting paper.
2. Keep the contribution precise: applying standard finite Helly to the fixed-marginal compatibility fiber yields the stated setting bound, then the existing finite list settles the arbitrary-$N$ source conjecture. The interface, gluing mechanism, setting lifting, finite list, and the $I_{5322}$ inequality are not new here.
3. Pin the finite source to Jesus–Zambrini Cruzeiro §IV.B and Appendix B.2. For coefficients and the exact witness relabeling, add the accessible Jesus 2022 thesis, Table A.4. A claim that this package independently re-enumerates all finite facets would be inaccurate.
4. Update review status truthfully: this separate AI review is complete for the frozen v1 proof. External expert review and comprehensive priority confirmation have not thereby occurred. Preserve the narrower Q066 scope and the no-quantum-realization limitation.

These are attribution and presentation changes, not a request for a different theorem or proof. Once checked in a new version, I recommend release as a working draft with those boundaries. No further specific missing theorem lookup was identified as a mathematical blocker.

Remaining work is precisely: apply/check those revisions; obtain broader literature or expert feedback if claiming priority or seeking journal acceptance; independently certify the finite enumeration only if removing the reliance on the cited published result. These latter two activities are not prerequisites imposed here for a cautiously worded draft.

## Resource and action accounting

Input tokens: unknown. Output tokens: unknown. Reasoning tokens: unknown. Monetary cost: unknown. No reliable telemetry was available; no numerical estimate is substituted. No new subagent or separately billed job was launched. The reviewer only wrote within this review directory and performed read-only checks of author inputs. Publication authorization and any later release are the parent agent's responsibility.

