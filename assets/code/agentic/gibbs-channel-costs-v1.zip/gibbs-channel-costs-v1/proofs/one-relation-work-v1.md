# An evaluated general-channel class: one Kraus-product relation

24 November 2026. Same-root proof candidate, partial Q117 coverage. Exact
sharp work in the normal countable-bath model, beta>0. This is not a
claim for every channel. Its temperature-selection lemma is written in
full below rather than inferred from convexity at a single temperature.

Let Phi:A->B be covariant, choose independent definite-frequency Kraus
operators K_a, and let Omega(C)=sum_ab C_ab K_a* K_b. Assume the real
Hermitian kernel of Omega is one-dimensional, spanned by H=H*. Then H is
indefinite. Let

    l=-1/lambda_max(H)<0,   h=-1/lambda_min(H)>0,
    T_-=I+l H,             T_+=I+h H,
    p_-=h/(h-l),           p_+=-l/(h-l).

The two endpoint channels Phi_-,Phi_+ have coefficient matrices T_-,T_+
(with the conventional Choi transpose). They are CPTP-extreme, and
Phi=p_-Phi_-+p_+Phi_+. Covariance makes H block diagonal in Kraus frequency:
a continuous real one-dimensional representation of U(1) is trivial.
Let r_(j,omega) be the rank of T_j in the frequency-omega block, and put

    Z_j(u)=sum_omega r_(j,omega) exp(u omega),
    R_j(u)=Z_B(u) Z_j(u)/Z_A(u),  j in {-,+}.

The proposed exact value is

 W_0(Phi)=max{
    beta^(-1)log[p_- R_-(beta)+p_+ R_+(beta)],
    sup_(u>=beta) u^(-1)log min{R_-(u),R_+(u)} }.          (1)

At H_A=H_B=0 and equal dimensions this simplifies to

    W_0(Phi)=beta^(-1)log[p_- rank(T_-)+p_+ rank(T_+)].   (2)

Equation (2) is fully evaluated in finite matrix eigenvalues. Formula (1)
involves only a scalar optimization of two explicit finite exponential
sums; ancillary matrix dimensions no longer occur.

## 1. Every dilation reduces to scalar points on the face

For a finite Gibbs isometric dilation expand V=sum_a K_a tensor S_a. Its
Gram matrix satisfies (Omega tensor id)(G)=I_A tensor I_E, so

    G=I_r tensor I_E + H tensor X,   X=X*.

Because H has only zero-frequency entries, energy covariance implies
[X,H_E]=0. Diagonalize X and H_E together. In their common eigenbasis
(label z), the Gram matrix is the direct sum of I+x_z H. Thus all vectors
S_a|z> belonging to distinct z are mutually orthogonal, even if their
physical output energies coincide. For each z their nonzero ranks in
frequency omega are exactly rank((I+x_z H)_omega). Discarding unused final
environment space can only reduce every partition index.

The scalar x_z belongs to [l,h]. Its corresponding channel is the point
Phi_(x_z) on the line segment. At an interior point all Kraus-frequency
ranks are full. At endpoints some drop. Consequently its partition sum
Z_x(u) is at least the affine interpolation of Z_-(u),Z_+(u) giving x.

For a dilation of Phi the Gibbs average of x_z at beta is zero. Therefore
its beta index is at least p_- R_-(beta)+p_+ R_+(beta), with equality for
the direct sum of the two endpoint Stinespring dilations, given the exact
Gibbs weights p_-,p_+. At every other u, irrespective of the Gibbs weights,
its ratio is at least min{R_-(u),R_+(u)}. This proves the lower bound (1).
Endpoint extremality follows because any kernel relation on the restricted
endpoint support would extend to a multiple of H on the full support,
whereas H is nonzero on the discarded extremal eigenspace.

## 2. Support minimum via a thermal selector

Let

    s_*=sup_(u>=beta) log min(R_-(u),R_+(u))/u.

For every W>s_*, one can construct a finite Gibbs mixture of the endpoint
Stinespring dilations whose all-temperature index is less than W. Here is
a constructive approximation argument.

Each R_j(u) is a ratio of finite exponential sums, and its logarithmic
slope at infinity is its largest Kraus frequency plus the system-ground
correction. At least one endpoint, call it j0, has that slope < W. Choose
U so it satisfies R_j0(u)<exp(uW) with a fixed exponential margin for
u>=U. On the compact interval [beta,U+1], the open sets on which an endpoint
ratio is <exp(uW) cover the interval. Choose continuous nonnegative
partition weights subordinate to these open sets and glue them to the
constant choice j0 for u>=U+1. This gives a continuous selection with
strict slack on the compact interval and zero weight on the other endpoint
for all sufficiently large u.

Use t=exp(-a u), with any fixed a>0. A desired scalar selector on the
compact t interval can be uniformly approximated by ratios of polynomials
with nonnegative coefficients: write s=t/(1+t) and use Bernstein
polynomials of a continuous extension to 0<=s<=1. After division by
(1+t)^N the Bernstein terms are binomial(N,k)t^k/(1+t)^N.
For the endpoint that must disappear at t=0, require its numerator to
vanish to order K. This is obtained by approximating the continuous
function w(t)/t^K, extended by zero near t=0. Choose a K large enough to
suppress that endpoint's larger exponential slope. The selected endpoint
j0 is kept with a strictly positive constant coefficient.

The polynomial coefficients represent finite environment multiplicities.
They can be approximated, after a common large scaling, by nonnegative
integers, preserving their zero pattern and uniform relative accuracy.
The surviving constant coefficient prevents loss of control at t=0.
The resulting finite input environments have energies 0,a,2a,... and
integer degeneracies; append the endpoint's finite Stinespring environment
on the output side. Their partition ratio realizes the rational selector.
Uniform approximation on the compact interval and the chosen vanishing
order at zero preserve the strict inequality for all u>=beta.

Thus the support minimum s(S) in `general-work-face-separation-v1.md`
equals s_*. That theorem combines this with the evaluated beta index in
Section 1 and proves (1). Exact target weights at beta are supplied by
that theorem's exact residual-channel mixture, so rounding selector
multiplicities never approximates the target channel.

## 3. Remaining review tasks

Check the selector's positive constant and vanishing-order construction
quantitatively; reproduce one nonextreme GP example by exact arithmetic;
compare the result with channel-factorization and one-shot work sources.
The scalar optimization in (1) and formulas alone are not a proof of a
universal optimum for supports with two or more independent relations.
