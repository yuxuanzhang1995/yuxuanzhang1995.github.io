# Version 2.1 — loss-model corollaries and attribution correction

3 November 2026. Author: Yuxuan Zhang; no affiliation listed.

The two supplied loss extensions are integrated in Section 6. Exchangeable loss replaces the binomial survival moments by mu_l; efficient sampling requires geometric decay and an efficiently supplied count law. The fixed-count corollary directly matches Go–Jeong's model at every m >= n. Independent nonuniform input loss is handled by a single random prefilter and one uniform sampler call. A convexity argument bounds the weighted unprojected reduced purity by eta_max^l, removing l+1. Matrix precision and bounded random bits are specified, including the n+1-outcome exchangeable count draw.

The source search found a material omission in version 2.0: Lim, arXiv:2611.01434v1, directly covers the main Fock and equal-squeezing Gaussian claims, includes finite-bit analysis, and explicitly gives the same nonuniform thinning reduction. Its analytic framework also overlaps the Haar-reduction and collision-aware estimates. The abstract, introduction, website lead, release metadata and source comparison now state this. The earlier “no equivalent theorem found” assessment is withdrawn. The signed-prefix implementation is a presentation difference from Lim's bounded rejection, not a proved improvement in complexity or a priority claim. The exchangeable and sharper-purity formulations are retained as explicit consequences.

The arXiv date is 1 November. The earlier 21 October Zenodo date is reported by arXiv and was not independently verified. We do not adjudicate worldwide priority. The earlier website assets and source records are preserved as historical versions, with the correction linked from the current page.

The ninth finite suite adds 6,957 exact assertions over 34 transmission profiles, including zero and very small values, reductions through degree six, fixed-count inequalities through n=20, and three detected mutation families. The existing mathematical checker functions and recorded Haar datasets are retained. The fresh package replay runs all nine suites and reaggregates the recorded Gaussian data; it does not count old samples as new experiments.

The analytic integration and source comparison were performed in the same AI-assisted author workflow. Independent expert review is still pending. Finite checks do not prove an asymptotic theorem, establish originality or benchmark the polynomial-time sampler. No research round, new catalog resolution, catalog comment or archival deposit is credited or performed by this release.
