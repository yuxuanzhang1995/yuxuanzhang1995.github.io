"""Fresh exhaustive audit, reusing the independent exact matrix backend.

Checks all 81 Pauli classes at every recursive level. Global phases are
removed exactly in Z[omega]. No floating arithmetic or native-model calls.
This strengthens enumeration coverage; it is not a third independent backend.
"""
from pathlib import Path
from contextlib import redirect_stdout
import hashlib
import io
import json
import runpy
import time

backend = Path(__file__).with_name('independent-check.py')
start = time.monotonic()
captured = io.StringIO()
with redirect_stdout(captured):
    env = runpy.run_path(str(backend))
conjugate, canonical = env['conjugate'], env['canonical']
paulis, labels, pauli_keys = env['paulis'], env['labels'], env['pauli_keys']
cache = {}
checks = {2: 0, 3: 0, 4: 0}


def belongs(matrix, level):
    matrix_key = canonical(matrix)
    if level == 1:
        return matrix_key in pauli_keys
    cache_key = level, matrix_key
    if cache_key not in cache:
        answer = True
        for pauli in paulis:
            checks[level] += 1
            if not belongs(conjugate(matrix, pauli), level - 1):
                answer = False
                break
        cache[cache_key] = answer
    return cache[cache_key]


assert belongs(env['identity'], 2)
assert belongs(env['D'], 3) and belongs(env['S'], 3)
U = env['U']
assert belongs(U, 4) and not belongs(U, 3)
preserved = [list(label) for label, P in zip(labels, paulis)
             if belongs(conjugate(U, P), 1)]
assert preserved == [[0, 0, c, 0] for c in range(3)]
assert len(preserved) < 9

# An explicit failure witness for the stronger, unnecessary C3 claim.
failure = None
for first_label, P in zip(labels, paulis):
    V = conjugate(U, P)
    for second_label, Q in zip(labels, paulis):
        if not belongs(conjugate(V, Q), 1):
            failure = [list(first_label), list(second_label)]
            break
    if failure is not None:
        break
assert failure is not None
X1 = paulis[labels.index((1, 0, 0, 0))]
X2 = paulis[labels.index((0, 1, 0, 0))]
double = conjugate(conjugate(U, X1), X2)
explicit = env['dense'](lambda x, y: (x, y + 1, 4*x*x - 6*x + 2*y + 3))
assert canonical(double) == canonical(explicit)

output = {'status': 'passed', 'arithmetic': 'exact Z[omega] 9x9 matrices',
          'backend_sha256': hashlib.sha256(backend.read_bytes()).hexdigest(),
          'candidate_C4': True, 'candidate_C3': False,
          'all_pauli_classes_checked_at_each_successful_recursive_node': 81,
          'recursive_edge_checks_by_level': checks, 'cached_nodes': len(cache),
          'pauli_preserving_labels': preserved, 'semi_clifford_necessary_minimum': 9,
          'semi_clifford': False, 'explicit_non_C3_double_conjugation_labels': failure,
          'explicit_non_C3_phase_formula': '4*x^2 - 6*x + 2*y + 3 (mod p)',
          'higher_prime_backend_checks': json.loads(captured.getvalue())['direct_conjugation_checks'],
          'seconds': time.monotonic() - start,
          'scope': 'Complete p=3 counterexample; arbitrary-prime extension requires the algebraic proof.'}
Path(__file__).with_name('strict-check-result.json').write_text(json.dumps(output, indent=2) + '\n')
Path(__file__).with_name('independent-backend-rerun.json').write_text(captured.getvalue())
print(json.dumps(output, indent=2))
