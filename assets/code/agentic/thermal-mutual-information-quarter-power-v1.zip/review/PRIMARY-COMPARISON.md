# Primary-source comparison

Accessed 13 November 2026. These are targeted theorem/interface comparisons,
not an exhaustive priority search. Stable arXiv versions identify the imported
statements. Where available, local source hashes are listed in `SOURCES.json`.
An open catalogue label is not evidence that no proof exists elsewhere.

| Source and inspected location | Relation to this review |
| --- | --- |
| [Kuwahara--Alhambra--Anshu, 2007.11174v2](https://arxiv.org/html/2007.11174v2), Section III.2, equations (21)--(22) | The thermal mutual-information construction has the 1/5 exponent with logarithmic loss. It supplies the baseline for P13, not the candidate's 1/4 full-Gibbs statement. |
| [Gottesman--Hastings, 0901.1108v2](https://arxiv.org/html/0901.1108v2), Sections 2--4, especially boundary equation (7) | Two rings, folding and the one-hole ground-state architecture are inherited. Its 1/4 gap-entanglement exponent is not a 1/4 inverse-temperature exponent. The strict finite-density boundary in the candidate differs from (7). |
| [Caputo--Liggett--Richthammer, 0906.1238v4](https://arxiv.org/html/0906.1238v4), Theorem 1.1 and Section 4.1.1 | The interchange/exclusion gap supplies the path-gap lower bound at every nontrivial occupation number. This is an imported theorem, with unit edge-rate normalization. |
| [Bakshi--Choi--Pilatowsky-Cameo, 2602.13386v2](https://arxiv.org/html/2602.13386v2), updated 2 November 2026 | The checked results concern exact Gibbs-state mixtures/upper representation bounds. No matching thermal lower-bound construction was identified. This comparison includes v2, rather than relying only on the v1 input citation. |
| [Hirche, 2103.02404v2](https://arxiv.org/html/2103.02404v2), Definition 4.4, Sections 5.3--5.5 and Appendix A | Supplies the operational classes, side-wire allowance, parallel rate and a conditional smoothed-chain framework. Q074's role is chiefly a synthesis with a CP-TNI replacement and its flag/limit interface. |
| [Gao--Ji--Liu, 2609.27196v1](https://arxiv.org/html/2609.27196v1), Corollaries 5.2--5.3 and Lemmas 4.4--4.5 | Supplies the exponentially accurate, dominated CP-TNI channel approximation and the tensor amplification algebra. It does not state the physical two-comb interleaving theorem. The ordinary channel approximation is not a local discovery. |
| [Fang--Fawzi--Renner--Sutter, 1909.05826v1](https://arxiv.org/html/1909.05826), Lemma 3.4 and Corollary 3.7 | The finite-state AEP has the explicit spectral constant used before the tester supremum. The amortized ordinary-channel divergence equals its regularized version. The saved HTML identifies v1. |
| [Nahar et al., 2403.11851v3](https://arxiv.org/html/2403.11851v3), Theorem 1 and Appendix A, Lemma 10 | Pure fixed-marginal postselection and its Schur normalization are inherited. The proposed new interface is composition through causal stages with canonical, covariant memories. |
| [Gutoski--Watrous, quant-ph/0611234v2](https://arxiv.org/html/quant-ph/0611234v2), Theorems 6 and 9 | Supplies the recursive trace characterization/realization of finite strategies and positive strategy domination duality. These justify the causal realization and gauge; they do not themselves establish the claimed asymptotic rate equality. |
| [Costa--Barrett--Shrapnel, 2403.10316v3](https://arxiv.org/html/2403.10316v3), theorem assumptions and Section 8 | The representation assumes infinite exchangeability/extendibility. Q114 needs finite-n domination without extension, not equality or a trace-norm approximation to the whole n-block object. Their result does not directly supply that statement. |
| [Zhu--Wang, 2609.30268v1](https://arxiv.org/html/2609.30268v1), Lemma 4.1 and Appendix A | Positive slack, exponential approximation and polynomial postselection already appear for ordinary memoryless channels and process-matrix testers. Q114 must be positioned as a causal higher-order extension, if new, rather than as invention of the overall framework. |
| [Ye--Bergh--Datta, 2609.40343v1](https://arxiv.org/html/2609.40343), Theorems 2--3 and Sections 5.1--5.3 | The standard result concerns reduced ordinary channels and has an error of order k/sqrt(n); the exponential statement uses no-signalling and almost-iid atoms. It does not directly give all-n polynomial domination by iid physical two-combs. Treating a comb merely as an ordinary channel would discard the causal constraints needed here. |
| [Gao--Ji--Liu, 2609.30762](https://arxiv.org/abs/2609.30762), stated generalized-family assumptions | The inspected abstract/statement requires an alternative family containing a faithful replacer. This does not directly identify the fixed-single-alternative superchannel theorem. This was a scope check, not a full proof review of that paper. |

The live [Q074 catalogue entry](https://qiqc-op.com/problem/op_a4600b38b94042a8/)
and [Q114 catalogue entry](https://qiqc-op.com/problem/op_02bb8f8228649ac3/)
were checked against the pinned originals. Their status labels are separate
from mathematical validity and priority. The
[website index](https://yuxuanzhang1995.github.io/agentic-research/) was checked
for duplicate published entries; no matching Q048/Q074/Q114 result was
identified there. No claim is made about unindexed manuscripts or private work.

The supported separation from the inspected sources is specific: a full
thermal 1/4 lower bound for Q048, and causal two-stage postselection plus its
general-interleaving use for Q114. A complete source search for equivalent
formulations and concurrent work remains outstanding. Q074 has especially
strong external-theorem dependence and is subsumed by Q114; neither the
source theorem nor the overlapping coverage is credited again.
