"""Exact local ordering, Hessian and competing-partition certificate."""
from qutrit_exact import *
def interval(a,b):
    a,b=Fraction(a),Fraction(b);m=(a+b)/2;r=(b-a)/2
    return arb(m.numerator)/m.denominator+arb(0,str(float(r)*1.0000001))
def run():
    assert PART[155]==[(0,3,6),(1,4,7),(2,5,8)]
    box=(Fraction(7,5),Fraction(3,2),Fraction(39,20),Fraction(41,20))
    a,b=interval(box[0],box[1]),interval(box[2],box[3])
    input_order=[0,3,1,6,4,2,7,5,8]
    exponents=[i*a+j*b for i in range(3) for j in range(3)]
    assert all(exponents[j]-exponents[i]>0 for i,j in zip(input_order,input_order[1:]))
    # Interval subtraction may obscure repeated dependency, so order costs by
    # direct affine differences in b rather than separately evaluated balls.
    output_order=[0,1,3,2,4,6,5,7,8]
    lam=[LAM0,arb(3),arb(0)]
    for i,j in zip(output_order,output_order[1:]):
        assert (j%3-i%3)*b-lam[j//3]+lam[i//3]>0
    hess=[]
    for i in range(20):
      for j in range(20):
        aa=interval(box[0]+i*(box[1]-box[0])/20,box[0]+(i+1)*(box[1]-box[0])/20)
        bb=interval(box[2]+j*(box[3]-box[2])/20,box[2]+(j+1)*(box[3]-box[2])/20)
        _,_,ea,_,dda=moments(aa);_,_,eb,_,ddb=moments(bb)
        eaa=dda[1]+2*dda[2];ebb=ddb[1]+2*ddb[2]
        h11=-2*ea+(bb-aa)*eaa;h12=ea
        h22=-2*eb-bb*ebb-LAM0*ddb[0]-3*ddb[1]
        det=h11*h22-h12*h12
        assert h11>0 and det>0,(i,j,str(det))
        hess.append((float(h11.lower()),float(det.lower())))
    todo=[box];passed=[];cache={}
    def point(x,y):
        if (x,y) not in cache:cache[x,y]=value(x,y,exclude=155)
        return cache[x,y]
    while todo:
        lo,hi,bo,bh=todo.pop()
        lower=arb(min(point(x,y).lower() for x in (lo,hi) for y in (bo,bh)))
        h1=arb((hi-lo).numerator)/(hi-lo).denominator;h2=arb((bh-bo).numerator)/(bh-bo).denominator
        lower-=(28*h1*h1+22*h2*h2)/8
        if lower>0:passed.append(float(lower.lower()));continue
        assert hi-lo>Fraction(1,100000) or bh-bo>Fraction(1,100000)
        if hi-lo>=bh-bo:
            m=(lo+hi)/2;todo.extend([(lo,m,bo,bh),(m,hi,bo,bh)])
        else:
            m=(bo+bh)/2;todo.extend([(lo,hi,bo,m),(lo,hi,m,bh)])
    work=Q+e2-e0
    out={'status':'pass','ordering_cell':[[str(box[0]),str(box[1])],[str(box[2]),str(box[3])]],'hessian_cells':400,'h11_lower':min(x[0] for x in hess),'det_lower':min(x[1] for x in hess),'other_partition_leaves':len(passed),'other_partition_margin':min(passed),'root_interval':str(A),'net_and_gross_swap_work':str(work),'local_statement':'Swap support is strictly convex on this cell, stationary at exact (a*,2), and every other partition has strictly larger support.'}
    return out

