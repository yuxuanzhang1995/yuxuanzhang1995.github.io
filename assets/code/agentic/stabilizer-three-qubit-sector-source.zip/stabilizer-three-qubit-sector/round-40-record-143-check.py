from fractions import Fraction as Q
from math import comb

# Exact rational certificate for the scalar contradiction in the proof.
f = [Q(8723,1024), Q(-10654,1024), Q(767,1024),
     Q(2352,1024), Q(-420,1024)]
S = [Q(3615,256), Q(-3780,256), Q(450,256),
     Q(588,256), Q(-105,256)]
M = [Q(5737,6144), Q(-4466,6144), Q(1033,6144), Q(0), Q(0)]
assert all(f[i] == S[i]-6*M[i] for i in range(5))
print('F = S - 6M: exact identity verified')

lo, hi = Q(73,50), Q(9,4)
h = hi-lo
# Power coefficients of F(lo+h*x), then degree-four Bernstein coefficients.
p = [sum(f[k]*comb(k,j)*lo**(k-j)*h**j for k in range(j,5))
     for j in range(5)]
b = [sum(p[j]*Q(comb(i,j),comb(4,j)) for j in range(i+1))
     for i in range(5)]
expected = [Q(33512387,160000000), Q(122637237,256000000),
            Q(81552893,61440000), Q(1123221,409600), Q(298307,65536)]
assert b == expected
for i,v in enumerate(b):
    assert v > 0
    print('Bernstein[%d] = %s > 0' % (i,v))

checks = [
    ('lower endpoint padding', Q(15,7)-lo**2, Q(197,17500)),
    ('upper endpoint padding', hi**2-5, Q(1,16)),
    ('sqrt7 lower-bound square gap', 7-Q(21,8)**2, Q(7,64)),
    ('upper bound numerator at 9/4', 77-29*hi, Q(47,4)),
    ('negative-sector contradiction gap', 15-63*Q(11,24)**2, Q(113,64))
]
for name,value,target in checks:
    assert value == target and value > 0
    print('%s = %s > 0' % (name,value))

import sympy as sp
s=sp.symbols('s', real=True)
S=(-105*s**4+588*s**3+450*s**2-3780*s+3615)/256
Mm=(137+30*s-39*s**2)/256
Mp=(641-690*s+177*s**2)/256
fm=(1-s)*(105*s**3-483*s**2-1167*s+2793)
fp=(s-1)*(-105*s**3+483*s**2-129*s+231)
assert sp.expand(256*(S-6*Mm)-fm)==0
assert sp.expand(256*(S-6*Mp)-fp)==0
print('Both mixed-sector quartic factorizations: exact identities verified')
for name,v in [('sqrt21 square gap',Q(21)-Q(9,2)**2),('left cubic interval bound',Q(10815,8)),('middle cubic interval bound',Q(1143)),('right cubic interval bound',Q(1329,8))]:
 assert v>0
 print('%s = %s > 0' %(name,v))
assert Mm.subs(s,-sp.Rational(3,2))>0 and Mm.subs(s,1)>0
assert Mp.subs(s,sp.Rational(3,2))==sp.Rational(17,1024)
print('Mixed-sector D upper bounds remain positive; Mplus(3/2)=17/1024>0')
assert S.subs(s,1)==3 and Mm.subs(s,1)==sp.Rational(1,2)
print('Equality: sumL^2=3; sumD=6; D<=1/2; exactly12 positiveD')
X=sp.Matrix([[0,1],[1,0]]);Y=sp.Matrix([[0,-sp.I],[sp.I,0]]);Z=sp.diag(1,-1)
A=(sp.eye(2)+X+Y+Z)/2
assert sp.trace(A)==1 and sp.simplify(sp.trace(A*A))==2
for T in [X,Y,Z]:
 for sign in [-1,1]:assert sp.simplify(sp.trace(A*(sp.eye(2)+sign*T)/2))in[0,1]
print('Sharp one-qubit factor: trace=1, purity=2, six stabilizer expectations in{0,1}')
