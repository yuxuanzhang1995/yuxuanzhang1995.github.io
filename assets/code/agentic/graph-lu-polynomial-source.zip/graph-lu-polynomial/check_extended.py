"""Targeted exact diagnostics for the graph-LU proof candidate.

Requires SymPy. Run without -O. This is not a complete graph-LU implementation.
"""
import itertools
import json
import math
from pathlib import Path

from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form


def lattice_basis(rows, m, q):
    if m == 0:
        return []
    generators = rows + [[q * int(i == j) for j in range(m)] for i in range(m)]
    return [[int(x) for x in row] for row in
            hermite_normal_form(Matrix(generators).T).T.tolist()]


def incidence_rows(a, m, r, seeds=False):
    q = 1 << r
    sizes = (2, 3) if seeds else range(2, min(r + 1, len(a)) + 1)
    rows = []
    for k in sizes:
        for subset in itertools.combinations(range(len(a)), k):
            weight = 2 if seeds else 1 << (k - 2 + int(k == 2))
            rows.append([(weight * math.prod(a[j][i] for j in subset)) % q
                         for i in range(m)])
    return rows


def compressed(a, m, r):
    q = 1 << r
    basis = lattice_basis(incidence_rows(a, m, r, seeds=True), m, q)
    changes = 0
    while True:
        rows = basis + [[2 * av[i] * row[i] for i in range(m)]
                        for av in a for row in basis]
        enlarged = lattice_basis(rows, m, q)
        assert all(0 <= x <= q for row in enlarged for x in row)
        if enlarged == basis:
            return basis, changes
        basis = enlarged
        changes += 1
        assert changes <= r * m


def kernel_generators(rows, m, q):
    """Exact row/column reduction over Z/q; q is a power of two."""
    a = [[x % q for x in row] for row in rows]
    v = [[int(i == j) for j in range(m)] for i in range(m)]
    pivots = []
    for k in range(min(len(a), m)):
        candidates = [(a[i][j] & -a[i][j], i, j)
                      for i in range(k, len(a)) for j in range(k, m) if a[i][j]]
        if not candidates:
            break
        pivot, i, j = min(candidates)
        a[k], a[i] = a[i], a[k]
        for row in a:
            row[k], row[j] = row[j], row[k]
        for row in v:
            row[k], row[j] = row[j], row[k]
        unit = pow(a[k][k] // pivot, -1, q)
        a[k] = [(x * unit) % q for x in a[k]]
        for i in range(k + 1, len(a)):
            assert a[i][k] % pivot == 0
            c = a[i][k] // pivot
            a[i] = [(x - c * y) % q for x, y in zip(a[i], a[k])]
        for j in range(k + 1, m):
            assert a[k][j] % pivot == 0
            c = a[k][j] // pivot
            for row in a:
                row[j] = (row[j] - c * row[k]) % q
            for row in v:
                row[j] = (row[j] - c * row[k]) % q
        pivots.append(pivot)
    generators = []
    for j in range(m):
        scale = q // pivots[j] if j < len(pivots) else 1
        g = tuple(scale * v[i][j] % q for i in range(m))
        if any(g):
            generators.append(g)
    return generators


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def modular_span(generators, m, q):
    out = {(0,) * m}
    for g in generators:
        out = {tuple((x + c * y) % q for x, y in zip(v, g))
               for v in out for c in range(q)}
    return out


def binary_span(vectors):
    out = {0}
    for v in vectors:
        out |= {x ^ v for x in list(out)}
    return out


def image(a, s, r):
    q, h = 1 << r, 1 << (r - 1)
    out = 0
    for bit, (av, aw) in enumerate(itertools.combinations(a, 2)):
        residue = sum(x * y * z for x, y, z in zip(av, aw, s)) % q
        assert residue in (0, h)
        out |= (residue // h) << bit
    return out


closure = []
for t in range(3, 7):
    columns = list(itertools.product((0, 1), repeat=t))
    a = [[column[j] for column in columns] for j in range(t)]
    m = len(columns)
    for r in (1, 2, 3, 4, 5, 7):
        q = 1 << r
        b, steps = compressed(a, m, r)
        direct = lattice_basis(incidence_rows(a, m, r), m, q)
        initial = lattice_basis(incidence_rows(a, m, r, seeds=True), m, q)
        assert b == direct
        expected = max(0, min(r - 2, t - 3))
        assert steps == expected
        assert (initial != direct) == (expected > 0)
        closure.append(dict(outside_vertices=t, support_size=m, level=r,
                            strict_enlargements=steps,
                            seed_only_mutation_detected=initial != direct))

kernel_cases = 0
nonfree_kernels = 0
for entries in itertools.product(range(4), repeat=4):
    rows = [list(entries[:2]), list(entries[2:])]
    generators = kernel_generators(rows, 2, 4)
    expected = {v for v in itertools.product(range(4), repeat=2)
                if all(dot(row, v) % 4 == 0 for row in rows)}
    assert modular_span(generators, 2, 4) == expected
    if len(expected) in (2, 8):
        nonfree_kernels += 1
    kernel_cases += 1

image_cases = 0
enumerated_vectors = 0
zero_images = 0
for ny, m in ((2, 3), (3, 2)):
    for entries in itertools.product((0, 1), repeat=ny * m):
        a = [list(entries[j*m:(j+1)*m]) for j in range(ny)]
        for r in (1, 2, 3):
            q = 1 << r
            b, _ = compressed(a, m, r)
            direct = incidence_rows(a, m, r)
            generators = kernel_generators(b, m, q)
            generated = binary_span([image(a, g, r) for g in generators])
            expected = set()
            for s in itertools.product(range(q), repeat=m):
                explicit = all(dot(row, s) % q == 0 for row in direct)
                assert explicit == all(dot(row, s) % q == 0 for row in b)
                if explicit:
                    expected.add(image(a, s, r))
                enumerated_vectors += 1
            assert generated == expected
            zero_images += expected == {0}
            image_cases += 1

boundaries = []
for a, m, r, name in [([], 0, 1, 'empty graph'), ([[], []], 0, 4, 'empty support'),
                       ([], 3, 3, 'empty outside set'),
                       ([[0, 0, 0]], 3, 1, 'isolated vertices at level one'),
                       ([[1, 0, 0], [0, 1, 0]], 3, 3, 'zero toggle image')]:
    q = 1 << r
    b, _ = compressed(a, m, r)
    generators = kernel_generators(b, m, q)
    expected = {s for s in itertools.product(range(q), repeat=m)
                if all(dot(row, s) % q == 0 for row in incidence_rows(a, m, r))}
    assert modular_span(generators, m, q) == expected
    assert binary_span([image(a, g, r) for g in generators]) == {image(a, s, r) for s in expected}
    boundaries.append(name)

result = dict(status='PASS', arithmetic='exact integer, lattice and modular operations',
              closure_cases=closure,
              nontrivial_closure_cases=sum(x['strict_enlargements'] > 0 for x in closure),
              max_strict_enlargements=max(x['strict_enlargements'] for x in closure),
              arbitrary_mod4_kernel_cases=kernel_cases,
              certified_nonfree_kernel_cases=nonfree_kernels,
              exhaustive_incidence_systems=image_cases,
              multiplicity_vectors_enumerated=enumerated_vectors,
              zero_image_systems=zero_images, boundary_cases=boundaries,
              scope='Targeted algebraic diagnostics, not an end-to-end LU implementation or a proof of the asymptotic theorem.')
Path(__file__).with_name('extended-results.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'closure_cases'}, indent=2))
