import numpy as np
from scipy.linalg import expm
from itertools import product
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]);ps=[]
for inds in product(range(4),repeat=3):
 P=np.array([[1]])
 for j in inds:P=np.kron(P,[I,X,Y,Z][j])
 ps.append(P)
H0=.11*ps[1]+.13*ps[6]-.17*ps[19]+.09*ps[47]
D=.2*ps[2]-.23*ps[13]+.19*ps[32]+.16*ps[47]
D/=np.linalg.norm(D,2)
v,V=np.linalg.eigh(H0);gaps=v[:,None]-v[None,:];times=[2,2.25]
def F(t):
 f=np.empty_like(gaps,dtype=complex);nz=abs(gaps)>1e-12;f[nz]=np.expm1(1j*gaps[nz]*t)/(1j*gaps[nz]);f[~nz]=t;return f
fs=[F(t)for t in times];G=sum(abs(f)**2 for f in fs)/2;rs=[f.conj()/G for f in fs]
assert G.min()>=1/(16*np.pi**2)
def fun(coeff,M):return V@(coeff*(V.conj().T@M@V))@V.conj().T
assert np.linalg.norm(sum(fun(rs[j]*fs[j],D)for j in range(2))/2-D,2)<1e-12
S=1024.;checks=0
for eta,r in [(1/512,1),(1/1024,2),(1/2048,4)]:
 H=H0+eta*D;assert np.linalg.norm(H,2)<1
 estimates=[];amps=[]
 for j,t in enumerate(times):
  W=expm(1j*H0*t)@expm(-1j*H*t);Wr=np.linalg.matrix_power(W,r)
  remainder=Wr-np.eye(8)+1j*r*fun(fs[j],eta*D)
  assert np.linalg.norm(remainder,2)<=r*r*eta*eta*t*t/2+1e-12
  y=fun(rs[j],Wr)/S;k=times[j]/(sum(q*q for q in times)/2)/S
  ai=np.trace(y)/8; ap=np.array([np.trace(P@y)/8 for P in ps[1:]])
  estimates.append(-S*(2*(ai.conjugate()*ap).imag)/(2*r*k));amps.append(ap)
 coeff=np.array([(np.trace(P@(eta*D))/8).real for P in ps[1:]])
 estimate=sum(estimates)/2
 # A conservative finite check, not the claimed uniform analytical bound.
 assert np.max(abs(estimate-coeff))<=100*r*eta*eta
 linear=-1j*r*coeff/S
 assert np.max(abs((amps[0]+amps[1])/2-linear))<=100*r*r*eta*eta/S
 checks+=len(coeff)
print('Exact-superoperator numerical control: two-time inverse identity PASS; error<1e-12.')
print('Dyson/power remainder: all6 cases <=r^2 eta^2 t^2/2 (1e-12 numerical allowance).')
print('Residual score and averaged amplitude:189 coefficient controls PASS.')
print('No scalable filter synthesis or full theorem is certified by this finite test.')
