# What constraints can a Gibbs-preserving channel encode?

Let \(R\) be the real Laurent ring in \(d\ge1\) independent energy labels. Let \(D_j(C)=\sum_{\alpha}x^\alpha D_{j,\alpha}(C)\) be any finite list of linear equations on Hermitian \(s\times s\) matrix polynomials, with real Hermitian-coordinate functionals \(D_{j,\alpha}\). Supply \(T>0\) satisfying \(\sum_\alpha D_{j,\alpha}(T)=0\). Ask whether there is a finite \(C\) with PSD coefficients, \(D_j(C)=0\) and \(C(1)=T\).

**Reduction.** This problem can be encoded exactly in the finite-coherence existence problem for a Gibbs-preserving channel. Conversely the finite-sector equations of an arbitrary channel are a problem of the stated algebraic type. The conversions are effective with algebraic sector data and a supplied integer lattice presentation. In the forward direction logs of distinct primes may be chosen as the energy generators and give rational Boltzmann weights at inverse temperature one.

## Encoding

Choose a code of dimension \(n\) with \(n^2-1\) at least the number of equations. Choose linearly independent traceless Hermitian \(Z_j\) on the code. Include in \(E\) the finitely many exponents, zero and all coordinate unit vectors. Define
\[
 \Omega_\alpha(C)=\operatorname{Tr}(C) I_n+e\sum_j D_{j,\alpha}(C)Z_j,\quad
 r(x)=\sum_{\alpha\in E}x^\alpha .
\]
Extend complex-linearly. Choose positive rational \(e\) so small that the Choi perturbation has norm less than one at every exponent, for example using Frobenius norms. The unperturbed Choi matrix is the identity, so every coefficient map is strictly completely positive. Thus \(L_x(C)=\sum_\alpha x^\alpha\Omega_\alpha(C)\) is scalar precisely when all \(D_j(C)=0\). Its scalar part is \(r(x)\operatorname{Tr}C\).

Factor \(\Omega_\alpha(C)=\sum_l V_{\alpha l}^* C V_{\alpha l}\). Assign output basis vector \((\alpha,l)\) energy \(\omega\cdot\alpha\). The \(sn|E|\)-dimensional output suffices. Put \((K_a)_{(\alpha,l),i}=(V_{\alpha l})_{ai}\). Then \(L_x(C)=\sum_{ab}C_{ab}K_a^* B(x)K_b\). Strict Choi positivity means that at each exponent the vectorized \(V_{\alpha l}\) span the full \(s\)-by-\(n\) matrix space. Consequently the \(K_a\) are independent. With \(T'=T/(|E|\operatorname{Tr}T)\), \(L_1(T')=I_n\). Mixing the independent \(K_a\) by a square root \(S^*S=T'\) gives a CPTP code channel \(\Phi\) with faithful Gram coordinates.

Give all code levels the same energy \(L=\omega\cdot\ell\). For \(C'=C/(|E|\operatorname{Tr}T)\) the polynomial \(p=x^{-\ell}r\operatorname{Tr} C'\) has nonnegative coefficients, \(p(1)=1\), and \(L_x(C')=p x^\ell I_n\). This is the finite-sector identity. Factoring each PSD coefficient gives Gram vectors for environment states at the corresponding energy. In each total-energy sector, the identity makes the map from the code a scaled isometry with that sector's program weight. The sum of environment Grams is \(T'\). This yields the channel on a pure finite clock with distribution \(p\). The finite sharp-blank completion of F05 implements the covariant processor thermally with zero extra QFI.

Conversely a finite, possibly mixed resource can be purified on a finite space and its purifier discarded. A thermal bath and its final trace give a covariant processor on the finite inputs and output. The finite-sector necessity gives positive environment Grams in each energy, with total value \(T'\). For labels in several cosets of the system energy group, shift each coset by its own representative and add its sector equations. This produces one finite Laurent witness and allows arbitrary original spectra. Rescale to \(T\).

## Gibbs completion

Add one flag at energy zero. Choose \(L\) sufficiently large in the same energy group that the Gibbs weight \(a=e^{-L}/(1+n e^{-L})\) of each code state satisfies \(na<\lambda_{\min}(\gamma_B)\). Since \(\Phi(I_n)\le nI\), the state \(\sigma=(\gamma_B-a\Phi(I_n))/(1-na)\) is strictly positive. The full channel discards flag coherences, applies \(\Phi\) on the code and prepares \(\sigma\) on the flag. It is CPTP and maps \(\gamma_A\) to \(\gamma_B\). Restricting a finite implementation to the code gives one for \(\Phi\). Conversely use the finite code resource and one copy of \(\sigma\), condition the covariant processor on the energy-commuting flag, and apply the same finite blank completion. The extra state has finite QFI. This proves the equivalence for finite coherence existence. Optimum values and the cost of a sharp work battery are outside the reduction.

## Reverse encoding and algorithmic consequence

The sector criterion for arbitrary independent Kraus coordinates is \(L_x(C)=p A(x)\), \(C(1)=T>0\), \(p(1)=1\). Place \(p,C\) on the diagonal of one \((s+1)\)-by-\((s+1)\) matrix. Impose zero off-block entries and all real Hermitian components of the sector identity. The required value is \(\operatorname{diag}(1,T)>0\). Coefficient positivity gives precisely the two required positivity conditions. This proves the reverse reduction.

A decision procedure could return zero on a negative instance and enumerate boxes until finding a witness on a positive instance, yielding a total computable cutoff. Conversely such a cutoff would decide the question by finite real quantifier elimination. No general decision procedure follows from this equivalence. F07 supplied one physical pencil. The new claim is the arbitrary list of constraints and the converse. It concerns kernels of polynomial linear maps with prescribed positive evaluation, not arbitrary matrix semigroups or every parametrized submodule. No undecidability transfer is asserted.
