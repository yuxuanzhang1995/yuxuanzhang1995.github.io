# Quantitative scalar compression and an explicit approximation iteration

Q119 extension; 16 November 2026. Candidate v1, pending the recorded review.
This extends the inherited variational argument at its existing dimension
threshold. It does not close the finite integer gap, claim an exact efficient
algorithm, or count the inherited asymptotic theorem as a new solution.

## Setting and metric

Let H_1,...,H_m be arbitrary Hermitian n by n matrices, k>=2, k<=n, and
n >= (m+1)k-1. Linear independence of the observables is unnecessary.
On the complex Grassmannian represented by an isometry X, set

    G_j=X^*H_jX,  T_j=G_j-tr(G_j)I/k,
    F=sum_j ||T_j||_F^2,  R=(I-XX^*) sum_j H_j X T_j.

Horizontal tangent vectors Z satisfy X^*Z=0. Use the real Frobenius metric
<Z,W>=Re tr(Z^*W); thus grad F=4R. The Hessian in direction Z is the
second derivative along exp[t(ZX^*-XZ^*)]X. Let

    eta=max(0,-lambda_min(Hess F)),  rho=||R||_op,
    a=(k-1)sqrt(k+1).

**Claim 1.** At every X,

    F^2 <= a^2 rho^2 + (k/4) eta F.                    (1)

Consequently,

    F <= a rho + (k/4)eta
      <= (a/4)||grad F||_F + (k/4)eta.                (2)

In particular, simultaneous approximate first- and second-order stationarity
certifies approximate scalar compression. No hypothesis of exact stationarity
is imposed in (1).

## A sharp singular-value lemma for traceless Hermitian stacks

Let A=[T_1;...;T_m], so A^*A=sum T_j^2=:Q and tr Q=F.
If F>0 then

    sigma_2(A)^2 >= F/[k(k-1)].                      (3)

To prove it, fix any unit v, and write each T in a basis beginning with v as
[[b,w^*],[w,C]], with b real and tr C=-b. Cauchy--Schwarz gives

    ||T||_F^2 = b^2+2||w||^2+||C||_F^2
      >= [k/(k-1)]b^2+2||w||^2
      >= [k/(k-1)]||Tv||^2.

After summation, lambda_max(Q)<=(k-1)F/k. The other k-1 eigenvalues
therefore sum to at least F/k, and their largest is at least F/[k(k-1)].
This proves (3). Equality holds for the single matrix
diag(k-1,-1,...,-1), so that constant cannot be improved for arbitrary
traceless Hermitian stacks. Omitting tracelessness makes (3) false, as
diag(1,0,...,0) shows.

## Approximately common orthogonal direction

Complete X to a unitary [X,Y] and write C_j=Y^*H_jX. Let
C=[C_1,...,C_m], a q by p matrix, where q=n-k and p=mk. Then

    C A=Y^*R,  q>=p-1.

Let U be the two left singular vectors of A associated with its two largest
singular values. Equation (3) implies

    ||C U||_op <= rho / sigma_2(A).

The matrix C(I-UU^*) has rank at most p-2, whereas q>=p-1. Choose a
unit vector u orthogonal to its range. Then

    ||C^*u||^2 <= ||C U||_op^2
                <= k(k-1)rho^2/F.                  (4)

Equivalently, a unit left vector minimizing ||C^*u|| satisfies (4). This
argument covers q=p-1, q=p, and q>p; in the last case C has a literal
left kernel. There is no use of a nonexistent inverse of the full stack A.

## Phase-summed curvature and proof of Claim 1

Put y=Yu, a unit vector orthogonal to X. For each column index b use the
two unit horizontal directions Z_b=y e_b^* and iZ_b. The general second
variation proved in S01 gives

    sum_b [Hess(Z_b,Z_b)+Hess(iZ_b,iZ_b)]
       =8(k-1/k)||C^*u||^2-8F.                    (5)

The terms with Y^*H_jY cancel because tr T_j=0. Both phases are essential:
they remove the real/imaginary anisotropy of the first-order squared term.
The left side is at least -2k eta. Combining (4) and (5) yields (1), since
(k-1/k)k(k-1)=(k-1)^2(k+1)=a^2. The positive root of
F^2-(k eta/4)F-a^2rho^2<=0 is at most k eta/4+a rho, proving (2).
If F=0, both conclusions hold directly without division by F.

At an exact stationary point rho=0, this gives
lambda_min(Hess F)<=-4F/k whenever F>0. This is a quantitative version
of the inherited strict-saddle conclusion. If n>mk+k-1, a literal left
kernel of C gives the same curvature estimate at every X, without imposing
stationarity.

## Explicit ideal-arithmetic descent

Choose known bounds h_j>=||H_j||_op and put P=k sum_j h_j^2. Thus
0<=F<=P. If P=0 or F=0, stop. Let tau>0 be the desired variance tolerance.
All linear algebra and function evaluations in this subsection are ideal
exact real/complex operations. No finite-precision or bit-complexity claim
is made.

At X with F>tau, compute g=||grad F||_F and a=(k-1)sqrt(k+1).

* If g>=F/a, set Z=-grad F/g and move along its Grassmann geodesic
  by time t=g/(16P).
* If g<F/a, find a unit left vector u minimizing ||C^*u||, and evaluate
  the 2k curvatures in (5). Select one with smallest curvature q_0.
  Use its rank-one geodesic, evaluate both times +/-t with
  t^2=F/(32Pk), and retain the smaller objective.

The second branch satisfies rho<=g/4<F/(4a), so (4)--(5) imply

    q_0 < -15F/(4k) <= -2F/k.                      (6)

This requires only a singular-vector computation and 2k directional
curvatures, not a full Hessian eigenproblem.

Here are the global derivative bounds needed to justify actual progress.
For any unit horizontal Z, K=ZX^*-XZ^* has operator norm <=1 and
X(t)=exp(tK)X. Each derivative X^(r)(t)=K^r X(t) has operator norm <=1
and Frobenius norm <=sqrt(k). Leibniz' rule gives

    ||(X(t)^*H_jX(t))^(r)||_F <= 2^r sqrt(k)h_j.

Traceless projection is a contraction for the Frobenius norm. Applying
Leibniz once more to its squared norm yields, for every r>=0,

    |(F(X(t)))^(r)| <= 4^r P.                      (7)

In particular, |F''|<=16P and |F''''|<=256P for the entire geodesic.
The gradient branch decreases F by at least

    g^2/(32P) >= F^2/(32P a^2) >= F^2/(32P k^3).

For the second branch, average the values at +/-t. The odd Taylor terms
cancel and the fourth derivative remainder in (7) gives

    [F(t)+F(-t)]/2 <= F + q_0 t^2/2 + (256P/24)t^4
                    <= F - F^2/(48Pk^2).

One of the two tested points is no larger than this average. Hence every
iteration with F>tau satisfies

    F_next <= F-F^2/(48Pk^3).                       (8)

Writing C_0=48Pk^3, positivity and F<=P imply
1/F_next>=1/F+1/C_0 unless F_next=0. Therefore at most
ceil(C_0/tau) iterations suffice to attain F<=tau. Each iteration uses
matrix multiplication, singular-vector calculations and geodesic function
evaluation of dimensions polynomial in n,m,k. This is an explicit ideal-
arithmetic iteration bound, not a logarithmic-in-precision or exact-code
complexity theorem. In particular tau=epsilon^2 gives a variance-norm
guarantee epsilon with a bound proportional to epsilon^(-2).

## Meaning for arbitrary error spaces

Fix an explicitly specified error basis A_1,...,A_e. Take m=e^2 Hermitian
observables consisting of A_i^*A_i and, for i<j,

    (A_i^*A_j+A_j^*A_i)/sqrt(2),
    (A_i^*A_j-A_j^*A_i)/(i sqrt(2)).

Their variance sum is exactly

    F=sum_{i,j} ||X^*A_i^*A_jX-lambda_ij I||_F^2,
    lambda_ij=tr(X^*A_i^*A_jX)/k.

Thus, for n >= (e^2+1)k-1 and any epsilon>0, the ideal iteration can
construct an isometry with F<=epsilon^2. For A=sum a_i A_i and
B=sum b_i A_i, Cauchy--Schwarz in the Hilbert space of k by k matrices gives

    ||X^*A^*BX-(a^*lambda b)I||_op
       <= epsilon ||a||_2 ||b||_2.                 (9)

The coefficient norms refer to this chosen basis; arbitrary rescaling changes
the residual and derivative norms. This is a quantitative approximate KL
statement. It does not itself claim recovery-channel diamond error, apply
below the dimension threshold, or prove c(2,6)=2. Exact scalar compression
still follows nonconstructively from the inherited compactness argument.

## Contribution and limits

The inherited scalar-compression theorem, its asymptotic Q119 consequence,
and the variance optimization approach receive no new credit. The proposed
extension is the uniform quantitative bound (1), together with the explicit
decrease analysis (8) and its basis-qualified approximate KL consequence.
Independent expert review, precise priority comparison, and a certified
finite-precision implementation remain pending. This is a stage within R037.
