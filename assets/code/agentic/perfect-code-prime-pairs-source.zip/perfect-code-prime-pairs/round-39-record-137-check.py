def prime(n):
    return n >= 2 and all(n % d for d in range(2, __import__('math').isqrt(n) + 1))

def legendre(a, p):
    t = pow(a % p, (p - 1) // 2, p)
    return -1 if t == p - 1 else t

def admissible(p, l):
    return (prime(p) and prime(l) and p != l and p % 2 == 1
            and p % 3 == 2 and l % 24 == 7 and legendre(p, l) == -1)

pairs = [(5, 7), (17, 7), (5, 103)]
for p, l in pairs:
    assert admissible(p, l)
    assert legendre(2, l) == 1 and legendre(3, l) == -1
    print(f'p={p}, l={l}: (p/l)=-1, (2/l)=1, (3/l)=-1; asserted')
    for a in (1, 2):
        for b in (1, 2):
            q = p**a * l**b
            Q = q*q
            A = Q-1
            for u in range(1, 25):
                n = 2+Q*Q*u
                V = 1+n*A+n*(n-1)*A*A//2
                S = 3+2*Q*A*u
                delta = 1+4*A*u
                R = 2+(3*Q-1)*A*u+Q*Q*A*A*u*u
                assert Q*Q*R == 2*V
                assert S*S-4*R == delta
                assert Q*S == 2*A*n-Q+4
                assert R % 8 == 2 and delta % 3 == 1
                assert S % p == 3 % p and S % l == 3
    # Exhaust one full exponent period of the multiplicative group modulo l.
    for i in range(1, l):
        if pow(p, i, l) == 3 or 2*pow(p, i, l) % l == 3:
            assert i % 2 == 1
    for i in (1, 3, 5):
        for j in (1, 2, 3):
            assert (p**i-2*l**j)**2 % 3 == 0
            assert (2*p**i-l**j)**2 % 3 == 0
print('288 exact parameter checks: identities hold; R mod 8 = 2; delta mod 3 = 1')
assert 5 > 2
assert 0 != 1
print('Root bound: 5 > 2; contradiction residues: 0 != 1; asserted')
for p, l in [(2, 7), (11, 7), (5, 31), (3, 7)]:
    assert not admissible(p, l)
print('Excluded controls (2,7), (11,7), (5,31), (3,7): rejected')
print('Finite consistency checks only; the universal proof is analytic.')