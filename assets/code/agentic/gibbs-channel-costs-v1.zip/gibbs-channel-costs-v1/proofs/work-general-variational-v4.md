# Finite-dilation variational principles for general deterministic work

24 November 2026. Same-root proof candidate. Normal countable Gibbs baths,
exact sharp battery, finite input/output systems, beta>0. No other resource.
This removes the CPTP-extremality assumption at the level of a matching
variational characterization. Evaluating the remaining finite-dimensional
factorization optimization is not solved and must not be hidden as a closed
formula for every channel.

A finite Gibbs isometric dilation of a covariant channel Psi consists of
finite E,F, Hamiltonians H_E,H_F, and an isometry V:A tensor E -> B tensor F
such that

    (H_B+H_F)V-V(H_A+H_E)=delta V,
    Psi(X)=Tr_F V(X tensor gamma_E)V*.

Define its two explicit indices

    c_beta(V)=delta+beta^(-1)log[Z_B(beta) Z_F(beta)/(Z_A(beta) Z_E(beta))],
    c_all(V)=sup_(u>=beta){delta+u^(-1)log[Z_B(u) Z_F(u)/(Z_A(u) Z_E(u))]}.

Both are invariant under consistent scalar shifts of any Hamiltonian.
Both are nonnegative: the intertwining isometry embeds the input energy
spectrum into the delta-shifted output spectrum, giving
exp(u delta) Z_B(u)Z_F(u)>=Z_A(u)Z_E(u).

Let C_0(Phi) be the infimum of c_all(V) over finite dilations implementing
Phi EXACTLY. Let C_epsilon^beta(Phi) be the infimum of c_beta(V) over such
finite dilations whose channel is within D_ch error epsilon of Phi.

## The exact variational principle

For every covariant finite channel,

    W_0(Phi)=C_0(Phi).                                 (1)

There is at least one finite dilation: take a one-dimensional initial E
and the ordinary covariant Stinespring environment F. Thus exact work is
finite. For a noncovariant channel exact work is infinite.

### Upper bound in (1)

Take any finite logical dilation V with shift delta and any W>c_all(V).
Append the free physical environment E tensor D, where D=B tensor F tensor R.
After applying V to A tensor E, embed D isometrically into
D'=A tensor E tensor R with energy increase W-delta. The input/output
multiplicity inequality for this embedding is

    [A_count*E_count - shifted_(W-delta)(B_count*F_count)]*R >=0.

Its Laplace transform is strictly positive for all u>=beta by W>c_all.
After shifting all finite factor grounds to zero, W>c_all implies
W>delta, so the negative part starts above energy zero and the positive
part has a positive constant term. The arbitrary-real-spectrum positive
convolution lemma therefore supplies a normal integer-degeneracy bath R.
V tensor S raises physical total nonbattery energy by W. The physical
system is A tensor B tensor E tensor F tensor R in both tensor orderings.
Complete with battery W->0 to an energy-conserving unitary sector by sector.
The initial E Gibbs marginal gives exactly Psi=Phi, not an approximation.
Taking infima proves W_0<=C_0.

### Lower bound in (1): finite exact replacement of an infinite bath tail

Suppose a normal-bath exact implementation of Phi uses sharp work W.
Combine its free initial systems into E and discarded systems into F, so
Z_A(u)Z_E(u)=Z_B(u)Z_F(u). The restricted map V:A tensor E -> B tensor F
is an isometry of shift W. Shift E,F ground energies consistently so that
E has ground zero; scalar-shift invariance permits this normalization.

Cut E at a large energy L. The Gibbs-conditioned finite part E_L has mass
p_L=Z_(E_L)(beta)/Z_E(beta)->1. Its image under V lies in A/B-dependent
finitely many bounded-energy sectors of F, each finite dimensional. Let
F_L be a finite spectral subspace containing that image. The restricted
isometry V_L is a finite dilation of a channel Phi_L with shift W.
The remaining Gibbs-conditioned tail defines a finite-system covariant
channel Phi_tail, and

    Phi=p_L Phi_L+(1-p_L)Phi_tail.

Implement Phi_tail by its finite covariant Stinespring isometry. Give its
one-dimensional initial environment the energy

    E_T=-beta^(-1)log Z_(E_tail)(beta),

and its final minimal Kraus environment energies E_T+W-nu_alpha, where
nu_alpha are its channel frequencies. Direct-sum this tail dilation with
V_L. The resulting finite Gibbs dilation implements Phi EXACTLY at common
shift W and has the correct Gibbs mixture weights. E_T tends to infinity.

For u>=beta, the ratio Z_E(u)/Z_(E_L)(u) is at most 1/p_L: increasing u
reduces the weight of the higher-energy tail relative to the cut. Also
Z_(F_L)(u)<=Z_F(u). Therefore the finite good part's exponential index
is bounded by exp(uW)/p_L. The added tail part contributes at most

    C exp[-u(E_T-C0)]

relative to exp(uW), uniformly for u>=beta, with C,C0 depending only on
the finite system spectra and dimensions (and fixed W), not on L. Indeed
the tail Kraus rank is bounded by d_A d_B and its frequencies belong to the
fixed finite set of system Bohr differences. A fixed ground contribution
bounds Z_(E_L)(u) below after the ground shift. Hence the new dilation obeys

    c_all <= W+beta^(-1)log[p_L^(-1)+o(1)] -> W.

This proves C_0<=W and hence (1). A finite approximation of the channel
alone would not suffice; the exact finite replacement of the residual tail
is the step preserving the zero-error target.

## Positive-error variational principle

Let delta_cov(Phi) be the minimum D_ch distance to covariant channels.
For every epsilon>delta_cov(Phi),

    W_epsilon(Phi)=C_epsilon^beta(Phi).                 (2)

For epsilon<delta_cov both are infinite. At the boundary epsilon=delta_cov,
(2) is not asserted: exact-work discontinuities can matter for the closest
covariant channels. In particular epsilon=0 for a covariant target is
covered by (1), not by replacing c_all with c_beta.

### A finite dilation's beta index is approximately achievable

The good-sector bath construction from
`work-extreme-approx-general-v3.md` applies verbatim to the single
embedding D=B tensor F tensor R -> D'=A tensor E tensor R, with shift
W-delta. For any W>c_beta(V), its signed counting measure has positive
Laplace transform at beta. Use the multivariate bath multiplicities
ceil(M exp(beta' k dot h)), beta'<beta, and apply the target dilation on
all high-coordinate good sectors. On the other sectors complete the full
W-shift isometry using a bath basis that includes W/g as a positive generator.
The battery is sharp everywhere; the channel error tends to zero as
beta' increases to beta. Thus c_beta(V) is an arbitrarily accurate work
upper bound for its finite logical channel.

### Converse by finite truncation

Any implementation within epsilon of Phi has a finite bath cut giving a
finite dilation within epsilon+eta and beta index at most W+o(1), as eta
vanishes. The needed partition estimate is the beta specialization of the
one used in the exact converse above. This yields the lower bound after
right continuity in the error tolerance.

### Why right continuity holds strictly above delta_cov

Exponentiated finite-dilation beta costs are convex under channel mixing.
For dilations V_i with shifts delta_i, take E=direct_sum(E_i+u_i) and
F=direct_sum(F_i+u_i-delta_i), so the common shift is zero. Choose u_i to
produce arbitrary desired Gibbs weights p_i. Then

    exp(beta c_beta(V))=sum_i p_i exp(beta c_beta(V_i)).  (3)

If epsilon>delta_cov there is a finite covariant dilation giving a channel
strictly inside the epsilon ball. Mix it with a candidate at error
 epsilon+eta, with a mixing weight tending to zero as eta tends to zero.
Root fidelity is concave, uniformly over reference-assisted inputs, so
this mixture lies inside the epsilon ball. Equation (3) makes its cost
change tend to zero. This proves right continuity of C_epsilon^beta and
allows the approximately achievable dilation to be placed strictly inside
the error tolerance before implementing it. Both inequalities in (2) follow.

## What remains nontrivial

- These are matching finite-dilation variational principles, not a solved
  evaluation of the dilation indices for arbitrary channel data.
- At H=0 the remaining optimization contains finite tracial/noisy channel
  factorization. The prior Musat--Rordam nonclosure results show why finite
  ancillary dimension and limits cannot simply be interchanged.
- CPTP-extreme channels are the case where orthogonality collapses this
  optimization to the explicit minimal-Kraus formulas already proved.
- Neither (1) nor (2) settles arbitrary-dimensional finite-coherence
  classification or all optimal QFI values in the other clause of Q117.
