"""Fully independent re-derivation. Nothing imported from eval_petz_cmi.py.
Petz map built as an explicit Choi matrix, applied by Choi-vectorization.
Ordering: A (0), B (1), C (2); dims dA,dB,dC."""
import numpy as np, json

def H(M): return (M + M.conj().T)/2

def eigh_fn(M, f, cutoff=1e-12):
    w, v = np.linalg.eigh(H(M))
    return (v * f(w, cutoff)) @ v.conj().T

sqrtm_  = lambda M: eigh_fn(M, lambda w,c: np.sqrt(np.clip(w,0,None)))
invsqrt = lambda M: eigh_fn(M, lambda w,c: np.where(w>c, 1/np.sqrt(np.where(w>c,w,1)), 0.0))

def entropy(M):
    w = np.linalg.eigvalsh(H(M)); w = w[w > 1e-13]
    return float(-(w*np.log2(w)).sum())

def ptrace(rho, dims, keep):
    """Partial trace, independent implementation via explicit loops (no einsum)."""
    n = len(dims); keep = sorted(keep); tr = [i for i in range(n) if i not in keep]
    dk = int(np.prod([dims[i] for i in keep])); dt = int(np.prod([dims[i] for i in tr])) if tr else 1
    # build index maps
    def idx(multi):  # multi-index over all n systems -> flat
        f = 0
        for i, d in enumerate(dims): f = f*d + multi[i]
        return f
    out = np.zeros((dk, dk), dtype=complex)
    from itertools import product
    keep_ranges = [range(dims[i]) for i in keep]; tr_ranges = [range(dims[i]) for i in tr]
    for ki, kk in enumerate(product(*keep_ranges)):
        for kj, ll in enumerate(product(*keep_ranges)):
            s = 0
            for tt in product(*tr_ranges):
                m1 = [0]*n; m2 = [0]*n
                for a, i in enumerate(keep): m1[i] = kk[a]; m2[i] = ll[a]
                for a, i in enumerate(tr):   m1[i] = tt[a]; m2[i] = tt[a]
                s += rho[idx(m1), idx(m2)]
            out[ki, kj] = s
    return out

def fidelity_sq(r, s):
    """F = ||sqrt(r) sqrt(s)||_1^2, computed via singular values (not eigenvalues)."""
    X = sqrtm_(r) @ sqrtm_(s)
    return float(np.sum(np.linalg.svd(X, compute_uv=False))**2)

def petz_choi(rho, dims):
    """Choi matrix J of P: L(C) -> L(AC), J = sum_{ij} |i><j|_Cin  (x) P(|i><j|)_ACout."""
    dA, dB, dC = dims
    rAC = ptrace(rho, dims, [0,2]); rC = ptrace(rho, dims, [2])
    S = sqrtm_(rAC); G = invsqrt(rC); IA = np.eye(dA)
    J = np.zeros((dC*dA*dC, dC*dA*dC), dtype=complex)
    for i in range(dC):
        for j in range(dC):
            X = np.zeros((dC,dC), dtype=complex); X[i,j] = 1
            Y = S @ np.kron(IA, G @ X @ G) @ S          # in AC
            # place into block (i,j) of the Cin index
            J[i*dA*dC:(i+1)*dA*dC, j*dA*dC:(j+1)*dA*dC] = Y
    return J

def apply_petz_to_BC(rho, dims):
    """(id_B (x) P_{C->AC})(rho_BC), output ordered A,B,C."""
    dA, dB, dC = dims
    rBC = ptrace(rho, dims, [1,2]).reshape(dB,dC,dB,dC)
    J = petz_choi(rho, dims)
    out = np.zeros((dA,dB,dC,dA,dB,dC), dtype=complex)
    for b1 in range(dB):
        for b2 in range(dB):
            # P(X) = sum_{ij} X[i,j] * J-block(i,j)
            Y = np.zeros((dA*dC, dA*dC), dtype=complex)
            for i in range(dC):
                for j in range(dC):
                    Y += rBC[b1,i,b2,j] * J[i*dA*dC:(i+1)*dA*dC, j*dA*dC:(j+1)*dA*dC]
            Yr = Y.reshape(dA,dC,dA,dC)
            out[:,b1,:,:,b2,:] = Yr
    return out.reshape(dA*dB*dC, dA*dB*dC)

def cmi(rho, dims):
    return (entropy(ptrace(rho,dims,[0,2])) + entropy(ptrace(rho,dims,[1,2]))
            - entropy(ptrace(rho,dims,[2])) - entropy(rho))

def gap(rho, dims):
    rec = apply_petz_to_BC(rho, dims)
    return cmi(rho,dims) + np.log2(fidelity_sq(rho, rec)), rec

