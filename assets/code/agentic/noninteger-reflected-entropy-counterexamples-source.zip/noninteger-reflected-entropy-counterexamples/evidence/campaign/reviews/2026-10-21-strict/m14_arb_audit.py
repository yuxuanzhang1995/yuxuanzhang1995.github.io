"""Independent M14 certificate, using Arb ball arithmetic throughout.

No import of candidate check.py, spectral residuals, cached envelopes, or its
claimed lower bounds. Only the geometric cover is read from the candidate.
Arb verified eigenvectors bound global second derivatives; direct matrix
exponentials give centre values and the memory witness.
"""
from pathlib import Path
import sys, json, time, hashlib
from fractions import Fraction
from math import comb
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'dependencies'))
import flint
from flint import arb, acb, arb_mat, acb_mat, ctx
ctx.prec = 160
BASE = HERE.parent.parent
S = 10**8
TICKS = 2**18
N = 31
ROWS = 26
q = arb(-1).exp()
mass = 1-q**11
started = time.time()

def floor_lower(x):
    f = x.lower().fmpq()
    return int(f.numerator // f.denominator)

def ceil_upper(x):
    f = x.upper().fmpq()
    return -int((-f.numerator) // f.denominator)

def record(stage, **kw):
    print(json.dumps(dict(stage=stage, elapsed=round(time.time()-started, 2), **kw)), flush=True)

def abs2(z):
    # Multiplication is defined even when a real ball straddles zero.
    return z.real*z.real+z.imag*z.imag

def hamiltonian(k):
    n = k//2+1
    H = arb_mat(n, n)
    for r in range(n-1):
        H[r,r+1] = H[r+1,r] = arb((r+1)*(k-2*r)*(k-2*r-1)).sqrt()
    return H

Hs = {k: hamiltonian(k) for k in range(61)}
blocks = []
M2 = arb_mat(ROWS,N)
for k,H in Hs.items():
    n = H.nrows()
    # Verified, isolated eigenvalues/eigenvectors, not approximate eig mode.
    w,V = H.eig(right=True, algorithm='rump')
    assert all(z.imag.contains(0) for z in w)
    w = [z.real for z in w]
    W = arb_mat(n,n)
    for j in range(n):
        norm = sum((abs2(V[i,j]) for i in range(n)), arb(0)).sqrt()
        assert norm > 0
        for i in range(n):
            W[i,j] = abs(V[i,j])/norm
    # For a real symmetric irreducible tridiagonal, eigenvalues are simple;
    # its normalized eigenvectors are orthonormal, independent of phase.
    A0 = W*W.transpose()
    D1 = arb_mat(n,n)
    D2 = arb_mat(n,n)
    for i in range(n):
        D1[i,i] = w[i]
        D2[i,i] = w[i]*w[i]
    A1 = W*D1*W.transpose()
    A2 = W*D2*W.transpose()
    source = [r for r in range(min(n,ROWS)) if 0 <= k-2*r <= 10]
    weights = {r:(1-q)*q**(k-2*r) for r in source}
    for r in source:
        for d in range(n):
            M2[r,d] += weights[r]*2*(A0[d,r]*A2[d,r]-A1[d,r]*A1[d,r])
    blocks.append((k,source,weights))
record('verified spectral envelopes', sectors=len(Hs))

cover_path = BASE/'candidates/M14-v2/reset-cover.npz'
data = np.load(cover_path)
assert list(map(int,data['scale'])) == [S,TICKS]
raw = data['leaves']
leaves = {tuple(map(int,row[1:])) for row in raw}
assert len(leaves)==len(raw)
seen = set()
nodes = 0
def visit(lo,hi):
    global nodes
    nodes += 1
    key = tuple(lo+hi)
    if key in leaves:
        seen.add(key)
        return
    if sum(lo)>TICKS:
        return
    widths=[b-a for a,b in zip(lo,hi)]
    i=widths.index(max(widths)); mid=(lo[i]+hi[i])//2
    assert lo[i]<mid<hi[i],('uncovered cell',lo,hi)
    left=hi.copy();left[i]=mid;visit(lo.copy(),left)
    right=lo.copy();right[i]=mid;visit(right,hi.copy())
visit([0]*4,[TICKS]*4)
assert seen==leaves
keys=set()
for key in leaves:
    lo=list(key[:4]);hi=[min(b,TICKS-sum(lo)+a) for a,b in zip(lo,key[4:])]
    keys.update(zip(lo,hi))
by_centre={}
for lo,hi in keys:by_centre.setdefault(lo+hi,[]).append((lo,hi))
mass_num=floor_lower(S*mass)
mass_cap=ceil_upper(S*mass)
initial=np.array([floor_lower(S*(1-q)*q**r) for r in range(11)],dtype=np.int64)
intervals={}
max_centre_radius=0.0
for count,(cnum,ranges) in enumerate(sorted(by_centre.items()),1):
    c=arb(2*cnum)/(5*TICKS)
    P=arb_mat(ROWS,N);D=arb_mat(ROWS,N)
    for k,source,weights in blocks:
        if not source:continue
        H=Hs[k];n=H.nrows()
        U=(acb_mat(H)*acb(0,-c)).exp()
        Ud=acb_mat(H)*U*acb(0,-1)
        for r in source:
            for d in range(n):
                P[r,d] += weights[r]*abs2(U[d,r])
                D[r,d] += weights[r]*2*(Ud[d,r]*U[d,r].conjugate()).real
    for lo,hi in ranges:
        h=arb(2*(hi-lo))/(5*TICKS)
        lower=np.zeros((ROWS,N),dtype=np.int64)
        upper=np.zeros((ROWS,N),dtype=np.int64)
        for r in range(ROWS):
            for d in range(N):
                # Upper endpoints make this a rigorous absolute Taylor bound.
                err=h*D[r,d].abs_upper()+h*h*M2[r,d].abs_upper()/2
                assert (P[r,d]-err).is_finite(), (lo,hi,r,d,str(P[r,d]),str(D[r,d]),str(M2[r,d]),str(err))
                lower[r,d]=max(0,floor_lower(S*(P[r,d]-err)))
                upper[r,d]=min(mass_cap,max(0,ceil_upper(S*(P[r,d]+err))))
                max_centre_radius=max(max_centre_radius,float(P[r,d].rad()))
        assert np.all(upper>=lower)
        intervals[lo,hi]=(lower,upper)
    if count%20==0 or count==len(by_centre):
        record('direct ball matrix exponentials', centres=count,total=len(by_centre))
ordered=sorted(intervals)
np.savez_compressed(HERE/'m14-arb-envelopes.npz',
    keys=np.array(ordered,dtype=np.int64),
    lower=np.array([intervals[k][0] for k in ordered]),
    upper=np.array([intervals[k][1] for k in ordered]),
    mass=np.array([mass_num]),initial=initial)

def dual_bound(key):
    lo=list(key[:4]);hi=[min(b,TICKS-sum(lo)+a) for a,b in zip(lo,key[4:])]
    costs=np.arange(N,dtype=np.int64)*S
    for j in (3,2,1,0):
        l,u=intervals[lo[j],hi[j]];reach=11+5*j;l=l[:reach];u=u[:reach]
        capacity=u-l;need=mass_num-l.sum(axis=1)
        assert np.all(need>=0) and np.all(capacity.sum(axis=1)>=need)
        order=np.argsort(costs);caps=capacity[:,order];v=costs[order]
        idx=np.argmax(np.cumsum(caps,axis=1)>=need[:,None],axis=1)
        eta=v[idx]
        penalty=(caps*np.maximum(0,eta[:,None]-v[None,:])).sum(axis=1)
        value=l@costs+eta*need-penalty
        assert np.all(value>=0)
        new=value//S
        costs=np.r_[new,np.zeros(N-reach,dtype=np.int64)]
    return int(initial@costs[:11])
minimum=min(dual_bound(key) for key in leaves)
assert minimum>2593*S*S//10000
record('all reset leaves certified',leaves=len(leaves),lower_numerator=minimum)

# Independent retained-memory propagation, with direct ball exponentials.
times=[arb(217)/1000,arb(404)/1000,arb(179)/1000]
single={(j,k):(acb_mat(Hs[k])*acb(0,-t)).exp()
        for j,t in enumerate(times) for k in range(38)}
energy=arb(0);retained=arb(0)
for e1 in range(2):
    for e2 in range(2):
        for L in range(19):
            basis=[(r,u,L-r-u) for r in range(L+1) for u in range(L-r+1)]
            index={x:i for i,x in enumerate(basis)};n=len(basis)
            U=acb_mat(n,n)
            for i in range(n):U[i,i]=1
            for j,bath in enumerate((0,1,0)):
                nxt=acb_mat(n,n)
                for spectator in range(L+1):
                    ids=[index[(r,L-spectator-r,spectator) if bath==0
                               else (r,spectator,L-spectator-r)]
                         for r in range(L-spectator+1)]
                    k=2*(L-spectator)+(e1 if bath==0 else e2)
                    sub=acb_mat([[U[i,col] for col in range(n)] for i in ids])
                    product=single[j,k]*sub
                    for row,i in enumerate(ids):
                        for col in range(n):nxt[i,col]=product[row,col]
                U=nxt
            weights=[(1-q)**3*q**(r+2*u+e1+2*v+e2) for r,u,v in basis]
            retained+=sum(weights,arb(0))
            for i,(r,u,v) in enumerate(basis):
                if r:
                    energy+=r*sum((abs2(U[i,j])*weights[j] for j in range(n)),arb(0))
        record('ball memory propagation',parities=[e1,e2])
# Exact tail expectation for S ~ negative-binomial(3,q). Missing L>18
# implies S>18, and final target energy is at most initial S.
tail=3*q/(1-q)-(1-q)**3*sum((s*comb(s+2,2)*q**s for s in range(19)),arb(0))
assert tail>0
upper=energy+tail
reset=arb(minimum)/(S*S)
gap=reset-upper
assert gap>arb(2)/10000
result={'status':'pass','implementation':'python-flint Arb/Acb',
    'version':flint.__version__,'precision_bits':ctx.prec,
    'cover_sha256':hashlib.sha256(cover_path.read_bytes()).hexdigest(),
    'cover_nodes':nodes,'cover_leaves':len(leaves),'time_intervals':len(intervals),
    'centres_directly_exponentiated':len(by_centre),'max_centre_radius':max_centre_radius,
    'reset_lower_numerator':minimum,'reset_lower_denominator':S*S,
    'reset_lower_decimal':str(reset),'memory_truncated_energy':str(energy),
    'memory_retained_mass':str(retained),'memory_tail_bound':str(tail),
    'memory_upper_ball':str(upper),'strict_gap_ball':str(gap),
    'seconds':time.time()-started,
    'independence':'New code and rigorous arithmetic library. Does not use candidate eigenproposals, error budgets, kernel cache or saved leaf values. Reuses only geometric cover; rechecks coverage. Same assistant, not an external reviewer.'}
(HERE/'m14-arb-audit.json').write_text(json.dumps(result,indent=2)+'\n')
record('complete',**result)
