"""Independent rational/Arb checks of the M06 proof's numerical constants."""
from pathlib import Path
from fractions import Fraction as F
import json
from flint import arb, ctx

ctx.prec = 200
q = (-arb(1)).exp()
phi = (1 - q) * (1 - q*q) / 200000
gap = phi*phi / 2
norm_cubed = (1 - q*q)**2 / ((1 + q)**3 * (1 - q.sqrt())**2)
second_moment_bound_cubed = 8 * 720 / (1 - q*q)**6
checks = {
    "small_frequency_loss": F(7, 45000) > F(1, 10000),
    "sinc_bound_from_half": F(1841, 1920) < F(24, 25),
    "sinc_bound_from_quarter": F(30401, 30720) < F(99, 100),
    "q_lt_two_fifths": q < arb(2)/5,
    "pi0_gt_four_fifths": 1 - q*q > arb(4)/5,
    "spectral_gap_gt_claimed": gap > arb(1)/10**12,
    "initial_Lp_norm_lt_two": norm_cubed < 8,
    "uniform_second_moment_lt_thirty": second_moment_bound_cubed < 30**3,
    "energy_error_prefactor": 68 * 500001 < 6000**2,
    "averaged_gross_work_series": 24000 * 4 * 10**12 < 10**17,
}
assert all(checks.values()), checks
result = {
    "status": "pass",
    "precision_bits": 200,
    "checks": checks,
    "values": {
        "conductance": str(phi),
        "Cheeger_gap_lower": str(gap),
        "initial_Lp_norm_cubed": str(norm_cubed),
        "second_moment_bound_cubed": str(second_moment_bound_cubed),
        "averaged_gross_work_series_upper": 24000 * 4 * 10**12,
    },
    "scope": (
        "Arithmetic safety of analytic proof constants only. The uniform sector, "
        "coarea, spectral, tail and work arguments require the mathematical review. "
        "Final frozen inputs are identified separately in inputs.json."
    ),
}
(Path(__file__).parent / "bounds-check.json").write_text(
    json.dumps(result, indent=2) + "\n"
)
print(json.dumps(result, indent=2))
