# Source comparison, 18 November 2026

The manuscript proves the arbitrary-operator, dimension-independent bound
`error <= J_alpha(X) (D+1)^(-(1/(2 alpha)-3/2))` for every
`0 < alpha < 1/3`. It makes no claim of first-publication priority.

The closest primary source is Kim et al., *Spectral Small-Incremental
Entangling*, Physical Review X 16, 041035 (published 9 November 2026),
https://doi.org/10.1103/8fcr-5tf4 . The comparison uses the published PDF,
not only the older arXiv version. Definition 2 and Conjecture 2 appear on
page 22. Discussion item (3) and the Note added on page 46 announce the
Hermitian positive result and the non-Hermitian obstruction at alpha >= 1/3;
the positive non-Hermitian low-order question is not answered there.
The negative-range obstruction is inherited, including its use to check
the exponent. The proposed contribution is the general positive upper bound.

The source lists Kim, Kusunoki and Kuwahara as unpublished reference 93
(page 49), with no title or public identifier. Its full contents were not
recovered. We checked the team's public preprint and publication lists:

- https://kuwahara-quantum.com/en/publications-preprint/
- https://kuwahara-quantum.com/en/publications-journal-published/

Neither list exposed that follow-up in the pages retrieved. Their freshness
and completeness cannot be guaranteed. Search queries included the three
authors' names together, non-Hermitian spectral-entangling approximation,
operator Schmidt approximation at p = 2/3, and equivalent low-order strength
phrasing, including arXiv-restricted searches. No public manuscript supplying
the same all-operator theorem was located in this bounded search. This does
not establish what the authors know privately or rule out unindexed work.

Two neighboring primary works were also compared:

- Mackay, Kim, Vu and Kuwahara, *Optimal low-rank compression of quantum
  dynamics*, https://arxiv.org/abs/2609.27497v1 . Its main compression results
  use spatial locality and generator assumptions. Those are absent here.
  The comparison covers the main statements and relevant sections examined,
  not a line-by-line audit of its 134-page supplement.
- Dowling, *Classical Simulability from Operator Entanglement Scaling*,
  https://arxiv.org/html/2603.05656v4 . The introduction, definitions and
  main guarantees distinguish correlation/ensemble approximation from
  arbitrary-state guarantees. The hypothesis uses operator entanglement
  of a specified vectorization, rather than a supremum over local purified
  inputs. It does not supply the theorem stated here.

The author's existing research website was checked for duplicate releases.
Its bounded-strength evolution entry, dated 17 November 2026, concerns a
dimension-dependent squared-logarithmic rank bound for full dynamics under
the ordinary strength condition. It is a different statement and is not
used as a lemma in this proof:
https://yuxuanzhang1995.github.io/agentic-research/bounded-se-operator-schmidt-rank/

Conclusion: a complete internally reviewed proof candidate for the stated
positive-range question, with a public-source separation identified.
Worldwide priority, overlap with reference 93, and independent expert
verification remain unresolved. Publication of the proof records its content
and date, not a determination of priority or external acceptance.
