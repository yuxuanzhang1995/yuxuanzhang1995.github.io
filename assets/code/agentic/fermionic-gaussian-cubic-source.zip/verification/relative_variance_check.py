"""Finite convention/variance checks for proposed Nambu matching estimator."""
import numpy as np,json
rng=np.random.default_rng(123456)
rows=[]
for m in (2,3,4):
 I=np.eye(2);Z=np.diag([1,-1]);a=np.array([[0,1],[0,0.]])
 def kron(xs):
  z=np.array([[1.]])
  for x in xs:z=np.kron(z,x)
  return z
 f=[kron([Z]*j+[a]+[I]*(m-j-1)) for j in range(m)];fs=f+[x.conj().T for x in f];dim=2**m
 for rep in range(15):
  # Includes arbitrary non-Gaussian positive states, since variance lemma uses only CAR.
  V=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));rho=V@V.conj().T;rho/=np.trace(rho)
  R=np.array([[np.trace(rho@x.conj().T@y)for y in fs]for x in fs]);p0=rng.uniform(.001,.999,m);tau=2.**(-(rep%8)-3)
  diag=np.r_[p0,1-p0]+tau;W=np.diag(diag**-.5);kap=max(1.,np.linalg.eigvalsh(W@(R+tau*np.eye(2*m))@W).max())
  built=np.zeros((2*m,2*m),complex)
  for i in range(m):
   ni=f[i].conj().T@f[i];pi=np.trace(rho@ni).real;built[i,i]=pi;built[m+i,m+i]=1-pi
  max_ratio=0.;max_norm=0.
  for i in range(m):
   for j in range(i+1,m):
    H=f[i].conj().T@f[j];P=f[i].conj().T@f[j].conj().T
    obs=[H+H.conj().T,-1j*(H-H.conj().T),P+P.conj().T,-1j*(P-P.conj().T)]
    for kind,O in enumerate(obs):
     F=np.zeros_like(R);z=.5 if kind%2==0 else .5j
     if kind<2:
      F[i,j]=z;F[j,i]=z.conjugate();F[m+i,m+j]=-z.conjugate();F[m+j,m+i]=-z
     else:
      F[i,m+j]=z;F[j,m+i]=-z;F[m+j,i]=z.conjugate();F[m+i,j]=-z.conjugate()
     mean=np.trace(rho@O).real;var=np.trace(rho@O@O).real-mean**2;built+=mean*F
     wf=W@F@W;varnorm=np.linalg.norm(var*(wf@wf),2);max_ratio=max(max_ratio,varnorm/(kap/tau));max_norm=max(max_norm,np.linalg.norm(wf,2)*tau)
  err=np.linalg.norm(built-R)
  assert err<1e-12,(m,rep,err)
  assert max_ratio<2.0+1e-12 and max_norm<=.5+1e-12
  rows.append({'m':m,'rep':rep,'reconstruction_error':float(err),'variance_ratio_to_K_over_tau':float(max_ratio),'coefficient_norm_times_tau':float(max_norm)})
print(json.dumps({'status':'finite_nambu_matching_checks_passed','instances':len(rows),'maximum_mean_error':max(x['reconstruction_error']for x in rows),'maximum_variance_ratio':max(x['variance_ratio_to_K_over_tau']for x in rows),'rows':rows},indent=2))
