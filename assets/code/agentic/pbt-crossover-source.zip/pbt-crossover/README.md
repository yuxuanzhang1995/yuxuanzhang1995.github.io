# pbt-crossover

This archive accompanies a complete original-problem candidate, not a partial-result release. Run `python3 check.py` and compare with `expected_stdout.txt`. The checker uses only the Python standard library. Read `frozen-proof.txt` for the full analytic argument and `independent-reviews.json` for internal review. Review is AI-assisted, not external refereeing. No novelty certification is claimed.

The frozen proof is unchanged. Historical wording about pending review is preserved; the dated review and publication records give the subsequent status. Public provenance paths omit the host workspace prefix.
