"""Supplementary exact algebra controls for the general Gaussian candidate."""
from pathlib import Path
import sympy as s
import json
F=s.Rational;I=s.eye(2);Z=s.diag(1,-1);J2=s.Matrix([[0,1],[-1,0]])
q=F(1,3);t=F(1,2);c=1/s.sqrt(1-q*q);sh=q*c
S=s.BlockMatrix([[c*I,sh*Z],[sh*Z,c*I]]).as_explicit()
eta=q/(2*(t-q)*(1-t*q))
Kt=s.BlockMatrix([[t*t*I,-t*Z],[-t*Z,I]]).as_explicit()
W0=eta*Kt;Gamma=s.simplify(S*S.T);J=s.diag(J2,J2)
G=s.simplify(S.T*s.diag(F(1,2),F(1,2),0,0)*S)
W=s.simplify(S.T*W0*S)
assert S*J*S.T==J and Gamma*J*Gamma==J
assert W+G==J*(W+G)*J.T and W.rank()==2
assert (W-J*W*J.T).rank()==4
kappa=c*sh/2
assert W[:2,2:]==-kappa*Z and W[0,0]*W[2,2]==kappa*kappa
u=s.sqrt(W[0,0]);v=s.sqrt(W[2,2]);a0=s.simplify(u*c+v*sh);b0=s.simplify(u*sh+v*c)
assert s.simplify(a0-q*b0-u/c)==0 and s.simplify(b0-q*a0-v/c)==0
assert s.simplify(a0/b0)==t
dt=(1-t*q)**2/(1-q*q)
assert s.simplify(s.trace(Kt*Gamma)/4+(1-t*t)/2-dt)==0
# General cross-block identity: rank-two positivity forces x=y=0.
x,y,k=s.symbols('x y k',real=True)
cross=x*I+y*J2-k*Z
assert s.simplify(cross.T*cross-((x*x+y*y+k*k)*I-2*k*x*Z-2*k*y*s.Matrix([[0,1],[1,0]])))==s.zeros(2)
records=[]
for bob_modes in [1,2,3]:
    n=2*(bob_modes+1);Om=s.diag(*([J2]*(bob_modes+1)))
    gam=s.diag(Gamma,s.eye(n-4));w0=s.diag(W0,s.zeros(n-4))
    # Orthogonal projection onto the EPR witness's two-dimensional range.
    B=w0[:,:2];P=B*(B.T*B).inv()*B.T
    vec=s.Matrix([(-1)**i*(i+1) for i in range(n)])
    H=s.diag(*range(1,n+1))+vec*vec.T/7
    D=(s.eye(n)-P)*H*(s.eye(n)-P)/5
    V=gam+D
    assert D.rank()==n-2 and w0*D==s.zeros(n)
    physical_minors=[s.factor((V+s.I*Om)[:j,:j].det()) for j in range(1,n+1)]
    assert all(z.is_positive for z in physical_minors)
    partial=s.eye(n);partial[1,1]=-1
    pt_det=s.factor((partial*V*partial+s.I*Om).det())
    assert pt_det<0
    assert s.trace(s.diag(Kt,s.zeros(n-4))*V)/4+(1-t*t)/2==dt
    # At the pure-whitened point, the strict inward tangent is exact.
    SS=s.diag(S,s.eye(n-4));Dt=s.simplify(SS.inv()*D*SS.inv().T)
    Wt=s.simplify(SS.T*w0*SS);B=Wt[:,:2];PK=s.simplify(B*(B.T*B).inv()*B.T)
    X0=Om*PK*Om.T-PK
    assert X0*Om+Om*X0==s.zeros(n)
    compression=s.simplify(B.T*X0*B)
    assert compression[0,0]<0 and compression.det()>0
    assert Dt*B==s.zeros(n,2)
    assert s.trace(Wt*X0)<0
    records.append({'Bob_modes':bob_modes,'physical_leading_minors':list(map(str,physical_minors)),'partial_transpose_uncertainty_determinant':str(pt_det),'noise_rank':D.rank(),'witness_rank':w0.rank(),'inward_tangent_compression':str(compression),'EPR_expectation':str(dt),'V':[[str(z) for z in row] for row in V.tolist()]})
r={'status':'PASS','arithmetic':'exact rational/radical SymPy','q':str(q),'gain_t':str(t),'eta':str(eta),'whitened_witness':str(W),'rank_two_cross_identity':True,'KKT_plus_sign':True,'double_covariance_factor':True,'cases':records,'scope':'Supplementary finite algebra controls; universal theorem relies on proof and imported source affine extremality.'}
Path('exact-controls.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='cases'},indent=2))
