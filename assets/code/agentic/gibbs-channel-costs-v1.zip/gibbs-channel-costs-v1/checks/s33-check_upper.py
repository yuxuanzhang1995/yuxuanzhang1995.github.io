"""Aggregation, augmentation ideals, and repairs on a refined energy mesh."""
import sympy as sp


x = sp.symbols("x", nonzero=True)
for i in range(-6,7):
    for j in range(-3,4):
        # Evaluation at one is the only constant term of an arbitrary multiplier.
        m = 2*x**i-3*x**j
        quotient = sp.cancel((m-m.subs(x,1))/(x-1))
        numerator, denominator = sp.fraction(quotient)
        assert len(sp.Poly(denominator,x).terms()) == 1
        assert sp.cancel((x-1)*quotient+m.subs(x,1)-m) == 0
T = sp.eye(2)/2
P = sp.diag(1,0)
Q = sp.diag(0,1)
assert P!=T and Q!=T and (P+Q)/2==T
z = sp.symbols("z",real=True)
for n in (2,7,23):
    spot = sp.Rational(round(n*float(sp.sqrt(2))),n)
    assert abs(spot-sp.sqrt(2)) <= 1/sp.Integer(n)
    assert sp.simplify((P+Q)/2-T)==sp.zeros(2)
# Eigenvalue positive-part repair for arbitrarily small complex defects,
# preserving a fixed terminal ratio when the same seed is translated.
for n in (2,9,31):
    d = sp.Rational(1,n)
    m = sp.Matrix([[0,sp.I*d],[-sp.I*d,0]])
    shift = -min(m.eigenvals())
    assert shift == d and min((m+shift*sp.eye(2)).eigenvals())==0
print("PASS: 91 Laurent augmentation identities, three branch-preserving rational "
      "energy shifts, and three exact continuous positive-part repairs.")
