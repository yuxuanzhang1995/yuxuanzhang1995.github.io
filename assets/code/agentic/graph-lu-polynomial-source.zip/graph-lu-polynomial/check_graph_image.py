"""Independent small exact checks of compressed kernel and binary edge image."""
from pathlib import Path
import json,itertools,math
import numpy as np
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
R=Path(__file__).resolve().parent;rng=np.random.default_rng(2121)
def hnf(rows,m,q):return hermite_normal_form(Matrix(rows+[[q*int(i==j)for j in range(m)]for i in range(m)]).T).T.tolist()
def kernel(B,q):
 M=np.array(B,dtype=object);rows,cols=M.shape;V=np.eye(cols,dtype=object);piv=[];k=0
 while k<min(rows,cols):
  candidates=[(int(M[i,j])&-int(M[i,j]),i,j)for i in range(k,rows)for j in range(k,cols)if M[i,j]%q]
  if not candidates:break
  p,i,j=min(candidates);M[[k,i]]=M[[i,k]];M[:,[k,j]]=M[:,[j,k]];V[:,[k,j]]=V[:,[j,k]]
  M[k,:]=(M[k,:]*pow(int(M[k,k])//p,-1,q))%q;assert M[k,k]==p
  for i in range(k+1,rows):
   assert M[i,k]%p==0
   M[i,:]=(M[i,:]-(M[i,k]//p)*M[k,:])%q
  for j in range(k+1,cols):
   assert M[k,j]%p==0
   f=M[k,j]//p;M[:,j]=(M[:,j]-f*M[:,k])%q;V[:,j]=(V[:,j]-f*V[:,k])%q
  piv.append(p);k+=1
 gen=[]
 for j in range(cols):
  scale=q//piv[j]if j<len(piv)else 1;v=tuple(int(x)for x in(scale*V[:,j])%q)
  if any(v):gen.append(v)
 return gen
def f2span(vectors):
 out={0}
 for v in vectors:out|={x^v for x in list(out)}
 return out
records=[]
for m in [1,2,3]:
 for ny in [3,5,7]:
  for r in [1,2,3,4]:
   q=2**r;A=rng.integers(0,2,size=(ny,m)).tolist();pairs=list(itertools.combinations(range(ny),2))
   prod=lambda K:[math.prod(A[v][x]for v in K)for x in range(m)]
   seeds=[[2*x for x in prod(K)]for k in[2,3]for K in itertools.combinations(range(ny),k)]
   B=hnf(seeds,m,q)
   while True:
    C=hnf(B+[[2*A[v][j]*row[j]for j in range(m)]for v in range(ny)for row in B],m,q)
    if C==B:break
    B=C
   gen=kernel(B,q)
   dot=lambda x,y:sum(a*b for a,b in zip(x,y))
   assert all(all(dot(row,v)%q==0 for row in B)for v in gen)
   def edge(v):
    res=0
    for i,K in enumerate(pairs):
     val=dot(prod(K),v)%q;assert val in[0,q//2];res|=(val//(q//2))<<i
    return res
   generated=f2span([edge(v)for v in gen]);expected=set();nullcount=0
   explicit=[(2**(k-2+int(k==2)),prod(K))for k in range(2,min(r+1,ny)+1)for K in itertools.combinations(range(ny),k)]
   for v in itertools.product(range(q),repeat=m):
    ok=all(c*dot(a,v)%q==0 for c,a in explicit)
    assert ok==all(dot(row,v)%q==0 for row in B)
    if ok:expected.add(edge(v));nullcount+=1
   assert generated==expected
   records.append({'support_size':m,'outside_size':ny,'r':r,'kernel_generators':len(gen),'enumerated_kernel_cardinality':nullcount,'binary_image_cardinality':len(expected)})
out={'status':'passed','records':records,'scope':'36 finite exact comparisons of kernel generators and binary images against exhaustive multiplicity enumeration. Supports a separate polynomial bit-complexity proof; does not by itself verify the entire sourced LU reduction.'}
(R/'graph-image-checks-rerun.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','cases':len(records)}))
