"""Analyze the frozen Haar grid; error bars are pointwise Monte Carlo SEs."""
from pathlib import Path
import collections, csv, json, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parents[1]/'results'
OUT=BASE/'haar-tv-results'
s=json.loads((OUT/'summary.json').read_text())
lookup={(x['m'],x['n'],x['eta'],x['r'],x['T'],x['mode']):x for x in s}
groups=collections.defaultdict(list)
for row in csv.DictReader((OUT/'moments.csv').open()):
    key=tuple(float(row[k]) for k in ('m','n','eta','r'))
    groups[key].append((float(row['weighted_squared_error']),float(row['predicted_Haar_mean'])))
moments=[]
for key,vals in groups.items():
    a=np.array(vals); mean=float(a[:,0].mean());se=float(a[:,0].std(ddof=1)/len(a)**.5);pred=a[0,1]
    moments.append(dict(zip(['m','n','eta','r'],key),draws=len(a),mean=mean,se=se,predicted=pred,z=None if se<1e-12 else (mean-pred)/se))
nonzero=[x for x in moments if x['z'] is not None]
colors=['#0072B2','#009E73','#D55E00','#CC79A7']
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
fig,axs=plt.subplots(2,2,figsize=(10.2,7.2),layout='constrained')
for col,m in enumerate((4,5)):
    for eta,c in zip((.25,.5,.75,.9),colors):
        vals=[lookup[m,4,eta,r,0,'ideal'] for r in range(5)]
        axs[0,col].errorbar(range(5),[x['mean_TV'] for x in vals],yerr=[2*x['standard_error'] for x in vals],color=c,marker='o',ms=4,capsize=2,label=fr'$\eta={eta}$')
        ts=(1,4,16,64,256);vals=[lookup[m,4,eta,4,t,'full'] for t in ts]
        axs[1,col].errorbar(ts,[x['mean_TV'] for x in vals],yerr=[2*x['standard_error'] for x in vals],color=c,marker='o',ms=4,capsize=2,label=fr'$\eta={eta}$')
    axs[0,col].set(title=fr'Ideal harmonic truncation: $(m,n)=({m},4)$',xlabel='Retained harmonic degree r',ylabel='Mean full-output TV',xticks=range(5),ylim=(-.01,.36))
    axs[1,col].set(title=fr'Randomized sampler: $(m,n)=({m},4)$, $r=4$',xlabel='Color collections T',ylabel='Mean conditional TV',xscale='log',yscale='log')
    axs[1,col].set_xticks(ts,labels=[str(t) for t in ts])
    for ax in axs[:,col]:ax.grid(alpha=.2)
axs[0,0].legend(ncol=2,frameon=False,fontsize=9)
fig.savefig(OUT/'haar-tv-curves.pdf');fig.savefig(OUT/'haar-tv-curves.png');plt.close(fig)
fig,ax=plt.subplots(figsize=(6.2,4.6),layout='constrained')
for m,n,c in [(2,2,colors[0]),(3,3,colors[1]),(4,3,colors[2]),(6,3,colors[3]),(4,4,'#555555'),(5,4,'#E69F00')]:
    vals=[x for x in nonzero if (x['m'],x['n'])==(m,n)]
    ax.errorbar([x['predicted'] for x in vals],[x['mean'] for x in vals],yerr=[2*x['se'] for x in vals],fmt='o',ms=3,capsize=2,color=c,alpha=.7,label=fr'$({m},{n})$')
ax.plot([1e-4,2],[1e-4,2],color='black',lw=1,ls='--')
ax.set(xscale='log',yscale='log',xlabel='Exact predicted Haar second moment',ylabel='Monte Carlo mean second moment',title='Independent reduction-projector construction')
ax.legend(title='(m,n)',ncol=2,frameon=False);ax.grid(alpha=.2)
fig.savefig(OUT/'haar-moments.pdf');fig.savefig(OUT/'haar-moments.png');plt.close(fig)
report={'nonzero_moment_cells':len(nonzero),'max_absolute_moment_z':max(abs(x['z']) for x in nonzero),'multiple_comparisons_note':'Cells reuse the same Haar draws, so the 76 residuals are correlated; SE bars are pointwise, not simultaneous confidence guarantees.','largest_mean_TV_minus_analytic_bound':max(x['mean_TV']-min(1,x['theoretical_mean_TV_bound']) for x in s),'ideal_r_equals_n_max_mean_TV':max(x['mean_TV'] for x in s if x['mode']=='ideal' and x['r']==x['n']),'selected_rows':[x for x in s if x['m']==x['n']==4 and x['eta'] in (.5,.9) and ((x['mode']=='ideal' and x['r'] in (2,3)) or (x['mode']=='full' and x['r']==4 and x['T'] in (1,16,256)))],'raw_sha256':hashlib.sha256((OUT/'raw.csv').read_bytes()).hexdigest(),'moments_sha256':hashlib.sha256((OUT/'moments.csv').read_bytes()).hexdigest()}
(OUT/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'moment-summary.json').write_text(json.dumps(moments,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='selected_rows'},indent=2))
