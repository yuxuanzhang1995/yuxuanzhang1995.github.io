"""Finite controls for a proposed decoder-dimension packing lemma, not a proof."""
import json
from pathlib import Path
import numpy as np
from scipy.linalg import expm
D=Path(__file__).resolve().parent;rng=np.random.default_rng(54491)
def kraus(din,dout,count):
 a=rng.normal(size=(count,dout,din))+1j*rng.normal(size=(count,dout,din));g=np.einsum('kai,kaj->ij',a.conj(),a);l,u=np.linalg.eigh(g);g=(u*(1/np.sqrt(l)))@u.conj().T
 return [v@g for v in a]
tau=np.diag([.4,.2,.4]);root=np.diag(np.sqrt(np.diag(tau)));psi=root.reshape(-1)
v0=np.diag([np.sqrt(2/3),np.sqrt(1/3),0]).reshape(-1);v1=np.diag([0,0,1]).reshape(-1);P=np.outer(v0,v0)+np.outer(v1,v1)
Y=np.array([[.2,.3j,0],[-.3j,-.1,0],[0,0,.4]]);J=np.linalg.norm(Y,2);rows=[]
for s in [.03,.2]:
 F=expm(-s*Y/2);phi=np.kron(np.eye(3),F)@psi;z=float(np.vdot(phi,phi).real);phi/=np.sqrt(z)
 qs=[float(np.sum(abs(phi.reshape(3,3)[:,idx])**2))for idx in [[0,1],[2]]];ratio=max(qs[0]/.6,qs[1]/.4)
 for m in [1,2]:
  for trial in range(4):
   E=kraus(3,m,3);Ds=kraus(m,3,3);sigma=sum(np.outer(v,v.conj())for A in Ds for B in E for v in [np.kron(A@B,np.eye(3))@phi])
   overlap=float(np.trace(sigma@P).real);bound=ratio*m*.4
   assert overlap<=bound+1e-10
   rows.append(dict(s=s,m=m,trial=trial,overlap=overlap,packing_bound=bound,block_ratio=ratio,exponential_ratio_bound=float(np.exp(2*s*J))))
out={'scope':'Finite controls only; no all-n statement inferred','rows':rows,'classical_SN_pitfall':{'m':1,'uniform_binary_actual_best_replacer_overlap':.5,'SN1_perfect_classical_correlation_overlap':1.,'reason':'Schmidt number alone loses classical memory cost; use encoder-decoder factorization and Tr D(I)=m.'}}
(D/'ki-packing-pilot.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'tests':len(rows),'all_passed':True,'source':'coordinator-proposed Kraus Cauchy-Schwarz lemma'},indent=2))
