# A three-qubit counterexample to the ordinary Petz recovery bound

Author: Yuxuan Zhang

Affiliations:

- Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland
- Department of Physics, Princeton University, Princeton, New Jersey 08544, USA

This archive contains the five-page manuscript, its editable LaTeX source, and the programs and results supporting its counterexample. The state is defined by the exact decimal coefficients printed in the manuscript, followed by explicit trace normalization.

## Contents

- `petz_cmi_article.pdf`: the manuscript, including references.
- `petz_cmi_article.tex`: self-contained REVTEX 4.2 source; references are included directly.
- `reproducibility/verify_from_printed_coefficients.py`: direct recovery, the rank-two fidelity formula, rotations, white-noise examples, and 50/80-digit computations.
- `reproducibility/choi_implementation.py`: the separate Choi construction supplied with the original candidate; its external-JSON entry point has been removed.
- `reproducibility/certify_counterexample.py`: exact-rational acceptance checks with explicit matrix-function and logarithm error bounds.
- `reproducibility/run_verification.py`: runs all the above checks from the printed coefficients.
- `reproducibility/*.json`: saved numerical results, the Choi comparison, and the certificate bounds.

## Reproduce the result

The complete reproducibility run was tested with Python 3.13 and the pinned dependencies below; no external state file is required.

```bash
python -m pip install -r reproducibility/requirements.txt
python reproducibility/run_verification.py
```

Run without Python's `-O` option: the certificate's assertion checks must remain enabled. Results are written beside the scripts.

The numerical result is approximately:

```text
I(A;B|C)      =  0.067098066457156731 bits
-log2 F      =  0.071379762699210688 bits
gap           = -0.004281696242053957 bits
```

The exact-arithmetic certificate, with outward decimal rounding, gives:

```text
-0.00428169624320 <= gap <= -0.00428169624091 < 0
```

Floating-point and arbitrary-precision routines only propose eigenvalue intervals and rational matrix approximants for the certificate. Characteristic-polynomial signs, positivity and residual bounds are then checked with exact rational arithmetic. Logarithms are enclosed by a finite rational series and an explicit remainder bound. White-noise and rotated-map diagnostics are numerical evaluations, separate from the certified counterexample.

## Build the paper

A TeX installation with REVTEX 4.2, amsmath, amsthm, mathtools, booktabs, microtype, xcolor and hyperref is sufficient. There are no external figures or bibliography databases.

```bash
pdflatex -interaction=nonstopmode -halt-on-error petz_cmi_article.tex
pdflatex -interaction=nonstopmode -halt-on-error petz_cmi_article.tex
```

The model attribution in the last sentence of the abstract is included as requested by the author. The affiliations are reproduced from the author's supplied text.
