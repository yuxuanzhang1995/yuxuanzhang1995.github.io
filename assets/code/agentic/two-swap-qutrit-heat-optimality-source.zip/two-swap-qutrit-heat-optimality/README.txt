Certified global heat optimality of two full swaps for a qutrit cooling task
Yuxuan Zhang — version 1, 22 October 2026
Affiliations: EPFL first; Princeton University second, as shown in the manuscript.

main.tex is the complete standalone paper; manuscript.pdf is its reviewed export.
Build: pdflatex main.tex, twice. Standard LaTeX packages are used.

Reproduction: install requirements.txt in a Python environment, then run python reproduce.py.
The driver verifies release-manifest.json and runs the selected unmodified checkers in a fresh temporary copy.
reproduction-results records their output. Finite controls do not prove universal analytic statements.
The seven earlier papers retain a small shared evidence snapshot so original relative checker paths remain valid.
Third-party full-text snapshots are not republished; the paper and comparison records give primary-source links.
Historical snapshot/full-candidate manifests describe the larger original local freeze and may reference files outside this selected release.
release-manifest.json is the inventory for this package. Historical proof-stage status labels remain unchanged;
the complete paper and dated independent review record are the current assessment.

Exact candidate: M08-v1. This is an exact result for the prescribed two-collision problem. It does not establish a universal optimal-schedule theorem for qutrits or higher-dimensional machines.

Internal independent-agent proof and source review found no specific unresolved blocker. This is not external peer review,
formal proof-assistant certification, or an exhaustive priority guarantee. Website release only; no archive or submission is implied.
