# Evidence-mapped outline — random Pauli rotations, n = 4 (drafting stage 1; prose in pauli-rotation-gap.tex)

Evidence classes: E# = external source (EVIDENCE.json); K = checker line tag of `check_pauli_rotation_gap.py`;
R49 = the round-49 isolated adversarial review; O49 = the orchestrator's independent 255-Pauli check (round 49);
I = internal rounds 45 and 48 (context only, not relied on); P = proved in the manuscript.

| ID | Claim | Type | Evidence |
|---|---|---|---|
| C01 | Walk, K_n, Delta_n on L^2_0(SU(2^n)), P uniform over the 4^n - 1 non-identity Paulis, exactly as in the record | declaration | E1; E2 (Def. 1.1, RPR definition) |
| C02 | Baer-Haah bounds (Thm 3.16, Prop. 3.17); at n = 4: 1/15 <= Delta_4 <= 26/255; Delta_3 = 5/63 | factual | E2; K [B1] |
| C03 | Conj. 3.48: the upper bound is the exact gap, tight irrep (1^4,0^{2^n-8},-1^4); their numerics used tau_{4,4}, n <= 3 | factual | E2; R49 |
| C04 | Baer-Haah's gap is an infimum over ALL finite-dimensional unitary representations, equal to the record's Delta_n, so unbalanced irreps count | factual + result | E2 (Def. 1.1); P (reduction lemma); R49 |
| C05 | Reduction: tr P = 0 so e^{i theta P} in SU(d); integer charges since e^{2 pi i P} = 1; K_n acts on the lambda-block as M_lambda = E_P Pi_0^P (x) 1 | result | P (Lemma 2); E5; R49 |
| C06 | The 30 affine hyperplanes; w = sum_A e_A in ascending binary order | declaration / result | P; K [W1] |
| C07 | Z-type counting: for Z^s exactly 28 of 30 hyperplanes are neutral (normal != s) | result | P (Lemma 3); K [W2]; R49 |
| C08 | Order lemma: echelon coordinates are order isomorphisms; AGL(3,2) < A_8; affine bijections map e_A to +e_A'; bit-reversed and Gray orders give the same w exactly | result | P (Lemma 4); K [W3], [W4], [N2]; R49 (sign attack, "same w up to sign") |
| C09 | RM(1,3) is self-dual; hence Lambda^8(sqrt2 H_0) w = 16 w | result | P (Lemma 5, Prop. 6); K [W5], [W6] |
| C10 | Lambda^8(S_j) w = w, Lambda^8(CNOT_jk) w = w, Lambda^8(H_j) w = w | result | P (Prop. 6); K [W6]; R49 (Cauchy-Binet over all 12870 coordinates) |
| C11 | Local Clifford reduction P -> Z^{supp P}; <w, Pi_0^P w> = 28 for all 255 P; Rayleigh quotient 14/15 | result | P (Prop. 7); K [W7], [W8]; R49 (routes X and Y, all 255 P); O49 (8x8 minors in each P's eigenbasis, all 255 P) |
| C12 | Upper bound ||M_lambda|| <= 14/15: Casimir sum_P H_P^2 = 1088 and max charge 8; independently the selection lemma with v = 3 | result | P (Prop. 8, Lemma 10); K [W10], [S1], [S2]; R49 (Lanczos: top 14/15, next 193/255) |
| C13 | Theorem 1: M w = (14/15) w, ||M_lambda|| = 14/15, Delta_4 <= 1/15 < 26/255, Delta_4 = 1/15 with Thm 3.16 | result | C05-C12, E2; K [W9] (Lie route, all 255 P, exact), [T]; R49; O49 |
| C14 | Explicit eigenfunction f(U) = sum_A det U[A,B0]: K_4 f = (14/15) f, Haar mean 0, f(1) = 1 for B0 = {0,...,7} | result | P (Cor. 9); K [E1] (floating point); R49 (three Haar-random U) |
| C15 | Selection lemma: v = nu_2(|lambda| mod 2^n) < n gives ||M_lambda|| <= (2^n - 2^{n-v})/(2^n - 1) (Walsh divisibility + Bose-Burton) | result | P (Lemma 10); E4; K [S1], [S2]; R49 (line by line) |
| C16 | Corollary: for n >= 3 every irrep with 8 not dividing |lambda| satisfies the conjectured bound strictly; the v = 3 bound does not | result | P (Cor. 11); K [S4] |
| C17 | Sharpness: equality for Lambda^2 C^d (all n), Lambda^4 C^8 (n = 3), Lambda^8 C^16 (n = 4) | result | P (Remark 12, Casimir for Lambda^2); K [S3]; R49 (spot checks) |
| C18 | Controls: Lambda^4 code vector gives 58/63 (n = 3) and 229/255 = 1 - 26/255 (n = 4) with the same charge conventions | control | K [C1], [C2]; I (round 48) |
| C19 | Negative controls: random signs and non-affine orders give quotients near 0.6; non-hyperplane 8-sets have at most 11 neutral Z-charges | control | K [N1], [N2], [N3]; R49 (3000 sign patterns <= 0.785; random orders 0.49-0.65) |
| C20 | Scope: Lambda^8 C^16 is unbalanced (centre acts by -1); PU(2^n)/design version at n = 4 open; Delta_n for n >= 5 open; 1/(2^n - 1) meets the Baer-Haah lower bound only at n = 4 | declaration + result | P (Section 5); K [B1] |
| C21 | Novelty: Baer-Haah v1 is the only version and conjectures the opposite; Haah-Liu-Tan concerns balanced moments; no forward-citation sweep | factual (search-limited) | E2, E3; R49 |
| C22 | Review status: AI review only (one isolated adversarial review plus the orchestrator's check); no human expert review | declaration | INTERNAL_REVIEW.json |
