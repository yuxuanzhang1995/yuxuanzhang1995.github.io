# No six-qubit distance-three code admits a transversal T gate

Yuxuan Zhang. Version 1.0, 28 September 2026.
EPFL is the first affiliation and Princeton the second.

The manuscript reports a complete negative answer to QIQCOP op_ddfbbe7ca0ead0c8.
The theorem covers arbitrary local unitaries, arbitrary complex code amplitudes,
and degenerate codes. The known seven-qubit construction is attributed prior work.

Run `python3 exact-check.py` with NumPy, SciPy and SymPy installed. The tested
environment was Python 3.12.13, NumPy 2.5.3, SciPy 1.18.1 and SymPy 1.14.0.
The full run took about 30 seconds in a two-CPU, 2 GB sandbox. Linear programming
only proposes witnesses; all accepted separating inequalities are checked with
exact Python integers. An optimizer failure stops the certificate; it cannot
become an exclusion. The mathematical proof also needs the analytic reduction
and the two complex-amplitude contradictions printed in the manuscript.

`static-witness-check.py` checks the saved modulus-32 and modulus-64 witnesses
without an optimizer, regenerating coverage with `numpy_coverage.py`. Alternatively
compile `independent-gray-coverage.cpp` with a C++17 compiler and run the executable
as `./gray 32 pairs32.txt` and `./gray 64 pairs64.txt`; pass those paths with
`python3 static-witness-check.py pairs32.txt pairs64.txt`. The Gray-code program
uses a separate enumeration algorithm. Large generated pair lists are not bundled.
`boundary-controls.py` exactly checks the small-support quadratic and the published
seven-qubit positive control, including all 211 low-weight Pauli compressions.

The frozen claim and two AI review records are unchanged. The initial compiled
helper failed under the verifier's no-execution temporary-folder policy; that
operational record is preserved. The released certificate works under the same
sandbox restrictions and does not execute a compiled helper. No human peer review,
historical priority, or QIQCOP catalog acceptance is asserted.

The PDF compiled successfully in the Codex native LaTeX editor and was exported
using the existing pdflatex installation. All seven pages were visually checked.
Primary-source PDFs are not bundled; source-comparison.md identifies them and
separates their results from the claimed result. No blanket reuse license is added.
