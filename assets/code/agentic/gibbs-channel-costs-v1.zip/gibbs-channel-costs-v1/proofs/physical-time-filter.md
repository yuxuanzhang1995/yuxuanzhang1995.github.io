# Exact-cost localization with singularities away from physical time

Let \(M_0\) be the finite sector module on the actual Kraus support as in [F25](sector-retraction.md). Assume the target has a finite exact seed. Let \(G\) generate \(M_0\), let \(d\) be the number of independent lattice generators, and write \(\omega\cdot n\) for physical energy. Let \(Z\) be the closed set on the unit torus where \(G\) has less than its generic rank. Denote the actual trajectory by \(O_\omega=\{e^{it\omega}:t\in\mathbb R\}\). Its closure can be the entire torus.

**Claim.** If \(Z\cap O_\omega=\varnothing\), the optimal exact-target QFI has certified finite lower and upper brackets of any requested width. This includes singularities on the unit torus and positive-dimensional singular loci. Only a finite orbit segment matters at any one precision. The procedure searches for finite certificates that terminate under the hypothesis. It does not need to decide intersection of an infinite trajectory with a given algebraic set.

## A positive clock filter supported in a thin tube in phase space

Assume \(d\ge2\) and the entries of \(\omega\) are rationally independent. Fix \(T>0\). The compact time segment \(\{e^{it\omega}: |t|\le 2T\}\) is disjoint from \(Z\) by hypothesis, hence at a positive distance from it. There is an embedded flow box
\[
 (t,u)\longmapsto t\omega+u \pmod {2\pi\mathbb Z^d},\qquad
 |t|<T,\quad u\in\omega^\perp,\quad \|u\|<a.
\]
For sufficiently small \(a>0\) the image difference set also avoids \(Z\). To check injectivity, no nonzero period lattice vector lies on \(\mathbb R\omega\), and only finitely many period vectors can be within distance one of the compact segment with \(|t|\le 2T\). Reduce \(a\) below half their nonzero transverse distances. For the difference set also reduce it below half the distance to \(Z\).

Choose a nonzero real smooth bump \(\varphi\) supported inside \((-1,1)\) and a real transverse bump \(\psi\) supported inside the transverse box. On the torus put \(u_T(t\omega+v)=\varphi(t/T)\psi(v)\), extending by zero. It is smooth. Its normalized autocorrelation \(\kappa(\theta)=\langle u_T,u_T(\cdot+\theta)\rangle/\|u_T\|^2\) is zero on a neighborhood of \(Z\), takes value one at the identity and has nonnegative, symmetric Fourier coefficients \(k_n=|\widehat u_T(n)|^2/\sum_m|\widehat u_T(m)|^2\). Their physical mean is zero. The second moment is
\[
 \sum_n (\omega\cdot n)^2 k_n
 =\|\partial_\omega u_T\|_2^2/\|u_T\|_2^2
 =T^{-2}\|\varphi'\|_2^2/\|\varphi\|_2^2 .
\]
The transverse width cancels exactly. Thus for any desired physical variance choose \(T\) first and the transverse width second. This uses a special feature of the cost: a large coordinate support in almost energy-neutral directions carries little physical variance.

Let \(h=\sum_I d_I^*d_I\) be the sum of squared maximal minors used in F25. The associated real Laurent endomorphism \(P\) has image in \(M_0\) and acts there by \(hI\). The function \(\kappa/h\), set to zero near \(Z\), is smooth on the entire compact torus. Both functions are real and even. Their Fourier coefficients decay faster than every fixed inverse power of \(\|n\|\), by repeated integration by parts. Consequently, for arbitrarily small \(\xi,\eta>0\) there are a finite symmetric *positive* probability polynomial \(k\) and a real Laurent \(b\) such that
\[
 \operatorname{Var}_\omega(k)<\xi,\qquad a=bh,\quad a(1)=1,\qquad
 \sum_n(1+|\omega\cdot n|^2)|a_n-k_n|<\eta .
\]
Choose \(T\) with margin, truncate and renormalize the nonnegative coefficients of \(\kappa\), and truncate \(\kappa/h\) and normalize \(bh\) at one. Multiplication by the fixed finite \(h\) is bounded in this weighted sequence norm. Algebraic coefficient inputs with computable frequencies permit a search over rational symmetric probability polynomials, rational approximants to \(b\), and the exact normalization by \(b(1)h(1)\). The tested inequalities are strict. They can use the true physical variances rather than a coordinate-radius upper bound, which would lose the theorem. The nonsingular one-generator case and the remaining one-generator modules are already covered by F25.

## Exact localization without requiring closeness to a point mass

Use a branch \(f\), its mean \(\mu\), variance \(v\), the seed \(s\), and the branch bound \(A(1+v)\) of F25. For the translated pointwise window \(g_t\) of coordinate width \(L\), set \(h_t=bP(g_t f)\). The positive comparison tuple for this step is \(k*(g_t f)\). It need not be close to \(g_t f\). Put \(D=bP-kI\). Since \(Df=(a-k)*f\),
\[
 h_t(n)-[k*(g_tf)]_n =
 g_t(n)[(a-k)*f]_n+
 \sum_j D_j\{g_t(n-j)-g_t(n)\}f_{n-j}.
\]
The sum of the weighted norms of these errors over \(n,t\) is at most \(A(1+v)(2\eta+K_D/L)\), where \(K_D=4\sum_j\|D_j\|\,\|j\|_1(1+|\omega\cdot j|^2)\). The repair at each site uses the positive seed \(s_0\succeq\lambda I\) as in F25. Before repair the sum of the localized branches is \(a*f\). Its total is exactly that of \(f\), and its probability second moment about \(\mu\) is at most \(v+\xi+2\eta(1+v)\), by comparison to the positive convolution \(k*f\). Every repaired packet satisfies the exact sector equations. On ensemble summation the repair adds a nonnegative multiple of the target to the unnormalized aggregate; normalizing gives the exact original target.

For a seed QFI upper bound \(B\) and seed second-moment constant \(K_s\) from F25, the bracket around \(C_{L+R}\), the minimum in enlarged boxes, is
\[
 C_{L+R}-
 \left[4\xi+8\eta(1+B/4)+
 \frac{4K_s A(1+B/4)}{\lambda}(2\eta+K_D/L)\right]
 \ \le\ F_c^0(\Phi)\ \le\ C_{L+R}.
\]
\(R\) is the coordinate enlargement by the supports of \(bP,k,s\). Choose \(\xi,\eta\) before \(L\). A branch-dependent energy translation does not affect this bound. The cutoff can be extremely large when the trajectory passes near the singular set.

## Obstruction and explicit singular control

For this scalar-multiplier argument avoidance of the *actual* trajectory is also necessary at arbitrary precision. If \(e^{it_0\omega}\in Z\), then \(a(e^{it_0\omega})=0\). Closeness in weighted coefficient norm implies \(|k(e^{it_0\omega})|\le\eta\). For a distribution of physical variance \(v\) about \(\mu\), the real part of its centered characteristic function is at least \(1-t_0^2v/2\), by the cosine inequality. For \(t_0\ne0\) this imposes \(v\ge 2(1-\eta)/t_0^2\); at \(t_0=0\) it contradicts normalization directly. This is an obstruction to the filter proof. A physical channel can have zero optimal cost even when its unreduced module has such a singularity.

The Laurent row \((x+1,y-1)\) has syzygy column \((1-y,x+1)^{\mathsf T}\). Its rank drops at \(x=-1,y=1\), with an entire third-character circle if a third variable is included. For \(\omega=(1,\sqrt2,\sqrt3)\) this set misses every actual time: \(t\) would be an odd multiple of \(\pi\), whereas \(t\sqrt2\) would be an even multiple of \(\pi\). For this example a finite even probability supported at \(0,\pm(p,-q,0)\), with masses \(1/2,1/4,1/4\), vanishes at the whole bad circle whenever \(p\) is odd. Pell approximants \(p^2-2q^2=\pm1\) give such filters with variance \((p-\sqrt2 q)^2/2\to0\). Their coefficient distance from a point mass stays one. This supplies a direct nonregular test of the change of reference used above.

This control tests the algebra of the sector construction. The earlier [encoding](physical-realization.md) preserves finite feasibility under Gibbs completion; equality of the code-only and flagged-channel optimal costs was never assumed. The general quantified bound in this note is derived directly for the actual sector module of the channel. The outstanding case for this method is a rank loss on the physical orbit.
