# Optimal precision dependence of low-energy Hamiltonian simulation

Yuxuan Zhang. Research draft dated 21 September 2026.

This is the manuscript for the eighth full-scope internally reviewed candidate in the project, first obtained in round 23. It is **not an externally confirmed solution**.

The theorem concerns exact controlled/inverse factor-block-encoding access, unrestricted oracle-independent gates, and phase-sensitive clean-output vector error. With T=t*lambda, s=t*Delta, L=log(1/epsilon), the claimed optimal query complexity is Theta(sqrt(T*L/log(2+L/s))) whenever epsilon=o(s), s=o(L), and L=o(T), with epsilon tending to zero.

## Read or edit

- `manuscript.pdf`: reading copy (included in the portable ZIP).
- `manuscript.tex`: complete editable LaTeX, including references.
- `claims.csv` and `source-manifest.json`: evidence mapping; human verification remains pending.
- `analytical-review.md`: mathematical transcription review and boundaries.
- `reproducibility/`: finite diagnostics and recorded results.

Public research note: https://yuxuanzhang1995.github.io/agentic-research/low-energy-precision/

The source manifest records public references and hashes/locators for local historical evidence snapshots. Those snapshots and raw model transcripts are not redistributed in this archive. The self-contained proof and reproducibility code are included.

## Build

With a standard TeX Live installation, run twice:

```sh
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex
```

No external bibliography processor or network access is required to compile.

## Reproduce finite diagnostics

Install the two versions in `reproducibility/requirements.txt` in a disposable Python environment, then run:

```sh
python reproducibility/check_formulas.py
```

This regenerates `reproducibility/diagnostic-results.json`. The fixed seed is 20260921. The checks cover 1,854 polynomial samples at 160 decimal digits, 9 general complex factor encodings, 5 unitary degree-stripping examples, and 8 circuit polynomialization examples. They do not prove the uniform theorem.

## Preparation and review status

The K-Dense scientific-writing skill was applied from project-pinned commit 330c8e764435a731eff571e3efdda70b363d0792. The Scientific Agent Skills paper is credited in Appendix A and reference [5]. PDF production used LaTeX for mathematical typesetting and rendered-page inspection.

Author: Yuxuan Zhang; EPFL first, Princeton second. AI assistance includes the outer coordinating assistant and the research/review model contexts. Human source verification, independent expert confirmation, exhaustive publication priority, and final author approval remain pending. Funding, competing interests, and venue declarations are not inferred. No new research API campaign or public posting was performed to prepare this draft.

## Public posting

The author authorized public posting of this research draft on 21 September 2026. Posting does not assert independent expert confirmation, formal verification, exhaustive priority checking, or journal submission readiness. The PDF and mathematical source are unchanged from the reviewed manuscript-preparation version.
