"""Mathematical controls from the integrated internal review."""

from fractions import Fraction
import sympy as sp

# A Gibbs-preserving X-basis measurement. CP domination proves the uniform
# upper bound on channel distance, including all reference inputs.
I = sp.eye(2)
Z = sp.diag(1, -1)
plus, minus = (sp.Matrix([1, s])/sp.sqrt(2) for s in [1, -1])
effects = [v*v.H for v in [plus, minus]]
J = sum((sp.kronecker_product(E, I[:, i]*I[:, i].H) for i, E in enumerate(effects)),
        sp.zeros(4))
assert J**2 == J and (sp.eye(4)-J).eigenvals() == {1: 2, 0: 2}
assert all(sp.trace(E*Z) == 0 for E in effects) and sp.trace(Z**2) != 0
q = sp.symbols("q", real=True)
assert [sp.trace(E*sp.diag(q, 1-q)).simplify() for E in effects] == [sp.Rational(1, 2)]*2

# The orthogonality variance bound is sharp for a pair of energies at +/-1/2
# at time pi. Coinciding preparation laws destroy the obligatory residual zero.
y = sp.symbols("y", real=True)
barrier = y**2 + sp.pi*sp.cos(y) - sp.pi**2/4
assert barrier.subs(y, sp.pi/2) == 0 and sp.diff(barrier, y).subs(y, sp.pi/2) == 0
assert sp.simplify((sp.exp(sp.I*sp.pi/2)+sp.exp(-sp.I*sp.pi/2))/2) == 0
phase = (-3+4*sp.I)/5
assert sp.simplify((phase+1/phase+sp.Rational(6, 5))**2) == 0
zx, zy = sp.symbols("zx zy", nonzero=True)
same_preparation = 2+zx+1/zx+(zy+1/zy+sp.Rational(6, 5))**2
common_clock = same_preparation/same_preparation.subs({zx: 1, zy: 1})
residual = sp.cancel(common_clock/(same_preparation/same_preparation.subs({zx: 1, zy: 1})))
assert sp.simplify(common_clock.subs({zx: -1, zy: phase})) == 0
assert residual.subs({zx: -1, zy: phase}) == 1

# Two independent Fejer phases. The correlation matrix of translated boxes is
# PSD globally and retains all phase cross terms. Unweighted full moment
# restoration need not preserve PSD once one harmonic is replaced alone.
locations = [(0, 0), (1, 0), (0, -1), (1, 1)]
width = 4
support = [(i, j) for i in range(-1, width+1) for j in range(-1, width+1)]
F = sp.Matrix(len(support), len(locations), lambda k, l:
              int(all(0 <= support[k][t]-locations[l][t] < width for t in (0, 1))))
D = sp.Matrix(len(locations), len(locations), lambda i, j:
              sp.prod(max(0, 1-sp.Rational(abs(locations[i][t]-locations[j][t]), width))
                      for t in (0, 1)))
assert D == F.H*F/width**2 and D.is_positive_definite
bad = D.copy()
bad[0, 1] = bad[1, 0] = 2
assert bad[:2, :2].det() < 0

# A qutrit work check from the Kraus products alone, at H=0.
e = sp.eye(3)
K = [(e[:, i]*e[:, j].T-e[:, j]*e[:, i].T)/sp.sqrt(2)
     for i, j in [(0, 1), (1, 2), (2, 0)]]
assert sum((v.H*v for v in K), sp.zeros(3)) == e
assert sum((v*v.H for v in K), sp.zeros(3)) == e
basis = sp.Matrix.hstack(*[(u.H*v).reshape(9, 1) for u in K for v in K])
assert basis.det() != 0
assert Fraction(9, 8) < 3

# Uniform ladders: a fixed shift isometry on the occupied interior costs a
# vanishing boundary fraction at infinite temperature, for either sign.
for length in (3, 7, 16):
    for direction in (-1, 1):
        v = sp.Matrix(length, length, lambda i, j: int(i == j+direction))
        assert sp.trace(sp.eye(length)-v.H*v) == 1
        assert sp.diag(*range(length))*v-v*sp.diag(*range(length)) == direction*v
print("Cross-checks passed for the entangled-input covariance threshold, orthogonality "
      "variance, two-phase positive tail and mutation, qutrit rank ratio, and both ladder directions.")
