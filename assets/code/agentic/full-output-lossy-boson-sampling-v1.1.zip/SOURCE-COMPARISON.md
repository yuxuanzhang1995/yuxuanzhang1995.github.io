# Source comparison: full-output lossy boson sampling, version 1.1

Checked 31 October 2026 against primary sources. The comparisons below concern stated theorems and proof interfaces; they do not establish exhaustive worldwide priority.

| Source and checked location | Relation to this manuscript |
| --- | --- |
| [QIQC Open Problem Zoo, op_d436ff9fb9cb0ce5](https://qiqc-op.com/problem/op_d436ff9fb9cb0ce5/), original statement | Fixed rational transmission, every m≥n, full Fock outcomes, Haar-average total variation, polynomial accuracy dependence and input-precision allowance. The catalog is a source for the question, not proof of novelty or acceptance. |
| [Aaronson–Arkhipov, arXiv:1011.3245](https://arxiv.org/abs/1011.3245) | Foundational boson-sampling model and complexity motivation. |
| [Kalai–Kindler, arXiv:1409.3093v1](https://arxiv.org/html/1409.3093v1) | Low-degree approximation under Gaussian matrix noise, a different noise model from independent photon loss. |
| [Renema–Shchesnovich–García-Patrón, arXiv:1809.01953v2](https://arxiv.org/html/1809.01953v2), interference-order expansion and sampling discussion | Truncation of many-particle interference with noise and loss. Their probability approximation and Metropolis sampling motivate, but do not supply, the present full-output marginal oracle. |
| [Shchesnovich, arXiv:1902.02258v3](https://arxiv.org/html/1902.02258v3) | Gaussian noise related to partial distinguishability and loss compensated by dark counts. The physical noise model differs. |
| [Oszmaniec–Brod, arXiv:1801.06166v1](https://arxiv.org/html/1801.06166v1) | Efficient approximation when sufficiently few photons survive, and implications for lossy optical networks. This stronger-loss regime does not give the fixed-transmission claim here. |
| [García-Patrón–Renema–Shchesnovich, arXiv:1712.10037v3](https://arxiv.org/html/1712.10037v3) | Architecture- and depth-dependent attenuation; deep-circuit thermal approximation and shallow-circuit tensor-network methods. Distinct from a fixed-transmission theorem with Haar-average error for every m≥n. |
| [Go–Jeong, arXiv:2610.27065v1](https://arxiv.org/html/2610.27065v1), Section IX, Corollary 4; Section XI | Closest full-output simulation theorem: with N input photons and k survivors, M≥C₀k²N and M≥C_Bk²/(εδ). These exclude comparable mode/photon counts. Section XI explicitly identifies that extension. The present mean-error claim converts to a high-probability claim by Markov at tolerance εδ. |
| [Arkhipov–Kuperberg, arXiv:1106.0849](https://arxiv.org/abs/1106.0849) | Bosonic birthday effect and the onset of collisions; background to dilute-output approximations. |
| [Nezami, arXiv:2104.06423v1](https://arxiv.org/html/2104.06423v1), Sections 1.4 and 5 | Exact representation-theoretic formulas for moments of permanents of Haar-unitary submatrices. Exact Haar methods are established prior work. |
| [Arienzo–Grinko–Kliesch–Heinrich, arXiv:2408.11111v2](https://arxiv.org/html/2408.11111v2), Lemma T1 / Proposition B2; Lemma T3 / Theorem T4 | Imported operator-sector decomposition and number-measurement frame; eigenvalue written here as 1/(D_l+D_{l−1}). |
| [Mhiri et al., arXiv:2604.14323v1](https://arxiv.org/html/2604.14323v1), Proposition 2, Corollary 1 and Section IV | Haar second moments through irreducible projection norms, with anti-concentration beyond the dilute regime. Loss is listed as a further direction. The present manuscript applies compatible reductions to loss and supplies the sampling interface. |
| [Alon–Yuster–Zwick, Color-coding](https://www.math.tau.ac.il/~nogaa/PDFS/col5.pdf) | Original random-color method. Here colorful input subsets and singleton output supports receive their inverse inclusion probabilities. |
| [Bremner–Montanaro–Shepherd, arXiv:1610.01808v4](https://arxiv.org/html/1610.01808v4), Section 3.2, Lemma 10 and Appendix B; Go–Jeong, Lemma 8 | Signed-prefix sampling antecedents. The proof here uses a normalized signed law, a finite output alphabet and an explicit marginal-perturbation bound; it does not identify its constant with the differently normalized BMS lemma. |
| Go–Jeong, Section VII and Appendix B | Color-coding and inverse-determinant evaluation framework. The present coefficient identity retains both harmonic projections, singleton spectators and heavy-mode multiplicities. |

The proposed contribution is the combination of the exact particle-reduction loss estimate with a collision-resolving compatible marginal evaluator at arbitrary mode density. Neither the sectorwise Haar method, color coding nor signed-prefix sampling is claimed as new by itself. The added accuracy-cost table unpacks bounds already used by the construction; it is not a performance benchmark.

No catalog report or archival submission is part of this website revision. The specific source comparisons above have been checked; independent expert validation and comprehensive priority confirmation remain pending.
