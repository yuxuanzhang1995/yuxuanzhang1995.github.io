"""Exact finite controls for the Q274 direct-transfer addendum.

This is an author-written supplementary checker, not a global proof or an
independent review. A finite, moment-matching distribution verifies the complex
Gaussian identities without Monte Carlo or numerical tolerances.
"""

from fractions import Fraction
from itertools import product
from pathlib import Path
from random import Random
import json

import sympy as s


checks = []
mutations = []


def require(name, condition):
    assert bool(condition), name
    checks.append(name)


def equal(a, b):
    return (a - b).applyfunc(s.expand).is_zero_matrix is True


def zero(n):
    return s.zeros(n, n)


def exact_matrices(n, count, seed):
    rng = Random(seed)
    return [s.Matrix(n, n, lambda i, j: rng.randrange(-2, 3)
                     + s.I * rng.randrange(-2, 3)) for _ in range(count)]


def kron(a, b):
    return s.kronecker_product(a, b)


# g=0 with probability 1/2, and g=sqrt(2)*phase for each of four phases
# with probability 1/8. Its moments through degree four match a standard
# circular complex Gaussian. The sqrt(2) disappears in each quadratic Z.
phase_law = [(s.Integer(0), s.Rational(1, 2))]
phase_law += [(z, s.Rational(1, 8)) for z in [s.Integer(1), -s.Integer(1), s.I, -s.I]]
require('coordinate_mean', sum(w*z for z, w in phase_law) == 0)
require('coordinate_pseudovariance', sum(w*2*z*z for z, w in phase_law) == 0)
require('coordinate_variance', sum(w*2*z*s.conjugate(z) for z, w in phase_law) == 1)
require('coordinate_fourth', sum(w*4*(z*s.conjugate(z))**2 for z, w in phase_law) == 2)

cases = []
for case_id, da, db, count in [('complex_equal', 2, 2, 3),
                              ('complex_rectangular', 2, 3, 3),
                              ('row_column_separation', 2, 2, 2)]:
    if case_id == 'row_column_separation':
        aa = [s.Matrix([[1, 0], [0, 0]]), s.Matrix([[0, 1], [0, 0]])]
        bb = [a.copy() for a in aa]
    else:
        aa = exact_matrices(da, count, 274 + da)
        bb = exact_matrices(db, count, 511 + db)
    dd = da * db
    w = sum((kron(a, b) for a, b in zip(aa, bb)), zero(dd))
    ez, ezz, ezstar, wrong_mean = [zero(dd) for _ in range(4)]
    mass = s.Integer(0)
    for choices in product(phase_law, repeat=count):
        phases = [z for z, _ in choices]
        weight = s.prod(v for _, v in choices)
        ap = sum((z*a for z, a in zip(phases, aa)), zero(da))
        bp = sum((s.conjugate(z)*b for z, b in zip(phases, bb)), zero(db))
        bp_wrong = sum((z*b for z, b in zip(phases, bb)), zero(db))
        zmat = 2*kron(ap, bp)
        ez += weight*zmat
        ezz += weight*(zmat*zmat.adjoint())
        ezstar += weight*(zmat.adjoint()*zmat)
        wrong_mean += weight*2*kron(ap, bp_wrong)
        mass += weight
    ar = sum((a*a.adjoint() for a in aa), zero(da))
    ac = sum((a.adjoint()*a for a in aa), zero(da))
    br = sum((b*b.adjoint() for b in bb), zero(db))
    bc = sum((b.adjoint()*b for b in bb), zero(db))
    require(case_id + ':probability_mass', mass == 1)
    require(case_id + ':mean', equal(ez, w))
    require(case_id + ':left_second_moment', equal(ezz, w*w.adjoint()+kron(ar, br)))
    require(case_id + ':right_second_moment', equal(ezstar, w.adjoint()*w+kron(ac, bc)))
    require(case_id + ':centered_left', equal(ezz-w*w.adjoint(), kron(ar, br)))
    require(case_id + ':centered_right', equal(ezstar-w.adjoint()*w, kron(ac, bc)))
    require(case_id + ':nonzero_target', not equal(w, zero(dd)))
    require(case_id + ':wrong_conjugation_detected', not equal(wrong_mean, w))
    require(case_id + ':omitted_WWstar_detected', not equal(ezz, kron(ar, br)))
    cases.append({'case': case_id, 'local_dimensions': [da, db],
                  'factors': count, 'quadrature_points': 5**count,
                  'arithmetic': 'exact Gaussian integers and rational weights'})
    if case_id == 'row_column_separation':
        require('column_only:both_column_sums_identity', ac == s.eye(2) and bc == s.eye(2))
        require('column_only:left_moment_eigenvalue_six', ezz == s.diag(6, 0, 0, 0))
        require('column_only:claimed_two_bound_false', ezz[0, 0] > 2)
        mutations.append('Using only column bounds in the two-sided variance estimate fails: 6 > 2.')

mutations.extend([
    'Removing conjugation from B(g) gives zero mean instead of the nonzero target.',
    'Deleting WW* from the left second moment fails all three exact cases.'
])


def pow2(k):
    return Fraction(2**k, 1) if k >= 0 else Fraction(1, 2**(-k))


require('a_upper_bound', Fraction(7, 8)**4 >= Fraction(1, 2))
require('a_lower_bound', Fraction(4, 5)**4 <= Fraction(1, 2))
require('uniform_tail_constant', Fraction(32*656, 2*2**16) == Fraction(41, 256))
parameter_cases = []
for exponent in range(8):
    u = 2**exponent
    delta = pow2(1-u)
    ell = 4*u + 4*exponent + 64
    tail_upper = 32*pow2(-ell//4)*(8*ell+72)
    b_actual = 4*(2*ell+1)*(pow2(ell+1)-pow2(-ell))
    b_upper = 147*2**72*delta**(-4)*u**5
    require(f'parameter_u_{u}:tail', tail_upper <= delta)
    require(f'parameter_u_{u}:factor_bound', b_actual <= b_upper)
    require(f'parameter_u_{u}:L_inequality', ell <= 73*u)
    # A lower bound on the first omitted term refutes L=4u without padding.
    bad_ell = 4*u
    bad_tail_lower = 32*(bad_ell+1)*pow2(-u)*Fraction(4, 5)
    require(f'parameter_u_{u}:naive_L_rejected', bad_tail_lower > delta)
    parameter_cases.append({'u': u, 'delta_power_of_two': 1-u, 'L': ell,
                            'tail_upper_over_delta': str(tail_upper/delta)})
mutations.append('The naive choice L=4u fails the error target by an exact first-term lower bound.')

b, eps, r = s.symbols('b eps r', positive=True)
tau = eps/4
n_over_log = 64*b*b/(eps*eps) + 16*r/(3*eps)
require('Bernstein_explicit_sample_constant',
        s.simplify(n_over_log*tau*tau/(4*b*b+s.Rational(4, 3)*r*tau)) == 1)
require('clipping_bias_constant',
        s.simplify(2*b*b*(eps*eps/(32*b*b)) - eps*eps/16) == 0)

result = {
    'status': 'all_asserted_finite_controls_pass',
    'assertions': len(checks),
    'cases': cases,
    'parameter_cases': parameter_cases,
    'mutation_controls': mutations,
    'checks': checks,
    'limitations': [
        'Same author; no independent mathematical review.',
        'Finite exact controls do not prove the imported balancing theorem.',
        'The uniform parameter bound is justified analytically in the addendum, not by this grid.',
        'No claim of novelty, numbered-round completion or actual token usage.'
    ]
}
output = Path(__file__).with_name('direct-transfer-checks.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'assertions': len(checks),
                  'exact_cases': len(cases), 'parameter_cases': len(parameter_cases),
                  'mutation_controls': len(mutations), 'output': str(output)}))
