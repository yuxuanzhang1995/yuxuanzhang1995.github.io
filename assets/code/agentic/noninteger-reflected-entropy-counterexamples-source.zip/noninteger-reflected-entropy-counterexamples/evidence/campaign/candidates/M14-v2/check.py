"""M14 certificate: exact integer branch bounds plus validated spectral error budgets.
Numerical eigenvectors are proposals only. Their residuals and orthogonality
are checked with exact integers against square-root enclosures. See proof.txt.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,comb
import numpy as np,heapq,json,time,hashlib
from scipy.linalg import eigh_tridiagonal
import gmpy2 as mp
from rational_interval import exp_minus_half,I

OUT=Path(__file__).resolve().parent
S=10**8;Q=2**60;TICKS=2**18;R0=10;L=10;N=R0+2*L+1
qi=exp_minus_half()**2
# Compress the exact enclosure outward before taking many powers.
qs=10**50;ql=qi.lo.numerator*qs//qi.lo.denominator;qh=-((-qi.hi.numerator*qs)//qi.hi.denominator)
qi=I(F(ql,qs),F(qh,qs));q=float((qi.lo+qi.hi)/2)
masslo=(1-qi**(L+1)).lo;masshi=(1-qi**(L+1)).hi
massnum=int(masslo*S); mass=float(masshi)+1e-14
pnum=np.array([int(((1-qi)*qi**r).lo*S) for r in range(R0+1)],dtype=np.int64)
blocks=[];spectra={};M2=np.zeros((N,N));spectral_records=[]
max_ep=F(0);max_ed=F(0);max_e2=F(0);max_eu=F(0)
for k in range(2*(N-1)+L+1):
 r=np.arange(k//2+1);n=len(r);ints=[int((a+1)*(k-2*a)*(k-2*a-1)) for a in r[:-1]]
 off=np.sqrt(ints);w,v=eigh_tridiagonal(np.zeros(n),off) if n>1 else (np.zeros(1),np.ones((1,1)))
 V=np.array([[int(round(float(x)*Q)) for x in row] for row in v],dtype=object)
 W=np.array([int(round(float(x)*Q)) for x in w],dtype=object)
 Hlo=[isqrt(x*Q*Q) for x in ints]
 O=V.T@V-np.eye(n,dtype=object)*Q*Q
 eo=F(n*max(abs(int(x)) for x in O.flat),Q*Q)
 residual=0
 for i in range(n):
  for j in range(n):
   val=-V[i,j]*W[j];err=0
   if i:val+=Hlo[i-1]*V[i-1,j];err+=abs(V[i-1,j])
   if i+1<n:val+=Hlo[i]*V[i+1,j];err+=abs(V[i+1,j])
   residual=max(residual,abs(int(val))+int(err))
 er=F(n*residual,Q*Q);J=max([sum(Hlo[max(0,i-1):min(n-1,i+1)])//Q+3 for i in range(n)])
 A=max(abs(int(x)) for x in W)//Q+1
 assert eo<F(1,100) and J<1000 and A<1000 and n<=36
 eu=F(4,5)*(2*er+(J+4*A)*eo)+4*eo
 ed=J*eu+2*er; e2=J*J*eu+2*er*(J+A)
 ep=eu*(4+eu); epd=2*(2*ed+2*A*eu+eu*ed)
 ep2=2*(4*A*ed+ed*ed)+2*(2*e2+2*A*A*eu+eu*e2)
 max_ep=max(max_ep,ep);max_ed=max(max_ed,epd);max_e2=max(max_e2,ep2);max_eu=max(max_eu,eu)
 spectra[k]=(W,np.asarray(V,dtype=float)/Q)
 spectral_records.append({'K':k,'dimension':n,'orthogonality_bound':str(eo),'residual_bound':str(er),'unitary_error_bound':str(eu),'J':J})
 src=r[(r<N)&(k-2*r<=L)];dst=r[r<N];pw=(1-q)*q**(k-2*src)
 for l,p in zip(k-2*src,pw):
  exact=(1-qi)*qi**int(l);f=F.from_float(float(p));assert max(abs(f-exact.lo),abs(f-exact.hi))<F(1,10**14)
 vf=spectra[k][1];wf=np.asarray(W,dtype=float)/Q;av=abs(vf)
 a0=av@av.T;a1=(av*wf)@av.T;a2=(av*wf**2)@av.T
 M2[np.ix_(src,dst)]+=(2*(a0*a2-a1*a1)[np.ix_(dst,src)]*pw).T
 blocks.append((k,src,dst,pw))

# Includes all IEEE arithmetic, weight and MPFR-to-float errors. The numerical
# envelopes have substantial slack; see the independent arithmetic bounds.
EP=float(max_ep)+1e-8;ED=float(max_ed)+1e-5;E2=float(max_e2)+.01
assert EP<1e-6 and ED<1e-3 and E2<.1
M2+=E2
phase_cache={}
def spectral_unitary(k,t,derivative=False):
 W,V=spectra[k];phase=[]
 with mp.context(precision=160,round=mp.RoundToNearest):
  for w in W:
   x=mp.mpfr(mp.mpq(int(w)*t.numerator,Q*t.denominator))
   assert abs(x)<2**14
   phase.append(complex(float(mp.cos(x)),-float(mp.sin(x))))
 phase=np.array(phase);U=(V*phase)@V.T
 if derivative:return U,(V*(-1j*np.asarray(W,dtype=float)/Q*phase))@V.T
 return U

cache={}
def interval(lo,hi):
 key=(int(lo),int(hi))
 if key in cache:return cache[key]
 c=F(2*(int(lo)+int(hi)),5*TICKS);hh=F(2*(int(hi)-int(lo)),5*TICKS);h=float(hh)
 P=np.zeros((N,N));D=np.zeros((N,N))
 for k,src,dst,pw in blocks:
  U,Ud=spectral_unitary(k,c,True);uu=U[np.ix_(dst,src)];du=Ud[np.ix_(dst,src)]
  P[np.ix_(src,dst)]+=(abs(uu)**2*pw).T
  D[np.ix_(src,dst)]+=(2*np.real(du*uu.conj())*pw).T
 err=EP+h*(abs(D)+ED)+.5*h*h*M2+1e-7
 low=np.floor(np.maximum(0,P-err)*S).astype(np.int64)
 high=np.ceil(np.minimum(mass,P+err)*S).astype(np.int64)
 assert np.all(high>=low)
 cache[key]=(low,high);return low,high

def lower(box):
 lo,hi=box
 if int(sum(lo))>TICKS:return None
 hi=np.minimum(hi,TICKS-int(sum(lo))+lo);value=np.arange(N,dtype=np.int64)*S
 for j in range(3,-1,-1):
  low,high=interval(lo[j],hi[j]);reach=R0+j*(L//2);low=low[:reach+1];high=high[:reach+1]
  order=np.argsort(value);caps=high[:,order]-low[:,order];need=massnum-low.sum(1)
  assert np.all(need>=0) and np.all(caps.sum(1)>=need)
  before=np.cumsum(caps,axis=1)-caps;fill=np.minimum(caps,np.maximum(0,need[:,None]-before))
  # All quantities are nonnegative. Products/sums are <=30*S^2<2^63.
  new=(low@value+fill@value[order])//S
  assert int(new.max())<=30*S
  value=np.r_[new,np.zeros(N-len(new),dtype=np.int64)]
 return int(pnum@value[:R0+1])

start=time.time();queue=[];counter=0;processed=0
root=(np.zeros(4,dtype=np.int64),np.full(4,TICKS,dtype=np.int64))
heapq.heappush(queue,(lower(root),counter,root));counter+=1
threshold=2593*S*S//10000;popped=None
while queue:
 lb,_,(lo,hi)=heapq.heappop(queue)
 if lb>threshold:popped=(lb,lo,hi);break
 assert processed<60000,'Qualification cap; no certificate if this assertion fails.'
 i=int(np.argmax(hi-lo));mid=(int(lo[i])+int(hi[i]))//2;assert lo[i]<mid<hi[i]
 for side in range(2):
  a=lo.copy();b=hi.copy()
  if side:a[i]=mid
  else:b[i]=mid
  if int(sum(a))>TICKS:continue
  v=lower((a,b));heapq.heappush(queue,(v,counter,(a,b)));counter+=1
 processed+=1
 if processed%3000==0:print(json.dumps({'processed':processed,'lower':queue[0][0]/S**2,'cache':len(cache)}),flush=True)
assert popped
leaves=[(popped[0],*popped[1],*popped[2])]+[(lb,*box[0],*box[1]) for lb,_,box in queue]
np.savez_compressed(OUT/'M14-reset-cover.npz',leaves=np.array(leaves,dtype=np.int64),scale=np.array([S,TICKS]))
reset_lower=F(min(row[0] for row in leaves),S*S);assert reset_lower>F(2593,10000)

# Fixed rational retained-memory witness; full invariant sectors, three pulses.
times=[F(217,1000),F(404,1000),F(179,1000)];word=[0,1,0];LMAX=18;energy=0.;retained=0.
ucache={}
for j,t in enumerate(times):
 for k in range(2*LMAX+2):ucache[j,k]=spectral_unitary(k,t)
for e1 in range(2):
 for e2 in range(2):
  for z in range(LMAX+1):
   basis=[(r,u,z-r-u) for r in range(z+1) for u in range(z-r+1)];index={x:i for i,x in enumerate(basis)};n=len(basis)
   occupations=np.array([r for r,u,v in basis]);weights=np.array([(1-q)**3*q**(r+2*u+e1+2*v+e2) for r,u,v in basis])
   for (r,u,v),p in zip(basis,weights):
    exact=(1-qi)**3*qi**(r+2*u+e1+2*v+e2);f=F.from_float(float(p));assert max(abs(f-exact.lo),abs(f-exact.hi))<F(1,10**14)
   Ut=np.eye(n,dtype=complex)
   for j,bath in enumerate(word):
    U=np.zeros((n,n),dtype=complex)
    for spectator in range(z+1):
     rr=list(range(z-spectator+1))
     ids=[index[r,z-spectator-r,spectator] if bath==0 else index[r,spectator,z-spectator-r] for r in rr]
     K=2*(z-spectator)+(e1 if bath==0 else e2)
     U[np.ix_(ids,ids)]=ucache[j,K]
    Ut=U@Ut
   energy+=float(occupations@(abs(Ut)**2@weights));retained+=float(weights.sum())
# Missing L>18 implies initial total occupation>18. Conserved K bounds
# target energy by initial total occupation, yielding the thermal tail below.
R=LMAX;m=3
tail=(1-qi)**m*(R+1)*comb(R+m,m-1)*qi**(R+1)/(1-qi*(1+F(m,R+1)))
# At most190-dimensional products of three near-unitaries; exact spectral
# defect plus all matrix/weight/summation roundoff is far below this allowance.
memory_arithmetic=F(1,1000000)
assert float(max_eu)<1e-9
memory_upper=F.from_float(energy)+tail.hi+memory_arithmetic
assert memory_upper<F(2592,10000) and memory_upper<reset_lower
out={'status':'certificate passes','T':'4/5','reset_lower':str(reset_lower),'reset_lower_decimal':float(reset_lower),
 'memory_times':[str(t) for t in times],'memory_word':word,'memory_phases':[0,0,0],'memory_truncated_energy':energy,
 'memory_retained_mass':retained,'memory_tail_upper':str(tail.hi),'memory_arithmetic_allowance':str(memory_arithmetic),
 'memory_upper':str(memory_upper),'memory_upper_decimal':float(memory_upper),'gap_lower':str(reset_lower-memory_upper),
 'gap_lower_decimal':float(reset_lower-memory_upper),'processed_boxes':processed,'cover_leaves':len(leaves),'cached_intervals':len(cache),
 'spectral_error_max':{'unitary':str(max_eu),'probability':str(max_ep),'derivative':str(max_ed),'second_derivative':str(max_e2)},
 'rounding_budgets':{'P':1e-8,'Pprime':1e-5,'Psecond':.01,'final_interval':1e-7},
 'seconds':time.time()-start,'scope':'Complete-original M14 candidate; certificate uses exact integer branch arithmetic with validated residuals and stated IEEE/MPFR error bounds. External review separate.'}
(OUT/'M14-spectral-residuals.json').write_text(json.dumps(spectral_records,indent=2)+'\n')
(OUT/'M14-certificate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['spectral_error_max','memory_tail_upper','memory_upper','gap_lower']},indent=2),flush=True)
