# CGLMP measurements need not maximize statistical strength

Yuxuan Zhang. Version1.0,28September2026. EPFL first affiliation; Princeton second.

The manuscript reports a complete negative answer to QIQCOP op_a34f0e2d6489068f.
It gives a fixed-state,d4,two-setting,four-outcome counterexample with an exact
statistical-strength separation greater than0.022bits. It does not identify the
globally optimal measurements or settle the linear CGLMP optimization problem.

Run `python3 exact-check.py` with Python3.9or later; no external packages are used.
The decisive comparisons must all print certified. The independent supplemental
`physical-check.py` requires mpmath and checks physical Born probabilities at90digits,
plus the local table with exact fractions. Its saved output is physical-check.json.
The proof and both frozen review records are provided unchanged. Reviews are AI
reviews, not human peer review. Literature priority remains unverified.

Compile cglmp-statistical-strength.tex with standard LaTeX. The supplied PDF was
compiled in the Codex native editor and exported with the existing pdflatex install;
all five pages were visually checked. Source PDFs of prior authors are not bundled;
their exact identifiers and supporting locations are in source-comparison.md.

This archive is the source and verification record for the named manuscript.
It does not replace the primary references in the manuscript bibliography.
No blanket reuse license is added; existing rights are retained.
