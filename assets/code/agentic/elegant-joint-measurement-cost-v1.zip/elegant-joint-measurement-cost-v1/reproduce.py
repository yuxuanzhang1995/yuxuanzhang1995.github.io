"""Verify release integrity and replay exact controls in a fresh directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main():
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError("Run without -O: the scientific checkers use assertions.")
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text())
    for name, expected in manifest["files"].items():
        target = (root / name).resolve()
        if not target.is_relative_to(root):
            raise RuntimeError("Manifest path escapes package: " + name)
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError("SHA-256 mismatch: " + name)

    jobs = [
        ("ejm_detector_exact.py", "ejm-detector-exact-check.json"),
        ("ejm_tail_exact.py", "ejm-tail-exact-check.json"),
        ("coordinate_identity.py", "coordinate-identity.json"),
    ]
    rows = []
    with tempfile.TemporaryDirectory(prefix="ejm-cost-reproduction-") as tmp:
        work = Path(tmp)
        for script, output in jobs:
            shutil.copy2(root / "checks" / script, work / script)
            proc = subprocess.run(
                [sys.executable, str(work / script)], cwd=work,
                capture_output=True, text=True, timeout=600,
            )
            if proc.returncode:
                raise RuntimeError(script + " failed:\n" + proc.stdout + proc.stderr)
            actual = json.loads((work / output).read_text())
            expected = json.loads((root / "expected" / output).read_text())
            if actual != expected:
                raise RuntimeError(script + " differs from its complete expected JSON result")
            rows.append({"checker": script, "status": actual["status"],
                         "complete_json_match": True})
    import sympy
    print(json.dumps({
        "status": "PASS", "hashes_verified": len(manifest["files"]),
        "python": sys.version.split()[0], "sympy": sympy.__version__,
        "checks": rows,
        "review_relation": "same_agent; no independent expert review",
        "scope": "Exact controls accompanying an analytic proof, not a formal proof of the theorem.",
    }, indent=2))


if __name__ == "__main__":
    main()
