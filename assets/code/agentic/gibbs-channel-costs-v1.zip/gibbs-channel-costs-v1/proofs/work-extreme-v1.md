# Deterministic sharp-battery work: an extreme-channel formula

24 November 2026. Same-root proof candidate. This is a conditional result
for a stated bath model, not a replacement of Q117's unspecified ideal
bath convention. No independent review or priority claim.

## Model

The system is finite, with the same Hilbert space and Hamiltonian H before
and after. The only supplied resource is a battery initially and finally
in specified pure energy eigenstates. Its energy loss W is deterministic
for every input. Ancillas are Gibbs states at beta>0. No coherent reference,
pure blank register, information battery, catalyst, or failure event is free.

For the theorem below, a countably infinite bath is allowed provided its
Hamiltonian B is bounded below and exp(-beta B) is trace class. Its Gibbs
state is a normal, full-support state. The processor is an exactly energy-
conserving unitary. The battery may be taken to have just the two relevant
levels; allowing additional levels does not change the converse.

Covariance of the induced channel is necessary. Consider a covariant
channel Phi with a minimal definite-frequency Kraus family K_alpha,

    [H,K_alpha]=omega_alpha K_alpha.

The frequency multiset, including Kraus-space multiplicities, is intrinsic.
Assume Phi is extreme in the full convex set of CPTP maps: the matrices
K_alpha^* K_beta are linearly independent. Extremality only in the smaller
Gibbs-preserving or covariant set does not suffice.

## Formula

Under this normal infinite-bath convention,

    inf W_exact(Phi) = beta^(-1) log sum_alpha exp(beta omega_alpha). (1)

For Kraus rank r>1 the infimum is not attained by a normal Gibbs bath.
Every strictly larger W has an exact realization. For r=1 on the same
finite system, covariance forces omega=0 and the channel is an energy-
commuting unitary; cost zero is attained.

The construction gives the same upper bound for nonextreme covariant
channels, but the matching lower bound uses extremality.

## Converse

Let {|i>} be an energy eigenbasis of the bath, with all Gibbs probabilities
g_i positive. Exact pure final battery state for their mixture implies
that each initial bath eigenvector has that same final battery state for
every system input. The restricted unitary is therefore an isometry

    V:S tensor B -> S tensor B,

raising the system-plus-bath energy by W. For each i its induced system
channel Phi_i is CPTP, and Phi=sum_i g_i Phi_i. Extremality implies Phi_i=Phi
for every i (isolate any one positive summand, even for a countable bath).
Minimal Stinespring uniqueness gives vectors v_{alpha i} with

    V(|psi> tensor |i>)=sum_alpha K_alpha|psi> tensor v_{alpha i}.

The isometry identity for arbitrary i,j reads

    sum_{alpha,beta} K_alpha^* K_beta
      <v_{alpha i},v_{beta j}> = delta_{ij} I.

Linear independence, together with sum K_alpha^* K_alpha=I, forces
<v_{alpha i},v_{beta j}>=delta_{alpha beta}delta_{ij}. Hence the maps
S_alpha|i>=v_{alpha i} extend to isometries with orthogonal ranges:

    S_alpha^* S_beta=delta_{alpha beta} I.

Energy conservation and independence of the K_alpha imply

    [B,S_alpha]=(W-omega_alpha) S_alpha.

Write delta_alpha=W-omega_alpha. Counting Gibbs-weighted basis vectors
(equivalently using the trace-class spectral relation) yields

    Tr(gamma_B S_alpha S_alpha^*)=exp(-beta delta_alpha).

The range projections are orthogonal, with sum at most I. Thus
sum_alpha exp[-beta(W-omega_alpha)]<=1, proving (1)'s lower bound.

If r>1 and equality holds, the full-support Gibbs state implies that the
sum of range projections is I. But W*=beta^(-1)log sum exp(beta omega)
is strictly larger than every omega_alpha, so every S_alpha raises bath
energy by a strictly positive delta_alpha. A trace-class Gibbs Hamiltonian
has a lowest eigenspace of finite nonzero dimension. This eigenspace is
orthogonal to all these ranges, contradiction. Hence equality is unattained.

## Exact implementation above the infimum

Take W>W* and delta_alpha=W-omega_alpha>0. Let the bath have an orthonormal
basis indexed by all finite words in the alphabet alpha, including the
empty word. Give a word energy equal to the sum of the delta values of its
letters. Its partition function is

    Z_B=sum_{n>=0} (sum_alpha exp(-beta delta_alpha))^n < infinity.

The left-creation maps S_alpha append alpha at the start of the word.
They are isometries with mutually orthogonal ranges and raise energy by
delta_alpha. Therefore V=sum_alpha K_alpha tensor S_alpha is an isometry
which raises total nonbattery energy by W. It implements Phi for every
individual bath word and hence for the full Gibbs mixture. The off-diagonal
Kraus terms vanish because S_alpha^* S_beta=delta_alpha_beta I.

Use battery levels W and zero. Define the unitary on the high-battery
subspace by V into the zero-battery subspace. Each total-energy sector has
finite dimension: system and battery are finite, the alphabet is finite,
and delta_min>0 bounds word length at bounded energy. In each such sector
the prescribed map is an isometry between subspaces of one finite-dimensional
space; complete it to a unitary on the orthogonal complements. Their direct
sum is an exactly energy-conserving unitary. It sends the battery from W
to zero with certainty for every system input. No approximate battery or
non-Gibbs blank is used.

## Finite-bath convention gives a different result

With a finite Gibbs bath, a nonzero deterministic energy change of a pure
battery is impossible uniformly over all system inputs. Indeed, choose
a full-rank input. The initial nonbattery support is the entire finite
system-plus-bath space. Pure final battery state makes the restricted map
an isometry onto a subspace of the equal-dimensional final battery sector,
hence a unitary on the entire nonbattery space. Its Hamiltonian spectrum
would have to equal its translation by W; a finite spectrum forces W=0.

At W=0, this restricted unitary is energy conserving on system plus bath,
so the resulting channel is an ordinary finite-bath thermal operation.
Consequently, under this strict finite-bath reading the work cost is zero
if some finite-bath thermal operation is within the permitted channel
error, and infinity otherwise. This is a reduction, not a complete
membership test for thermal operations.

It is invalid to turn the infinite-bath construction into a finite-bath
exact implementation by truncating words: the top words then cannot be
shifted, so deterministic final battery fails. The two bath conventions
must be kept separate, even when system-channel error is allowed.

## Scope and remaining questions

The proof presently treats the same system/Hamiltonian. For different
input/output systems a converse has an extra partition-function factor,
but the word-bath upper bound has not yet been matched. Nonextreme channels
also require more than Gibbs-subpreservation: unital channels already
exhibit a nontrivial factorization obstruction. The formula above is not
claimed for those cases. Its novelty requires comparison with earlier
single-shot work and extremal-channel dilation results.
