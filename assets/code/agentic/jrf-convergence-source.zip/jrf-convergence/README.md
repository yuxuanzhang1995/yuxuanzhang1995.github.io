# jrf-convergence

Working draft dated 16 September 2026.

The proof was generated and internally reviewed by AI agents in the QIQC
research workflow. External expert confirmation and literature novelty
remain unverified. Internal PASS is not a formal proof-assistant certificate.

Files:
- jrf-convergence.pdf: full manuscript (7 pages).
- jrf-convergence.tex: standalone LaTeX source.
- provenance.json: scope, review status, and manuscript hashes.

Compile twice with a standard TeX Live installation:

    pdflatex jrf-convergence.tex
    pdflatex jrf-convergence.tex

Original problem: https://qiqc-op.com/problem/op_76e284219621a785/
Article: https://yuxuanzhang1995.github.io/agentic-research/jrf-convergence/
