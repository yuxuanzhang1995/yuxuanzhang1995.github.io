import numpy as np
from scipy.linalg import expm
from itertools import product
I=np.eye(2); X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]);rng=np.random.default_rng(581)
paulis=[]
for idx in product(range(4),repeat=3):
 p=np.array([[1]])
 for j in idx:p=np.kron(p,[I,X,Y,Z][j])
 paulis.append(p)
H=.18*paulis[1]+.24*paulis[6]-.21*paulis[19]+.16*paulis[47]
assert np.linalg.norm(H,2)<=1 and abs(np.trace(H))<1e-12
errs=[]
for T in [1.7,23.4]:
 for delta in [.02,.001]:
  U=expm(-1j*H*T);V=expm(-1j*H*(T+delta));W=expm(-1j*H*delta)
  x=U.reshape(-1)/np.sqrt(8);y=V.reshape(-1)/np.sqrt(8)
  for P in paulis[1:]:
   paired=np.vdot(x,np.kron(P,np.eye(8))@y)*np.vdot(y,x)
   target=np.trace(P@W)/8*np.conj(np.trace(W)/8)
   errs.append(abs(paired-target)); assert abs(paired-target)<1e-12
   a=(np.trace(P@H)/8).real
   assert abs(paired.imag/(-delta)-a)<=2*delta
print('Paired-Choi identity:252 noncommuting/phase checks PASS, max error below1e-12')
print('Coefficient estimator bias control:252 checks PASS, error <=2delta')
print('This checks the identity; it does not establish unknown-support discovery.')
