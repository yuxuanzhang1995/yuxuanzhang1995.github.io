"""Direct, bounded controls of the support-moment candidate; not an all-n proof."""
from pathlib import Path
from fractions import Fraction
from itertools import product
import json, hashlib, math, sys
import numpy as np

I=np.eye(2,dtype=complex)
P1=[I,np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
def kron_all(xs):
    z=np.ones((1,1),complex)
    for x in xs: z=np.kron(z,x)
    return z
def paulis(q): return [kron_all(xs) for xs in product(P1,repeat=q)]
def swap(d):
    z=np.zeros((d*d,d*d),complex)
    for i,j in product(range(d),repeat=2): z[i*d+j,j*d+i]=1
    return z
def supports(q):
    ps=paulis(q); eye=ps[0]
    return [(eye+s*p)/2 for p in ps[1:] for s in [-1,1]]
def random_decoder(m,d,e,rng):
    z=rng.normal(size=(d*e,m))+1j*rng.normal(size=(d*e,m))
    v=np.linalg.qr(z)[0][:,:m].reshape(d,e,m)
    return [v[:,j,:] for j in range(e)]
def dual(ks,x): return sum(k.conj().T@x@k for k in ks)
def choi(ks):
    vs=[k.T.reshape(-1) for k in ks]
    return sum(np.outer(v,v.conj()) for v in vs)
def reduced_kraus(ks,D,n,S):
    keep=list(S); drop=[j for j in range(n) if j not in keep]
    ds,dc=D**len(keep),D**len(drop);m=ks[0].shape[1]
    ans=[]
    for k in ks:
        z=k.reshape([D]*n+[m]).transpose(keep+drop+[n]).reshape(ds,dc,m)
        ans.extend(z[:,j,:] for j in range(dc))
    return ans
def close(a,b,tol=2e-10):
    assert abs(a-b)<tol*max(1,abs(a),abs(b)), (a,b)

report={'scope':'same-agent direct numerical/index controls; analytic all-n proof remains separate','exact':{},'moment_cases':[],'decoder_cases':[],'mutations':{}}
D=16;a=Fraction(D*D-2,4*(D*D-1));c=Fraction(D,4*(D*D-1)); bracket=a+4*c
assert bracket==Fraction(53,170)
assert 8*53**2 < 170**2
report['exact']={'D':D,'labels':2*(D*D-1),'rank':D//2,'chi_bits':1,'a':str(a),'c':str(c),'bracket':str(bracket),'strict_margin_integer':170**2-8*53**2,'rate_lower_bound_display':2/3*math.log2(170/53)}
for q in [1,2,3,4]:
    D=2**q;ps=paulis(q);F=swap(D)
    basis_sum=sum(np.kron(p,p) for p in ps)
    # Entries are Gaussian integers, exactly represented throughout these sums.
    assert np.array_equal(basis_sum,D*F)
    if q<=3:
        qs=supports(q); actual=sum(np.kron(x,x) for x in qs)/len(qs)
        a=(D*D-2)/(4*(D*D-1));c=D/(4*(D*D-1))
        assert np.max(np.abs(actual-a*np.eye(D*D)-c*F))<2e-15
    report['moment_cases'].append({'qubits':q,'pauli_count':len(ps),'basis_identity_exact':True})

rng=np.random.default_rng(314101)
for q,n,m,e in [(1,1,1,2),(1,1,3,2),(1,2,2,2),(1,3,3,2),(2,1,3,2),(2,2,4,2),(2,2,6,2)]:
    D=2**q;dout=D**n;ks=random_decoder(m,dout,e,rng)
    assert np.linalg.norm(sum(k.conj().T@k for k in ks)-np.eye(m))<1e-12
    a=(D*D-2)/(4*(D*D-1));c=D/(4*(D*D-1));qs=supports(q)
    direct=[];success=[]
    for tup in product(qs,repeat=n):
        A=dual(ks,kron_all(tup))
        direct.append(np.trace(A@A).real);success.append(np.linalg.eigvalsh(A)[-1])
    formula=0;subset_details=[]
    for bits in product([0,1],repeat=n):
        S=[j for j,b in enumerate(bits) if b];J=choi(reduced_kraus(ks,D,n,S))
        d=D**len(S);tr=np.trace(J).real;pur=np.trace(J@J).real;ev=np.linalg.eigvalsh(J)
        close(tr,m)
        close(np.linalg.norm(J.reshape(m,d,m,d).trace(axis1=1,axis2=3)-np.eye(m)),0)
        assert ev[0]>-1e-12 and ev[-1]<=min(m,d)+1e-10
        assert pur<=min(m*m,m*d)+1e-10
        formula+=a**(n-len(S))*c**len(S)*pur
        subset_details.append({'subset':S,'choi_purity':pur,'dimension_bound':min(m*m,m*d)})
    close(np.mean(direct),formula)
    bound=m**1.5*(a+c*D**.5)**n
    assert formula<=bound+1e-10
    assert np.mean(success)<=np.sqrt(formula)+1e-10
    report['decoder_cases'].append({'D':D,'n':n,'message_dimension':m,'environment_dimension':e,'label_words':len(direct),'direct_second_moment':float(np.mean(direct)),'partial_choi_sum':formula,'interpolated_bound':bound,'maximal_encoding_mean_acceptance':float(np.mean(success)),'subsets':subset_details})

# Exact extremal Choi controls, with input and output dimensions in both orders.
for m,d,ks in [(3,3,[np.eye(3)]),(2,4,[np.eye(4)[:,:2]]),
               (4,2,[np.array([[1,0,0,0],[0,0,1,0]]),np.array([[0,1,0,0],[0,0,0,1]])])]:
    J=choi(ks);pur=np.trace(J@J).real;close(pur,min(m*m,m*d))
report['extremal_choi_controls']=3

# Adverse versions that must fail the very controls carrying the conclusion.
ps=paulis(1);wrong=sum(np.kron(p,p.conj()) for p in ps)
report['mutations']['conjugating_second_pauli_detected']=bool(np.max(abs(wrong-2*swap(2)))>1)
report['mutations']['omitting_nonidentity_correction_detected']=bool(Fraction(1,4)+4*Fraction(4,255)!=Fraction(53,170))
report['mutations']['dropping_message_dimension_detected']=bool(np.trace(choi([np.eye(3)])@choi([np.eye(3)])).real>3)
rho=np.eye(2)/2;branch=[np.diag([1.,0.]),np.diag([0.,1.])]
trace_distance=lambda a,b:float(sum(abs(np.linalg.eigvalsh(a-b)))/2)
before=trace_distance(rho,sum(branch)/2);after=sum(trace_distance(rho,x) for x in branch)/2
assert before==0 and after==.5
report['seed_averaging_control']={'after_averaging_state_error':before,'average_branch_error':after,'different':True}
assert all(report['mutations'].values())
report['passed']=True
report['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('q101-checks.json')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'exact_rate_bound':report['exact']['rate_lower_bound_display'],'moment_cases':len(report['moment_cases']),'arbitrary_decoder_cases':len(report['decoder_cases']),'mutations_caught':len(report['mutations']),'output':str(out)}))
