"""Replay finite exact controls; not a certification of the analytic theorem."""
from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
for entry in manifest['files']:
    path = ROOT / entry['path']
    if sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        raise RuntimeError('Hash mismatch: ' + entry['path'])

reports = []
for name in ['check_variational_identity.py', 'check_block_models.py']:
    with tempfile.TemporaryDirectory(prefix='tough-model-check-') as tmp:
        path = Path(tmp) / name
        shutil.copyfile(ROOT / name, path)
        result = subprocess.run([sys.executable, str(path)], cwd=tmp,
                                text=True, capture_output=True, check=True)
        reports.append({'checker': name, 'result': json.loads(result.stdout)})

print(json.dumps({'hashes_verified': len(manifest['files']),
                  'checks': reports,
                  'scope': 'Finite exact controls only; analytic proof separate.'},
                 indent=2))
