"""Exact interface checks plus bounded floating implementation diagnostics.

Inputs/caps are fixed before execution. Floats do not certify the theorem.
"""
from pathlib import Path
import hashlib, json, time
import numpy as np
import sympy as s

OUT=Path(__file__).resolve().parent
START=time.monotonic()
SCIENCE_CAP=120
I=s.I

def exact_interfaces():
    rows=[]
    for k in [2,3,4,7]:
        T=s.diag(k-1,*([-1]*(k-1)))
        F=s.trace(T*T)
        vals=sorted(T.conjugate().T.__mul__(T).eigenvals().items(),reverse=True)
        spectrum=sorted([x for x,mult in vals for _ in range(mult)],reverse=True)
        assert spectrum[1]==F/(k*(k-1))
        C=s.eye(k)[1:,:]
        assert C*C.conjugate().T==s.eye(k-1)
        assert (C*T)*(C*T).conjugate().T==s.eye(k-1)
        invalid=s.diag(1,*([0]*(k-1)))
        assert invalid.rank()==1 and s.trace(invalid*invalid)>0
        rows.append({'kind':'sharp stack and rectangular control','k':k,'F':str(F),
                     'sigma2_squared':str(spectrum[1]),'min_left_defect_squared':'1',
                     'R_operator_norm_squared':'1','nontraceless_negative_control':True})

    def hermitian(n,offset):
        B=s.Matrix(n,n,lambda a,b:s.Integer(((3*a+2*b+offset)%7)-3)+I*((a+3*b+offset)%5-2))
        return (B+B.conjugate().T)/2

    for k,m in [(2,4),(3,2),(4,1)]:
        n=(m+1)*k-1; q=n-k
        X=s.eye(n)[:,:k]
        H=[hermitian(n,j+1) for j in range(m)]
        G=[X.conjugate().T*h*X for h in H]
        T=[g-s.trace(g)/k*s.eye(k) for g in G]
        F=sum(s.trace(t*t) for t in T)
        R=(s.eye(n)-X*X.conjugate().T)*sum((h*X*t for h,t in zip(H,T)),s.zeros(n,k))
        y=s.eye(n)[:,-1]
        qsum=0
        for a in range(k):
            for phase in [1,I]:
                Z=phase*y*s.eye(k)[a,:]
                X2=-X*(Z.conjugate().T*Z)/2
                first=0; second=0
                for h,g,t in zip(H,G,T):
                    c1=Z.conjugate().T*h*X+X.conjugate().T*h*Z
                    c2=X2.conjugate().T*h*X+X.conjugate().T*h*X2+Z.conjugate().T*h*Z
                    first+=2*s.trace(t*c1)
                    second+=2*(s.trace(c1*c1)+2*s.trace(g*c2)
                              -(s.trace(c1)**2+2*s.trace(g)*s.trace(c2))/k)
                assert s.simplify(first-4*s.re(s.trace(R.conjugate().T*Z)))==0
                qsum+=second
        cross=sum(((X.conjugate().T*h*y).conjugate().T*(X.conjugate().T*h*y))[0] for h in H)
        rhs=8*(k-s.Rational(1,k))*cross-8*F
        assert s.simplify(qsum-rhs)==0
        rows.append({'kind':'independent two-phase expansion','k':k,'m':m,'n':n,
                     'phase_sum':str(s.simplify(qsum)),'F':str(s.simplify(F)),
                     'cross_norm_squared':str(s.simplify(cross)),'gradient_identity':True})

    # The Hermitian product basis is orthogonal in coefficient space.
    n,k=5,2; X=s.eye(n)[:,:k]
    errors=[hermitian(n,2)+I*hermitian(n,3),hermitian(n,4)+I*hermitian(n,5)]
    products=[[X.conjugate().T*a.conjugate().T*b*X for b in errors] for a in errors]
    T=[[p-s.trace(p)/k*s.eye(k) for p in row] for row in products]
    F=s.simplify(sum(s.trace(t.conjugate().T*t) for row in T for t in row))
    H=[errors[0].conjugate().T*errors[0], errors[1].conjugate().T*errors[1],
       (errors[0].conjugate().T*errors[1]+errors[1].conjugate().T*errors[0])/s.sqrt(2),
       (errors[0].conjugate().T*errors[1]-errors[1].conjugate().T*errors[0])/(I*s.sqrt(2))]
    FH=0
    for h in H:
        g=X.conjugate().T*h*X;t=g-s.trace(g)/k*s.eye(k);FH+=s.trace(t*t)
    assert s.simplify(FH-F)==0
    avec=s.Matrix([1,I]);bvec=s.Matrix([2,-1])
    residue=sum((s.conjugate(avec[i])*bvec[j]*T[i][j] for i in range(2) for j in range(2)),s.zeros(k))
    square=s.simplify(s.trace(residue.conjugate().T*residue))
    bound=F*(avec.conjugate().T*avec)[0]*(bvec.conjugate().T*bvec)[0]
    assert s.simplify(bound-square)>=0
    rows.append({'kind':'exact error-basis conversion','F':str(F),'coefficient_Frobenius_square':str(square),'Cauchy_bound':str(bound)})
    return rows

def quantities(H,X):
    k=X.shape[1]; G=[X.conj().T@h@X for h in H]
    T=[g-np.trace(g)*np.eye(k)/k for g in G]
    F=sum(float(np.vdot(t,t).real) for t in T)
    raw=sum((h@X@t for h,t in zip(H,T)),np.zeros_like(X))
    R=raw-X@(X.conj().T@raw)
    return F,G,T,R

def curvature(H,X,G,T,Z):
    k=X.shape[1]; val=0.
    S=sum((g@t for g,t in zip(G,T)),np.zeros((k,k),complex))
    for h,t in zip(H,T):
        L=X.conj().T@h@Z+Z.conj().T@h@X
        L-=np.trace(L)*np.eye(k)/k
        val+=2*np.vdot(L,L).real+4*np.trace(t@Z.conj().T@h@Z).real
    return float(val-4*np.trace(S@Z.conj().T@Z).real)

def geodesic(X,Z,t):
    U,v,Vh=np.linalg.svd(Z,full_matrices=False)
    V=Vh.conj().T
    return (X@V*np.cos(t*v))@Vh+(U*np.sin(t*v))@Vh

def run_diagnostic(name,H,X):
    n,k=X.shape;m=len(H)
    if n<(m+1)*k-1:raise ValueError('dimension threshold fails')
    P=k*sum(float(np.vdot(h,h).real) for h in H)
    a=(k-1)*np.sqrt(k+1)
    F0=quantities(H,X)[0]; tau=.05*F0
    branches={'gradient':0,'curvature':0}
    min_margin=float('inf');max_isometry=0.;max_phase_error=0.
    history=[]
    for step in range(4096):
        if time.monotonic()-START>SCIENCE_CAP:break
        F,G,T,R=quantities(H,X)
        if F<=tau:break
        g=4*np.linalg.norm(R)
        if g>=F/a:
            Z=-4*R/g; Y=geodesic(X,Z,g/(16*P));branch='gradient'
        else:
            perp=np.linalg.qr(X,mode='complete')[0][:,k:]
            C=np.concatenate([perp.conj().T@h@X for h in H],axis=1)
            U,_,_=np.linalg.svd(C,full_matrices=True)
            y=perp@U[:,-1]
            opts=[]
            for b in range(k):
                for phase in [1,1j]:
                    Z=np.zeros_like(X);Z[:,b]=phase*y
                    opts.append((curvature(H,X,G,T,Z),Z))
            phase_sum=sum(q for q,z in opts)
            target=8*(k-1/k)*np.linalg.norm(C.conj().T@U[:,-1])**2-8*F
            max_phase_error=max(max_phase_error,abs(phase_sum-target))
            q,Z=min(opts,key=lambda item:item[0])
            assert q<=-2*F/k+1e-10*max(1,P)
            t=np.sqrt(F/(32*P*k))
            candidates=[geodesic(X,Z,t),geodesic(X,Z,-t)]
            Y=min(candidates,key=lambda Y:quantities(H,Y)[0]);branch='curvature'
        Fy=quantities(H,Y)[0]
        required=F*F/(48*P*k**3)
        margin=F-Fy-required
        min_margin=min(min_margin,margin)
        assert margin>=-2e-10*max(1,P), (name,step,margin)
        iso=np.linalg.norm(Y.conj().T@Y-np.eye(k))
        assert iso<2e-9,(name,step,iso)
        max_isometry=max(max_isometry,iso)
        branches[branch]+=1
        if step<3 or step%512==0:history.append({'step':step,'F':F,'next_F':Fy,'branch':branch,'required_decrease':required})
        X=Y
    Fend=quantities(H,X)[0]
    np.savez(OUT/(name+'.npz'),H=np.array(H),X=X)
    return {'name':name,'n':n,'k':k,'m':m,'P':P,'initial_F':F0,'final_F':Fend,
            'target_F':tau,'target_reached':Fend<=tau,'steps':sum(branches.values()),
            'branches':branches,'minimum_decrease_margin':min_margin,'max_isometry_error':max_isometry,
            'max_phase_trace_error':max_phase_error,'samples':history,
            'scope':'Floating implementation regression; no certification of exact code, global theorem or finite precision complexity.'}

def main():
    exact=exact_interfaces()
    exact_seconds=time.monotonic()-START
    rng=np.random.default_rng(371192)
    def herm(n):
        a=rng.integers(-3,4,(n,n))+1j*rng.integers(-3,4,(n,n))
        return (a+a.conj().T)/(2*n)
    n,k=9,2
    H=[herm(n) for _ in range(4)]
    X=np.linalg.qr(rng.normal(size=(n,k))+1j*rng.normal(size=(n,k)))[0]
    cases=[('generic-threshold',H,X)]
    A=[(rng.integers(-3,4,(n,n))+1j*rng.integers(-3,4,(n,n)))/n for _ in range(2)]
    cross=A[0].conj().T@A[1]
    H=[a.conj().T@a for a in A]+[(cross+cross.conj().T)/np.sqrt(2),(cross-cross.conj().T)/(1j*np.sqrt(2))]
    cases.append(('actual-two-error-threshold',H,np.eye(n,dtype=complex)[:,:k]))
    z=np.diag([1.,-1.]);x=np.array([[0,1.],[1.,0]])
    C=[np.vstack([np.eye(2),np.zeros((1,2))]),np.vstack([-z@x,np.zeros((1,2))])]
    H=[np.block([[g,c.conj().T],[c,np.zeros((3,3))]]).astype(complex) for g,c in zip([z,x],C)]
    cases.append(('stationary-saddle-escape',H,np.eye(5,dtype=complex)[:,:2]))
    diagnostics=[run_diagnostic(*case) for case in cases]
    try:
        run_diagnostic('invalid-dimension',[h[:3,:3] for h in H],np.eye(3,dtype=complex)[:,:2])
        raise AssertionError('invalid dimension was accepted')
    except ValueError:
        invalid_rejected=True
    report={'seed':371192,'exact_controls':exact,'diagnostics':diagnostics,
            'invalid_dimension_rejected':invalid_rejected,'exact_seconds':exact_seconds,
            'scientific_seconds':time.monotonic()-START,'compute_cap_seconds':SCIENCE_CAP,
            'proof_sha256':hashlib.sha256((OUT/'proof-candidate-v1.md').read_bytes()).hexdigest()}
    (OUT/'checks-v1.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'exact_controls':len(exact),'diagnostics':[{k:r[k] for k in ['name','steps','branches','initial_F','final_F','target_reached']} for r in diagnostics],
                      'scientific_seconds':report['scientific_seconds'],'invalid_dimension_rejected':invalid_rejected}))

if __name__=='__main__':main()
