"""Replay the exact quantum/population witnesses and assert the final gap."""
from pathlib import Path
from fractions import Fraction as F
import json
from p11_rational_quantum_certificate_common import I,D,q,p,ns,certificate

if __name__=='__main__':
    data=json.loads(Path('run/checks/r131_p11_witness.json').read_text())
    tail=json.loads(Path('run/checks/r131_p11_tail_certificate.result.json').read_text())
    audit=json.loads(Path('run/checks/r131_p11_audit.result.json').read_text())
    assert tail['remaining_unclosed_states']==0 and tail['frontier_count']==88
    assert audit['legal_control_and_polynomial_replays']==tail['post_U2_states']
    assert D(audit['price_transfer_margin'][0])>0
    pop=certificate(data['population'],'.289564')
    quantum=certificate(data['quantum'],'.287732')
    y=[I(str(v)) for v in data['price']]
    qg=q*ns['exp_minus_fraction'](F(1,100000),40);Zg=1+qg+qg*qg
    target=[qg**(i//2)*q**(i%2)/(Zg*(1+q)) for i in range(6)]
    lower=sum(a*(t-v) for a,t,v in zip(y,target,p))
    upper=I(*quantum['finite_work']);gap=lower-upper
    assert gap.a>D(data['delta'])>0
    out=dict(gamma=data['gamma'],delta=data['delta'],population_lower=lower.pair(),
        quantum_upper=upper.pair(),strict_gap=gap.pair(),
        population_feasible_upper=pop['finite_work'],population_certificate=pop,
        quantum_certificate=quantum,claim='W_Q(1.00001)+6e-9 <= W_C(1.00001), both finite',
        scope='Complete original-problem candidate using the frozen prefix reduction and exhaustive R131 suffix proof; same-agent assessment, independent review and novelty unresolved')
    Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['population_certificate','quantum_certificate']},indent=2))
