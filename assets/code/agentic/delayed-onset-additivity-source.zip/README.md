# Additivity of minimum output Rényi entropy can fail first at three copies

Yuxuan Zhang. Research preprint, 27 September 2026.
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

The complete mathematical argument is in `delayed-onset-additivity.tex`. The paper is a proof candidate reviewed only by
AI (an isolated adversarial review of the complete proof and a final audit, both recorded in `INTERNAL_REVIEW.json`). **No independent
human expert has examined the argument, and neither external peer review nor human novelty certification is recorded.**
AI assistance is disclosed in the paper.

**Result.** Ruskai asked whether additivity of the minimum output Rényi entropy can hold for all tensor powers below some
order m and fail first at the m-th. It can, with m = 3: an explicit channel Φ from ℂ⁵ to ℂ⁶ — a flagged direct sum of the
constant channel with output τ⋆ = diag(1−2⁻²⁰, 2⁻²¹, 2⁻²¹) and a channel Ψ from ℂ⁴ to ℂ³ with six two-entry Kraus operators —
has S_p,min(Φ⊗Φ) = 2 S_p,min(Φ) and S_p,min(Φ⊗Φ⊗Φ) < 3 S_p,min(Φ) at p = 1/1000. At every sufficiently small p > 0 the same
holds with a p-dependent constant block. The mechanism is the minimum output
rank: every output of Ψ⊗Ψ has full rank 9, while a GHZ-structured input gives Ψ^⊗3 an output of rank at most 26.

## Reproduce the computation

`check_delayed_onset.py` uses **only the Python standard library** and runs on CPython 3.10 or later:

```sh
python3 check_delayed_onset.py | diff - expected_stdout.txt && echo BYTE-EXACT
```

Or with no network at all:

```sh
docker run --rm --network=none -v "$PWD":/workspace:ro python:3.12-slim \
  python /workspace/check_delayed_onset.py | diff - expected_stdout.txt
```

It prints 21 lines in under a second: the design and trace preservation; the matrix W and the identity h = x†Wx; the key
positive-definiteness proved two independent ways (fraction-free elimination over ℤ[ω], and an embedded Gram factor with an
exact Frobenius bound); the negative control with all θ = 1; the 216 three-copy identities; the inequality at p = 1/1000 as the
exact big-integer statement X^500 > 26^333; and the window for the explicit block τ⋆ (T^1000 > 26^333 and T² ≤ X). `mutate.py` applies 30 single-point mutations, each of which makes the
program exit nonzero (`MUTATION_REPORT.txt`). The certificate R was found by a numerical semidefinite program and is embedded verbatim;
`build_cert.py` produced the Gram factor G′. The checker trusts neither. Reproduction confirms only that the program computes
what the paper describes; Lemmas 2 and 3 and the analytic part of Lemma 8 are established by the written argument, and the
numerical inequalities of Lemma 8 are certified by the program.

## Build the manuscript

Compile `delayed-onset-additivity.tex` twice with pdfLaTeX (amsmath, amsthm, amssymb, mathtools, geometry, lmodern,
microtype, xcolor, hyperref). `EVIDENCE.json` gives primary-source locators for every external claim; source inspection was
performed by AI, and independent human verification remains unrecorded.

The scientific-writing guidance from K-Dense's Scientific Agent Skills was consulted at commit
330c8e764435a731eff571e3efdda70b363d0792 and is cited in the manuscript. Its evidence workflow was followed selectively: a
source register (`EVIDENCE.json`) and an evidence-mapped claims outline (`OUTLINE.md`) were written before the prose.

## Caution for readers

The two-copy full-rank statement (Proposition 5) is the computer-certified step, and its correctness depends on the
partial-transpose convention: for a product vector x = u ⊗ v, x†Q^Γx must equal (u ⊗ v̄)†Q(u ⊗ v̄). Scrutiny should start
there. The closest prior art is Cubitt–Harrow–Leung–Montanaro–Winter (2008), who used a non-multiplicative minimum output
rank for a pair of channels; here a single channel's rank stays multiplicative at two copies and first fails at three.
