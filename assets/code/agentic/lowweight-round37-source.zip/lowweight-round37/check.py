from itertools import combinations, product
from functools import lru_cache

N = 8

def column(support, labels):
    mask = sum(1 << i for i in support)
    groups = [0, 0, 0]
    for i, lab in zip(support, labels):
        groups[lab] |= 1 << i
    syndromes = [mask ^ g for g in groups]
    assert 0 not in syndromes and len(set(syndromes)) == 3
    sy = sum(1 << s for s in syndromes)
    anti = 0
    for a in range(len(support)):
        for b in range(a + 1, len(support)):
            if labels[a] != labels[b]:
                i, j = support[a], support[b]
                anti |= 1 << (8 * i + j)
    return (tuple(support), sy, anti)

def variants(support):
    support = tuple(sorted(support))
    for labels in product(range(3), repeat=len(support)):
        if labels[0] != 0 or max(labels) == 0:
            continue
        if any(labels[k] > 1 + max(labels[:k])
               for k in range(1, len(labels))):
            continue
        yield column(support, labels)

fixed_sy = 0
fixed_anti = 0
matching_mask = 0
for i in (0, 2, 4):
    _, sy, anti = column((i, i + 1), (0, 1))
    assert not (fixed_sy & sy)
    fixed_sy |= sy
    fixed_anti ^= anti
    matching_mask |= 1 << (8 * i + i + 1)

triples = tuple(c for support in combinations(range(N), 3)
                for c in variants(support) if not (c[1] & fixed_sy))
assert len(triples) == 74
assert all(not (c[2] & matching_mask) for c in triples)
print('canonical triples = 74; asserted == 74')

@lru_cache(maxsize=None)
def complete(rem, parity, used_sy):
    if not any(rem):
        return parity == 0
    assert sum(rem) % 3 == 0
    eligible = []
    by_row = [[] for _ in range(N)]
    possible_parity = 0
    for c in triples:
        support, sy, anti = c
        if sy & used_sy or any(rem[i] == 0 for i in support):
            continue
        eligible.append(c)
        possible_parity |= anti
        for i in support:
            by_row[i].append(c)
    if parity & ~possible_parity:
        return False
    active = [i for i in range(N) if rem[i] > 0]
    if any(len(by_row[i]) < rem[i] for i in active):
        return False
    row = min(active, key=lambda i: len(by_row[i]))
    for support, sy, anti in by_row[row]:
        new_rem = list(rem)
        for i in support:
            new_rem[i] -= 1
        if complete(tuple(new_rem), parity ^ anti, used_sy | sy):
            return True
    return False

h1_support = (0, 1, 2, 3)
templates = ((0, 4, 5, 6), (0, 2, 4, 5))
total_cases = 0
total_completions = 0
for template_number, h2_support in enumerate(templates, 1):
    cases = 0
    completions = 0
    for h1 in variants(h1_support):
        for h2 in variants(h2_support):
            if (h1[1] & fixed_sy or h2[1] & fixed_sy
                    or h1[1] & h2[1]):
                continue
            parity = fixed_anti ^ h1[2] ^ h2[2]
            if parity & matching_mask:
                continue
            rem = tuple(4 - int(i < 6) - int(i in h1[0])
                        - int(i in h2[0]) for i in range(N))
            assert min(rem) >= 0 and sum(rem) == 18
            cases += 1
            complete.cache_clear()
            completions += int(complete(
                rem, parity, fixed_sy | h1[1] | h2[1]))
    assert cases == 36, (template_number, cases)
    assert completions == 0, (template_number, completions)
    print(f'template {template_number}: higher-label cases = {cases}; '
          'asserted == 36; completions = 0; asserted == 0')
    total_cases += cases
    total_completions += completions
assert total_cases == 72 and total_completions == 0
print('total higher-label cases = 72; asserted == 72; completions = 0; asserted == 0')
