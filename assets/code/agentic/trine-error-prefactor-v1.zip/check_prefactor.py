"""Exact arithmetic controls for the trine error-prefactor note (Python 3.9+)."""

import json
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, isqrt


def posterior(a, b):
    """Bloch effect vector (a, b/sqrt(3), c), with the trine in the xy plane."""
    return ((1 + a) / 3, (1 - a / 2 + b / 2) / 3, (1 - a / 2 - b / 2) / 3)


def pair_mass(p):
    return sum(x * y for x, y in combinations(p, 2))


def check_first_copy():
    count = 0
    for k, ell, m in product(range(-6, 7), range(-11, 12), range(-6, 7)):
        a, b, c = F(k, 6), F(ell, 6), F(m, 6)
        planar_norm_sq = a * a + b * b / 3
        if planar_norm_sq + c * c > 1:
            continue
        p = posterior(a, b)
        assert min(p) >= 0 and sum(p) == 1
        assert sum(x * x for x in p) == F(1, 3) + planar_norm_sq / 6
        assert pair_mass(p) >= F(1, 4)
        count += 1
    assert posterior(F(-1), F(0)) == (0, F(1, 2), F(1, 2))
    assert pair_mass(posterior(F(0), F(0))) == F(1, 3)
    # A vector outside the Bloch ball can still give three positive priors.
    assert pair_mass(posterior(F(5, 4), F(0))) < F(1, 4)
    return count


def check_binary_coarsening():
    # Columns are probability distributions of the final guess for each signal.
    columns = [(F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1)),
               (F(1, 2), F(1, 3), F(1, 6))]
    priors = [(F(1, 3),) * 3, (F(0), F(1, 2), F(1, 2)),
              (F(1, 7), F(2, 7), F(4, 7))]
    count = 0
    for decision in product(columns, repeat=3):
        for p in priors:
            error = sum(p[j] * (1 - decision[j][j]) for j in range(3))
            binary_sum = F(0)
            for i in range(3):
                miss = 1 - decision[i][i]
                alternatives = [j for j in range(3) if j != i]
                binary_error = p[i] * miss + sum(p[j] * decision[j][i] for j in alternatives)
                mixture = sum(p[j] / (1 - p[i]) *
                              (p[i] * miss + (1 - p[i]) * decision[j][i]) for j in alternatives)
                assert mixture == binary_error
                binary_sum += binary_error
            assert binary_sum == 2 * error
            count += 1
    return count


def sqrt_bounds(value, bits):
    """Two dyadic fractions enclosing the square root, without rounding to float."""
    scale = 1 << bits
    floor = isqrt((value.numerator * scale * scale) // value.denominator)
    lower = F(floor, scale)
    upper = lower if lower * lower == value else F(floor + 1, scale)
    assert lower * lower <= value <= upper * upper
    return lower, upper


def check_copy_counts():
    for n in range(2, 129):
        t, x = F(1, 4**n), F((-1)**n, 2**n)
        bits = 2 * n + 72
        # Independent collective calculation in the equatorial phase convention.
        # q[r] is the mass of bit strings of Hamming weight r (mod 3).
        masses = [F(sum(comb(n, k) for k in range(r, n + 1, 3)), 2**n) for r in range(3)]
        assert sum(masses) == 1
        roots = [sqrt_bounds(mass, bits) for mass in masses]
        fourier_lo = 1 - sum(hi for _, hi in roots)**2 / 3
        fourier_hi = 1 - sum(lo for lo, _ in roots)**2 / 3

        a_lo, a_hi = sqrt_bounds(1 + 2 * x, bits)
        b_lo, b_hi = sqrt_bounds(1 - x, bits)
        gram_lo = 2 * t / (a_hi + b_hi)**2
        gram_hi = 2 * t / (a_lo + b_lo)**2
        assert max(fourier_lo, gram_lo) <= min(fourier_hi, gram_hi)
        assert max(fourier_hi - fourier_lo, gram_hi - gram_lo) < t / 2**60

        h_lo, h_hi = sqrt_bounds(1 - 4 * t, bits)
        protocol_lo, protocol_hi = 2 * t / (1 + h_hi), 2 * t / (1 + h_lo)
        assert t <= protocol_lo <= protocol_hi <= t + 4 * t**2
        if n == 2:
            # Substituting overlap amplitude for squared fidelity violates achievability.
            assert F(1, 8) > protocol_hi
        if n == 128:
            assert 2 - F(1, 2**124) < t / gram_hi <= protocol_hi / gram_lo < 2 + F(1, 2**124)
    return 127


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Run without Python's -O switch so that assertions execute.")
    print(json.dumps({
        "physical_first_effects": check_first_copy(),
        "binary_coarsening_cases": check_binary_coarsening(),
        "copy_counts_with_certified_enclosures": check_copy_counts(),
        "arithmetic": "rational arithmetic and integer square-root enclosures",
    }, indent=2))
