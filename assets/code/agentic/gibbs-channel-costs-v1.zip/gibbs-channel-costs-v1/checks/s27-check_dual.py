"""Validate the signs, centering, smoothing and an identity-singular control."""
import sympy as sp


e, x, y = sp.symbols("e x y", real=True)
sqrt2 = sp.sqrt(2)
b = {0: sp.Rational(1, 4), 2: sp.Rational(1, 4), sqrt2: sp.Rational(1, 2)}
mean = sum(v*k for k, v in b.items())
variance = sp.expand(sum(v*(k-mean)**2 for k, v in b.items()))
assert variance.is_positive
assert sp.expand(sum(v*((e+k)**2-variance) for k,v in b.items()) - (e+mean)**2) == 0
row = sp.Matrix([[x-1, y-1]])
gen = sp.Matrix([1-y, x-1])
assert sp.expand((row * gen)[0]) == 0 and gen.subs({x:1,y:1}) == sp.zeros(2, 1)
# This row constrains two cross coordinates, while positive matrices control
# their trace. The optimal dual puts zero weight on the p-coordinate.
psd = [sp.Matrix([[2, 1+sp.I], [1-sp.I, 2]]), sp.eye(2)/7]
positions = [sqrt2, -3]
left = sum(m.trace()*sum(w*((z+k)**2-variance) for k,w in b.items())
           for m,z in zip(psd, positions))
right = sum(m.trace()*(z+mean)**2 for m,z in zip(psd, positions))
assert sp.simplify(left-right) == 0
assert sp.simplify(sum(w*((k-mean)**2-variance) for k,w in b.items())) == 0
# For the physical sharpness test C = T at E = -mean. A classically mixed
# ensemble with two distinct centers has an avoidable positive between-term.
bias = sp.Rational(1, 3)
assert sp.simplify((variance+bias**2)-variance) > 0
a, c = sp.symbols("a c", real=True)
assert sp.expand(((e+a)**2-c + (e-a)**2-c)/2 - (e**2-(c-a**2))) == 0
# Relative boundary sizes in the measurable-field construction. All fractional
# powers cancel: only a fixed stencil and the box boundary appear.
for radius in (4, 8, 15):
    box = {(i,j) for i in range(-radius,radius+1) for j in range(-radius,radius+1)}
    for shift in ((1,0),(-1,1),(2,1)):
        translated = {(i+shift[0],j+shift[1]) for i,j in box}
        assert len(box ^ translated) <= 2*(abs(shift[0])+abs(shift[1]))*(2*radius+1)
print("PASS: exact one-dimensional energy dual at an identity-singular two-gap "
      "module, off-diagonal matrix control, optimal centering, correct smoothing "
      "cost and nine measurable-field boundary counts.")
