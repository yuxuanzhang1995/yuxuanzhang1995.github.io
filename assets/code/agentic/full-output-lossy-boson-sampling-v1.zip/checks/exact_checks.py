"""Targeted exact controls, newly implemented for the 2026-10-31 review.

No candidate checker is imported. The reciprocal determinant is computed by a
Leibniz determinant followed by a finite geometric series, rather than exp(tr
log). It is compared with direct permanent sums, including spectator modes and
multiple heavy modes. These finite controls do not certify an asymptotic theorem.
"""
from fractions import Fraction as F
from itertools import combinations, permutations, product
from math import comb, factorial, prod
from pathlib import Path
import hashlib
import json
import time


class Q:
    __slots__ = ('a', 'b')
    def __init__(self, a=0, b=0):
        if isinstance(a, Q): self.a, self.b = a.a, a.b
        else: self.a, self.b = F(a), F(b)
    def __add__(self, v):
        v=Q(v); return Q(self.a+v.a, self.b+v.b)
    __radd__=__add__
    def __neg__(self): return Q(-self.a,-self.b)
    def __sub__(self, v): return self+-Q(v)
    def __rsub__(self, v): return Q(v)+-self
    def __mul__(self, v):
        v=Q(v); return Q(self.a*v.a-self.b*v.b,self.a*v.b+self.b*v.a)
    __rmul__=__mul__
    def __truediv__(self, v):
        v=Q(v); d=v.a*v.a+v.b*v.b
        return self*Q(v.a/d,-v.b/d)
    def __bool__(self): return bool(self.a or self.b)
    def __eq__(self, v):
        v=Q(v); return self.a==v.a and self.b==v.b
    def conj(self): return Q(self.a,-self.b)
    def norm2(self): return self.a*self.a+self.b*self.b
    def serial(self): return {'real':str(self.a),'imag':str(self.b)}


def eye(n): return [[Q(int(i==j)) for j in range(n)] for i in range(n)]
def mm(a,b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))),Q())
             for j in range(len(b[0]))] for i in range(len(a))]
def unitary(m):
    u=eye(m)
    for j in range(m-1):
        r=eye(m); r[j][j]=r[j+1][j+1]=Q(F(3,5))
        r[j][j+1]=Q(F(4,5)); r[j+1][j]=Q(F(-4,5)); u=mm(u,r)
    ph=eye(m);ph[0][0]=Q(F(5,13),F(12,13));u=mm(u,ph)
    r=eye(m);r[0][0]=r[-1][-1]=Q(F(8,17))
    r[0][-1]=Q(F(15,17));r[-1][0]=Q(F(-15,17));u=mm(u,r)
    ud=[[u[j][i].conj() for j in range(m)] for i in range(m)]
    assert mm(ud,u)==eye(m)
    return u
def permanent(a):
    n=len(a);return sum((prodq(a[i][p[i]] for i in range(n))
                        for p in permutations(range(n))),Q())
def prodq(a):
    z=Q(1)
    for x in a:z=z*x
    return z
def fall(n,k):return factorial(n)//factorial(n-k)
def dim(m,k):return comb(m+k-1,k) if k>=0 else 0
def bnorm(m,k,l):return factorial(l)**2*comb(m+k+l-1,k-l)
def singular(m,k,j,l):
    return F(fall(j,l)**2*bnorm(m,k,l),fall(k,l)**2*bnorm(m,j,l))
def coefficients(m,l):
    c=[F(0)]*(l+1);c[l]=F(1)
    for j in reversed(range(l)):
        c[j]=-sum(c[a]*singular(m,l,a,j) for a in range(j+1,l+1))/singular(m,l,j,j)
    for j in range(l+1):
        assert sum(c[a]*singular(m,l,a,j) for a in range(j,l+1))==int(j==l)
    return c
def occupations(m,k):
    if m==1:return [(k,)]
    return [(j,)+v for j in range(k+1) for v in occupations(m-1,k-j)]
def poly_product(a,b,l):
    z=[F(0)]*(l+1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            if i+j<=l:z[i+j]+=x*y
    return z


class Ring:
    def __init__(self,l,s,b):
        self.l,self.s,self.b=l,s,tuple(b)
        self.zero=(0,0,(0,)*len(b),0);self.one={self.zero:Q(1)}
    def add(self,a,b):
        z=a.copy()
        for k,v in b.items():z[k]=z.get(k,Q())+v
        return {k:v for k,v in z.items() if v}
    def scale(self,a,c):return {k:v*c for k,v in a.items() if v*c}
    def mon(self,x=0,y=0,z=None,w=0,c=1):
        return {(x,y,(0,)*len(self.b) if z is None else tuple(z),w):Q(c)}
    def mul(self,a,b):
        out={}
        for (x,y,z,w),v in a.items():
            for (xx,yy,zz,ww),vv in b.items():
                if x&xx or y&yy or w+ww>self.l:continue
                zs=tuple(i+j for i,j in zip(z,zz))
                if any(i>j for i,j in zip(zs,self.b)):continue
                key=(x|xx,y|yy,zs,w+ww)
                out[key]=out.get(key,Q())+v*vv
        return {k:v for k,v in out.items() if v}
    def reciprocal_determinant(self,M):
        n=len(M);a=[[self.add(self.one if i==j else {},self.scale(M[i][j],-1))
                      for j in range(n)] for i in range(n)]
        det={}
        for p in permutations(range(n)):
            term=self.one
            for i in range(n):term=self.mul(term,a[i][p[i]])
            inversions=sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
            det=self.add(det,self.scale(term,(-1)**inversions))
        delta=self.add(self.one,self.scale(det,-1))
        assert all(y for (_,y,_,_) in delta)
        inv=self.one;power=self.one
        for _ in range(self.l):
            power=self.mul(power,delta);inv=self.add(inv,power)
        assert not self.mul(power,delta)
        assert self.mul(det,inv)==self.one
        return inv


def ring_pattern(U,n,l,H,b,h,hi,go,omit_spectators=False,one_binom=False,omit_heavy=False):
    m=len(U);s=l-sum(b);R=Ring(l,s,b);P=R.one;Z=[]
    for i in range(m):
        if i in H:
            z=[0]*len(H);z[H.index(i)]=1;Z.append(R.mon(z=z))
        elif s:
            zi=R.add(R.mon(x=1<<go[s][i]),R.mon(x=1<<go[s][i],w=1,c=h[i]))
            Z.append(zi)
            if not omit_spectators:P=R.mul(P,R.add(R.one,zi))
        else:Z.append({})
    for i,bi in zip(H,b):
        z={}
        for j in range(min(bi,h[i])+1):z=R.add(z,R.mon(w=j,c=comb(bi,j)*comb(h[i],j)))
        P=R.mul(P,z)
    M=[]
    for a in range(n):
        row=[]
        for bb in range(n):
            z={}
            for i in range(m):z=R.add(z,R.scale(Z[i],U[i][a].conj()*U[i][bb]))
            row.append(R.mul(R.mon(y=1<<hi[a]),z))
        M.append(row)
    G=R.mul(P,R.reciprocal_determinant(M));c=coefficients(m,l)
    N=[hi.count(j) for j in range(l)];pl=F(factorial(l),l**l)
    ps=F(factorial(s),s**s) if s else F(1);ell=sum(h);result=Q()
    for (xb,yb,zv,j),val in G.items():
        if xb!=(1<<s)-1:continue
        a=yb.bit_count();unused=prod(N[t] for t in range(l) if not yb>>t&1)
        heavy=1 if omit_heavy else prod(comb(bi,ui) for bi,ui in zip(b,zv))
        denominator=pl*comb(n,l)*comb(l,a)**(1 if one_binom else 2)*comb(l,j)*comb(ell,j)*ps
        result+=val*c[a]*c[j]*unused*heavy/denominator
    return result/singular(m,ell,l,l),len(G)


def direct_pattern(U,n,l,H,b,h,hi,go):
    m=len(U);s=l-sum(b);ell=sum(h);c=coefficients(m,l)
    N=[hi.count(j) for j in range(l)];pl=F(factorial(l),l**l)
    ps=F(factorial(s),s**s) if s else F(1);result=F(0)
    for S in combinations([i for i in range(m) if i not in H],s):
        if s and len({go[s][i] for i in S})!=s:continue
        v=[0]*m
        for i,bi in zip(H,b):v[i]=bi
        for i in S:v[i]=1
        fp=[F(1)]
        for vi,hh in zip(v,h):fp=poly_product(fp,[F(comb(vi,j)*comb(hh,j)) for j in range(min(vi,hh)+1)],l)
        outer=sum(c[j]*fp[j]/(comb(l,j)*comb(ell,j)) for j in range(l+1))
        inner=F(0)
        for a in range(l+1):
            for I in combinations(range(n),a):
                colors={hi[i] for i in I}
                if len(colors)!=a:continue
                unused=prod(N[t] for t in range(l) if t not in colors)
                for u in product(*(range(vi+1) for vi in v)):
                    if sum(u)!=a:continue
                    rows=[i for i,ui in enumerate(u) for _ in range(ui)]
                    amp=permanent([[U[i][j] for j in I] for i in rows])
                    weight=F(prod(comb(vi,ui) for vi,ui in zip(v,u)),prod(factorial(ui) for ui in u))
                    inner+=c[a]*unused*weight*amp.norm2()/(pl*comb(n,l)*comb(l,a)**2)
        result+=outer*inner/ps
    return Q(result/singular(m,ell,l,l))


def main():
    start=time.monotonic();root=Path(__file__).resolve().parents[1]
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for row in manifest['files']:
        assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
    identities=0
    for m in range(2,9):
        for n in range(1,m+1):
            for k in range(1,n+1):
                for l in range(1,k+1):
                    f=F(1,dim(m,l)+dim(m,l-1))
                    source_f=F(m-1,2*l+m-1)/comb(l+m-2,l)
                    assert f==source_f
                    lhs=F(dim(m,k),1)*f/(singular(m,k,l,l)*comb(n,l))
                    rhs=F(fall(k,l),fall(n,l))*F(prod(m+l+j for j in range(l)),prod(m+k+j for j in range(l)))*F(m+l-1,m+2*l-1)
                    assert lhs==rhs and lhs<=F(fall(k,l),fall(n,l))
                    identities+=1
    cases=[(3,3,2,(),(),(2,1,0),False),
           (3,3,2,(0,),(2,),(2,1,0),False),
           (3,3,3,(),(),(2,1,0),False),
           (3,3,3,(1,),(2,),(1,2,0),False),
           (3,3,3,(0,),(3,),(3,0,0),False),
           (3,3,3,(1,),(2,),(1,1,1),True),
           (4,4,4,(0,2),(2,2),(2,1,1,0),False),
           (4,4,4,(1,),(2,),(1,2,1,0),False)]
    rows=[];caught={'missing_spectators':0,'missing_second_binomial':0,'missing_heavy_binomial':0}
    for m,n,l,H,b,h,empty in cases:
        U=unitary(m);hi=[i%l for i in range(n)]
        if empty:hi=[0]*(n-1)+[1]
        go={s:[i%s for i in range(m)] for s in range(1,l+1)}
        direct=direct_pattern(U,n,l,H,b,h,hi,go)
        actual,size=ring_pattern(U,n,l,H,b,h,hi,go)
        assert actual==direct and actual.b==0
        for label,kw in [('missing_spectators',{'omit_spectators':True}),('missing_second_binomial',{'one_binom':True}),('missing_heavy_binomial',{'omit_heavy':True})]:
            wrong,_=ring_pattern(U,n,l,H,b,h,hi,go,**kw)
            caught[label]+=int(wrong!=direct)
        rows.append({'m':m,'n':n,'l':l,'heavy_modes':H,'heavy_occupancies':b,'prefix':h,'empty_input_color':empty,'exact_value':actual.serial(),'ring_terms':size})
        print(json.dumps({'case':len(rows),'l':l,'exact_match':True}),flush=True)
    assert all(caught.values())
    out={'package_hashes_checked':len(manifest['files']),'exact_frame_and_factorial_identities':identities,'coefficient_cases':rows,'mutation_controls_detected':caught,'arithmetic':'Exact rational real and imaginary parts; no floating acceptance tolerance','independence':'New implementation by the same root reviewer; not an independent agent or expert review','elapsed_seconds':time.monotonic()-start}
    (root/'results'/'exact-results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='coefficient_cases'}),flush=True)

if __name__=='__main__':main()
