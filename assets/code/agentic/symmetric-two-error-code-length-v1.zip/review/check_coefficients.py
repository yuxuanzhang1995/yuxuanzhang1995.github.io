from pathlib import Path
import sys,json,time,math
from functools import lru_cache
import sympy as sp
from sympy.physics.wigner import wigner_6j
sys.path.insert(0,str(Path(__file__).resolve().parent/'clean-replay'))
from moment3 import recoupling,h_rational
R=sp.Rational
@lru_cache(None)
def tri(a,b,c):
 return R(math.factorial(int(a+b-c))*math.factorial(int(a-b+c))*math.factorial(int(-a+b+c)),math.factorial(int(a+b+c+1)))
def same_sign_and_square(actual,square,sign):
 assert sp.factor(R(actual)**2-square)==0
 assert sp.sign(actual)==sp.sign(sign)
out=[]
for n in range(9,19):
 j=R(n,2);rct=hct=0;t=time.time()
 for bl in recoupling(n):
  J=R(bl['J']);aa=bl['aa'];dd=list(map(R,bl['d']))
  for i,a in enumerate(aa):
   for k,b in enumerate(aa):
    w=wigner_6j(j,j,a,j,J,b)
    same_sign_and_square(bl['R'][i,k],(2*a+1)*(2*b+1)*w*w*dd[k]/dd[i],(-1)**n*w);rct+=1
    for l in range(abs(a-b),min(4,a+b)+1):
     w=wigner_6j(a,j,J,j,b,l)
     h=(2*J+1)*(-1)**int(b+j+J)*w
     kap2=(2*a+1)*(2*b+1)*tri(j,j,a)*tri(j,j,b)*tri(a,b,l)*tri(j,j,l)
     same_sign_and_square(h_rational(bl,a,b,l),sp.cancel(h*h*dd[i]*dd[k]/kap2),h);hct+=1
 item=dict(n=n,exact_swap_coefficients=rct,exact_lift_coefficients=hct,method='independent SymPy 6j value, positive-scale sign and squared rational equality',elapsed_seconds=time.time()-t)
 out.append(item);print(json.dumps(item),flush=True)
(Path(__file__).resolve().parent/'EXACT-COEFFICIENT-CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
