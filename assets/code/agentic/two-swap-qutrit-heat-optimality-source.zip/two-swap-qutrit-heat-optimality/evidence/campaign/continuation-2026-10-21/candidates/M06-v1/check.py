"""Replay frozen M06 arithmetic and payload integrity; analytic proof is separate."""
from pathlib import Path
import json,hashlib
from m06_constants import check
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text())
for name,sha in m['files'].items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==sha, name
a=check();a['manifest_pass']=True;a['manifest_files']=len(m['files'])
print(json.dumps(a,indent=2))
