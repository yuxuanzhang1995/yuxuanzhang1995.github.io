"""Exact rational certificate and independent transcript-error implementation.

Python standard library only. The finite checks supplement the all-n proof.
No expected numeric answer is used in constructing the transcript errors.
"""
from fractions import Fraction as F
from math import comb
import json

BITS = 160
S = 1 << BITS


def floorq(x):
    return F((x.numerator * S) // x.denominator, S)


def ceilq(x):
    return -floorq(-x)


def add(x, y):
    return floorq(x[0] + y[0]), ceilq(x[1] + y[1])


def neg(x):
    return -x[1], -x[0]


def mul(x, y):
    v = [a * b for a in x for b in y]
    return floorq(min(v)), ceilq(max(v))


def div(x, y):
    assert y[0] > 0
    return mul(x, (floorq(1 / y[1]), ceilq(1 / y[0])))


def point(x):
    return F(x), F(x)


def positive_log_series(q, n=90):
    """q >= 1, q <= 2+2^-160: rigorous log enclosure."""
    w = (q - 1) / (q + 1)
    assert 0 <= w < F(34, 100)
    w2 = (floorq(w * w), ceilq(w * w))
    power = (floorq(w), ceilq(w))
    total = point(0)
    for k in range(n):
        total = add(total, mul(power, point(F(2, 2 * k + 1))))
        power = mul(power, w2)
    tail = 2 * power[1] / ((2 * n + 1) * (1 - w2[1]))
    return total[0], ceilq(total[1] + tail)


LOG2 = positive_log_series(F(2))


def logq(q):
    assert q > 0
    k = q.numerator.bit_length() - q.denominator.bit_length()
    two = F(2) ** k
    y = q / two
    if y < 1:
        k -= 1
        y *= 2
    elif y >= 2:
        k += 1
        y /= 2
    yl, yh = floorq(y), ceilq(y)
    lo = positive_log_series(yl)[0]
    hi = positive_log_series(yh)[1]
    return add((lo, hi), mul(point(k), LOG2))


def logi(x):
    assert x[0] > 0
    return logq(x[0])[0], logq(x[1])[1]


def transcript_error(n):
    """Integer count of flag strings and qubit strings, with exact denominators."""
    b, small = 65535, 1
    denom_p, denom_q = 65536 ** n, 2 ** n
    common = denom_p  # divisible by denom_q
    uniform_count = common // denom_q
    numerator = 0
    for k in range(n + 1):
        rho_flag = 4 ** k
        sigma_flag = 4 ** (n - k)
        for ell in range(n + 1):
            peaky_count = b ** (n - ell) * small ** ell
            x, y = ((peaky_count, uniform_count) if 2 * k >= n
                    else (uniform_count, peaky_count))
            numerator += comb(n, k) * comb(n, ell) * min(rho_flag * x, sigma_flag * y)
    return F(numerator, 2 * 5 ** n * common)


def main():
    eps, a = F(1, 65536), F(65535, 65536)
    # Exact algebra and local outcome laws.
    A = [[a, F(0)], [F(0), eps]]
    B = [[F(1, 2), (a - eps) / 2], [(a - eps) / 2, F(1, 2)]]
    assert sum(A[i][i] for i in range(2)) == sum(B[i][i] for i in range(2)) == 1
    assert (a - eps) ** 2 / 2 > 0 and eps / 5 == F(1, 327680)
    assert sum(A[i][j] * B[j][i] for i in range(2) for j in range(2)) == F(1, 2)
    # Strict uniform measured-coefficient certificate, independently recomputed.
    l2, h2 = F(6931, 10000), F(6932, 10000)
    xl, xh = F(248, 10000), F(249, 10000)
    assert l2 < LOG2[0] <= LOG2[1] < h2
    assert logq(F(3))[0] > F(10986, 10000)
    assert xl ** 3 < eps < xh ** 3
    lx = xl - xh ** 2 / 2
    assert F(10986, 10000) - F(9, 4) * h2 + F(3, 4) * lx > -F(443, 1000)
    assert -h2 / 3 + lx + F(64, 3) * l2 * xl / (1 + xh) > 0
    assert -l2 / 3 + xh + F(64, 3) * h2 * xh / (1 + xl) < F(77, 500)
    assert F(64, 25) * l2 ** 2 > F(6, 5)
    delta = F(443, 1000) + F(77, 500) ** 2 / F(12, 5) + F(1, 131070)
    assert delta < F(454, 1000)
    assert F(3, 4) * l2 - F(1, 16) > F(457, 1000)
    # Interval evaluation of the exact policy exponent.
    d = logq(a / eps)
    u = div(logq(2 * a), d)
    one_minus_u = add(point(1), neg(u))
    entropy = neg(add(mul(u, logi(u)), mul(one_minus_u, logi(one_minus_u))))
    E = add(add(logq(F(5, 4)), LOG2), neg(entropy))
    cap = add(logq(F(5, 4)), point(F(454, 1000)))
    gap = add(E, neg(cap))
    assert F(68250256, 10 ** 8) < E[0] <= E[1] < F(68250257, 10 ** 8)
    assert cap[1] < F(677144, 10 ** 6)
    assert gap[0] > F(5359, 10 ** 6)
    tstar = div(logi(div(one_minus_u, u)), d)
    assert 0 < tstar[0] <= tstar[1] < F(1, 2)
    # Independent enumeration and interval verification of both all-n inequalities.
    checked = []
    for n in (1, 2, 3, 4, 8, 16, 32, 64, 128):
        err = transcript_error(n)
        assert 0 < err < F(1, 2)
        if n == 1:
            assert err == F(8193, 81920)
        le = logq(err)
        upper = add(logq(F(n + 1, 2)), neg(mul(point(n), E)))
        lower = neg(add(add(d, mul(point(n), E)), add(logq(F(4)), mul(point(2), logq(F(n + 1))))))
        assert le[1] < upper[0]
        assert le[0] > lower[1]
        checked.append(n)
    result = {'status': 'PASS', 'arithmetic': 'exact integers and outward rational intervals',
              'epsilon': '1/65536', 'min_eigenvalue': '1/327680',
              'measured_cap_below': '0.677144', 'policy_exponent_interval': ['0.68250256', '0.68250257'],
              'exponent_gap_above': '0.005359', 'analytic_rational_gap_above': '0.003',
              'exact_error_n1': '8193/81920', 'both_error_bounds_checked_n': checked,
              'all_n_proof': 'analytic manuscript; finite checks are supplementary'}
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
