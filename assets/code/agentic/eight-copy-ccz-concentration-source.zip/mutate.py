#!/usr/bin/env python3
"""Mutation test for check_eight_copy_ccz.py (standard library only).

Each mutant is ONE single-point text edit of the checker (the old text must occur exactly once).  Every mutant in
MUTANTS must make the checker exit nonzero.  The edits in EQUIVALENT are mathematically equivalent changes (same leaf
projectors, a relabelled but equally valid witness, a convention the protocol never sees, reordered commuting gates);
each must still exit 0, which shows that the checker tests the mathematics rather than the spelling.  Mutants run from
memory (source piped to the interpreter on stdin), so the only file written is MUTATION_REPORT.txt.  Exit status 1 if
any mutant survives, any equivalent edit fails, or the unmutated checker does not reproduce expected_stdout.txt.
"""
import subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = (HERE / "check_eight_copy_ccz.py").read_text()
EXPECTED = (HERE / "expected_stdout.txt").read_text()

def text(old, new):
    assert SRC.count(old) == 1, old
    return SRC.replace(old, new), "%r -> %r" % (old, new)

MUTANTS = [
    ("B mask E2 = {0,3,4,5} -> {1,3,4,5} (another rank-one leaf, different state)",
     lambda: text("bits(0, 3, 4, 5)", "bits(1, 3, 4, 5)")),
    ("leaf B accepts the +1 outcome of P^E2 (wrong-sign B)", lambda: text("pt(P, E2, -1)", "pt(P, E2, +1)")),
    ("leaf A1 filter sign -P^E1 -> +P^E1", lambda: text('"A1": r + [pt(P, E1, -1)', '"A1": r + [pt(P, E1, +1)')),
    ("sector Y root outcome (-1,-1) -> (+1,-1)", lambda: text('"Y": (-1, -1)', '"Y": (+1, -1)')),
    ("split measurement P_0P_1 -> P_1", lambda: text("bits(0, 1), bits(0, 1, 4, 6)", "bits(1), bits(0, 1, 4, 6)")),
    ("rejection leaf (+1,+1) of the root dropped", lambda: text(" + [[(ALL8, 0, +1), (0, ALL8, +1)]]", "")),
    ("Pauli phase i^{|x&z|} dropped (Y0Y1 changes sign)",
     lambda: text("ph = s * (1 - 2 * ((POP[x & z] // 2) & 1))", "ph = s")),
    ("sector direction E_Z = u2 - u6 -> u2 + u6", lambda: text("EZ = [p - q for p, q in zip(U[2], U[6])]",
                                                           "EZ = [p + q for p, q in zip(U[2], U[6])]")),
    ("decoder D_B gate CX(4,0) -> CX(4,2)", lambda: text('("cx", 4, 0)', '("cx", 4, 2)')),
    ("decoder D_A1 gate X_0 -> X_1", lambda: text('("h", 0), ("x", 0),', '("h", 0), ("x", 1),')),
    ("decoder D_B gate CX(6,3) deleted", lambda: text('("cx", 4, 3), ("cx", 6, 3),', '("cx", 4, 3),')),
    ("Hadamard convention [[1,1],[1,-1]] -> [[1,1],[-1,1]]", lambda: text("v[i & ~b] - v[i]", "v[i] - v[i & ~b]")),
    ("CNOT control and target exchanged", lambda: text("v[i ^ (((i >> c) & 1) << t)]", "v[i ^ (((i >> t) & 1) << c)]")),
    ("target phase (-1)^{x1x2x3} -> (-1)^{x1x2}", lambda: text("(i >> a) & (i >> b) & (i >> c) & 1", "(i >> a) & (i >> b) & 1")),
    ("per-leaf form, sector X: (v1-v3) -> (v1+v3)", lambda: text('"X": outer(1, Vm, Vm)', '"X": outer(1, Vp, Vp)')),
    ("Hermitian-form identity: 6 -> 7", lambda: text("check(NTOT == [[6 * c", "check(NTOT == [[7 * c")),
    ("Bloch z = |a|^2 - |b|^2 -> |a|^2 + |b|^2", lambda: text("bz, nn = A * b + a * B, const(0, -1) * (A * b - a * B), a * A - b * B,",
                                                            "bz, nn = A * b + a * B, const(0, -1) * (A * b - a * B), a * A + b * B,")),
    ("sextic f6 = ab(a^4 - b^4) -> ab(a^4 + b^4)", lambda: text("f6, F6 = a ** 5 * b - a * b ** 5,", "f6, F6 = a ** 5 * b + a * b ** 5,")),
    ("polynomial product: imaginary cross term sign", lambda: text("u[1] + v1[0] * v2[1] + v1[1] * v2[0]", "u[1] + v1[0] * v2[1] - v1[1] * v2[0]")),
    ("point evaluation: m_3 exponent 6 -> 4", lambda: text("(1 - x1 ** 6 - y1 ** 6 - z1 ** 6) / 2", "(1 - x1 ** 4 - y1 ** 4 - z1 ** 4) / 2")),
    ("point evaluation: Bloch y sign of the cross term", lambda: text("2 * (al[0] * be[1] - al[1] * be[0])", "2 * (al[0] * be[1] + al[1] * be[0])")),
    ("positive control: RL coefficient 4 -> 5", lambda: text("NRL == [[4 * c", "NRL == [[5 * c")),
    ("negative control: T3 = {0,1,4,6} -> {0,1,4,5} (not a transversal of the four pairs)",
     lambda: text("bits(0, 1, 4, 6)", "bits(0, 1, 4, 5)")),
    ("negative control: -Z^T3 -> +Z^T3", lambda: text('pt("Z", T3, -1)', 'pt("Z", T3, +1)')),
    ("negative control: rejected leaf replaced by B in the sector-Z image test",
     lambda: text('IMR = [proj(U[w], LV["Z"]["R"])', 'IMR = [proj(U[w], LV["Z"]["B"])')),
]

EQUIVALENT = [
    ("E2 -> E1 xor E2 = {1,2,4,5}: identical leaf projectors on the branch +P^E1",
     lambda: text("bits(0, 3, 4, 5)", "bits(1, 2, 4, 5)")),
    ("E2 -> {0,3,6,7}: identical projectors (P^{4567} = P^E1 P^(x)8 = +1 on the branch)",
     lambda: text("bits(0, 3, 4, 5)", "bits(0, 3, 6, 7)")),
    ("T3 -> {2,3,4,6}: another transversal of the pairs 03,12,45,67 (same negative-control leaf state)",
     lambda: text("bits(0, 1, 4, 6)", "bits(2, 3, 4, 6)")),
    ("R^dag -> R in the sector-Y decoder (R^(x)8 R^(x)8 = X^(x)8 = -1 on sector-Z leaf states)",
     lambda: text('r_all((CHI[("Y", k)], ZERO), -1)', 'r_all((CHI[("Y", k)], ZERO), +1)')),
    ("Y -> -Y in the Kronecker reference (only even-weight Y strings occur)",
     lambda: text('"Y": {(0, 1): (0, -1), (1, 0): (0, 1)}', '"Y": {(0, 1): (0, 1), (1, 0): (0, -1)}')),
    ("two commuting CNOTs of D_B reordered", lambda: text('("cx", 4, 5), ("cx", 6, 7)', '("cx", 6, 7), ("cx", 4, 5)')),
]

def run(src):
    r = subprocess.run([sys.executable, "-"], input=src, capture_output=True, text=True, cwd=HERE, timeout=600)
    fl = [l for l in r.stdout.splitlines() if l.startswith("FAIL ")]
    err = r.stderr.strip().splitlines()[-1] if r.stderr.strip() else ""
    return r.returncode, r.stdout, fl, err

def main():
    code, out, fl, _ = run(SRC)
    base_ok = code == 0 and out == EXPECTED and not fl
    lines = ["Mutation report for check_eight_copy_ccz.py: %d single-point mutants (each must exit nonzero) and %d equivalent "
             "edits (each must exit 0)." % (len(MUTANTS), len(EQUIVALENT)),
             "baseline (unmutated): exit %d, FAIL lines %d, stdout identical to expected_stdout.txt: %s"
             % (code, len(fl), "yes" if out == EXPECTED else "NO"), ""]
    survivors, broken = [], []
    for n, (name, make) in enumerate(MUTANTS, 1):
        src, edit = make()
        assert src != SRC
        code, out, fl, err = run(src)
        if code == 0: survivors.append("M%02d" % n)
        first = fl[0][:150] if fl else ("(no FAIL line; aborted: %s)" % err[:120] if err else "(none)")
        lines += ["M%02d %s" % (n, name), "    edit: " + edit, "    exit %d | FAIL lines %d | first: %s" % (code, len(fl), first)]
    lines += ["", "Equivalent edits (must still PASS):"]
    for n, (name, make) in enumerate(EQUIVALENT, 1):
        src, edit = make()
        assert src != SRC
        code, out, fl, err = run(src)
        if code != 0: broken.append("Q%02d" % n)
        lines += ["Q%02d %s" % (n, name), "    edit: " + edit,
                  "    exit %d | FAIL lines %d | stdout identical to expected: %s" % (code, len(fl), "yes" if out == EXPECTED else "no")]
    lines += ["", "summary: %d/%d mutants exit nonzero; survivors: %s; equivalent edits passing: %d/%d%s"
              % (len(MUTANTS) - len(survivors), len(MUTANTS), ", ".join(survivors) or "none",
                 len(EQUIVALENT) - len(broken), len(EQUIVALENT), (" (failing: %s)" % ", ".join(broken)) if broken else "")]
    (HERE / "MUTATION_REPORT.txt").write_text("\n".join(lines) + "\n")
    print(lines[-1]); print(lines[1])
    sys.exit(0 if base_ok and not survivors and not broken else 1)

if __name__ == "__main__":
    main()
