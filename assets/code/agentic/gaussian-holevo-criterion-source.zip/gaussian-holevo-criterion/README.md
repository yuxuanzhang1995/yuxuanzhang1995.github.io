# Gaussian attainment of the Holevo bound

Author: Yuxuan Zhang. Round 42, 24 September 2026.

This package accompanies a complete proof candidate for QIQCOP problem
`op_8f1853475db7ea27`. The result is a finite semialgebraic equality certificate
for arbitrary faithful finite-mode Gaussian local models with nonsingular SLD
Fisher information and a positive weight, together with a realizing measurement.
It is not an efficient algorithm or a closed-form geometric classification.

The mathematical argument passed two internal AI reviews. External specialist
confirmation, human source verification, and literature novelty remain unverified.

## Reading the result

- `manuscript.md` and `gaussian-holevo-criterion.pdf`: the prepared manuscript.
- `manuscript.tex`: standalone generated LaTeX source.
- `frozen-proof.txt` and `frozen-candidate.json`: unchanged round-42 submission.
- `original-problem.json`: the problem statement used in that round, excluding
  the large research seed packet.
- `independent-reviews.json`: the initial and frozen internal review records.
- `publication-provenance.json`, `source-manifest.json`, and `claim-evidence.json`:
  origin, source comparison, and the claims-to-evidence map.

## Reproducing the exact examples

With Python and SymPy installed, run:

```sh
python check.py
```

The output must match `expected_stdout.txt` exactly. The checker asserts the
matrix conditions, positive-semidefinite eigenvalues, zero residuals, and costs
3 and 2/3 for the two examples in Section 8. Publication reruns are recorded in
`publication-reproduction.json`. These examples do not prove the general theorem.

The additional `gaussian_precision_controls.py` and
`gaussian_mixed_certificate_controls.py` scripts check six exact instances
between them. `gaussian_precision_numeric.py` checks 48 floating-point cases
using NumPy and SciPy. Their recorded JSON outputs are included. Some control
scripts use a non-normalized symmetric basis with the corresponding coefficient
convention; the frozen main checker uses the orthonormal basis of the theorem.
Descriptions in historical outputs retain their original pre-review wording.

To rebuild the manuscript using Pandoc and XeLaTeX:

```sh
pandoc manuscript.md --standalone --pdf-engine=xelatex -o gaussian-holevo-criterion.pdf
```

All ancillary modes in the theorem have finite covariance. Singular measurement
precision is handled by the explicit construction, not by declaring an idealized
ancillary infinite-squeezing limit admissible.

Primary-source full texts and private service transcripts are not redistributed.
The withdrawn restricted one-mode submission is not part of this release.
