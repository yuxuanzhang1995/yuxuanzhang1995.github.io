#!/usr/bin/env python3
"""Mutation harness for check_c3_n5_n6.py (standard library only).
Each mutant is a single-point string edit of the checker source (the edited string must occur exactly once); the
mutant is run from stdin (no files written) and must exit nonzero. Also audits that the call graphs of route 1
(R_route1) and route 2 (R_route2) are disjoint. Writes MUTATION_REPORT.txt next to this file."""
import ast
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = (HERE / "check_c3_n5_n6.py").read_text()
EXPECTED = (HERE / "expected_stdout.txt").read_text()

MUTANTS = [  # (id, description, old, new)
    ("M1", "route-1 Clifford deg-2 modulus 4->8",
     "CLIFF_MULT = {1: 4, 2: 2}", "CLIFF_MULT = {1: 4, 2: 1}"),
    ("M2", "census expected (4,2) sizes 280->281",
     "(4, 2): [56, 210, 280], (5, 1): []}", "(4, 2): [56, 210, 281], (5, 1): []}"),
    ("M3", "EXT rep -> a tangent line",
     "[[(0, 1), (2, 3)], [(0, 1), (0, 2), (1, 3)]]", "[[(0, 1), (2, 3)], [(0, 2), (1, 3)]]"),
    ("M5", "H_pi support includes targets",
     "cl, H = diag_gens(n, [i for i in range(n) if i not in T])", "cl, H = diag_gens(n, list(range(n)))"),
    ("M6", "expected log2 size of A_pi, TOF n=6, 56->55",
     "6: {'TOF': 56,", "6: {'TOF': 55,"),
    ("M7", "class-C rep -> duplicate Toffoli form",
     "'C':   (3, 2, [[(0, 1)], [(0, 2)]])", "'C':   (3, 2, [[(0, 1)], [(0, 1)]])"),
    ("M8", "cubic term of 7-qubit control removed",
     "b[6] ^ (b[0] & b[1] & b[2]) ^ ", "b[6] ^ "),
    ("M9", "strict is_pauli accepts S-phases",
     "if any(v % 4 for v in g):", "if any(v % 2 for v in g):"),
    ("M10", "Z-correction search restricted to M=0",
     "sols = [al for al in range(1 << len(T))", "sols = [al for al in range(1)"),
    ("M11", "psi-formula helper (route 1): d_{e_i}(lam o pi) instead of (d_{e_i} lam) o pi",
     "row[pi[y] ^ (1 << i)] += 1", "row[pi[y ^ (1 << i)]] += 1"),
    ("M12", "orbit-census BFS body: new orbit points not expanded",
     "orb.add(Y); front.append(Y)", "orb.add(Y)"),
    ("M13", "kernel certificate (Lemma C): independence tested on R V_j instead of w_j",
     "((entry(x, j) >> vals[j]) & 1)", "(entry(x, j) & 1)"),
    ("M14", "Smith search corrupted (V misses the column eliminations); certificate must reject",
     "for X in A + V:\n            for j in range(r + 1, nc):", "for X in A:\n            for j in range(r + 1, nc):"),
    ("M15", "generated-subgroup size by counting generators (3k), not elementary divisors",
     "return ok, 3 * len(gens) - sk", "return ok, 3 * len(gens)"),
    ("M16", "generated-subgroup comparison: Cliff.pi omitted from the generating set",
     "allg = cl + [[g[pi[x]] for x in range(N)] for g in cl[1:]] + H", "allg = cl + H"),
    ("M17", "L-fixing check (fixes_L): X_c instead of Z_c on non-targets",
     "L = [pauli(n, 0, 1 << c) for c in range(n) if c not in T]",
     "L = [pauli(n, 1 << c, 0) for c in range(n) if c not in T]"),
    ("M18", "literal route's Pauli test: relative phases allowed in 2Z_8 (4g=0 instead of 2g=0)",
     "conds += [form_add({}, g[x], 2), lin]", "conds += [form_add({}, g[x], 4), lin]"),
    ("M19", "literal route: inverse operator keeps the phase sign",
     "sig[y], ph[y] = x, {k: -c % 8 for k, c in A[1][x].items()}",
     "sig[y], ph[y] = x, {k: c % 8 for k, c in A[1][x].items()}"),
    ("M20", "literal route: X_j conjugations skipped (Z_j only)",
     "        for Q in gen:\n", "        for Q in gen[n:]:\n"),
    ("M21", "C5 diagonal check: H_id reduced to T gates (CS, CCZ dropped)",
     "allg = cl + H\n", "allg = cl + H[:n]\n"),
]


def run(src):
    p = subprocess.run([sys.executable, "-"], input=src, capture_output=True, text=True, timeout=1200)
    return p.returncode, [ln for ln in p.stdout.splitlines() if ln.startswith("FAIL ")], p.stdout, p.stderr


def closure(tree, root):
    defs = {f.name: f for f in tree.body if isinstance(f, ast.FunctionDef)}
    seen, todo = set(), [root]
    while todo:
        f = todo.pop()
        if f in seen or f not in defs:
            continue
        seen.add(f)
        todo += [c.func.id for c in ast.walk(defs[f]) if isinstance(c, ast.Call) and isinstance(c.func, ast.Name)]
    return seen


def main():
    tree = ast.parse(SRC)
    c1, c2 = closure(tree, "R_route1"), closure(tree, "R_route2")
    lines = [f"AUDIT route 1 call closure: {sorted(c1)}",
             f"AUDIT route 2 call closure: {sorted(c2)}",
             f"AUDIT shared functions: {sorted(c1 & c2)} (both kernels then go through kernel8/annihilates only)"]
    base = run(SRC)
    same = base[2] == EXPECTED
    lines.append(f"BASELINE unmutated: exit {base[0]}, FAIL lines {len(base[1])}, stdout == expected_stdout.txt: {same}")
    for mid, desc, old, new in MUTANTS:
        assert SRC.count(old) == 1, (mid, SRC.count(old))
    with ThreadPoolExecutor(max_workers=4) as ex:
        results = list(ex.map(lambda mu: run(SRC.replace(mu[2], mu[3])), MUTANTS))
    survivors = 0
    for (mid, desc, old, new), (code, fails, out, err) in zip(MUTANTS, results):
        survivors += code == 0
        first = fails[0][:140] if fails else "(none)"
        lines.append(f"{mid} | {desc} | edit {old.strip()!r} -> {new.strip()!r} | exit {code} | "
                     f"FAIL lines {len(fails)} | first: {first}")
    lines.append("NOTE excluded as provably equivalent (not counted): 'for Q in gen' -> 'for Q in gen[:n]' (Z_j conjugations skipped). For a monomial M = P_s D, if every M X_j M^dag is a translation times a diagonal then s is affine, so M Z_j M^dag = P_s Z_j P_s^dag is already a Pauli; no monomial input separates it.")
    lines.append(f"TOTAL {len(MUTANTS)} mutants: {len(MUTANTS) - survivors} killed (exit != 0), {survivors} survived")
    (HERE / "MUTATION_REPORT.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines[:4] + lines[-1:]))
    sys.exit(1 if survivors or base[0] != 0 or not same or (c1 & c2) else 0)


if __name__ == "__main__":
    main()
