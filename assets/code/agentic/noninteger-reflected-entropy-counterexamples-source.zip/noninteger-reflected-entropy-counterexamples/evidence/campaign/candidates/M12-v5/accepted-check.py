"""Exhaust accepted lower blocks and small upper ensembles using integer F2 operations."""
from pathlib import Path
import itertools,json
def parity(x):return x.bit_count()&1
def image(cols,x):
    y=0
    for j,c in enumerate(cols):
        if x>>j&1:y^=c
    return y
def radical_image(cols):
    gram=[sum(parity(a&b)<<j for j,b in enumerate(cols)) for a in cols]
    return {image(cols,x) for x in range(1<<len(cols)) if all(not parity(row&x) for row in gram)}
def check_upper(m,F,D):
    k=len(F)+len(D);ones=(1<<m)-1;T=F+D
    u=[x for x in range(1<<k) if image(T,x)==ones];assert len(u)==1;u=u[0]
    f=u&((1<<len(F))-1);b=u>>len(F);counts={};accepted=full=0; support=0
    for C in [1,2,3]:
        v=next(x for x in [1,2,3] if parity(x&C)==0)
        for lower in itertools.product(range(4),repeat=k):
            R=sum(parity(v&a)<<j for j,a in enumerate(lower))
            if parity(R&u):continue
            accepted+=1; Bbar=R>>len(F);counts[Bbar]=counts.get(Bbar,0)+1
            cols=[a|(c<<m) for a,c in zip(T,lower)]+[C<<m]
            assert len({image(cols,x) for x in range(1<<len(cols))})==1<<len(cols)
            assert ones in {image(cols,x) for x in range(1<<len(cols))}
            if Bbar:
                full+=1
                expected={image(D,x) for x in range(1<<len(D)) if not parity(Bbar&x)}
                actual=radical_image(cols);assert actual==expected
                combined=0
                for x in actual:combined|=x
                if combined==ones:support+=1
                if not f:assert combined==ones
    if f:assert set(counts)==set(range(1<<len(D))) and len(set(counts.values()))==1
    else:
        assert set(counts)=={x for x in range(1<<len(D)) if not parity(x&b)}
        assert len(set(counts.values()))==1
    return accepted,full,support

def main():
    vals=[x for x in range(1,128) if x.bit_count()%4==0];upper=0;totals=[0,0,0]
    for a in vals:
      for b in vals:
       if a==b or parity(a&b):continue
       D=[a,b]
       for x in range(4):
        F=[127^image(D,x)]
        z=check_upper(7,F,D);assert z[0]==96
        totals=[u+v for u,v in zip(totals,z)];upper+=1
    # Accepted branch where the all-ones vector belongs to D.
    f0=check_upper(8,[3,6],[255,15])
    out={'status':'pass','f_nonzero':{'upper_matrices':upper,'accepted_instances':totals[0],'full_Bbar_rank':totals[1],'full_support':totals[2]},
      'f_zero':{'accepted_instances':f0[0],'full_Bbar_rank':f0[1],'full_support':f0[2]},
      'scope':'Exact finite-ensemble conditional-law and radical-image check; asymptotic bounds remain proved by the general argument.'}
    p=Path(__file__).resolve().parent/'accepted-check-results-new.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
