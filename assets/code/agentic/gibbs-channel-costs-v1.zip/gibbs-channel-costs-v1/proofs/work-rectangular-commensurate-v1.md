# Exact sharp-battery work for extreme covariant channels between different systems

24 November 2026. Extension beyond the same-system word bath. Same-root
proof candidate; priority and independent review unconfirmed. The bath is
allowed to be countably infinite with a normal Gibbs state, exactly as in
`work-extreme-v1.md`. No coherence reference or battery failure is allowed.

Let Phi:A->B be a finite-dimensional covariant channel with minimal
definite-frequency Kraus operators K_alpha,

    H_B K_alpha-K_alpha H_A=omega_alpha K_alpha.

Define partition functions Z_A(u)=Tr exp(-u H_A), Z_B(u) similarly, and
Z_K(u)=sum_alpha exp(u omega_alpha). Suppose the energy gaps of A and B
are commensurate (scalar shifts of their Hamiltonians are immaterial).

If Phi is extreme in the full CPTP set, its exact work infimum is

    W_* = sup_{u>=beta} [log(Z_B(u) Z_K(u)/Z_A(u))]/u.    (1)

Every W>W_* that is commensurate with the system gaps has an exact
implementation; these W are dense above W_*, proving equality of infima.
The infimum need not be attained. For nonextreme channels, the same
expression remains a constructive upper bound, but not a general lower
bound. The original arbitrary-channel cost is not thereby solved.

## Converse: all colder partition functions constrain an exact bath

Combine all free initial ancillas into E and all discarded final systems
into F. The physical nonbattery Hamiltonian has both decompositions
H_A+H_E and H_B+H_F. Thus

    Z_A(u) Z_E(u)=Z_B(u) Z_F(u).                        (2)

Normality of the bath at beta and a lower bounded Hamiltonian ensure that
these partition functions are finite for every u>=beta. The exact
extremality argument gives orthogonal-range isometries S_alpha:E->F,

    S_alpha^*S_lambda=delta_alpha_lambda I,
    H_F S_alpha-S_alpha H_E=(W-omega_alpha)S_alpha.

Take the trace with exp(-u H_F), for any u>=beta:

    exp(-uW) Z_K(u) Z_E(u) <= Z_F(u).

Cancel Z_E using (2) to obtain (1). This bound includes the ground-energy
constraint as u tends to infinity. In ground-zero conventions it is
W>=max_alpha omega_alpha. Checking only the physical temperature beta
would miss the other constraints when A and B differ.

## A positive convolution lemma with integer degeneracies

Let f(x) be a real polynomial with integer coefficients, f(0)>0, and
f(x)>0 for every x in [0,q0], where 0<q0<1. There is a sequence of
positive integers r_k, k>=0, such that

    sum_k r_k q0^k < infinity,
    every coefficient of f(x) sum_k r_k x^k is nonnegative.             (3)

Proof: choose q0<q<1 and c>0 such that f-c is positive on [0,q].
For sufficiently large N its degree-N Bernstein coefficients on that
interval are all nonnegative. This follows directly from uniform
convergence of degree-elevated Bernstein coefficients to the sampled
values of a fixed polynomial. Dividing its Bernstein expansion by
(1-x/q)^N proves that

    (f-c)R has nonnegative power-series coefficients,
    R=(1-x/q)^(-N).

Take N>=1. Its coefficients R_k are positive, at least one, and grow as
q^-k times a polynomial in k. Set r_k=ceil(M R_k), with integer M large
enough that Mc>sum_j |f_j|. Coefficientwise rounding changes fMR by at
most sum_j|f_j|. Since fMR>=Mc R coefficientwise, all coefficients of fr
are nonnegative. The Gibbs series at q0 converges because q0<q. This proves
(3). The use of integer r_k is necessary for physical degeneracies.

## Constructing the bath and its orthogonal isometries

Shift each system's ground to zero. Choose W>W_* rationally commensurate
with all system gaps, and take h>0 so that all relevant energies and W
are integers times h. Let x=exp(-u h). Define integer-coefficient polynomials

    A(x)=sum_a x^(e_a/h),
    T_W(x)=sum_{b,alpha} x^((f_b+W-omega_alpha)/h),
    f(x)=A(x)-T_W(x), q0=exp(-beta h).

The condition W>W_* gives f(x)>0 on (0,q0]. Its infinite-u limit also
gives W>max omega_alpha, so T_W has strictly positive lowest exponent
and f(0)>0. Apply (3). Give a bath R the energy kh with degeneracy r_k.
It has a normal Gibbs state. Let E=B tensor R and F=A tensor R; B is
appended initially in its Gibbs state and A is discarded finally.

At every energy kh, (3) says that the dimension of the corresponding
subspace of F is at least the sum, over alpha, of dimensions of the
subspaces of E shifted by W-omega_alpha. Choose arbitrary orthogonal
embeddings at each energy. Their direct sums give isometries S_alpha:E->F
with the required shifts and mutually orthogonal ranges.

Now V=sum K_alpha tensor S_alpha maps A tensor E isometrically into
B tensor F and raises total nonbattery energy by W. It implements Phi
for every initial E state, hence also its Gibbs state. Treat both sides
as the same physical A tensor B tensor R Hilbert space by reordering
factors. Every fixed total-energy sector is finite dimensional. Appending
the sharp battery levels W and zero, complete V sector by sector to an
energy-conserving unitary. The battery loses precisely W on every input.

This proves the upper bound and hence (1) for extreme channels.

## Checks and useful special cases

- If A and B are the same system with the same H, the partition ratio
  cancels. The function log Z_K(u)/u is nonincreasing because its derivative
  is minus the Shannon entropy of the frequency Gibbs weights divided by
  u^2. Thus (1) reduces to beta^(-1)log Z_K(beta), agreeing with the word bath.
- If H_A=H_B=0 but dimensions differ, (1) is
  beta^(-1)log(r d_B/d_A). Trace preservation implies r d_B>=d_A.
  A channel with r d_B=d_A is a unitary identification followed by a
  partial trace and needs no work. This includes the trace channel.
- Pure energy-state preparation gives the usual sharp-state formation
  expression E_target+beta^(-1)log Z_B(beta), independently of the discarded
  input. This case is a control of the formula, not a new GP example.
- The formula is invariant under separate scalar shifts of H_A and H_B:
  their effect on Z_B/Z_A cancels the shift of every omega_alpha.

The commensurability assumption is used in the constructive integer
convolution argument. It has not been removed here. Also, the all-u
converse uses exact extremality of every bath-conditional channel; it is
not yet a uniform small-error lower bound for different input/output
systems. The same-system stability proof remains valid separately.
