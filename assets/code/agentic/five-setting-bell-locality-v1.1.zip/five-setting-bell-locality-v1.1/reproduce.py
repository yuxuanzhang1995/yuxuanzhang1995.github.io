"""Hash-check and reproduce all finite controls in a clean directory."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile


def main():
    base = Path(__file__).resolve().parent
    manifest = json.loads((base / 'SHA256.json').read_text())
    for name, expected in manifest.items():
        if hashlib.sha256((base / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Hash mismatch: ' + name)
    with tempfile.TemporaryDirectory(prefix='bell-reproduction-') as directory:
        tmp = Path(directory)
        for name in ('verify_control.py', 'independent_control.py',
                     'source_facet_control.py', 'five-setting-certificate.json'):
            shutil.copyfile(base / name, tmp / name)
        # Isolated Python; the explicitly supplied directory contains only
        # this package's checked scripts and certificate.
        driver = ('import sys, runpy; sys.path.insert(0, sys.argv[1]); '
                  'script=sys.argv[2]; sys.argv=[script]; '
                  'runpy.run_path(script, run_name="__main__")')
        for name in ('verify_control.py', 'independent_control.py', 'source_facet_control.py'):
            subprocess.run([sys.executable, '-I', '-c', driver, str(tmp), str(tmp / name)],
                           cwd=tmp, check=True, capture_output=True, text=True)
        author = json.loads((tmp / 'exact-control-report.json').read_text())
        independent = json.loads((tmp / 'independent-control-results.json').read_text())
        source = json.loads((tmp / 'source-facet-control-results.json').read_text())
    expected = {'deterministic_vertices': 256, 'minimum_local_slack': '0',
                'saturating_vertices': 40, 'facet_affine_dimension': 22,
                'nonlocal_slack': '-11/5000', 'conditional_probabilities_checked': 60,
                'minimum_probability': '99/2000', 'exact_four_setting_models': 5,
                'terms_per_model': [20] * 5}
    for key, value in expected.items():
        if author[key] != value:
            raise RuntimeError('Unexpected author result: ' + key)
    if set(author['mutations_caught']) != {
        'reverse_inequality', 'remove_model_mass', 'change_joint_probability'}:
        raise RuntimeError('Author mutation controls failed')
    if (independent['status'] != 'pass' or
        independent['direct_model_probability_equalities'] != 240 or
        not independent['mutated_model_rejected']):
        raise RuntimeError('Independent probability control failed')
    if (source['status'] != 'pass' or
        source['total_nontrivial_inequalities_generated'] != 71280 or
        source['with_60_positivity_facets'] != 71340 or
        not source['paper_witness_is_source_I5322']):
        raise RuntimeError('Source facet control failed')
    print(json.dumps({'status': 'pass', 'verified_file_hashes': len(manifest),
                      'author_control': author, 'independent_control': independent,
                      'source_facet_control': source}, indent=2))


if __name__ == '__main__':
    main()
