# Q119: scalar compressions and tough error models — version 2.0

Yuxuan Zhang · 16 November 2026

`main.tex` and `main.pdf` are the authoritative, integrated manuscript.
The earlier exact asymptotic bounds and explicit tough models are retained.
Sections 4–6 add a quantitative gradient–curvature inequality, an
ideal-arithmetic approximate-code search, and a normalized-channel recovery
guarantee. The exact finite integer gap, including c(2,6), remains open.

## Reproduction

Requires Python 3 with NumPy and SymPy. From this directory run:

```sh
python -B reproduce.py > replay.json
```

The runner verifies the release manifest when present, copies the checks
into a fresh temporary directory, and runs them sequentially. Original
files are not changed. Four fixed floating diagnostics must attain their
declared targets for a successful replay. Results can differ slightly with
numerical library versions; they are not interval-certified results.
`REPLAY.json` records the publisher's clean replay.

Build the standalone LaTeX source with:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The numerical routines implement the described search, including the
negative-curvature branch. They are research checks on fixed examples,
not a certified finite-precision solver for arbitrary input. The universal
theorems rely on the analytic proofs in the manuscript.

## Review and provenance

`REVIEW.md` documents the integrated, sequential internal review, its
correction and limits. `CHANGELOG.md` identifies the differences from the
previous manuscript. `MANIFEST.json` hashes release files. The inherited
checks and R037 stage checks are preserved without code changes; their
original notes remain as historical evidence in `checks/`.

**Correction to a historical stage note:** in
`checks/S02-q119-quantitative-landscape/proof-candidate-v1.md`, the optional
assertion of a literal left kernel at every point after Claim 1 requires
`n > (m+1)k`, rather than `n > (m+1)k-1`. At equality the cross block can
be square and invertible. The manuscript corrects this statement, and
`check_kernel_boundary.py` supplies an exact counterexample to the old
wording. The main quantitative theorem and iteration thresholds are
unchanged. Historical notes are not the current manuscript.

This release has same-agent analytical review and finite checks. It has
not received independent expert acceptance or formal proof certification.
The variance objective and transpose/Petz recovery are attributed to
prior work; exhaustive priority and finite-precision complexity remain
unestablished. See the manuscript for precise hypotheses and references.

Website: https://yuxuanzhang1995.github.io/agentic-research/tough-error-models/

This version updates the website. The earlier archival record and catalog
report refer to the previous version and were not updated by this release.
