import sympy as s,json

def blocks(*ms):return s.diag(*ms)

def gram(V,O):
 q=V.rows;G=V+s.I*O/2;B=[]
 for i in range(q):
  for j in range(i,q):
   x=s.zeros(q);x[i,j]=x[j,i]=1 if i==j else s.Rational(1,2);B.append(x)
 Q=s.Matrix([[s.simplify(2*s.trace(b*G*c*G.T))for c in B]for b in B]);return blocks(G,Q)
def psd(A):return A==A.conjugate().T and all(x>=0 for x in A.eigenvals())
rows=[]
for vs,inds in [([1],[0,1]),([1],[0]),([1,2],[0,1,2,3])]:
 O=blocks(*[s.Matrix([[0,1],[-1,0]])for _ in vs]);V=blocks(*[s.eye(2)*v for v in vs]);q=V.rows;S=gram(V,O);D0=S.rows;p=len(inds);Gamma=V+s.I*O/2
 if p==1:
  G=s.diag(1,0);E=s.eye(1);Y=s.eye(1)
 else:
  G=blocks(*[s.eye(2)/(v+s.Rational(1,2))for v in vs]);E=G.inv();Y=s.eye(q)+s.I*O
 A=s.zeros(D0,p);J=s.zeros(D0,p)
 for j,i in enumerate(inds):A[i,j]=J[i,j]=1
 U=E;M=U.row_join(A.T).col_join(A.row_join(S.inv()));T=s.eye(p).col_join(-S*A);dual=s.simplify(T*Y*T.conjugate().T)
 Lam=-2*E
 assert psd(S) and min(S.eigenvals())>0
 assert psd(G) and psd(Gamma.inv()-G)
 assert psd(U-A.T*S*A) and psd(Y)
 assert s.simplify(dual*M)==s.zeros(p+D0)
 assert s.re(dual[:p,:p])==s.eye(p)
 assert 2*s.re(dual[p:,:p])==J*Lam
 rows.append({'modes':len(vs),'parameters':p,'signal_precision':str(G),'cost':str(s.trace(E)),'physical_psd':'passed','dual_stationarity':'passed','complementarity':'passed','boundary_homodyne':p==1})
print(json.dumps({'status':'passed','scope':'Exact equality controls for unreviewed compact-precision/KKT route. Controls do not prove general completeness or novelty.','controls':rows},indent=2))
