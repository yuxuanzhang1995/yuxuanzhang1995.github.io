"""Sharp-battery boundary control at a fixed physical gap."""

from fractions import Fraction as Q
from collections import Counter
import sympy as sp


system = Counter({0: 1, 1: 1})
bath = Counter({0: 1, 1: 2, 2: 1})
shell = Counter()
for i, a in system.items():
    for n, b in bath.items():
        shell[i+n] += a*b

beta_weight = Q(1, 2)
partition = lambda mult: sum(v*beta_weight**k for k, v in mult.items())
z_a, z_e = partition(system), partition(bath)
gap = 1
extra = Counter()
loss = polar_error = 0
for g, d in sorted(shell.items()):
    r = shell[g+gap]
    singular = [Q(j+2, j+3) for j in range(min(d, r))]+[Q(0)]*max(0, d-r)
    defect = d-sum(s*s for s in singular)
    polar = sum((1-s)**2 for s in singular)
    shortage = max(0, d-r)
    assert polar <= defect and shortage <= defect
    # Compare a contraction with its phase-preserving polar isometry;
    # both occupy the required augmented output sector.
    rows = max(d, r)
    m = sp.zeros(rows, d)
    v = sp.zeros(rows, d)
    for j, s in enumerate(singular):
        phase = sp.I**j
        m[j, j] = phase*s
        v[j, j] = phase
    assert v.H*v == sp.eye(d)
    assert sp.trace((v-m).H*(v-m)) == polar
    if shortage:
        extra[g+gap] += shortage
    loss += beta_weight**g*defect
    polar_error += beta_weight**g*polar

assert min(shell[g+gap]-shell[g] for g in shell) == -2
assert extra == {3: 2, 4: 1}
delta = loss/(z_a*z_e)
actual_index = (z_e+partition(extra))/(beta_weight**gap*z_e)
assert 1/beta_weight**gap < actual_index <= 1/beta_weight**gap+z_a*delta
assert polar_error/(z_a*z_e) <= delta
for g, d in shell.items():
    assert shell[g+gap]+sum(a*extra[g+gap-i] for i, a in system.items()) >= d

y = sp.symbols("y", positive=True)
cap_difference = (1+y+y**3)-(1+y**2+y**3)**2
f = sp.cancel(cap_difference/y)
assert sp.expand(f) == 1-2*y-y**2-y**3-2*y**4-y**5
assert f.subs(y, sp.Rational(1, 4)) == sp.Rational(423, 1024)
ratio = (1+y**2+y**3)**2/(y**2*(1+y+y**3))
assert ratio.subs(y, sp.Rational(1, 4)) == sp.Rational(529, 36) < 16
print("PASS: four polar repairs including two deficient energy sectors, exact "
      "Gibbs and singular-value estimates, omitted-level mutation and qutrit endpoint gap.")
