#!/usr/bin/env python3
"""Build-time helper for check_delayed_onset.py (uses numpy; NOT needed to run the checker).

1. Reads the frozen round-38 checker (sha256 pinned) and takes its embedded certificate R verbatim.
2. Recomputes P = W - 2^-14 I - Q^Gamma (Q = R R^dag) in floating point, takes a floating-point Cholesky
   factor of P - 2^-14 I and rounds it coordinate-wise to G' in (2^-GS Z[w])^(144 x 144), lower triangular.
3. Finds the step-(4) rationals a = A6/10^6, b = B6/10^6, the threshold bound TUP6/10^6, and for the explicit
   tau the root brackets RC/10^6 <= (1-2^-20)^(1/1000), RD/10^6 <= 2^(-21/1000) and 26^(333/1000) <= TW/10^6,
   all by exact integer bisection.
4. Writes GS, the rationals, R and G' (zigzag varints + zlib + base64) into check_delayed_onset.py.
Nothing computed here is trusted: the checker re-verifies every claim exactly with the standard library.
Certificate matrices are never printed.
"""
import base64, hashlib, re, zlib
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parents[1] / "round-38" / "frozen-candidates" / "op_c0b1045a614d2353" / "checker.py"
FROZEN_SHA256 = "56000230994a22fb3ef002430742e442749563b163324db9f000cb89c9cd787f"
TARGET = HERE / "check_delayed_onset.py"
GS = 24                                   # G' scale 2^-GS
N, RK, C0, GAM = 144, 110, 2.0**-14, 2.0**-14
PAIRS = [((0,0),(2,2)), ((0,1),(1,2)), ((0,2),(2,1)), ((0,3),(1,0)), ((1,1),(2,3)), ((1,3),(2,0))]
THETA_EXP = [0, 0, 0, 0, 0, 1]
OMEGA = np.exp(2j*np.pi/3)
MU_D, P_DEN, SC, RANK3, EN, EM = 9 << 14, 1000, 10**6, 26, 333, 500
EPS = 20                                  # explicit tau = diag(1 - 2^-EPS, 2^-(EPS+1), 2^-(EPS+1))

def zigzag_varints(vals):
    out = bytearray()
    for x in vals:
        z = 2*x if x >= 0 else -2*x - 1
        while z >= 128: out.append((z & 127) | 128); z >>= 7
        out.append(z)
    return bytes(out)

def to_zw(z, s):  # coordinate rounding of complex z to (a + b w)/2^s, z = (a - b/2) + i (b sqrt3/2)
    b = np.rint(2*z.imag/np.sqrt(3)*2.0**s)
    return np.rint(z.real*2.0**s + b/2).astype(np.int64), b.astype(np.int64)

def bisect_max(pred, lo, hi):  # largest x in [lo, hi) with pred(x); pred monotone, pred(lo) true
    while hi - lo > 1:
        mid = (lo + hi)//2
        lo, hi = (mid, hi) if pred(mid) else (lo, mid)
    return lo

def main():
    src = FROZEN.read_bytes()
    assert hashlib.sha256(src).hexdigest() == FROZEN_SHA256, "frozen checker changed"
    data_r = re.search(rb'^DATA = "([A-Za-z0-9+/=]+)"$', src, re.M).group(1).decode()
    raw = zlib.decompress(base64.b64decode(data_r)); arr = np.frombuffer(raw, dtype="<i8")
    assert arr.size == 2*N*RK
    R = (arr[:N*RK] + OMEGA*arr[N*RK:]).reshape(N, RK)/2.0**32
    K = []
    for (c1, c2), e in zip(PAIRS, THETA_EXP):
        k = np.zeros((3, 4), complex); k[c1] = 1; k[c2] = OMEGA**e; K.append(k)
    Nm = np.array([np.kron(a, b).reshape(-1) for a in K for b in K])   # rows N_ab, index (3s+s')*16 + 4k+k'
    W = Nm.conj().T @ Nm
    Q = R @ R.conj().T
    QG = Q.reshape(9, 16, 9, 16).transpose(0, 3, 2, 1).reshape(N, N)  # Q^Gamma[(i,j),(i2,j2)] = Q[(i,j2),(i2,j)]
    P = W - C0*np.eye(N) - QG
    ev = np.linalg.eigvalsh(P)
    print("float: lambda_min(P) = %.4e, lambda_max(P) = %.4f, 2^-14 = %.4e" % (ev[0], ev[-1], GAM))
    Lc = np.linalg.cholesky(P - GAM*np.eye(N))
    il = np.tril_indices(N)
    for s in (22, 24, 26, 28, 32):
        a, b = to_zw(Lc, s); Gp = np.tril((a + OMEGA*b)/2.0**s)
        E = P - GAM*np.eye(N) - Gp @ Gp.conj().T
        blob = base64.b64encode(zlib.compress(zigzag_varints([int(t) for t in a[il]] + [int(t) for t in b[il]]), 9))
        print("GS = %2d: ||E||_F ~ 2^%.2f (need < 2^-14), G' blob %d chars%s"
              % (s, np.log2(np.linalg.norm(E)), len(blob), "  <- used" if s == GS else ""))
        if s == GS: data_g = blob.decode(); assert np.all(b[np.diag_indices(N)] == 0)
    A6 = bisect_max(lambda A: A**P_DEN*MU_D <= SC**P_DEN, 0, SC)
    B6 = bisect_max(lambda B: B**P_DEN*MU_D <= (MU_D - 8)*SC**P_DEN, 0, SC + 1)
    TUP6 = 1 + bisect_max(lambda t: t**EM < RANK3**EN*SC**EM, 0, 10*SC)
    print("step (4): A6 = %d, B6 = %d, TUP6 = %d, 8*A6 + B6 - TUP6 = %d" % (A6, B6, TUP6, 8*A6 + B6 - TUP6))
    RC = bisect_max(lambda c: c**P_DEN*(1 << EPS) <= ((1 << EPS) - 1)*SC**P_DEN, 0, SC + 1)
    RD = bisect_max(lambda d: d**P_DEN*(2 << EPS) <= SC**P_DEN, 0, SC + 1)
    TW = 1 + bisect_max(lambda t: t**1000 < RANK3**333*SC**1000, 0, 10*SC)
    print("tau: RC = %d, RD = %d, TW = %d, RC + 2*RD - TW = %d, 8*A6 + B6 - ((RC+1) + 2*(RD+1))^2/10^6 = %.6f"
          % (RC, RD, TW, RC + 2*RD - TW, 8*A6 + B6 - ((RC + 1) + 2*(RD + 1))**2/SC))
    txt = TARGET.read_text()
    lines = {"GS = ": "GS = %d; GAM_LOG2 = 14                  # route (b): ||P - G'G'^dag - 2^-14 I||_F < 2^-14" % GS,
             "SC6 = ": "SC6 = 10**6; A6 = %d; B6 = %d; TUP6 = %d   # step (4): a = A6/SC6, b = B6/SC6, "
                       "26^(333/500) <= TUP6/SC6" % (A6, B6, TUP6),
             "EPS_LOG2 = ": "EPS_LOG2 = %d; RC = %d; RD = %d; TW = %d   # tau = diag(1-2^-%d, 2^-%d, 2^-%d): RC/SC6 <= "
                            "(1-2^-%d)^p < (RC+1)/SC6, RD/SC6 <= 2^(-%dp) < (RD+1)/SC6, 26^(333/1000) <= TW/SC6"
                            % (EPS, RC, RD, TW, EPS, EPS + 1, EPS + 1, EPS, EPS + 1),
             "DATA_R = ": 'DATA_R = "%s"' % data_r, "DATA_G = ": 'DATA_G = "%s"' % data_g}
    for prefix, line in lines.items():
        txt, k = re.subn(r"^" + re.escape(prefix) + r".*$", lambda m: line, txt, count=1, flags=re.M)
        assert k == 1, prefix
    TARGET.write_text(txt)
    print("wrote %s (%d bytes); R blob %d chars (verbatim from round 38), G' blob %d chars"
          % (TARGET.name, len(txt.encode()), len(data_r), len(data_g)))

if __name__ == "__main__":
    main()
