"""Reproducible finite diagnostics for the JRF manuscript; not a convergence proof."""
import json,sys
import numpy as np

def one(d,ranks,seed,steps=80):
 rng=np.random.default_rng(seed);m=len(ranks);vs=[];ls=[]
 for rank in ranks:
  v,_=np.linalg.qr(rng.normal(size=(d,rank))+1j*rng.normal(size=(d,rank)))
  vs.append(v);ls.append(np.diag(rng.uniform(.05,1,rank)))
 scale=sum(np.trace(l).real for l in ls);ls=[l/scale for l in ls]
 aa=[v@l@v.conj().T for v,l in zip(vs,ls)]
 assert np.linalg.eigvalsh(sum(aa)).min()>1e-12
 xx=[np.eye(d,dtype=complex)/np.sqrt(m) for _ in aa]
 pp=[np.eye(d,dtype=complex)/m for _ in aa]
 mu=min(np.linalg.eigvalsh(l).min() for l in ls)
 errors={name:0. for name in ['literal_factor','povm_sum','score','support_pullback','normalizer','compression_update','polar_oracle','ascent_violation','competing_linear_violation']}
 def record(name,v):errors[name]=max(errors[name],float(v))
 for _ in range(steps):
  ss=[v.conj().T@x@v for v,x in zip(vs,xx)]
  yy=[x@a for x,a in zip(xx,aa)]
  d2=sum(y.conj().T@y for y in yy)
  dlit=sum(a@p@a for a,p in zip(aa,pp))
  ec,uc=np.linalg.eigh(d2);el,ul=np.linalg.eigh(dlit)
  assert min(ec)>0 and min(el)>0
  dc=(uc*np.sqrt(ec))@uc.conj().T;di=(uc/np.sqrt(ec))@uc.conj().T
  dilit=(ul/np.sqrt(el))@ul.conj().T
  xn=[y@di for y in yy]
  pn=[dilit@a@p@a@dilit for a,p in zip(aa,pp)]
  sn=[v.conj().T@x@v for v,x in zip(vs,xn)]
  record('literal_factor',max(np.linalg.norm(p-x.conj().T@x) for p,x in zip(pn,xn)))
  record('povm_sum',np.linalg.norm(sum(pn)-np.eye(d)))
  score=sum(np.trace(a@x.conj().T@x).real for a,x in zip(aa,xx))
  f=sum(np.trace(l@s.conj().T@s).real for l,s in zip(ls,ss))
  fn=sum(np.trace(l@s.conj().T@s).real for l,s in zip(ls,sn))
  record('score',abs(score-f))
  record('support_pullback',max(np.linalg.norm(y-v@s@l@v.conj().T) for y,v,s,l in zip(yy,vs,ss,ls)))
  record('normalizer',np.linalg.norm(d2-sum(v@l@s.conj().T@s@l@v.conj().T for v,l,s in zip(vs,ls,ss))))
  record('compression_update',max(np.linalg.norm(t-s@l@v.conj().T@di@v) for t,s,l,v in zip(sn,ss,ls,vs)))
  linear=sum(np.trace((s@l).conj().T@t).real for s,l,t in zip(ss,ls,sn))
  record('polar_oracle',abs(linear-np.trace(dc).real))
  record('ascent_violation',mu*sum(np.linalg.norm(s-t)**2 for s,t in zip(ss,sn))-(fn-f))
  z=rng.normal(size=(m*d,d))+1j*rng.normal(size=(m*d,d));z/=np.linalg.norm(z,2)
  qs=[v.conj().T@b@v for v,b in zip(vs,np.split(z,m))]
  trial=sum(np.trace((s@l).conj().T@q).real for s,l,q in zip(ss,ls,qs))
  record('competing_linear_violation',trial-linear)
  xx=xn;pp=pn
 assert max(errors.values())<2e-10
 return dict(dimension=d,ranks=ranks,seed=seed,steps=steps,maximum_residuals=errors)

def run():
 cases=[(2,[1,2]),(2,[1,1,1]),(3,[2,2]),(3,[1,2,1]),(3,[3,3]),(3,[1,1,1,1]),(4,[2,2,1]),(4,[2,3,2]),(4,[4,4,4]),(4,[1,1,1,1,1]),(5,[2,2,2]),(5,[1,3,2,1]),(5,[5,2]),(6,[2,3,4]),(6,[6,6]),(6,[1,2,3,4])]
 result=[one(d,r,2026091900+j) for j,(d,r) in enumerate(cases)]
 return dict(status='passed',ensembles=len(result),total_updates=sum(r['steps'] for r in result),maximum_residual=max(max(r['maximum_residuals'].values()) for r in result),numpy=np.__version__,cases=result,scope='Finite identity diagnostics only. No universal convergence, rate, or optimality claim is inferred from these experiments.')
if __name__=='__main__':
 data=run()
 print(json.dumps(data,indent=2) if '--json' in sys.argv else 'PASS: 16 JRF ensembles, 1280 updates; literal and compressed identities agree within 2e-10. Numerical diagnostics only.')
