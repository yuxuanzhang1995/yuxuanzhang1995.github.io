"""New finite controls for the M03/M07 CAR bridge and M12 quotient weighting.
These check the algebraic interfaces, not the volume-uniform analytic bounds.
"""
from pathlib import Path
import itertools,json
import numpy as np
HERE=Path(__file__).resolve().parent
N=4;dim=2**N
I=np.eye(dim,dtype=complex)
c=[]
for site in range(N):
    a=np.zeros((dim,dim),dtype=complex)
    for x in range(dim):
        if x>>site&1:a[x^(1<<site),x]=(-1)**((x&((1<<site)-1)).bit_count())
    c.append(a)
cd=[a.conj().T for a in c]
number=[a.conj().T@a for a in c]
Z=[I-2*x for x in number]
parity=np.diag([(-1)**x.bit_count() for x in range(dim)])
majoranas=[a+b for a,b in zip(c,cd)]+[1j*(b-a) for a,b in zip(c,cd)]
even=[]
for mask in range(2**(2*N)):
    if mask.bit_count()%2:continue
    O=I.copy()
    for j,g in enumerate(majoranas):
        if mask>>j&1:O=O@g
    even.append(O)
def comm(a,b):return a@b-b@a
def dissipator(l,O):
    d=l.conj().T
    return d@O@l-(d@l@O+O@d@l)/2
def trace_site(O,i):
    paulis=[I,c[i]+cd[i],1j*(cd[i]-c[i]),Z[i]]
    return sum((u@O@u.conj().T for u in paulis))/4
def Delta(O,i,sign):
    part=(O+sign*Z[i]@O@Z[i])/2
    return part-trace_site(part,i)
def zero(x):
    # Every arithmetic input and intermediate here is a small dyadic Gaussian
    # rational, represented exactly by binary64 (integers stay far below 2^53).
    assert np.count_nonzero(x)==0, np.max(abs(x))
counts={'even_majorana_monomials':len(even),'free_oscillator_identities':0,
        'graded_linear_jump_identities':0,'outside_locality_identities':0}
linear=c[0]+2j*c[1]+cd[2]
nonlinear=c[0]@number[1]
G=number[0]@number[1]
def E(O):return dissipator(nonlinear,O)+1j*comm(G,O)
for O in even:
    for i in range(N):
        for sign,rate in [(1,1),(-1,.5)]:
            zero(Delta(dissipator(c[i],O),i,sign)+rate*Delta(O,i,sign))
            counts['free_oscillator_identities']+=1
        for a in (c[i],cd[i]):
            correction=((a@linear.conj().T+linear.conj().T@a)@comm(linear,O)
                        +(a@linear+linear@a)@comm(linear.conj().T,O))/2
            zero(comm(a,dissipator(linear,O))
                 -parity@dissipator(linear,parity@comm(a,O))+correction)
            counts['graded_linear_jump_identities']+=1
        if i>=2:
            for a in (c[i],cd[i]):
                zero(comm(a,E(O))-parity@E(parity@comm(a,O)))
                counts['outside_locality_identities']+=1
            for sign in (1,-1):
                zero(Delta(E(O),i,sign)-E(Delta(O,i,sign)))
                counts['outside_locality_identities']+=1
    # Local annihilation really requires E(I)=0, which holds for this E.
    zero(E(trace_site(trace_site(O,0),1)))

def span(basis):
    s={0}
    for x in basis:s|={y^x for y in tuple(s)}
    return s
def dot(x,y):return (x&y).bit_count()%2
def determinant3(a,b,c):
    rows=[sum(dot(x,y)<<j for j,y in enumerate((a,b,c))) for x in (a,b,c)]
    rank=0
    for col in range(3):
        pivot=next((i for i in range(rank,3) if rows[i]>>col&1),None)
        if pivot is None:continue
        rows[rank],rows[pivot]=rows[pivot],rows[rank]
        for i in range(3):
            if i!=rank and rows[i]>>col&1:rows[i]^=rows[rank]
        rank+=1
    return rank==3

# Compare codes with different Hamming weight distributions. Isometry of the
# quotient is not being inferred from a coordinate-permutation symmetry.
cases=[(9,[0xF]),(9,[0xFF]),(10,[0xF,0x33]),(10,[0xF,0xFF]),
       (11,[0xF,0x33]),(11,[0xF,0xFF])]
records=[];by_dimension={}
for m,basis in cases:
    ds=span(basis);ones=(1<<m)-1
    assert len(ds)==2**len(basis) and ones not in ds
    assert all(x.bit_count()%4==0 for x in ds)
    orth=[x for x in range(1<<m) if all(dot(x,b)==0 for b in basis)]
    reps=sorted({min(x^d for d in ds) for x in orth})
    canon=min(ones^d for d in ds)
    assert len(reps)==2**(m-2*len(basis)) and canon in reps
    assert all(dot(x,x)==dot(canon,x) for x in reps)
    g1=int(dot(canon,canon)==1)
    g2=sum(dot(canon,canon)*dot(v,v)^dot(canon,v) for v in reps if v not in (0,canon))
    g3=0
    for v in reps:
        if v in (0,canon):continue
        forbidden={0,canon,v,min((canon^v)^d for d in ds)}
        for w in reps:
            if w not in forbidden and determinant3(canon,v,w):g3+=1
    result=(g1,g2,g3);key=(m,len(basis))
    if key in by_dimension:assert result==by_dimension[key]
    else:by_dimension[key]=result
    records.append({'m':m,'d':len(basis),'basis':basis,
                    'codeword_weights':sorted(x.bit_count() for x in ds),
                    'nondegenerate_g1_g2_g3_bases_with_c_first':list(result)})
out={'status':'pass','CAR_controls':counts,'M12_quotient_weight_controls':records,
     'limitations':'Exact finite algebraic controls; uniform locality, convolution estimates and all-dimensional counting are reviewed analytically.'}
(HERE/'algebra-controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
