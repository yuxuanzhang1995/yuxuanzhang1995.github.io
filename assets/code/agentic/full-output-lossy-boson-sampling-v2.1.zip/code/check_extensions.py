"""Two different full-output formulas for orthogonal bad-bit inputs, plus scope controls."""
from pathlib import Path
from math import factorial
import itertools, json
import numpy as np
from haar_tv import Geometry, haar, fock

BASE=Path(__file__).resolve().parents[1]/'results'

def partial(U,inputs,gram):
    m=len(U);k=len(inputs);out={}
    perms=list(itertools.permutations(range(k)))
    overlaps={(s,t):np.prod([gram[t[a],s[a]] for a in range(k)]) for s in perms for t in perms}
    for v in fock(m,k):
        rows=[a for a,x in enumerate(v) for _ in range(x)]
        amps={s:np.prod([U[rows[a],inputs[s[a]]] for a in range(k)]) for s in perms}
        p=sum(amps[s]*amps[t].conjugate()*overlaps[s,t] for s in perms for t in perms)
        assert abs(p.imag)<1e-10
        out[v]=float(p.real)/np.prod([factorial(x) for x in v])
    return out

def convolve(p,q):
    out={}
    for v,pv in p.items():
        for w,qw in q.items():
            key=tuple(a+b for a,b in zip(v,w));out[key]=out.get(key,0)+pv*qw
    return out

def partition_formula(U,inputs,x):
    m=len(U);out={}
    for bits in itertools.product((0,1),repeat=len(inputs)):
        wt=np.prod([x[i] if b else 1-x[i] for i,b in enumerate(bits)])
        common=[inputs[i] for i,b in enumerate(bits) if b]
        p=partial(U,common,np.ones((len(common),len(common))))
        for i,b in enumerate(bits):
            if not b:
                single={tuple(int(a==j) for a in range(m)):float(abs(U[j,inputs[i]])**2) for j in range(m)}
                p=convolve(p,single)
        for v,pv in p.items():out[v]=out.get(v,0)+wt*pv
    return out

def full_loss(U,n,eta,conditional):
    out={}
    for k in range(n+1):
        for inputs in itertools.combinations(range(n),k):
            wt=eta**k*(1-eta)**(n-k)
            for v,p in conditional(inputs).items():out[v]=out.get(v,0)+wt*p
    return out

def main():
    rng=np.random.default_rng(440331);cases=[]
    for n in (2,3,4):
        for m in (n,n+1):
            x=np.linspace(.2,.9,n);gram=np.sqrt(x[:,None]*x[None,:]);np.fill_diagonal(gram,1)
            for draw in range(3):
                U=haar(rng,m)
                for eta in (.3,.8):
                    p=full_loss(U,n,eta,lambda I:partial(U,I,gram[np.ix_(I,I)]))
                    q=full_loss(U,n,eta,lambda I:partition_formula(U,I,x[list(I)]))
                    err=sum(abs(p[v]-q[v]) for v in p)
                    assert err<2e-12 and abs(sum(p.values())-1)<2e-12
                    cases.append(dict(m=m,n=n,draw=draw,eta=eta,L1=err))
    # Same pairwise overlap magnitudes, different three-cycle phase: the
    # orthogonal bad-bit reduction must not be extended to arbitrary Gram data.
    states=np.array([[1,0],[1,1],[1,1j]],complex);states/=np.linalg.norm(states,axis=1)[:,None]
    gram=states.conj()@states.T;badbit=np.full((3,3),1/np.sqrt(2));np.fill_diagonal(badbit,1)
    U=np.exp(2j*np.pi*np.arange(3)[:,None]*np.arange(3)[None,:]/3)/np.sqrt(3)
    p=full_loss(U,3,.8,lambda I:partial(U,I,gram[np.ix_(I,I)]))
    q=full_loss(U,3,.8,lambda I:partial(U,I,badbit[np.ix_(I,I)]))
    phase_tv=.5*sum(abs(p[v]-q[v]) for v in p)
    assert np.max(abs(abs(gram)-abs(badbit)))<1e-14 and phase_tv>1e-3
    # Removing the outer projection destroys the signed marginal invariant.
    g=Geometry(4,3);U=haar(rng,4);trans=abs(g.representations(U)[2])**2
    X=g.rho[2];mask=np.array([1. if max(v)<=1 else 0. for v in g.occ[2]])
    raw=mask*(trans@(g.proj[2,2]@X));good=g.proj[2,2]@raw
    residual=float(np.linalg.norm(g.red[2,1]@raw));good_res=float(np.linalg.norm(g.red[2,1]@good))
    assert residual>1e-4 and good_res<1e-12
    report={'partial_distinguishability_cases':len(cases),'max_L1_formula_difference':max(x['L1'] for x in cases),'same_pairwise_visibilities_three_cycle_counterexample_TV':phase_tv,'outer_projection_mutation_reduction_residual':residual,'correct_outer_projection_reduction_residual':good_res,'scope':'Same-agent finite floating checks; exact proof uses orthogonality of private internal occupations. The negative control excludes arbitrary-Gram inference.','cases':cases}
    (BASE/'extension-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
