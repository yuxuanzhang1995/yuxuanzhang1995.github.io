# Full-output simulation of lossy boson sampling — version 2.1

Yuxuan Zhang · 3 November 2026

This supplement accompanies research notes for single-photon Fock inputs at every m >= n and Gaussian inputs with **every mode equally squeezed**, with full-output Haar-average error. **Literature correction:** Lim, [arXiv:2611.01434v1](https://arxiv.org/html/2611.01434v1), already covers both main guarantees and the nonuniform-input thinning reduction. Version 2.0 missed that source. This release adds explicit loss-model consequences and corrects attribution; it makes no priority claim. Independent expert review remains outstanding.

## Reproduce the finite checks

Use Python 3.10 or later with NumPy and SymPy installed. The tested environment was Python 3.13.5, NumPy 2.1.3 and SymPy 1.13.3. No network access is used by the runner.

```text
python3 reproduce.py
```

The runner verifies every payload hash, executes nine finite check suites, compares their scientific counts and mutation controls, and reaggregates the Gaussian Haar CSV against its recorded statistics. The new loss-model suite verifies 6,957 exact assertions, including the thinning law and the bound without l+1. Logs and a receipt appear in `results/`. Rational identities use exact arithmetic; the explicitly identified finite-Fock and prefix comparisons use floating arithmetic.

To rerun both complete recorded Haar grids as well, install Matplotlib and run:

```text
python3 reproduce.py --haar
```

This optional path redraws 1,536 Fock-input and 512 conditional-pair Haar matrices with the recorded seeds. It can take substantially longer. It uses exponential full-Fock enumeration, not the asymptotically efficient sampler. Grid cells sharing a matrix are correlated. The conditional-pair tests do not sample the unbounded squeezed-input number mixture; that tail is controlled analytically in the manuscript.

Regenerate the Gaussian figure from the frozen data with:

```text
python3 code/plot_gaussian.py --data reference/gaussian/E04-haar.csv --out results/gaussian-haar.pdf
```

After the optional Fock replay, `code/analyze_haar.py` produces its figures in `results/haar-tv-results/`.

## Contents and scope

- `manuscript/`: complete LaTeX source and three figures; compile `main.tex` twice with pdfLaTeX.
- The PDF: version 2.1, including exchangeable loss with geometric survival moments, fixed survivor count, independent nonuniform input loss, and the reduced-purity bound without l+1.
- `code/`, `checks/`: mathematical controls and replay scripts, not an optimized production sampler.
- `reference/`: frozen raw data and original stage-specific reports. Their historical scope labels describe each check's role, not the final theorem's status.
- `SOURCE-COMPARISON.md`: checked primary-source assumptions, direct overlap and the correction to the previous novelty assessment.
- `REVISION-NOTES.md`: changes and remaining review limits.
- `PROVENANCE.json`: original/public code hashes and AST comparisons; only import roots and output locations were adapted.
- `REVIEW-STATUS.json`: final scoped claims and review limitations.
- `MANIFEST.json`: payload SHA-256 hashes; generated results are outside this manifest.

The identity runner also retains finite fixed-order vacuum-embedding diagnostics from the derivation. Those diagnostics are auxiliary and do not establish a theorem for extra vacuum inputs, unequal squeezing or general Gaussian states. Likewise, no uniform Gaussian eta-to-one theorem or practical runtime improvement is claimed.

Version 1.1's Fock theorem and exact-check functions are retained. The uniform Fock loss–accuracy and orthogonal bad-bit corollaries were published in version 2.0 alongside the equal-squeezing Gaussian proof. The new input-loss statements require either geometric survival moments or a fixed maximum transmission below one; exchangeability alone and a mean transmission alone are insufficient hypotheses. General path-dependent loss is not included. No new solved-question credit is recorded.

AI assistance was used under human direction for derivation, sources, computation, internal review and drafting. The package's multiple computational constructions come from that workflow, not independent expert review.
