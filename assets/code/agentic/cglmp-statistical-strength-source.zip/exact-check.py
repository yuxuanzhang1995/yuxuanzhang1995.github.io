from fractions import Fraction as F
from math import isqrt

# Every interval endpoint is an exact rational number.
def C(x):
    x = F(x)
    return (x, x)

def add(a, b):
    return (a[0] + b[0], a[1] + b[1])

def neg(a):
    return (-a[1], -a[0])

def sub(a, b):
    return add(a, neg(b))

def mul(a, b):
    vals = [x*y for x in a for y in b]
    return (min(vals), max(vals))

def div(a, b):
    assert b[0] > 0
    return mul(a, (1/b[1], 1/b[0]))

def sqrt_interval(a):
    assert a[0] >= 0
    N = 10**18
    lo = isqrt((a[0].numerator*N*N)//a[0].denominator)
    hi = isqrt((a[1].numerator*N*N)//a[1].denominator) + 1
    result = (F(lo, N), F(hi, N))
    assert result[0]**2 <= a[0]
    assert result[1]**2 >= a[1]
    return result

def ln_point(x):
    assert x > 0
    if x < 1:
        a, b = ln_point(1/x)
        return (-b, -a)
    z = (x-1)/(x+1)
    assert 0 <= z < 1
    n = 80
    s = F(0)
    power = z
    for j in range(n):
        s += 2*power/F(2*j+1)
        power *= z*z
    tail = 2*power/(F(2*n+1)*(1-z*z))
    return (s, s+tail)

def ln_interval(a):
    assert a[0] > 0
    return (ln_point(a[0])[0], ln_point(a[1])[1])

LN2 = ln_interval(C(2))
def log2_interval(a):
    return div(ln_interval(a), LN2)

root2 = sqrt_interval(C(2))
p0 = div(sub(C(3), mul(C(2), root2)), C(8))
p2 = div(add(C(3), mul(C(2), root2)), C(8))
L = add(add(mul(C(-2), p0),
            mul(C(F(1,4)), log2_interval(C(F(3,4))))),
        mul(p2, log2_interval(C(F(5,4)))))

u = sqrt_interval(add(C(2), root2))
v = sqrt_interval(sub(C(2), root2))
q = [div(C(1), mul(C(8), sub(C(2), u))),
     div(C(1), mul(C(8), add(C(2), v))),
     div(C(1), mul(C(8), add(C(2), u))),
     div(C(1), mul(C(8), sub(C(2), v)))]
r = [F(7,10), F(1,20), F(1,20), F(1,5)]
assert sum(r) == 1
assert sum(t[0] for t in q) <= 1 <= sum(t[1] for t in q)
U = C(0)
for qt, rt in zip(q, r):
    U = add(U, mul(qt, log2_interval(div(qt, C(rt)))))

# Check the local construction by exhaustive deterministic assignments.
from itertools import permutations, product
mass = [F(0) for _ in range(4)]
for template, weight in [((0,0,0,3), F(4,5)),
                         ((0,0,1,2), F(1,5))]:
    tuples = list(permutations(template))
    for t in tuples:
        a0 = 0
        b0 = -t[0] % 4
        b1 = (t[1]+1) % 4
        a1 = (t[3]+b1) % 4
        actual = ((a0-b0)%4, (-a0+b1-1)%4,
                  (-a1+b0)%4, (a1-b1)%4)
        assert actual == t
        mass[t[0]] += weight/F(len(tuples))
assert mass == r
for a0, a1, b0, b1 in product(range(4), repeat=4):
    wins = 0
    for x, y in product(range(2), repeat=2):
        a, b = (a0,a1)[x], (b0,b1)[y]
        for i in range(2):
            wins += (((a >> i) & 1) ^ ((b >> i) & 1)) == x*y
    assert wins <= 6

assert L[0] > F(87,1000)
print('Tensor lower bound > 87/1000 bits: certified')
assert U[1] < F(65,1000)
print('CGLMP upper bound < 65/1000 bits: certified')
assert L[0]-U[1] > F(22,1000)
print('Strength separation > 22/1000 bits: certified')
