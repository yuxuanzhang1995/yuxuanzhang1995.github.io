#!/usr/bin/env python3
"""Check packaged hashes and rerun the finite controls in an empty directory."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys, tempfile

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for name,expected in manifest['files'].items():
        p=(root/name).resolve()
        if not p.is_relative_to(root) or not p.is_file():
            raise RuntimeError('Invalid package path: '+name)
        if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Hash mismatch: '+name)
    jobs=[('controls.py','controls-result.json')]
    if (root/'checks/q048_checks.py').exists():jobs.insert(0,('q048_checks.py','q048-checks.json'))
    rows=[]
    with tempfile.TemporaryDirectory(prefix='qi-research-reproduction-') as tmp:
        work=Path(tmp)
        for script,out in jobs:
            shutil.copy2(root/'checks'/script,work/script)
            p=subprocess.run([sys.executable,str(work/script)],cwd=work,capture_output=True,text=True,timeout=600)
            if p.returncode:raise RuntimeError(script+' failed:\n'+p.stdout+p.stderr)
            got=json.loads((work/out).read_text())
            expected=json.loads((root/'expected'/out).read_text())
            if got['status']!='PASS':raise RuntimeError('Checker did not pass')
            if script=='controls.py':
                if got!=expected:raise RuntimeError('Exact control output differs')
                rows.append({'script':script,'status':'PASS','complete_exact_output_match':True})
            else:
                for field in ['exact_physical_intertwining','mutation_mismatches','exact_monogamy_spectrum','exact_constants']:
                    if got[field]!=expected[field]:raise RuntimeError('Exact field differs: '+field)
                if got['numerical_endpoint_controls']['cases']!=expected['numerical_endpoint_controls']['cases']:
                    raise RuntimeError('Numerical case count differs')
                if len(got['numerical_spin_controls'])!=len(expected['numerical_spin_controls']):
                    raise RuntimeError('Spin case count differs')
                rows.append({'script':script,'status':'PASS','exact_fields_match':True,'floating_controls':'Assertions pass; last-bit floating equality is not required'})
    import sympy
    print(json.dumps({'status':'PASS','hashes_verified':len(manifest['files']),'fresh_directory':True,'python':sys.version.split()[0],'sympy':sympy.__version__,'checks':rows,'scope':'Finite controls for an analytical proof; not formal or independent expert certification'},indent=2))
if __name__=='__main__':main()
