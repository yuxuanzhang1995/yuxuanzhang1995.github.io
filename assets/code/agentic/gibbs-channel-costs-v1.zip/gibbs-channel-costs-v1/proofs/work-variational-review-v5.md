# Review and all-error extension of the work variational principle

24 November 2026. Same-root analytic review, not independent verification.
This supplements, rather than overwrites, `work-general-variational-v4.md`.
All statements use normal countable Gibbs baths and an exactly sharp,
nondegenerate battery, with no extra coherence or pure resource supplied.

## All error tolerances, including the nearest-covariant boundary

For any target channel Phi and epsilon >= 0, let

    C_epsilon^all(Phi) = inf { c_all(V) : V is a finite Gibbs isometric
                              dilation and D_ch(Phi,Psi_V) <= epsilon }.

Then the v4 exact variational principle applied separately to every
implemented covariant channel gives the matching identity

    W_epsilon(Phi) = C_epsilon^all(Phi).                 (1)

Empty feasible sets have value infinity. This includes the boundary
epsilon = delta_cov(Phi), which was excluded only from the simplification
to the beta index. Since the covariant channel set is compact and every
covariant finite-system channel has a finite Stinespring dilation,

    W_epsilon(Phi) < infinity iff epsilon >= delta_cov(Phi).

The assertion concerns the normal-bath model. It is not a finite-bath
claim and is not a closed-form evaluation of the optimization in (1).

For epsilon > delta_cov(Phi), v4's mixing argument gives the stronger
simplification W_epsilon=C_epsilon^beta. At the boundary one must retain
c_all; the explicit extreme-channel discontinuity is a counterexample to
using c_beta at epsilon=0 without further hypotheses.

## Check of the exact tail replacement

Normalize the initial environment ground to zero by shifting E and F
by the same constant. This leaves the shift W and the physical partition
identity Z_A Z_E=Z_B Z_F unchanged. Let E_L include the ground and all
energies at most L. Write z_L=Z_(E_L), z_tail=Z_E-z_L and
p_L=z_L(beta)/Z_E(beta). The tail's Gibbs-conditioned channel is covariant.
It has at most d_A d_B Kraus frequencies, each in the fixed finite set
{f_b-e_a}. Its one-dimensional initial environment at

    E_T = -log z_tail(beta)/beta

has precisely the missing Gibbs weight. Its final environment levels are
E_T+W-nu_alpha. The finite direct sum therefore reproduces the original
channel exactly, not just its restriction to a high-probability sector.

For u>=beta, the finite replacement's exponential index divided by e^(uW)
is at most

    Z_E(u)/z_L(u)
      + [Z_B(u)/Z_A(u)] e^[-u(E_T+W)] Z_K,tail(u)/z_L(u).

The first term is <= 1/p_L: every omitted energy exceeds every retained
energy, so the omitted/retained partition ratio decreases with u. The
second term is <= C exp[-u(E_T-C0)] with fixed finite C,C0, since z_L has
a ground contribution and the finite system spectra bound all frequencies.
For large L, E_T>C0, hence its supremum is bounded by
C exp[-beta(E_T-C0)] -> 0. Consequently

    c_all(V_finite) <= W + beta^(-1) log(1/p_L+o(1)) -> W.

This also gives a direct positive-error converse: replace the bath tail
of the actually implemented channel exactly. Its channel error stays
<=epsilon and c_beta<=c_all<=W+o(1). No enlargement of epsilon is needed
for this inequality. Right continuity and mixing are needed only for the
upper bound using approximately achievable beta indices.

## Check of the physical implementation and energy shifts

For a logical dilation V:A E -> B F with shift delta, the initial free
environment is E B F R. The second isometry maps B F R -> A E R with
shift W-delta. The total nonbattery physical space is A B E F R in both
orders, and the combined shift is W. Thus the construction does not
provide a pure E register for free: E starts Gibbs, exactly as specified.

Choose all four finite Hamiltonian grounds to be zero. Then an isometry
of shift delta has delta>=0, while the limit of its index as u->infinity
is delta. Hence W>c_all implies W>delta. The positive-convolution lemma
applies to A_count*E_count - shifted_(W-delta)(B_count*F_count), whose
constant term is positive and whose negative support starts above zero.
Changing these energy reference levels consistently changes delta and
the partition ratio in opposite ways; c_all and c_beta are unchanged.

For the approximate construction, W>c_beta>=0 ensures a positive full
W-shift on the bath. The logical spectator shift W-delta may be negative;
that causes no problem in the deep-coordinate sector construction. Its
signed counting polynomial is allowed negative exponent coordinates.
The full W-shift, not this spectator shift, supplies the global dimension
inequality used to complete the bad input sectors. The battery remains
sharp on those sectors as well.

## Status relative to the original question

The work clause now has a matching finite-dilation variational candidate
at every error, explicit evaluated formulas for CPTP-extreme covariant
channels at zero and asymptotically small error, and a proved bath-model
distinction. The general dilation optimization is still unresolved; at
zero Hamiltonian it contains noncommutative channel factorization.
This reduction is not counted as a complete solution to all of Q117.
