"""Check saved integer separators without invoking an optimizer."""
from itertools import combinations
from pathlib import Path
import json, sys
import numpy as np
from numpy_coverage import enumerate_pairs

base = Path(__file__).resolve().parent
features = []
for x in range(64):
    bits = [(x >> j) & 1 for j in range(6)]
    features.append([1] + bits + [bits[i]*bits[j] for i,j in combinations(range(6),2)])
for index, modulus in enumerate((32,64)):
    if len(sys.argv) == 3:
        pairs = np.loadtxt(sys.argv[index+1], dtype=np.uint64).reshape(-1,2)
        assert len(set(map(tuple,pairs))) == len(pairs)
    else:
        assert len(sys.argv) == 1
        report, pairs = enumerate_pairs(modulus)
    assert len(pairs) == {32:89598,64:139817}[modulus]
    a,b = pairs[:,0],pairs[:,1]
    uncovered = np.ones(len(pairs),dtype=bool)
    bank = json.loads((base/f'mod{modulus}-witness-bank.json').read_text())
    for item in bank:
        coeff = item['coefficients']
        assert len(coeff) == 22 and all(type(c) is int for c in coeff)
        values = [sum(c*f for c,f in zip(coeff,row)) for row in features]
        positive = sum(1<<x for x,v in enumerate(values) if v>0)
        negative = sum(1<<x for x,v in enumerate(values) if v<0)
        assert str(positive) == item['positive_mask'] and str(negative) == item['negative_mask']
        match = ((a&np.uint64(positive))==a)&((b&np.uint64(negative))==b)
        uncovered &= ~match
    assert not uncovered.any()
    print(f'modulus={modulus}; pairs={len(pairs)}; integer witnesses={len(bank)}; uncovered=0; optimizer called=False')
