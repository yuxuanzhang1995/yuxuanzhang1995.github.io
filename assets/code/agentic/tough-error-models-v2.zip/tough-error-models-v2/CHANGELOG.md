# Version 2.0 — 16 November 2026

- Retained the original arbitrary-error definition, exact scalar-compression
  proof, explicit tough models, and asymptotically matching bounds from v1.1.
- Added the complete general Hessian calculation and sharp traceless-stack
  estimate, including the quantitative gradient–curvature inequality.
- Added a specified two-branch geodesic search with a proved ideal-arithmetic
  iteration count and a basis-qualified approximate Knill–Laflamme residual.
- Added a completely positive, trace-preserving polar/transpose recovery,
  singular-matrix analysis, a residual-to-diamond estimate, and the
  normalized-channel search corollary.
- Distinguished Kraus normalization from the original arbitrary error space,
  and ideal arithmetic from finite-precision or qubit-efficient complexity.
- Corrected one auxiliary left-kernel threshold in the historical R037 S02
  note. No main result or main search threshold was changed by this correction.
- Added primary-source attribution for variance optimization, transpose
  recovery, approximate QEC conditions, and Stinespring continuity.
- Added portable finite checks, review records and versioned website assets.

The author remains Yuxuan Zhang. No affiliation or coauthor was added.
The remaining integer problem, in particular c(2,6), is not resolved here.
