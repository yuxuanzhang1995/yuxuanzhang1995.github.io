# Evidence-mapped outline — n_min = 7 (drafting stage 1; prose follows in semi-clifford-six-qubits.tex)

Evidence classes: E# = external source (EVIDENCE.json); K = line(s) of the standalone checker; R28/R31/R33 = internal
AI adversarial reviews (round-28, round-31, round-33 REVIEW.md); P = proved in the manuscript itself.

## Claims
| ID | Claim | Type | Evidence |
|---|---|---|---|
| C01 | Definitions of C_k(n) (Pauli group with arbitrary phases), SC(n), n_min exactly as in the problem record | declaration | E1 Eqs. (1)-(2) |
| C02 | The hierarchy was introduced by Gottesman and Chuang | factual | E2 |
| C03 | C_3(n) ⊆ SC(n) for n ≤ 3 (and all levels for n ≤ 2) | factual | E3 abstract; E1 Eq. (3) |
| C04 | C_3(4) ⊆ SC(4) | factual | E5 abstract; E1 Eq. (5) |
| C05 | A seven-qubit gate of Gottesman–Mochon lies in C_3(7)∖SC(7) | factual | E4 §1.1 |
| C06 | Every C_3 gate is generalized semi-Clifford | factual (load-bearing input) | E4 Thm 1.1 (verbatim) |
| C07 | Generalized semi-Clifford ⇒ P L1 R L2 diagonal | factual (load-bearing input) | E3 Prop. 2 (verbatim) |
| C08 | n = 5, 6 stated open by He–Robitaille–Tan; they characterise C_3 permutation gates (staircase form) | factual | E6 §2.1, abstract, Cor. 3.9 |
| C09 | Permutation gates in C_3 on ≤ 6 qubits are semi-Clifford (He–Robitaille–Tan App. A) | factual (context only) | E6 App. A (read by the final audit); E1 Eq. (6) |
| C10 | Correspondence abelian regular subgroups ↔ radical rings | factual (attribution) | E7 abstract; re-proved (P) |
| C11 | Third-level diagonal gates = Cliff + H_id (qubits) | result | P (Lemma 4, proof in text); E8 attribution; K (C5 lines) |
| C12 | Monomial Clifford ⇒ affine permutation part | result | P; R33 Priority 2 |
| C13 | Single-layer lemma for n ≤ 6 under the affine-conjugation hypothesis | result | P; R31 (proof), R33 (line-by-line check) |
| C14 | Nondegenerate classes for m+t ≤ 6: TOF, B, C, TRI, SEC, TAN, EXT; orbit sizes 1, 28, 7, 1, 280, 210, 56 | result | P (hand) + K (census, derived twice); R31, R33 (full-group enumeration) |
| C15 | Klein line counts 105/280/210/56 | result | P (hand count); R33 |
| C16 | Eighth-root reduction θ(b)−θ(0) ∈ (π/4)ℤ | result | P; R31 |
| C17 | A_π ⊇ Cliff + Cliff∘π + H_π | result | P |
| C18 | log2|A_π| = 38, 38, 33 (n=5) and 56, 56, 47, 47, 47, 47, 43 (n=6), equal to the generated subgroup's size | result (computer-assisted) | K; R28, R31, R33 (three independent recomputations; R33 from the literal definition) |
| C19 | Restriction argument covers n < 6 | result | P; R33 |
| C20 | Explicit factorisation U = C1 D1 π_f D_h D2 C2 = (C1 D1 H_T) E (H_T D2 C2) | result | P; R33 |
| C21 | Main Theorem: C_3(n) ⊆ SC(n) for n ≤ 6 | result | C06, C07, C11–C20 |
| C22 | The 7-qubit permutation y is in C_3(7), S_U = ⟨X_7,Z_1,Z_2,Z_3⟩ isotropic, so not semi-Clifford | result (hand-proved, program-confirmed) | P (Proposition 17) + K; R33 (own code); final audit |
| C23 | n_min = 7 | result | C21 + C22 |
| C24 | Only substantive published input: E4 Thm 1.1 (with E3 Prop. 2) | declaration | R33 Priority 2; P |
| C25 | Novelty: no arXiv paper through 26 Sep 2026 settles n = 5 or 6 | factual (search-limited) | R31, R33 arXiv newest-first searches; E6 §2.1 |
| C26 | Review status: three AI reviews, no human review | declaration | R28, R31, R33; INTERNAL_REVIEW.json |

## Unresolved-issues log (kept out of the prose)
- E6 Appendix A item numbers (Lemma A.3, Thm A.6, Prop. 5.8) not confirmed; the Appendix A statement itself was read by the final audit and is cited as context only, never used in the proof.
- E9 not read directly: context sentence only.
- Transitivity of GL(4,2) on each Klein line type is taken from the computation (K) — not re-proved by hand.

## Section plan
1 Introduction (C01–C05, C08, C21, C23, C24) · 2 Preliminaries (Lemmas 3–5; Lemma 4 = C11) ·
3 Reduction (C06, C07, C12) · 4 Single-layer lemma (C10, C13) · 5 Classification (C14, C15) ·
6 Admissible phases (C16–C19) · 7 Main theorem (C20, C21) · 8 Upper bound (C22, C23) · 9 Verification (K, R) ·
10 Discussion (C09, C24, C25) · AI assistance and review status (C26) · References (E1–E10).
