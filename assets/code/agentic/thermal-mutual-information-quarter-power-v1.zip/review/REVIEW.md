# Q048 / P13: review of the full thermal lower-bound candidate

13 November 2026. Reviewer relation: same root/model, with newly written
computational controls. This is not an independent agent or expert audit.
The reviewed proof is the unchanged
[R306/C01 v2](../proof-reviewed.md),
SHA-256 `01e2e98f9ae37c9f0091e2aeef7ad29b5b27750aa09c9714baf6f1f7595ef2f0`.
Input identities are in [../PROVENANCE.json](../PROVENANCE.json).

**Verdict:** supported internally as a complete-original proof candidate.
No fatal gap was identified in the all-size argument. Novelty and independent
review remain unresolved. The evidence is stronger than a script replay:
the endpoint comparison, arbitrary spin sectors, scalar ground transform and
full partition-function estimate were inspected analytically.

## Original-statement mapping

The immutable input is `questions/P13.json`. It requests some uniformly bounded
local dimension, range and local term norms in one dimension, a sequence
beta_n tending to infinity, and a middle-cut Gibbs mutual-information lower
bound with any fixed exponent strictly exceeding 1/5. It does not require
translation invariance, n-independent coupling constants or a bound at every
real temperature.

The candidate uses N dimension-nine sites after folding, range one, a bounded
number of bounded terms per site/edge, N divisible by four and N>=2^30. Its
parameters are beta_N=2^44 N^4 and I(L:R)>=(ln 2)N/8. Consequently gamma=1/4,
a=0, c=(ln 2)/(8*2^11) meet the original. The inverse-temperature sequence
and small N-dependent potential are admissible. The large constants make
this an asymptotic construction, not a practical-temperature claim.

## Local model and exact decomposition

The strict boundary interaction exchanges a hole and a particle on both rings
at once. It vanishes if either endpoint pair contains two holes. This detail
is necessary: blindly extending the old one-hole boundary formula would
allow a one-ring motion and lose the spin alignment.

Folding pairs sites within each ring, never across L:R. Both endpoint
interactions become interactions of the two middle dimension-nine sites.
The middle cut and bounded interaction count are preserved.

At fixed particle counts, sorting spins by occupied site order is a unitary
charge/spin identification. Interior hopping acts on occupations alone.
The synchronized edge carries the adjoint of the first-to-last spin rotation;
this orientation in v2 agrees with the physical operator. Contact acts as
the singlet-complement projection on the first occupied pair. These are full
operator identities, including arbitrary coherent spin states.

## The N^-3 coercivity estimate

The imported exclusion-process gap applies with unit edge rates. Removing
the spin twist gives the sum of two path-exclusion Laplacians, followed by
additional positive edges; its nonconstant gap is at least 4/N^2. Trivial
zero/full occupation factors are treated separately.

The endpoint estimate in equation (11) can be reconstructed without treating
charges as independent. Each event uses at most two positions per ring.
Send these positions to a uniformly chosen distinct ordered tuple, extending
the map by at most two transpositions per ring. Each long transposition
has an adjacent-swap word of length at most 2N and uses each path edge at
most twice. Across the two rings the total word length is at most 8N and
edge multiplicity at most eight. Telescoping, Cauchy--Schwarz, uniform-measure
invariance at each prefix and the Dirichlet-form normalization give the
stated conservative 128N coefficient. Only occupations are transported;
this step does not permute physical spin labels in the interior model.

In the central density band the synchronized-event probability is at least
1/256 and the contact probability at least 1/16. Combining the endpoint
comparison with the boundary/contact forms yields equation (14)'s constants.
Those constants and their combination into (19) were checked exactly.

For equal counts, simultaneous rotation permutes the Bell-pair word basis.
Each non-singlet orbit has length at most the spin count and a contact defect;
the finite-cycle Poincare estimate gives (16) off the all-singlet line.
For unequal counts, rotating by the smaller count returns one ring but
moves the paired spin on the other. Two singlet projectors sharing a qubit
satisfy Q1 Q2 Q1=Q1/4, hence ||Q1+Q2||=3/2. This gives (17)--(18) for
arbitrary spin vectors, without an expensive least-common-multiple cycle.
Together with the charge variance, the result is (19), an N^-3 bound on
every central unwanted spin subspace.

## Scalar potential and all charge sectors

The local potential lies between -1/(64N^3) and zero. Its exact charge-sector
mean is the quadratic expression (21), minimized at half filling. Temple's
inequality uses a second eigenvalue at least 4/N^2-a_N and a trial variance
at most a_N^2; the error 1/(4096N^4) is conservative. One-point sectors have
zero variance and are handled directly.

It would be invalid to subtract the full potential norm from the very small
spin gap. The actual proof avoids that step: scalar heat-kernel mixing at
time N^3, with at most 4^N configurations, gives the pointwise kernel bounds.
Feynman--Kac then bounds the positive scalar ground-vector ratio by
3 exp(1/64)<4. This controls the weights in the exact twisted ground-state
transform, not just the vector's L2 distance from the constant vector.

For psi(x)=u(x)f(x), the scalar eigenvector equation cancels the potential and
diagonal correction. Every twisted kinetic edge receives u(x)u(y); contact
receives u(x)^2. The same identity holds for arbitrary unitary twists.
This preserves the pointwise unwanted-spin subspace and yields (27) relative
to the scalar energy in that charge sector. Vector-valued diamagnetism covers
all remaining sectors, including empty/full rings. The quadratic charge mean
separates noncentral densities; the N^-4 Temple error is absorbed by N^-3
spin separation at the declared threshold. Thus (31) covers the entire bad
subspace, not just nearby particle counts.

## Actual Gibbs state and entropy

The good subspace contains all charge-clock excitations in central equal-count
sectors with their ordered singlet vector. It is reducing. There is a good
state at energy E_*, while every bad state has energy at least
E_*+2^-40 N^-3. Using the entire Hilbert dimension 3^(2N) in the numerator
and that one good state in the partition function gives bad weight <exp(-13N)
at beta=2^44 N^4. This directly treats the unconstrained Gibbs ensemble.

Local count measurement, ordered-spin extraction and padding define genuine
CPTP maps on every sector. They extract N/4 singlets on every good state,
including arbitrary clock mixtures. Entropy continuity and local data
processing give the displayed mutual-information lower bound. There is no
postselection on a successful charge measurement.

## Computational evidence and limits

The original script was rerun from a new temporary directory: 22,113 exact
operator-column comparisons, 50 exact charge means, four mutation classes,
126 floating-point endpoint controls and 16 floating-point spin controls
passed. The integer operator comparison uses twice the Hamiltonian on both
sides consistently. See [q048-reproduction.json](q048-reproduction.json).

New code, without importing the original checker, verifies the twisted
ground transform with a nonconstant positive rational u in two N=3 sectors
(dimensions 72 and 144). A deliberately wrong u(x)^2 edge weight fails.
Eight rational constant controls pass. The artificial scalar potential in
this control is chosen to make u an eigenvector: it tests the identity,
not the physical thermal distribution. See [bottleneck_checks.json](bottleneck_checks.json).

These finite checks do not prove the all-size theorem. That judgment rests
on the analytic steps above. The principal remaining review risk is a missed
interaction among those steps, so a fresh proof review should concentrate on
equations (11), (17), and (26)--(31), rather than replaying the same script.

## Source and release status

The thermal baseline in Kuwahara--Alhambra--Anshu has exponent 1/5 with a
logarithmic loss; the 1/4 ground-state gap exponent in Gottesman--Hastings
is a different quantity. The two-ring architecture and folding are inherited.
The candidate's proposed added content is its finite-density strict boundary,
all-spin coercivity and local density selection giving a full thermal bound.
The latest checked Gibbs-MPS source concerns upper/representation results,
not this lower-bound construction. Precise versions and limits of this
comparison are in [PRIMARY-COMPARISON.md](PRIMARY-COMPARISON.md).

The bounded search did not identify a source covering the exact thermal
statement. That is not a priority clearance. Retain the full-original
candidate, with independent mathematical review and priority still pending.
No publication or catalogue submission was performed.
