"""Exact integer counts and exhaustive small doubly-even code controls."""
from fractions import Fraction as F
from pathlib import Path
import json
def orthogonal_count(h,d,sign):
    if d<0:return 0
    if d==0:return 1
    if d>h:return 0
    x=F(1)
    for r in range(d):
        k=h-r;x*=F(2**(2*k-1)+sign*2**(k-1)-1,2**(d-r)-1)
    assert x.denominator==1
    return int(x)
def symplectic_count(h,d):
    if d<0 or d>h:return 0
    x=F(1)
    for r in range(d):x*=F(2**(2*(h-r))-1,2**(d-r)-1)
    assert x.denominator==1
    return int(x)
def counts(m,d):
    if m%2:
        h=(m-1)//2;s=1 if m%8 in (1,7) else -1
        n=orthogonal_count(h,d,s);return n,n
    h=(m-2)//2
    if m%4==0:
        s=(-1)**(m//4);no=(2**d)*orthogonal_count(h,d,s)
        return no+orthogonal_count(h,d-1,s),no
    n=symplectic_count(h,d);return n,n
def enumerate_codes(m,maxd):
    allowed=[x for x in range(1,2**m) if x.bit_count()%4==0]
    spaces={frozenset([0])};rows=[]
    for d in range(maxd+1):
        n,no=counts(m,d);actual_no=sum((2**m-1) not in s for s in spaces)
        assert len(spaces)==n and actual_no==no,(m,d,len(spaces),n,actual_no,no)
        for i in range(m):
            short=sum(all(not(x>>i&1) for x in s) for s in spaces)
            assert short==counts(m-1,d)[0]
        rows.append({'m':m,'d':d,'all':n,'excluding_ones':no})
        if d<maxd:
            nxt=set()
            for s in spaces:
                for x in allowed:
                    if x in s or any((x&y).bit_count()%2 for y in s):continue
                    nxt.add(s|frozenset(x^y for y in s))
            spaces=nxt
    return rows
def main():
    rows=[]
    for m in range(3,10):rows.extend(enumerate_codes(m,min(3,m//2)))
    large=[]
    for m in range(5,129):
        for d in range(1,m//2+1):
            n,no=counts(m,d)
            if not no:continue
            ratio=F(counts(m-1,d)[0],no)
            assert ratio<=F(2,2**d),(m,d,ratio)
            large.append((m,d))
    out={'status':'pass','exhaustive_counts':rows,'integer_ratio_controls':len(large),
         'scope':'Exact small exhaustive verification and algebraic formula controls; general proof is in candidate text.'}
    (Path(__file__).resolve().parent/'check-results-new.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'pass','small_cases':len(rows),'ratio_cases':len(large)}))
if __name__=='__main__':main()
