"""Finite diagnostics for the low-energy precision manuscript.

These checks corroborate formulas. They are neither a proof of a uniform
inequality nor independent human verification. Run from any directory with
Python 3, mpmath, and numpy. Only diagnostic-results.json is written.
"""
from datetime import datetime, timezone
from pathlib import Path
import json

import mpmath as mp
import numpy as np


def check_polynomials():
    mp.mp.dps = 160
    records = []
    for M in [1, 2, 4, 8, 16, 32]:
        for r in [1, 2, 7]:
            T = mp.mpf(M) * r * r / 32
            b = [mp.mpf(0), T / (r * r)]
            for j in range(1, M):
                b.append(b[-1] * (j * j - mp.mpf(1) / (r * r))
                         / ((j + 1) * (mp.mpf(j) + mp.mpf('0.5'))))
            c = [mp.mpc(1)]
            for n in range(1, M):
                c.append(-mp.j * sum(j * b[j] * c[n-j]
                                     for j in range(1, n+1)) / n)
            grid = [mp.mpf(j) / 100 for j in range(101)]
            grid += [mp.mpf('0.001'), mp.mpf('0.005')]
            max_mod = mp.mpf(0)
            max_ratio = mp.mpf(0)
            for z in grid:
                f = sum(mp.binomial(16*M, j) * z**j * (1-z)**(16*M-j)
                        for j in range(M))
                P = f * sum(c[j] * z**j for j in range(M))
                target = mp.exp(-mp.j * T * mp.sin(mp.asin(mp.sqrt(z))/r)**2)
                assert abs(P) <= 1 + mp.mpf('1e-140'), (M, r, z, abs(P))
                max_mod = max(max_mod, abs(P))
                if z:
                    ratio = abs(P-target) / (64*z)**M
                    assert ratio <= 1 + mp.mpf('1e-60'), (M, r, z, ratio)
                    max_ratio = max(max_ratio, ratio)
            records.append({
                'M': M, 'r': r, 'T': str(T), 'grid_points': len(grid),
                'max_modulus': mp.nstr(max_mod, 20),
                'max_error_over_bound': mp.nstr(max_ratio, 20),
            })
    assert 16 * 7**15 > 2 * 8**15  # Exact integer inequality.
    return {'decimal_precision': 160, 'parameter_cases': len(records),
            'grid_checks': sum(x['grid_points'] for x in records), 'records': records}


def haar_unitary(n, rng):
    q, r = np.linalg.qr(rng.normal(size=(n, n)) + 1j*rng.normal(size=(n, n)))
    phases = np.diag(r)
    return q @ np.diag(phases / abs(phases))


def check_general_encodings(rng):
    records = []
    for n in [2, 4, 6]:
        for r in [1, 2, 7]:
            left, right = haar_unitary(n, rng), haar_unitary(n, rng)
            singular = np.linspace(0, 0.1/r, n)
            A = left @ np.diag(singular) @ right.conj().T
            dleft = left @ np.diag(np.sqrt(1-singular**2)) @ left.conj().T
            dright = right @ np.diag(np.sqrt(1-singular**2)) @ right.conj().T
            V = np.block([[A, dleft], [dright, -A.conj().T]])
            # Independent junk-space rotations preserve the encoded top-left block.
            lrot, rrot = np.eye(2*n, dtype=complex), np.eye(2*n, dtype=complex)
            lrot[n:, n:] = haar_unitary(n, rng)
            rrot[n:, n:] = haar_unitary(n, rng)
            V = lrot @ V @ rrot
            Pi = np.diag([1]*n + [0]*n)
            Pip = V.conj().T @ Pi @ V
            R = 2*Pi - np.eye(2*n)
            Rp = 2*Pip - np.eye(2*n)
            B = np.linalg.matrix_power(-Rp @ R, r)
            Z = (2*np.eye(2*n) - B - B.conj().T) / 4
            clean_vectors = np.vstack([right, np.zeros((n, n))])
            z = np.sin(r*np.arcsin(singular))**2
            defects = {
                'unitarity': np.linalg.norm(V.conj().T @ V-np.eye(2*n), 2),
                'encoded_factor': np.linalg.norm(V[:n, :n]-A, 2),
                'compressed_projector': np.linalg.norm(Pip[:n, :n]-A.conj().T@A, 2),
                'walk_on_clean_eigenvectors': np.linalg.norm(Z@clean_vectors-clean_vectors@np.diag(z), 2),
                'inverse_branch': np.max(abs(np.sin(np.arcsin(np.sqrt(z))/r)**2-singular**2)),
            }
            assert max(defects.values()) < 1e-11, (n, r, defects)
            records.append({'system_dimension': n, 'r': r,
                            'defects': {k: float(v) for k, v in defects.items()}})
    return {'parameter_cases': len(records), 'absolute_tolerance': 1e-11, 'records': records}


def check_degree_stripping(rng):
    records = []
    for degree in [1, 2, 4, 8, 16]:
        coef = [haar_unitary(2, rng)]
        for _ in range(degree):
            v = haar_unitary(2, rng)[:, 0]
            E = np.outer(v, v.conj())
            new = [np.zeros((2, 2), complex) for _ in range(len(coef)+1)]
            for j, c in enumerate(coef):
                new[j] += (np.eye(2)-E) @ c
                new[j+1] += E @ c
            coef = new
        original = coef
        factors, defects = [], []
        for _ in range(degree):
            u, _, _ = np.linalg.svd(coef[-1])
            E = np.outer(u[:, 0], u[:, 0].conj())
            defects += [np.linalg.norm(E@coef[0]),
                        np.linalg.norm((np.eye(2)-E)@coef[-1])]
            factors.append(E)
            coef = [(np.eye(2)-E)@coef[j] + E@coef[j+1]
                    for j in range(len(coef)-1)]
        for theta in np.linspace(0, 2*np.pi, 17):
            w = np.exp(1j*theta)
            expected = sum(c*w**j for j, c in enumerate(original))
            actual = coef[0]
            for E in reversed(factors):
                actual = (np.eye(2)-E+w*E)@actual
            defects.append(np.linalg.norm(expected-actual))
        assert max(defects) < 1e-10, (degree, max(defects))
        records.append({'degree': degree, 'max_defect': float(max(defects))})
    return {'parameter_cases': len(records), 'absolute_tolerance': 1e-10, 'records': records}


def check_four_sign_polynomialization(rng):
    records = []
    for queries in [0, 1, 2, 3, 4, 5, 6, 8]:
        gates = [haar_unitary(4, rng) for _ in range(queries+1)]
        controlled = rng.integers(0, 2, size=queries)

        def amplitude(a, b):
            V = np.array([[a, b], [b, -a]], complex)
            state = gates[0][:, 0]
            for j in range(queries):
                oracle = np.kron(np.eye(2), V)
                if controlled[j]:
                    oracle[:2, :2] = np.eye(2)
                state = gates[j+1] @ oracle @ state
            return state[0]

        def average(y):
            return sum(amplitude(alpha*np.sqrt(y), beta*np.sqrt(1-y))
                       for alpha in [-1, 1] for beta in [-1, 1]) / 4

        xs = (1+np.cos(np.linspace(0, np.pi, 31))) / 2
        vals = np.array([average(x) for x in xs])
        fit = np.polynomial.Polynomial.fit(xs, vals, queries//2, domain=[0, 1])
        probe = np.linspace(0, 1, 64)
        observed = np.array([average(x) for x in probe])
        defect = float(np.max(abs(fit(probe)-observed)))
        assert defect < 1e-11 and max(abs(observed)) <= 1+1e-12
        records.append({'queries': queries, 'degree_bound': queries//2,
                        'max_fit_defect': defect, 'max_modulus': float(max(abs(observed)))})
    return {'parameter_cases': len(records), 'absolute_tolerance': 1e-11, 'records': records}


if __name__ == '__main__':
    rng = np.random.default_rng(20260921)
    result = {
        'status': 'passed',
        'completed_at': datetime.now(timezone.utc).isoformat(),
        'scope': 'Finite deterministic diagnostics; not a proof or external confirmation.',
        'versions': {'numpy': np.__version__, 'mpmath': mp.__version__},
        'polynomial': check_polynomials(),
        'general_factor_encodings': check_general_encodings(rng),
        'unitary_degree_stripping': check_degree_stripping(rng),
        'four_sign_polynomialization': check_four_sign_polynomialization(rng),
    }
    path = Path(__file__).with_name('diagnostic-results.json')
    path.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({
        'status': result['status'], 'polynomial_grid_checks': result['polynomial']['grid_checks'],
        'factor_encodings': result['general_factor_encodings']['parameter_cases'],
        'synthesis_cases': result['unitary_degree_stripping']['parameter_cases'],
        'circuit_cases': result['four_sign_polynomialization']['parameter_cases'],
    }))
