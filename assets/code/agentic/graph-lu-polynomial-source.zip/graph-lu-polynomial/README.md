# Polynomial-time decision of local-unitary equivalence for graph states

Yuxuan Zhang

1. Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
2. Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

Working manuscript dated 22 September 2026. AI-assisted proof candidate; independent expert review and historical-priority verification are pending. This is a full exposition of the round-21 candidate, not a new research round or another solved-problem count.

## Scope

The proposed theorem decides local-unitary equivalence of arbitrary finite simple graph states on the same labelled vertex set in deterministic polynomial bit complexity. It depends on the credited Claudet–Perdrix graph reductions. The contribution is a polynomial incidence-module closure, its complete modular-kernel and binary-image construction, and the verification that they meet the reduction's hypotheses.

The claim does not include vertex relabelling, an optimized exponent, practical performance, or a complete executable implementation of the graph-state algorithm. The scripts check finite algebraic systems and a restricted graph-reduction primitive. They do not certify the general theorem or implement the full polynomial MLS standardization algorithm.

## Files

- `graph-lu-polynomial.pdf` and `graph-lu-polynomial.tex`: the 12-page manuscript and its LaTeX source.
- `frozen-proof.md`: the unchanged three-part proof from round 21 and QIQC issue #97.
- `check_graph_closure.py`, `check_graph_image.py`: the original exact diagnostic scripts.
- `graph-closure-checks-rerun.json`, `graph-image-checks-rerun.json`: the original rerun outputs from 22 September 2026.
- `check_extended.py`, `extended-results.json`: earlier targeted checks and results.
- `check_recheck.py`, `recheck-results.json`: a fresh dual-lattice implementation, large-modulus checks, complete image/witness enumeration, restricted gadget comparisons, and a 27-vertex LU-but-not-LC control.
- `consistency_manifest.json`, `consistency-report.json`: the descriptive numeric/method registry and K-Dense consistency-check output (not a mathematical certificate).
- `review-record.json`: the two historical internal AI reviews of the frozen claim. These are not human reviews or new reviews of the formatted manuscript.
- `source-manifest.json`, `claim-evidence-map.json`: source locators, proof obligations, verification scope, and pending review.
- `SHA256SUMS`: hashes of every other archive member.

## Reproduction

Use Python 3 with NumPy 2.5.3 and SymPy 1.14.0 (the versions in the recorded container). Both additional scripts need only SymPy and the standard library. Do not enable Python's `-O` option: the diagnostics use assertions. In a writable copy of this directory, run:

```sh
python check_graph_closure.py
python check_graph_image.py
python check_extended.py
python check_recheck.py
```

Each script writes JSON beside itself. The original scripts select finite binary instances with fixed random seeds. The additional scripts enumerate their stated families deterministically. The recorded runs used the local `qiqc-sandbox:v1` container with networking disabled. That image is not required to run these standalone scripts.

Expected results:

| Family | Coverage |
|---|---|
| Original closure checks | 45 comparisons; all pass, all stabilize at the seed lattice |
| Original kernel/image checks | 36 comparisons; all pass |
| Extended Boolean-pattern closures | 24 systems; 12 require strict enlargement, up to 3 steps |
| Seed-only mutation | Detected in all 12 systems requiring enlargement |
| Arbitrary 2-by-2 matrices over Z/4 | All 256 matrices; complete kernels agree with enumeration |
| Certified nonfree kernels | 81 of those kernels have cardinality 2 or 8 |
| Binary incidence matrices | All matrices of shapes 2-by-3 and 3-by-2 at levels 1, 2, 3: 384 systems, 42,752 multiplicity vectors |
| Zero toggle images | 129 of the 384 incidence systems |
| Explicit boundaries | Empty graph, empty support, empty outside set, isolated vertices at level one, zero toggle image |

The second recheck passes the following families:

| Family | Coverage |
|---|---|
| Large-modulus closures | 16 Boolean-pattern systems, levels through r=256; all attain the sharper bound |
| Deliberate wrong variants | Omitting triple seeds and omitting the factor two are both detected |
| Dual-lattice general kernels | All 256 two-by-two mod-4 matrices; 81 certified nonfree kernels; 3 unconstrained boundaries |
| Literal incidence and full images | All binary 3-by-3 matrices at levels 2 and 3: 1,024 systems and 294,912 multiplicity vectors |
| Carried image-basis witnesses | All 2,928 binary combinations pass |
| Restricted gadget comparison | 2,460 cases: 1,020 accept and 1,440 reject; all agree with direct graph search |
| Excluded arbitrary-support cases | 261 zero-image support/level cases, because the general zero-image lemma requires standard form |
| Ordinary LC reference comparison | 1,105 connected small-graph pairs with an even-degree vertex: 379 yes and 726 no |
| Higher-level control | One 27-vertex common-standard-form pair: valid level-two operation, not ordinary LC |

The higher-level control uses all four- and five-subsets of a six-element set as the 21 support vertices. The second graph adds the six-vertex clique. Each pair has ten common neighbors, each triple six, so all-one multiplicities are valid at level two. All 42 support stars are checked to be minimal local sets, giving a common standard form. The ordinary-LC linear solution space has dimension eight; its entire 256-element space is checked and rejected by the determinant conditions. The 15-dimensional toggle image and the 21-vertex constrained gadget both accept the generalized transformation. This is a diagnostic construction, with no novelty claim.

These rows count different objects; do not add them to estimate an independent sample size. The fresh checker imports no earlier checker and uses `q*H.inv()` to construct the kernel, rather than the earlier modular elimination code. It still shares the same underlying mathematical claim, and is not a human review.

Build the manuscript with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
```

All 12 rendered pages were visually inspected. The final compiler log contained no unresolved references or layout warnings. PDF hashes need not be identical across builds because TeX embeds build metadata.

## Relationship to the frozen proof

The original proof is preserved byte for byte (SHA-256 `682c2e29f0818e51f04fc850fe9a535ff1fafb9b412ce416f82ec88131ade9fb`). Its Part I becomes manuscript Section 3; Part II becomes Section 4; Part III becomes Sections 5–6. Sections 1–2 supply conventional context and notation; Sections 7–8 report diagnostics and limits. The full claim remains the labelled decision problem.

The frozen text used arXiv:2502.06566v2. The manuscript explicitly uses the v3 numbering, and the corresponding dependencies were compared by the AI assistant. The initial extended checks address the original strict-growth coverage gap. This revision additionally proves the sharper bound max(0,min(r-2,t-3)) and replaces modular elimination in the exposition by the dual-lattice kernel construction. Both are mathematical revisions, not merely prose edits. The frozen proof still uses the valid, looser r|X| bound and the earlier elimination proof. Historical review verdicts have not been relabelled as reviews of the new manuscript.

## Sources and public record

- Research page: https://yuxuanzhang1995.github.io/agentic-research/graph-lu-polynomial/
- QIQCOP question: https://qiqc-op.com/problem/op_66affd4b198fd445/
- Existing submission: https://github.com/Naixu-Guo/quantum-open-problems/issues/97
- Full source metadata and locators: `source-manifest.json`.

## Licensing and disclosure

The original frozen proof was contributed under CC BY 4.0 and the two original diagnostic scripts under Apache-2.0, as recorded in issue #97. Those terms remain unchanged. The newly prepared manuscript, evidence records, and additional diagnostic script are supplied for review; no separate license is asserted for them here. Third-party articles and dependencies retain their own terms and are not bundled.

The proof candidate, diagnostic code, internal reviews, and exposition involved substantial AI assistance under the author's direction. Source comparison by an AI and finite exact testing are distinct from independent human mathematical verification. The source manifest records that distinction. Scientific Agent Skills supplied writing and evidence-tracking guidance and is cited in the manuscript; it did not verify the mathematics. This package is not marked ready for formal journal submission.

## Writing and consistency audit

K-Dense scientific-writing and scientific-critical-thinking guidance was selectively applied from commit `330c8e764435a731eff571e3efdda70b363d0792` of https://github.com/K-Dense-AI/scientific-agent-skills. The `scientific-writing/scripts/check_consistency.py` tool reports zero errors and warnings on 28 registered numeric facts and six method/result mappings. It checks registry consistency, not the general theorem, source truth, novelty, or human approval. All source and claim records retain human verification as false, and submission_ready remains false.

The revision removes the R1-R5 interface labels and round-history prose from the introduction, states all standard-form conditions explicitly, and reduces repetition. The evidence claims and the AI-assistance disclosure remain visible.
