# The spectral gap of random Pauli rotations on four qubits is 1/15

Yuxuan Zhang. Research preprint, 28 September 2026.
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

The complete mathematical argument is in `pauli-rotation-gap.tex`. The paper is a proof candidate reviewed only by
AI (an isolated adversarial review of the complete proof and an independent numerical check, both recorded in
`INTERNAL_REVIEW.json`). **No independent human expert has examined the argument, and neither external peer review nor
human novelty certification is recorded.** AI assistance is disclosed in the paper.

**Result.** One step of the random-Pauli-rotation walk on SU(2ⁿ) applies e^{iθP}, with P a uniformly random non-identity
n-qubit Pauli operator and θ uniform on [0, 2π). Baer and Haah (arXiv:2607.20919) proved
(4ⁿ+16)/(16(4ⁿ−1)) ≤ Δₙ ≤ 2ⁿ(2ⁿ−3)/(8(4ⁿ−1)) for its spectral gap (n ≥ 3) and conjectured that the upper bound, which comes
from the fourth moment, is exact (their Conjecture 3.48). It is not: **Δ₄ = 1/15, not 26/255**, so their lower bound is
attained at n = 4. In the irreducible representation Λ⁸ℂ¹⁶ of SU(16), the vector w = Σ_A e_A over the 30 affine
hyperplanes A of F₂⁴ (each e_A the wedge of its 8 basis vectors in ascending binary order) satisfies M w = (14/15) w, where
M = E_P Π₀^P is the averaged step. Equivalently, f(U) = Σ_A det U[A, B₀] is a zero-mean eigenfunction of the walk with
eigenvalue 14/15. The proof: for each Z-type Pauli exactly 28 of the 30 wedges carry zero charge; w is Clifford invariant
(the Hadamard step uses the self-duality of the Reed–Muller code RM(1,3)); and ‖M‖ ≤ 14/15 follows from a quadratic
Casimir identity and, independently, from a selection rule (Walsh-charge divisibility plus Bose–Burton) which also shows
that no irreducible representation λ with 8 ∤ |λ| can violate the conjectured value, for any n ≥ 3.

## Reproduce the computation

`check_pauli_rotation_gap.py` uses **only the Python standard library** (no third-party packages, no network, no input):
Tested with CPython 3.13.5 (macOS host), CPython 3.12.13 (isolated container, no network) and CPython 3.9.6; the outputs
are byte-identical (`reproduction.json`).

```sh
python3 check_pauli_rotation_gap.py | diff - expected_stdout.txt && echo BYTE-EXACT
```

Or with no network at all (any image with Python ≥ 3.9; the recorded run used a local CPython 3.12.13 image):

```sh
docker run --rm --network=none -v "$PWD":/workspace:ro python:3.12-slim \
  python /workspace/check_pauli_rotation_gap.py | diff - expected_stdout.txt
```

It prints 22 tagged checks and a verdict line, and exits nonzero on any failure; it runs in about 10 s.
[B1] checks the Baer–Haah values; [W1]–[W10] the witness (the 30 hyperplanes, the Z-type counts, the order lemma, the
self-duality of RM(1,3), Clifford invariance for all 20 generators by exact exterior-algebra expansion over ℤ[i], the
value 28 for all 255 Paulis, the Rayleigh quotient 14/15, an independent Lie-algebra route that verifies M w = (14/15) w
exactly without Clifford invariance, and the Casimir identity); [S1]–[S4] the selection rule (Walsh divisibility,
exhaustive Bose–Burton counts at n = 3, 4, the equality cases, and the corollary for n = 3..64); [C1]–[C2] positive
controls (58/63 and 229/255 from the balanced fourth-moment sector); [N1]–[N3] negative controls (random signs, non-affine
orders, non-hyperplane 8-sets); [E1] a floating-point evaluation of the eigenfunction at three pseudo-random unitaries;
[T] the theorem. `mutate.py` applies 32 single-point mutations, each of which makes the program exit nonzero; none
survives (`MUTATION_REPORT.txt`).
Reproduction confirms only that the program computes what the paper describes; the reduction, the order lemma, the
Hadamard step and the selection rule are established by the written argument.

## Build the manuscript

Compile `pauli-rotation-gap.tex` twice with pdfLaTeX (amsmath, amsthm, amssymb, mathtools, geometry, lmodern,
microtype, xcolor, hyperref). `EVIDENCE.json` gives primary-source locators for every external claim; source inspection was
performed by AI, and independent human verification remains unrecorded.

The scientific-writing guidance from K-Dense's Scientific Agent Skills was consulted at commit
330c8e764435a731eff571e3efdda70b363d0792 and is cited in the manuscript. Its evidence workflow was followed selectively: a
source register (`EVIDENCE.json`) and an evidence-mapped claims outline (`OUTLINE.md`) were written before the prose.

## Caution for readers

The result concerns Δₙ exactly as defined on L²₀(SU(2ⁿ)), which is also Baer–Haah's gap: their Definition 1.1 takes the
infimum over all finite-dimensional unitary representations. The slow mode is unbalanced (the centre of SU(16) acts on
Λ⁸ℂ¹⁶ by −1), so it does not occur in any moment operator U^⊗t ⊗ Ū^⊗t; the balanced (PU(16), t-design) gap at n = 4 and Δₙ
for n ≥ 5 remain open. The transfer from Z-type Paulis to all Paulis rests on the Clifford invariance of w
(Proposition 6), whose Hadamard step depends on the wedge signs in the binary order (Lemma 4); scrutiny should start there.
The equality Δ₄ = 1/15 uses Baer–Haah Theorem 3.16 as published; the refutation Δ₄ ≤ 1/15 < 26/255 is self-contained.
