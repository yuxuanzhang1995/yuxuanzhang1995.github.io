from functools import lru_cache
from itertools import product

p=3
points=tuple(product(range(p),repeat=2))
index={v:i for i,v in enumerate(points)}
labels=tuple(product(range(p),repeat=4))
def gate(perm,phase):
    phase=tuple(int(v)%p for v in phase)
    return (tuple(int(v) for v in perm),tuple((v-phase[0])%p for v in phase))
def compose(A,B):
    a,f=A; b,g=B
    return gate((a[b[j]] for j in range(9)),(g[j]+f[b[j]] for j in range(9)))
def inverse(A):
    a,f=A
    b=[0]*9
    for j in range(9): b[a[j]]=j
    return gate(b,(-f[b[j]] for j in range(9)))
def conjugate(A,B): return compose(compose(A,B),inverse(A))
def pauli(label):
    a,b,c,d=label
    return gate((index[((x+a)%p,(y+b)%p)] for x,y in points),(c*x+d*y for x,y in points))
P=tuple(pauli(v) for v in labels)
Pset=set(P)
G=tuple(pauli(v) for v in ((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)))
@lru_cache(None)
def clifford(A): return all(conjugate(A,g) in Pset for g in G)
@lru_cache(None)
def c3(A): return all(clifford(conjugate(A,q)) for q in P)
def c4(A): return all(c3(conjugate(A,q)) for q in P)
def preserved(A): return tuple(v for v,q in zip(labels,P) if conjugate(A,q) in Pset)
def sc(A):
    V=preserved(A)
    for v in V:
        if v==(0,0,0,0): continue
        multiples={tuple(t*z%p for z in v) for t in range(p)}
        for w in V:
            if w in multiples: continue
            if (v[0]*w[2]+v[1]*w[3]-v[2]*w[0]-v[3]*w[1])%p==0: return True
    return False
I=gate(range(9),[0]*9)
S=gate((index[(x,(y+x*x)%p)] for x,y in points),[0]*9)
D=gate(range(9),(x*y*y for x,y in points))
U=compose(D,S)
for name,A in [('identity',I),('shear',S),('diagonal',D),('candidate',U)]:
    print(name,'C3',c3(A),'C4',c4(A),'SC',sc(A))
assert c4(U) and not c3(U) and not sc(U)
assert preserved(U)==((0,0,0,0),(0,0,1,0),(0,0,2,0))
print('Pauli-to-Pauli labels:',preserved(U))
# Check the symbolic conjugation formula independently at p=3.
for a,b,c,d in labels:
    perm=[]; phase=[]
    for x,y in points:
        xx=(x+a)%p; yy=(y+b+2*a*x+a*a)%p
        perm.append(index[(xx,yy)])
        phase.append(c*x+d*(y-x*x)+xx*yy*yy-x*y*y)
    assert conjugate(U,pauli((a,b,c,d)))==gate(perm,phase)
print('All 81 conjugation formulas verified exactly modulo 3.')
