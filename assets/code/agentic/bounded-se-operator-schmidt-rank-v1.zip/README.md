# Operator Schmidt rank under bounded spectral entangling strength

Yuxuan Zhang. Version 1.0, 17 November 2026.

The manuscript proves a squared-logarithmic operator Schmidt rank bound at
fixed time and operator-norm accuracy, assuming bounded ancilla-assisted
spectral entangling strength of the interaction. It imposes no spatial
locality or uniform bound on either local Hamiltonian. The representation
is existential; the manuscript does not give an efficient compiler.

## Run the supplementary checks

Use Python 3.10 or later with NumPy, SciPy and SymPy. The versions used for
the release are pinned in `requirements.txt`. After extracting this package
into an empty directory, run:

```sh
python3 reproduce.py
```

The runner verifies all files in `MANIFEST.json`, copies the two checkers
into a fresh temporary directory, executes them, and checks their result
records. The calculations need no network access. Dependency installation,
if necessary, is a separate step. No third-party libraries or papers are
redistributed here.

- `checks/check_local_bands.py` runs 374 assertions, combining floating-point
  matrix controls with a rational large-star calculation. It detects three
  invalid shortcuts.
- `checks/check_direct_transfer.py` runs 71 exact assertions. It uses finite
  quadrature matching the relevant complex Gaussian moments, eight exact
  parameter cases, and symbolic checks of the concentration constants. Four
  classes of invalid substitution are detected.
- `expected/` contains the original result records. Floating-point entries
  can vary slightly with the numerical libraries; the runner validates the
  assertions and result structure rather than demanding byte-identical floats.
- `manuscript/main.tex` is the complete paper. Compile it with a standard
  LaTeX installation, for example `latexmk -pdf main.tex` from that folder.

These finite controls supplement an analytic proof; they are not an
all-dimensional certificate. The review has been sequential and internal,
not independent expert review or formal verification. Worldwide priority
is not established. In particular, the full unpublished reference 93 in
Kim et al., PRX 16, 041035 (2026), was unavailable for comparison.

The original question is the fixed-time, fixed-error positive-power rank
question following Proposition 9 of that paper:
https://doi.org/10.1103/8fcr-5tf4

The evolution SE norm bound is already its Corollary 6. The regular/decomposable
map theorem of Arhancet--Kriegler, the completely bounded norm formulation,
and matrix concentration are attributed in the manuscript. The proposed new
step is uniform approximate balancing through local spectral bands, followed
by its application to the full unitary.

The author directed the research and manuscript preparation. AI assistance
contributed to derivation, literature comparison, implementation, checking
and drafting.
