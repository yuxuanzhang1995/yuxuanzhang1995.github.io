"""Finite tests of the orbit entropy and the endpoint-chord criterion. Python 3."""
from fractions import Fraction as F
from itertools import product
from math import comb, log2, sqrt
import json


def entropy(weights):
    return -sum(float(w) * log2(float(w)) for w in weights if w)


def binary_entropy(x):
    return entropy([x, 1-x])


def orbit_entropy(n, mu):
    """A diagonal product input, half mu and half 1-mu, twirled on all slots."""
    half = n // 2
    mass = [F(0)] * (n + 1)
    for a, b in product(range(half + 1), repeat=2):
        multiplicity = comb(half, a) * comb(half, b)
        mass[a+b] += multiplicity * mu**(a+half-b) * (1-mu)**(half-a+b)
    assert sum(mass) == 1
    return entropy(mass) + sum(float(p)*log2(comb(n, t)) for t, p in enumerate(mass))


def run():
    phase_flip = F(1, 4)
    mu = F(1, 10)
    lam = 1-binary_entropy(phase_flip)
    gamma = (1+sqrt(1-16*phase_flip*(1-phase_flip)*mu*(1-mu)))/2
    costs = binary_entropy(mu)
    dephasing = {}
    for n in (2, 4, 8, 16, 32, 64, 128, 256):
        orbit = orbit_entropy(n, mu)
        dephasing[n] = orbit/n + (1-lam)*costs - binary_entropy(gamma) - 1
        assert orbit/n <= 1 + 1e-12
    assert dephasing[64] < 0 < dephasing[128]
    wrong_without_twirl = costs + (1-lam)*costs - binary_entropy(gamma) - 1
    assert wrong_without_twirl < 0
    # For the noiseless qubit lambda*=1 and S(twirled output)<=n exactly.
    for n in (2, 4, 8, 16):
        for x in (F(0), F(1, 10), F(1, 2)):
            assert orbit_entropy(n, x) <= n + 1e-12
    # At n=1 an offset-free use of the Schur cross entropy is unsound.
    # The constant pure-output channel has zero rate; its cross entropy versus I/2 is 1.
    assert binary_entropy(0) == 0 and -log2(1/2) == 1
    return {"phase_flip_probability": str(phase_flip), "input_parameter": str(mu),
            "support_excess_bits_per_use": dephasing, "without_twirl": wrong_without_twirl,
            "noiseless_controls": 12, "constant_channel_cross_entropy_false_positive": True}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
