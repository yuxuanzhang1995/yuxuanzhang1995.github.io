# The entropy photon-number inequality near a nonthermal vacuum boundary

Yuxuan Zhang

Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland

Department of Physics, Princeton University, Princeton, New Jersey 08544, USA

Research rounds 39–41; released 24 September 2026. Partial result, not a full resolution of op_ba39e7a80122b256.

## Contents

RESEARCH-NOTE.md is the edited overview. Each round-*-record-*.json preserves the original claim, proof, advance, remaining gap, code and expected output without mathematical changes. The corresponding proof.txt is a direct text extraction. Review JSON files preserve the internal assessment and provenance. No third-party papers or private model transcripts are included.

## Checks

- round-41-record-150-check.py

Run each script with Python 3, without -O. The release reruns used Python 3.12.13, NumPy 2.5.3, SciPy 1.18.1, SymPy 1.14.0 and mpmath 1.3.0 in a network-disabled container. A portable reproduction environment can install these versions in Python 3.12. Code and stdout are preserved, including Unicode. The two early Bell scripts additionally require a writable /workspace directory for their JSON output; the release runner supplies an empty tmpfs there. This does not require changing the frozen scripts. Ordinary Python execution of these two scripts on a host without /workspace needs that directory to be prepared or the scripts to be run in a container with it mounted writable.

The initial packaging run made /workspace read-only and those two scripts stopped while writing results, after their first certificate checks. A first writable mount still lacked permission for the container user; adding a writable tmpfs with mode 1777 corrected the environment, and the same scripts reran successfully. The failed attempts are retained for the Bell note. Three scripts differ from their archived expected output only by a final newline; the release records both byte equality and equality after stripping final newlines. All twelve supplied scripts across the eight notes completed successfully in the final publication check. No checker is claimed for submissions without code.

Reproduction confirms the stated executable assertions, not all analytic arguments or novelty. The Bell region checks use outward interval arithmetic and exact geometric pruning; the interval library is trusted. Other checks range from exact algebra to explicitly labelled floating-point controls. Internal model reviews are not human peer review or formal verification.

## Scope and provenance

The general catalog problem remains open under this note. Frozen statements and proofs identify their exact hypotheses. Existing results are attributed in RESEARCH-NOTE.md and in any source-correction file. In the Gaussian note, the round-39 Holevo formula is identified as a consequence of the final published Chang–Genoni–Albarelli Eq. (76), not a new formula. In the perfect-code note, the broader unresolved source-count audit is excluded from the submitted theorem.

These are AI-generated research notes, prepared and checked with AI assistance under Yuxuan Zhang’s direction. Separate internal AI review found no error in the frozen claims, but this is not independent human peer review or proof-assistant verification. Historical novelty remains unverified.

## References and rights

The linked QIQCOP statement is https://qiqc-op.com/problem/op_ba39e7a80122b256/ . Third-party papers are linked and credited rather than redistributed. Original GitHub issue text is contributed under CC BY 4.0 as required by the catalog. This archive does not purport to relicense cited papers or dependencies. AI is not listed as an author.

Evidence and writing procedure: Kassis, T., Agarwal, V., He, Y., Patel, D., and Brueckner, A. M. (2026). Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents. https://doi.org/10.48550/arXiv.2609.00065
