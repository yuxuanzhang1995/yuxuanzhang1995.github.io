# Primary-source and predecessor comparison, 16 November 2026

The current [Q119 statement](https://qiqc-op.com/problem/op_b1b41f737f9b4aeb/)
still includes the asymptotic alternative and arbitrary linear error spaces.
Its catalog status does not adjudicate the inherited candidate.

[Allen–Kornell v2](https://arxiv.org/html/2507.04128v2), Lemma 2.3,
gives n>=3k-2 for systems of dimension at most three. Theorem 2.7 gives
the 3^ell and 2*3^ell sufficient thresholds in higher dimensions. These are
existence statements; they do not supply the proposed quantitative derivative
bound. The arXiv abstract identifies v2, 8 July 2025, as the latest version.
A third-party search hit suggesting v3 was not relied upon; that URL returned 404.

The inherited comparison with [Weaver, Theorem 2.10](https://msp.org/pjm/2019/301-1/pjm-v301-n1-p14-p.pdf)
concerns a quadratic-in-D sufficient dimension condition. His block obstruction
is an inherited ingredient, not a new contribution of this block.

Reimpell's dissertation, section 3.3.4, was retrieved from the existing full
local source because the [archival endpoint](https://www.osti.gov/etdeweb/servlets/purl/21161752)
returned 502. The inspected text formulates normalized channel correction,
relates it to unnormalized errors by adding a Kraus operator, and studies
seesaw optimization. It explicitly distinguishes numerical failure from a
global obstruction. That distinction is retained here. The separate R275
metric-lifting obstruction has also been read; normalization alone cannot
close c(2,6).

[Gupta et al.](https://arxiv.org/html/2604.21800), sections I and VI, is
relevant to attribution for variance/Stiefel approaches to prescribed Pauli
families. A universal quantitative guarantee for arbitrary observables is not
established by the inspected material. A full review of that precise overlap
remains pending before any priority claim.

[Robust Quantum Extremal Numbers](https://arxiv.org/abs/2608.13907)
concerns marginal maximal mixing and hypergraph counts; it is not the
operator-system rounding theorem sought here. The bounded searches do not
certify novelty. No publication or external communication was performed.
