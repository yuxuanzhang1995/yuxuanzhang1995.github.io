from pathlib import Path
import itertools,json,time,numpy as np
from p11_free_pulses_common import E,total,blocks
from p11_rational_quantum_certificate_common import I,D,q,p,bath
if __name__=='__main__':
 start=time.time();data=json.loads(Path('run/checks/r125_first_stage.result.json').read_text());store=np.load('run/checks/r125_first_stage_states.npz');N=store['coefficients'];U=store['collisions'];pid=store['profile_ids'];y=[I(str(x)) for x in data['price']];configs=sorted([(s,r,t,u) for s in range(6) for r,t,u in itertools.product(range(3),repeat=3)],key=lambda z:int(E[z[0]])+sum(z[1:]),reverse=True);globalp=[p[s]*bath[r]*bath[t]*bath[u] for s,r,t,u in configs];rewards=sorted(y*27,key=lambda x:x.a);cap=sum(a*b for a,b in zip(globalp,rewards))-sum(a*b for a,b in zip(y,p));Zsm=(1+q+q*q)*(1+q);active=[];pruned=0
 for profile in sorted(set(itertools.permutations(E.tolist()))):
  if profile==tuple(E):continue
  w=sum(int(E[i])*(q**int(profile[i])/Zsm-p[i]) for i in range(6));assert w.a>0
  if w.a>cap.b:pruned+=1
  else:active.append(list(profile))
 assert active==[r['profile'] for r in data['profiles']]
 assert np.all(np.sort(U,axis=1)==np.arange(18)) and np.all(total[U]==total)
 check=np.zeros_like(N)
 for profile_id,r in enumerate(data['profiles']):
  inds=np.flatnonzero(pid==profile_id);exps=np.array([r['profile'][s]+rr for s in range(6) for rr in range(3)])
  for src in range(18):check[inds,U[inds,src]//3,exps[src]]+=1
 assert np.array_equal(check,N);assert np.all(N.sum(axis=2)==3)
 # Independent full518400 collision enumeration for the first retained profile.
 profile=data['profiles'][0]['profile'];incoming=np.array([profile[s]+r for s in range(6) for r in range(3)]);BP=[np.array(list(itertools.permutations(range(len(B))))) for B in blocks];idx=np.indices(tuple(len(a) for a in BP)).reshape(6,-1).T;raw=np.zeros((len(idx),6,6),dtype=np.int8)
 for k,(B,perms) in enumerate(zip(blocks,BP)):
  patterns=incoming[B][np.argsort(perms,axis=1)]
  for j,dst in enumerate(B):raw[np.arange(len(idx)),dst//3,patterns[idx[:,k],j]]+=1
 distinct=np.unique(raw.reshape(len(raw),36),axis=0);expected=N[pid==0].reshape(-1,36);assert np.array_equal(distinct,expected)
 out=dict(precision=80,profile_cap=cap.pair(),all_profiles=180,inactive_profiles=1,certified_pruned_active_profiles=pruned,retained_profiles=len(active),integer_states_verified=len(N),full_collision_control_permutations=len(raw),full_collision_control_distinct=len(distinct),seconds=time.time()-start,scope='complete first-stage states for every potentially positively priced population branch at the specified price; suffix numerical pruning not certified here');Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
