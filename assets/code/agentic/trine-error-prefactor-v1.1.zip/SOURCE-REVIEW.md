# X20 source and proof review, 5 November 2026

The question under review asks whether the ratio of the two optimal error probabilities tends to one for every equally likely finite cyclic orbit of pure states. The receiver measures each copy once and retains classical outcomes. The real qubit trine gives a ratio of two. The Vienna question uses a broader verbal formulation of asymptotic attainment. [Vienna Problem 31](https://oqp.iqoqi.oeaw.ac.at/individual-measurement-strategies-on-geometrically-uniform-states/)

## Which part of the result appeared earlier?

**The collective error for every copy count is known.** In Sec. IV-B3, Chitambar, Duan and Hsieh write the collective success in the proof of Theorem 12, after defining \(\kappa\) in Eq. (15) and the following lines. Put \(x=(-1/2)^N\). Substituting \(\kappa=1+2x\) gives \((\sqrt{1+2x}+2\sqrt{1-x})^2/9\). Their theorem excludes finite-copy attainment by the larger class of LOCC protocols for \(N\ge2\). The protocol after their proof has success tending to one. These statements allow different limiting ratios of the residual errors. [Chitambar, Duan and Hsieh, Sec. IV-B3](https://arxiv.org/html/1308.1737)

**There is direct formula-level overlap with Wang, Guo and Zhang.** Their Eq. (3) sets \(S=(-1/2)^N\). In Sec. 3, Eq. (22) transforms the whole \(N\)-copy input. Eq. (26) defines the fraction of correct guesses conditional on the branch outside unambiguous identification. Setting their \(P_s=0\) in Eq. (28) gives their Eq. (29), on p. 100311-4. In our notation their average correct probability is

\[
C(x)=\frac{5-2x+4\sqrt{(1-x)(1+2x)}}9
    =\frac{(\sqrt{1+2x}+2\sqrt{1-x})^2}9.
\]

Writing \(a=\sqrt{1+2x}\) and \(b=\sqrt{1-x}\), one gets \(1-C(x)=2(a-b)^2/9=2x^2/(a+b)^2\). Hence \((1-C(x))/4^{-N}\to1/2\), for both parities. This last limit is our inference from their exact expression. Their term “individual correct probability” denotes success conditional on a state label. Eq. (22) still acts on all the copies before the output measurement. Their statement of collective advantage in Sec. 4 gives no coefficient for the optimal protocol that discards one copy after each measurement. [Wang, Guo and Zhang, journal article](https://doi.org/10.1360/SSPMA-2024-0534) · [Publisher full text, pp. 100311-2 to 100311-5](https://dds.sciengine.com/cfs/files/pdfs/1674-7275/BA59F02F361849B693D15B71112B09AF.pdf)

**Wen-Hai Zhang's 2023 article was checked separately.** The publisher dates it to 15 December 2022 online and volume 22 (2023). Its abstract reports an optimal \(N\)-copy POVM and convergence of the correct probability to one. The accessible publisher page and PDF link led to a subscription preview. The author's ORCID record points to the DOI. The 2023 list at Huainan Normal University contains the exact article, and opening its record led to institutional sign-in. OpenAlex listed no open full-text copy. The public preview did not expose the body of the paper. Whether its body proves the sequential converse or explicitly gives the factor two is **unverified**. The 2025 paper above has different authorship and a different DOI. Worldwide priority remains open. [Springer](https://doi.org/10.1007/s11128-022-03772-7) · [Author's institutional record](https://ir.specialsci.cn/hnu/detail/bfa391cd-9428-4a7b-8ff1-21f56989a9b2) · [OpenAlex record](https://openalex.org/W4311774546)

**Two-copy sequential discrimination is known exactly.** Croke, Barnett and Weir establish the optimal double-trine antitrine-then-binary protocol. Achenbach et al., v2, Sec. 6.2, Eq. (6.3), report its success \(1/2+\sqrt3/4\). Their Sec. 6 compares measurements on two copies. For the all-copy collective formula, Eq. (5.25) in that version prints off-diagonals \(-2^{-k}\) for every \(k\). At \(k=2\) its Eq. (5.24) gives \((11+2\sqrt{10})/18\), whereas its Eq. (6.2) correctly gives \(1/2+\sqrt2/3\). The signed overlap \(x=(-1/2)^k\) in Wang et al. and Chitambar et al. reproduces the latter value. The accompanying checker includes this sign control. [Croke, Barnett and Weir](https://arxiv.org/html/1704.01409) · [Achenbach et al., v2, pp. 15 and 17–18](https://arxiv.org/pdf/2604.26647v2)

## Direct check of the all-protocol lower bound

Here is a second derivation of the step that fixes the sequential coefficient. It uses a purification of the “other two labels” hypothesis. The release manuscript instead applies Montanaro's theorem and gives its pairwise binary-test proof. Both arguments are author-side checks. [Montanaro, Theorem 1](https://arxiv.org/html/0711.2012)

1. Fix any outcome of the first-copy POVM, with posterior \(p_i\). The trine Bloch-vector identity in the manuscript gives \(\sum p_i^2\le1/2\). The remaining state with label \(i\) is \(\phi_i=\psi_i^{\otimes(N-1)}\). Write \(c=4^{-(N-1)}\). All distinct overlaps are the same real number, of squared magnitude \(c\).
2. Fix a label \(i\) with \(0<p_i<1\), set \(w_j=p_j/(1-p_i)\) for \(j\ne i\), and give the receiver an auxiliary register with orthogonal labels \(|j\rangle\). Two unit vectors purifying the hypotheses “\(i\)” and “any other label” are
   \[
   |u_i\rangle=|\phi_i\rangle\otimes\sum_{j\ne i}\sqrt{w_j}|j\rangle,\qquad
   |v_i\rangle=\sum_{j\ne i}\sqrt{w_j}|\phi_j\rangle\otimes |j\rangle .
   \]
   Tracing out that register gives exactly the state and the conditional mixture in the binary problem. Since the real overlaps are identical, \(|\langle u_i|v_i\rangle|^2=c\). Any original test is available on the purifications by ignoring the register. Thus the error \(B_i\) obtained by turning a final guess into the binary answer “\(i\)” obeys
   \[
   B_i\ge \frac{1-\sqrt{1-4p_i(1-p_i)c}}2\ge p_i(1-p_i)c .
   \]
   When \(p_i\) is zero or one, the right-hand side vanishes.
3. Every incorrect ternary decision changes exactly two binary answers. For conditional error \(e\), this gives \(2e=\sum_i B_i\ge c(1-\sum_i p_i^2)\ge c/2\). Thus \(e\ge4^{-N}\) for every first outcome, even with an arbitrary joint measurement on the remainder. Integration covers continuous outcomes and \(N\)-dependent protocols.
4. The first-copy antitrine followed by optimal adaptive binary discrimination attains error \(2t/(1+\sqrt{1-4t})\), \(t=4^{-N}\). Together with the lower bound this gives \(P_{\rm seq}/t\to1\). The published collective formula above gives \(P_{\rm coll}/t\to1/2\). Their quotient tends to two. [Acín et al., adaptive binary optimum](https://arxiv.org/abs/quant-ph/0410097)

The checker in the source archive computes exact dyadic enclosures for the three collective formulas for \(N=2,\ldots,128\). Their intervals intersect at each tested \(N\). The identities and the uniform first-outcome bound establish the limit for arbitrary \(N\). Independent expert review of this manuscript is outstanding.
