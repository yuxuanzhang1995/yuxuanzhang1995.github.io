# A support-moment converse for visible mixed-state compression

Candidate v1, 2026-11-15. Same-agent derivation; independent review and priority
confirmation have not been performed. No publication. This is a proposed
counterexample to the exact original Q101, not a claim to compute its optimal
rate for every ensemble.

All logarithms are base two. The message dimension below is denoted m and the
single-signal output dimension D. An n-signal decoder may be any CPTP map from
C^m to (C^D)^{tensor n}; it need not factor over signals. Encodings may be
arbitrary mixed states. A finite shared seed, independent of the signal labels,
has arbitrary distribution and size. The seed is averaged BEFORE the error.

## Statement

Set D=16. Let P range over the 255 nonidentity, unsigned Hermitian four-qubit
Pauli matrices, and let b range over {-1,+1}. Give the 510 labels x=(P,b) equal
probability and define

    W_x=(I+bP)/16,       Q_x=(I+bP)/2.

Here Q_x is a rank-eight orthogonal projector, W_x=Q_x/8, and
Tr(Q_x W_x)=1. The average state is I/16. Each signal has entropy three,
so the ensemble Holevo information is exactly one bit.

For every blocklength n and every admissible protocol with message dimension
m and original average trace-distance error epsilon_n,

    1-epsilon_n <= m^(3/4) (53/170)^(n/2).                 (1)

In particular,

    R_vis,q,cr >= (2/3) log(170/53) > 1 = chi.             (2)

For any sequence with limsup log(m)/n strictly below the constant in (2),
the error tends to one exponentially. The general universal equality asked
in Q101 would therefore be false. The direct-send rate four is an elementary
upper bound, so this statement is not an exact evaluation of this ensemble's
optimal rate.

## 1. An exact finite projector moment

Write F for the swap on C^D tensor C^D. The Hermitian Pauli basis obeys

    sum_(all P) P tensor P = D F.

One proof expands the matrix units in the Hilbert--Schmidt orthogonal basis
P/sqrt(D): the coefficient identity is
sum_P P_ij P_kl = D delta_il delta_jk. No entrywise complex conjugation is
placed on the second tensor factor; in particular the Y terms are present.
Averaging the two signs removes the linear terms, giving

    E_x Q_x tensor Q_x
       = (1/4)[ I tensor I + (D F-I tensor I)/(D^2-1) ]
       = a I tensor I + c F,
    a=(D^2-2)/(4(D^2-1)),     c=D/(4(D^2-1)).              (3)

Both coefficients are nonnegative. For n independent labels, write
Q_xn=Q_x1 tensor ... tensor Q_xn and group the two copies site by site.
Then

    E Q_xn tensor Q_xn
       = sum_(S subset [n]) a^(n-|S|) c^|S| F_S,          (4)

where F_S swaps precisely the output sites in S and is the identity on
the two copies of all other sites.

## 2. Decoder second moments are partial Choi purities

Fix an arbitrary decoder Dcal:L(C^m)->L((C^D)^tensor n), and let
T=Dcal^* be its Hilbert--Schmidt adjoint. For S subset [n], put
Dcal_S=Tr_(S complement) composed with Dcal. It is CPTP. Its unnormalized
Choi operator J_S has Tr_(output S) J_S=I_m and Tr J_S=m.

The swap trick and adjointness give the exact identity

    E Tr[T(Q_xn)^2]
       = sum_S a^(n-|S|) c^|S| Tr J_S^2.                 (5)

To verify the indices, expand the partial swap as

    F_S = sum_ij (E_ij^S tensor I_(S complement))
                   tensor (E_ji^S tensor I_(S complement)).

After applying T tensor T and tracing against the message swap F_m, its
contribution is sum_ij Tr[Dcal_S^*(E_ij) Dcal_S^*(E_ji)]. In matrix units
this is the squared Hilbert--Schmidt norm of the superoperator Dcal_S.
Reshuffling its four indices gives J_S without changing the sum of the
absolute squares of its entries. Since J_S is Hermitian this equals
Tr J_S^2. This proves (5) including S empty, for which J_empty=I_m and the
contribution is m. No hypothesis of an isometric, unital-output or product
decoder has been used.

## 3. The dimension-sensitive Choi bound

For any CPTP map with input dimension m and output dimension d,

    Tr J^2 <= min(m^2, m d).                              (6)

The first bound follows from J>=0 and Tr J=m. For the second, let lambda
be its largest eigenvalue and v a normalized associated eigenvector.
From J>=lambda |v><v| and Tr_output J=I_m one obtains
I_m >= lambda rho_input, where rho_input=Tr_output |v><v|.
The Schmidt rank of v is at most d, hence lambda_max(rho_input)>=1/d,
so lambda<=d. Therefore Tr J^2<=lambda Tr J<=d m. This argument works
also when d>m; the other bound remains available.

For 0<=t<=1, min(u,v)<=u^t v^(1-t). Apply this to (6), with d=D^|S|,
in (5). Positivity of a,c justifies bounding every summand in the same
direction, and the binomial theorem gives

    E Tr[T(Q_xn)^2]
       <= m^(1+t) [a+c D^(1-t)]^n.                       (7)

For D=16 and t=1/2 the bracket is exactly

    a+4c = 127/510+16/255 = 53/170.                       (8)

## 4. Arbitrary encodings and free shared randomness

For any density matrix tau_xn on the message system, positivity implies

    Tr[Q_xn Dcal(tau_xn)]
       <= ||T(Q_xn)||_infinity
       <= sqrt(Tr[T(Q_xn)^2]).

Averaging over the iid labels and using scalar Cauchy--Schwarz with (7),

    E_xn Tr[Q_xn Dcal(tau_xn)]
       <= m^((1+t)/2) [a+c D^(1-t)]^(n/2).               (9)

Now condition on each shared seed s. Its decoder is an arbitrary CPTP map,
so (9) holds with the SAME right-hand side, independently of s. The label
law remains the fixed iid law because the shared seed is independent of
the labels. Thus averaging the acceptance probability over s preserves
this bound. This does not fix a good seed in a trace-norm expression.

For the actually reproduced, seed-averaged state WhatW_xn, let
delta_xn=||W_xn-WhatW_xn||_1/2. The effect 0<=Q_xn<=I accepts W_xn with
probability one, so

    Tr[Q_xn WhatW_xn] >= 1-delta_xn.

Averaging over labels gives acceptance at least 1-epsilon_n, precisely
for the original error criterion. Combining with (9) and (8) proves (1).

## 5. Asymptotic and exact strictness checks

Taking logs of (1) yields

    log(m)/n >= (2/3)log(170/53)
                   + (4/(3n))log(1-epsilon_n).

For epsilon_n->0 the last term tends to zero. The inequality holds for
every n, every message dimension and every seed distribution. It bounds
the liminf, hence also every operational limsup rate and their infimum.
For a rate bounded below the displayed constant by delta>0, (1) instead
gives 1-epsilon_n<=2^(-3 delta n/4) for all sufficiently large n.

Strictness above chi=1 is an integer comparison, not floating evidence:

    (53/170)^2 < 1/8,
    8*53^2=22472 < 28900=170^2.

## Scope, attribution and review limits

This is a finite fixed ensemble of allowed mixed states. It addresses the
unrestricted original coding model, including collective decoding and the
weaker seed-averaged error criterion. It does not require a product encoder,
pure messages, an entanglement resource, or a bound on shared randomness.

Winter's original formulation is quant-ph/0208131, Section VII, Conjecture 23.
Bab Hadiashar--Nayak, 1905.02110v4, Theorem 1.1, proves an information/compression
separation for a one-shot random-subspace ensemble. Support tests and such a
separation are not claimed as new ideas. The proposed contribution here is the
finite Pauli-ensemble tensor-power converse (1), using the partial-output Choi
purity bounds simultaneously for every subset in (5). The ordinary Pauli
basis identity, swap trick and elementary Choi facts are inherited mathematics.

The proof is self-contained after these elementary identities, but it has not
received an independent review. The bounded source search in selection.md does
not establish first priority. A clean numerical reconstruction can catch index
errors; it cannot replace the arbitrary-n analytic argument above.
