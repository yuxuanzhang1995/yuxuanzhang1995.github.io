# Analytical transcription review

Review performed by the coordinating AI assistant during manuscript preparation. This is not an independent human or formal proof review. The archived full-resolution classification is retained as an internal candidate status, not upgraded to external confirmation.

## Proof checks

1. **Exact problem match.** The current public record still specifies a square contraction, exact factor encoding, controlled/inverse access, phase-sensitive clean-output vector error, and all three small-o conditions. The manuscript preserves each of these.
2. **Coefficient bound.** The differential equation gives the displayed nonnegative recurrence, including r=1. Monotone convergence at z=1 and the exponential coefficient majorant justify the Taylor remainder.
3. **Global cutoff.** The M-th binomial term supplies the small-z margin. The factor 1-E*z^M is nonnegative because the same lower bound is at most 1. The large-z Markov bound compensates the coefficient norm. The factorial moment supplies the local approximation bound.
4. **Exact completion.** The complementary polynomial has degree at most 2d. Multiplication by w^(2d) gives matrix degree at most 4d. The highest-coefficient range projection removes one degree since C0-dagger*Cn=0, using at most 6d walk calls after undoing the scalar factor. This synthesis principle is credited to prior QSP work.
5. **Arbitrary encoding.** J-dagger*Pi-prime*J=A-dagger*A; no assumption of a Hermitian factor or canonical dilation. The invariant-plane walk calculation includes the zero singular value. The s<T restriction in the finite proposition avoids the sigma=1 endpoint.
6. **No missing leakage.** The overlap with the ideal full clean output is at least 1-delta in real part; unit norms give squared vector error at most 2delta. No energy projector, postselection, or free amplitude amplification is assumed.
7. **Uniform asymptotics.** D<=L+log L+o(1) keeps L/D bounded below. M=ceil(6L/D) may remain bounded, but MD/L stays bounded above and below. M/s tends to infinity, the walk does not cross an inverse-sine branch, and log(M/(32768s))/D tends to 1.
8. **Circuit quantifiers.** A single oracle-independent circuit works for every scalar reflection encoding. Its amplitude has total degree at most Q even with arbitrary workspace and controlled/inverse queries. Four-sign averaging gives degree at most floor(Q/2) in y, bounded on the full interval.
9. **Complex derivative estimate.** The Joukowski argument bounds complex polynomials, not just real ones. The focal identity and Cauchy radius (k/n)^2 give the claimed constant.
10. **Finite difference.** All evaluation points stay in the promised interval; the 2^k epsilon error is dominated by the oscillatory difference under the explicit admissibility condition. Nonzero kth difference forces n>=k before the derivative estimate is invoked.
11. **k=1 edge.** epsilon=o(s) and epsilon->0 handle k=1 separately. Higher k uses k log(8 max(k/s,1))<=L. The resulting absolute lower constant is 1/(e sqrt(8)).

## Editorial additions relative to the frozen proof

The finite-parameter upper/lower propositions expose inequalities already proved in the archived argument. The three parameter examples follow by substitution into the same formula. The theorem has not been broadened to gate complexity, imperfect oracles, or phase-insensitive error. Existing source and frozen-review records are preserved unchanged, including their historical formatting.

## Fresh finite diagnostics

All four groups in reproducibility/diagnostic-results.json passed: 1,854 polynomial evaluations, 9 factor encodings, 5 degree-stripping examples, and 8 four-sign circuit examples. No asymptotic theorem is inferred from these finite samples. The first local invocation lacked mpmath; a disposable uv environment with mpmath and numpy completed the run without modifying project dependencies.

## Source checks and remaining work

The primary arXiv metadata and relevant full-text passages for Zlokapa-Somma, Haah, and Zlokapa-Allen-Harrow were inspected. The QIQCOP model was checked live. K-Dense authors and latest metadata were fetched before citation. This bounded source comparison does not prove priority. Independent expert review, human source verification, final author review, and any venue-specific declarations remain pending.
