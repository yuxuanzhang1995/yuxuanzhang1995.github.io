# Primary-source comparison for the visible-compression counterexample

Checked 16 November 2026 local time. These comparisons concern the exact
coding resources, error and quantifiers, not just titles or catalog labels.

| Primary source and checked location | Existing result | Difference from this manuscript |
| --- | --- | --- |
| A. Winter, [quant-ph/0208131](https://arxiv.org/abs/quant-ph/0208131), Section VII, Eqs. (15)-(16), Conjecture 23; Section III for the common-randomness convention | Quantum visible coding and a conjectured Holevo-rate protocol with prescribed common-randomness consumption | The present theorem rules out Holevo rate even with unrestricted independent classical shared randomness; its error uses the averaged reconstructed state. |
| R. Jain, J. Radhakrishnan and P. Sen, [cs/0304020v2](https://arxiv.org/abs/cs/0304020), Theorem 5 | Random-subspace ensembles have little information yet resist low-dimensional support compression | This is a one-shot subspace theorem. It does not supply an arbitrary-CPTP-decoder converse for all tensor powers of one fixed finite ensemble. Support projections and information/compression separation are credited to this work. |
| S. Bab Hadiashar and A. Nayak, [1905.02110v4](https://arxiv.org/abs/1905.02110), Theorems 1.1 and 3.3, Eqs. (3.2)-(3.5) | One-shot near-incompressibility and communication/entanglement lower bounds with general decoding channels | Their existential ensemble depends on one-shot parameters. This paper instead fixes 510 Pauli-labelled states and proves an exponential converse for every iid blocklength, also after convexification by arbitrary shared classical randomness. No claim is made that the support-test idea is new. |
| M. Hayashi, [quant-ph/0511267v2](https://arxiv.org/abs/quant-ph/0511267), visible-code definition and Eq. (8) | The unassisted asymptotic visible rate is regularized entanglement of purification | This is a different resource model. An unassisted lower bound cannot simply be transferred to freely randomized encoders and decoders. The present proof handles the seed directly. |
| H. Nator and U. Pereg, [2404.18297](https://arxiv.org/abs/2404.18297), coding definition and Corollary 3 | Classical communication with shared randomness for cq coordination | A classical-message restriction is not an unrestricted quantum-message converse. This source provides relevant classical context, not the present lower bound. |
| Z. Baghali Khanian, [2206.09415v2](https://arxiv.org/abs/2206.09415), Sections II and IV | Visible-compression strong-converse bounds through regularized Renyi entanglement of purification | The model has one encoder/decoder and no free independent shared seed. The present finite support-moment bound is different and explicitly survives averaging over seeds. |

The site's [mixed-source strong-converse article](https://yuxuanzhang1995.github.io/agentic-research/mixed-source-strong-converse/)
concerns reference-preserving compression at Koashi-Imoto entropy. It is not
the visible free-shared-randomness problem and does not duplicate this result.
The current index was retrieved and checked before release preparation.

Targeted searches included Winter Conjecture 23; visible compression with
shared/common randomness; Holevo-rate counterexamples; Pauli-ensemble
compression; fixed-ensemble tensor-power lower bounds; and forward context
from the Jain-Radhakrishnan-Sen and Bab Hadiashar-Nayak papers. A thesis search
hit for Xiaodi Wu described a conditional separation using sign rigidity;
no matching unconditional theorem was located from that lead. It is not used
as proof or as a definitive statement about unpublished work. Broad keyword
absence is not treated as novelty certification.

The defensible contribution is the explicit fixed Pauli ensemble and the
all-blocklength partial-Choi-purity argument. The existence of one-shot
information/compression separations, support testing, the Pauli swap identity
and the ordinary Choi formalism are prior ideas. First priority and external
acceptance are unconfirmed.
