from fractions import Fraction as Q

assert Q(56,81) > Q(69,100)
print('ln2 lower: 56/81 > 69/100')

t_lower = Q(69,50) * Q(482,583)
assert t_lower == Q(16629,14575)
assert t_lower > Q(9,8)
print('T lower: 16629/14575 > 9/8')

f_upper = Q(1) + Q(1,12) + Q(1,30)
assert f_upper == Q(67,60)
assert Q(9,8) - f_upper == Q(1,120)
print('F upper: 67/60 < 9/8; gap=1/120')
print('All certified scalar comparisons passed.')
