"""Exact local identities, not a finite proof of universal code existence.

The second derivative is reconstructed from ambient matrix paths.  An invalid
control deliberately drops the common-orthogonality hypothesis.
"""
import json
import random
from pathlib import Path
import sympy as s

ROOT = Path(__file__).parent
rng = random.Random(3131194)

def herm(n):
    a = s.Matrix(n, n, lambda i, j: rng.randrange(-2, 3) + s.I*rng.randrange(-2, 3))
    return a + a.H

def energy_coeffs(Hs, X, Y, Z):
    k = X.cols
    f0 = 0
    f2 = 0
    for H in Hs:
        G = X.H*H*X
        L = Y.H*H*X + X.H*H*Y
        Q = Z.H*H*X + X.H*H*Z + Y.H*H*Y
        f0 += s.trace(G*G) - s.trace(G)**2/k
        f2 += s.trace(L*L + 2*G*Q) - (s.trace(L)**2 + 2*s.trace(G)*s.trace(Q))/k
    return s.simplify(f0), s.simplify(2*f2)

rows = []
mutations = []
for k in [2, 3, 4]:
    for number in [1, 2, 4]:
        n = k+3
        X = s.eye(n)[:, :k]
        y = s.eye(n)[:, k]
        Hs = [herm(n) for _ in range(number)]
        for H in Hs:
            for a in range(k):
                H[a,k] = H[k,a] = 0
        total = 0
        for a in range(k):
            Y = s.zeros(n,k); Y[:,a] = y
            Z = s.zeros(n,k); Z[:,a] = -X[:,a]/2
            F, dd = energy_coeffs(Hs, X, Y, Z)
            total += dd
        assert s.simplify(total+4*F) == 0
        rows.append({'k':k, 'observables':number, 'F':str(F), 'summed_second_derivative':str(total)})
        bad = [H.copy() for H in Hs]
        bad[0][0,k] = bad[0][k,0] = 1
        total_bad = 0
        for a in range(k):
            Y = s.zeros(n,k); Y[:,a] = y
            Z = s.zeros(n,k); Z[:,a] = -X[:,a]/2
            _, dd = energy_coeffs(bad, X, Y, Z)
            total_bad += dd
        assert s.simplify(total_bad+4*F) != 0
        mutations.append({'k':k,'observables':number,'missing_orthogonality_detected':True})

# A positive energy minimum at an insufficient dimension must be possible.
# Full diagonal algebra on C^3 has no rank-2 scalar compression: every rank-one
# coordinate projector would compress to zero, contradicting their sum I.
# Here the common-orthogonal complement is empty, so the theorem does not apply.
n=3; k=2
Hs=[s.diag(1,0,0),s.diag(0,1,0)]
X=s.Matrix([[1,0],[0,1],[1,1]])
span=s.Matrix.hstack(X,*[H*X for H in Hs])
assert span.rank()==n

result={'exact_derivative_cases':rows,'mutations':mutations,
        'dimension_control_full_span':int(span.rank()),
        'scope':'Exact identities and hypothesis controls only. Universal conclusion rests on the analytic proof.'}
(ROOT/'q119-variational-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'exact_derivative_cases':len(rows),'mutations_caught':len(mutations),'dimension_control':True}))
