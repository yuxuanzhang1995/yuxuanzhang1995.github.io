"""Exact rational parameter budgets, including capped r and nearly unit transmission."""
from pathlib import Path
from fractions import Fraction as F
from math import ceil,comb
import json

cases=[]
for eta in (F(1,100),F(1,4),F(1,2),F(9,10),F(999,1000),1-F(1,2**30)):
    for eps in (F(1,2),F(1,10),F(1,1000)):
        for n in (1,2,10,1000):
            s=1-eta;r=0;p=F(1)
            while r<n and p>eps**2*s/64:r+=1;p*=eta
            tau=eps**2*s/192;T=ceil(64*eps**-2*r*9**r)
            tail=F(0) if r==n else eta**(r+1)*(1-eta**(n-r))/s
            bias2=3*tau*eta*(1-eta**r)/s
            # exp(2)<9 gives a rational upper bound for the variance term.
            a=9*eta;variance=(a*(a**r-1)/(a-1) if a!=1 else F(r))/T
            assert tail<=eps**2/64 and bias2<=eps**2/64 and variance<=eps**2/64
            assert T<=65*eps**-2*r*9**r
            cases.append({'eta':str(eta),'eps':str(eps),'n':n,'r':r,'capped':r==n,'T_bits':T.bit_length()})
obstruction=[{'m':m,'pair_sector_norm2':str(1-F(1,comb(m+1,2))),'single_photon_bound':str(F(1,comb(m,2)))} for m in range(3,21)]
assert all(F(x['pair_sector_norm2'])>F(x['single_photon_bound']) for x in obstruction)
report={'status':'PASS','exact_parameter_cases':len(cases),'cases':cases,'GBS_direct_substitution_obstruction':obstruction,'limits':'Checks arithmetic budget identities, not the full all-size algorithm or arbitrary Gaussian input sectors.'}
(Path(__file__).resolve().parents[1]/'results/parameter-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','exact_parameter_cases':len(cases),'GBS_pair_sector_cases':len(obstruction)}))
