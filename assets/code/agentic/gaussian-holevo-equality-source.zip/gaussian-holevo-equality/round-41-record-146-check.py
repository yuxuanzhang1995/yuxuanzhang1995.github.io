import sympy as s
v,k,h=s.symbols('v k h',real=True)
c=v+s.Rational(1,2); t=v*v+s.Rational(1,4); rad=v*v-s.Rational(1,4)
f=(k*k+h*h)/c+1/c**2
R=s.diag(v,v,4*t,4*t,4*rad)
I=s.zeros(5); I[0,1]=s.Rational(1,2); I[1,0]=-s.Rational(1,2); I[2,3]=4*v; I[3,2]=-4*v
H=R.row_join(I).col_join((-I).row_join(R))
D=s.Matrix([[k,-h],[h,k],[2,0],[0,2],[0,0]])
x1=s.Matrix([k/(f*c),h/(f*c),1/(2*f*c*c),0,0])
x2=s.Matrix([-h/(f*c),k/(f*c),0,1/(2*f*c*c),0])
x=x1.col_join(x2)
assert s.simplify(x1.T*D)==s.Matrix([[1,0]])
assert s.simplify(x2.T*D)==s.Matrix([[0,1]])
target=(D[:,0]/f).col_join(D[:,1]/f)
assert s.simplify(H*x-target)==s.zeros(10,1)
value=s.factor((x.T*H*x)[0])
assert s.simplify(value-2*c*c/(1+c*(k*k+h*h)))==0
imag=s.factor((x1.T*I*x2)[0])
assert s.simplify(imag-((k*k+h*h)/(2*f*f*c*c)+v/(f*f*c**4)))==0
print('Unbiasedness residual = 0; signed stationarity residual = 0: PASS')
print('Signed optimum = 2*c^2/(1+c*(k^2+h^2)): PASS')
# Exact spectrum verifies global, not merely symmetry-restricted, optimality.
eigs={s.factor(a):b for a,b in H.eigenvals().items()}
expected={s.factor(v-s.Rational(1,2)):2,s.factor(v+s.Rational(1,2)):2,s.factor(4*(v-s.Rational(1,2))**2):2,s.factor(4*(v+s.Rational(1,2))**2):2,s.factor(4*rad):2}
assert eigs==expected
print('Signed Hessian eigenvalues: v-1/2, v+1/2, 4*(v-1/2)^2, 4*(v+1/2)^2, 4*(v^2-1/4), each twice; all > 0 for v > 1/2: PASS')
n=s.symbols('n',positive=True)
seed=s.factor(n/(v+n)**2-(1/(4*n))/(v+1/(4*n))**2)
assert s.factor(seed-(n-1/(4*n))*(v*v-s.Rational(1,4))/((v+n)**2*(v+1/(4*n))**2))==0
print('Seed isotropy identity: difference = (n-1/(4*n))*(v^2-1/4)/[(v+n)^2*(v+1/(4*n))^2]: PASS')
print('Homodyne radial descent coefficient = 2*v^2-1/2 > 0 for v > 1/2: PASS')
for label,expr in [('Hessian minimum at v=1',v-s.Rational(1,2)),('Homodyne radial coefficient at v=1',2*v*v-s.Rational(1,2))]:
    z=expr.subs(v,1); assert z>0; print(str(label)+' = '+str(z)+' > 0: PASS')
