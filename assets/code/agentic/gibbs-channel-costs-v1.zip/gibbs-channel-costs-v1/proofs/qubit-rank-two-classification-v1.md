# Finite exact coherence for qubit Gibbs-preserving channels of rank at most two

24 November 2026. Candidate classification of a complete low-rank class.
It does not cover all Q117 dimensions or all channel ranks, and it does not
give the optimum QFI in each feasible case. Same-root review and novelty
comparison are still required.

The canonical form and pure-output geometry of rank-two qubit channels
are prior results of Ruskai--Szarek--Werner, *An Analysis of Completely-
Positive Trace-Preserving Maps on M2*, arXiv:quant-ph/0101003. We use that
form as an input; it is not a new channel classification.

Let rho=gamma_A and sigma=Phi(rho)=gamma_B be full-rank qubit Gibbs states.
Hamiltonian scalar shifts are irrelevant to coherence. The statements below
use only the fixed channel, these two states, and their physical gaps.

## Proposed classification

1. Rank one: a GP unitary intertwines the two Gibbs Hamiltonians up to a
   scalar. It is covariant and has exact QFI cost zero.
2. Rank two, not extreme in the full CPTP set: a finite exact resource
   exists iff the channel is covariant. The cost then is zero.
3. Rank two, CPTP-extreme and entanglement breaking: the channel measures
   a two-outcome projective basis and prepares two distinct nonorthogonal
   pure output states. A finite exact resource exists iff rho is diagonal
   in that measurement basis. No rationality restriction on energy gaps
   is needed in this branch.
4. Rank two, CPTP-extreme, not entanglement breaking, with only one pure
   input mapped to a pure output (the amplitude-damping boundary): no
   finite exact resource exists.
5. Rank two, CPTP-extreme, not entanglement breaking, with two distinct
   pure inputs psi_+,psi_- mapped to pure outputs phi_+,phi_-: a finite
   exact resource exists iff both conditions hold:
   (a) rho is a strict convex mixture of the two pure input projectors;
   (b) the nonzero input and output energy gaps a,b have rational ratio.
   In this branch 0<a<b. The gap arithmetic is an actual exact-resource
   obstruction; bounded positive-error cost alone does not remove it.

The strict-mixture requirement follows from full rank. A constant pure
preparation channel cannot preserve a finite-temperature, finite-Hamiltonian
full-rank Gibbs state and is excluded by the problem's hypotheses.

## Canonical algebra giving the inverse-Gibbs obstruction

After input/output unitaries, take

    K0=diag(c,d), K1=[[0,s],[t,0]],
    c^2+t^2=d^2+s^2=1, c,d,s,t>=0.

For the interior extreme branch all four numbers are positive and c!=d.
Write q=c^2 d^2-s^2 t^2=c^2+d^2-1. Entanglement breaking is q=0.
For B=[[b0,x+iy],[x-iy,b1]]>0 let

    L_B(C)=sum_{alpha,beta} C_alpha_beta K_alpha^* B K_beta.

In the real Hermitian basis E00,E11,X,[[0,i],[-i,0]], its determinant is

 [(b0 c s+b1 d t)^2-4cdst x^2]
 [(b0 c s-b1 d t)^2+4cdst y^2].                         (1)

The first factor is strictly positive for B>0. Thus L_B is singular iff
y=0 and b0 c s=b1 d t. These conditions and the computations below are
finite exact algebra, to be retained in the reproducibility checks.

For q!=0, direct multiplication with sigma=Phi(rho) yields

    L_(sigma^-1)(Z)=q det(rho)/det(sigma) rho^-1.         (2)

A finite exact resource requires a positive definite solution of
L_(sigma^-1)(C)=rho^-1 (the exponential test at inverse Gibbs temperature;
normalizing scalar partition factors have no effect on positivity).
If L is injective, (2) makes its unique solution a nonzero scalar multiple
of Z, which is indefinite. With rho=[[u,z],[conj(z),v]], the singularity
conditions reduce, for q!=0, to

    Im z=0,  u/v=ds/(ct).                              (3)

These are precisely the states in the open line segment between

    psi_+ = sqrt(u0)|0> + sqrt(v0)|1>,
    psi_- = sqrt(u0)|0> - sqrt(v0)|1>,
    u0=ds/(ct+ds), v0=ct/(ct+ds).

Both are mapped to distinct pure states with ground population
cs/(cs+dt). This proves the mixture necessity in case 5.
When a canonical coefficient vanishes, but q!=0 and the output is not
constant pure, (1) is nonzero for every B>0. Equation (2) then proves case 4.

## Why irrational gaps are impossible in case 5

Let a,b be the two spectral gaps. Because the channel strictly increases
the overlap of the two nonorthogonal pure inputs, the two mixtures with
the same weights have spectral gaps satisfying 0<a<b.

If a/b is irrational, finite-sector balance holds as a Laurent identity
in independent input and output energy variables X,Y. Fix Y at the value
making B proportional to sigma^-1. The right-hand target A(X) spans
span{I,rho^-1} as X varies. But I is not in the range of L_(sigma^-1).

For completeness, in the canonical coordinates put B01=x real and
b1=b0 cs/(dt). Form the two real columns L_B(E00), L_B(X), and append I,
using their (00,11,01) entries. Their determinant is

    (2c/t)(ds-ct)(b0^2 cs-dt x^2),                      (4)

up to the sign from column order. It is nonzero: B>0 makes the last
factor positive, and ds!=ct follows from c!=d and q!=0. The image has
dimension two, so I lies outside it. At some positive X the sector
equation is inconsistent, whereas a nonzero nonnegative clock polynomial
is strictly positive there. This proves impossibility for irrational a/b.

## Positive real-frequency solution for every mixture in case 5

This step is needed before applying the coefficient multiplier theorem;
compatibility at a single Gibbs point is not sufficient by itself.

Write rho=p|psi_+><psi_+|+(1-p)|psi_-><psi_-| and the analogous sigma
with the same p and phi vectors. Phases may be chosen so that the overlaps
c_A=|<psi_+,psi_->| and c_B=|<phi_+,phi_->| satisfy 0<c_A<c_B<1.
Let D_p=diag(sqrt(p),sqrt(1-p)) and define the ensemble Gram matrices

    G_c=[[p,c sqrt(p(1-p))],[c sqrt(p(1-p)),1-p]].

A minimal Stinespring map has V psi_i=phi_i tensor e_i. The two e_i are
linearly independent. Testing L_(sigma^-u)(C)=rho^-u between the two
input vectors gives, in this environment-vector basis,

    <e_i,C e_j> = (G_(c_A)^(1-u))_ij /
                  (G_(c_B)^(1-u))_ij.                 (5)

There is a removable zero-over-zero entry at u=1. Positivity is equivalent
to the normalized off-diagonal correlation of G_(c_A)^k being strictly
smaller in magnitude than that of G_(c_B)^k, with k=1-u.

Here is a direct proof for every real k. Set z=2p-1,
r(c)=sqrt(z^2+c^2(1-z^2)), and

    A_k(c)=c sqrt(1-z^2)/r(c) sinh(|k| atanh r(c)).

The magnitude of that normalized correlation is
A_k(c)/sqrt(1+A_k(c)^2). For k!=0, both c/r(c) and
sinh(|k|atanh r(c)) are nondecreasing in c, and their product is strictly
increasing on 0<c<1. At k=0 use the limit: the ratio of the two correlations
is the ratio of [c/r(c)]atanh r(c), also strictly increasing. Thus (5)
defines a positive definite environment form for every real u, analytically
through u=1. Conjugating by the invertible e-vector matrix gives C(u)>0.

## Commensurate sufficiency

Write a=mh,b=nh with integers 0<m<n. In the respective energy bases,
L_x(C)=A(x), where A=P_A0+x^m P_A1 and B=P_B0+x^n P_B1, has a unique
rational solution R(x), since Omega_0 is injective for a CPTP-extreme
channel. Equation (5) proves that it is regular and positive definite on
the entire positive half-line, with R(1)=I.

The endpoint kernel tests also pass. The maps
C -> V^*(P_B0 tensor C)V and C -> V^*(P_B1 tensor C)V are invertible
congruences: neither output energy eigenstate equals either of the two
pure outputs of the channel. Otherwise a full-rank strict mixture of two
nonorthogonal pure states would have one of its components as an eigenstate.

Near zero, inverting the first congruence yields

    R(x)=R0+x^m Rm+O(x^n),

with R0,Rm nonnegative rank-one matrices whose sum is positive definite.
Thus all coefficients before m annihilate ker R0, and at m the compression
to that kernel is strictly positive. Near infinity the analogous form is

    R(x)=x^(m-n) [S0+x^-m Sm+O(x^-n)],

with the same two positivity properties. Multiplication by any scalar
denominator positive on x>0 only adds multiples of the existing leading
rank-one matrices before the first positive kernel compression. Hence both
finite endpoint flags of the polynomial numerator pass.

The proved one-variable matrix-multiplier criterion now supplies finite
nonnegative scalar and PSD matrix coefficient polynomials satisfying exact
sector balance. The finite conserving completion constructs a finite exact
resource. This proves sufficiency for every commensurate case 5 channel,
including mixtures not diagonal in the canonical Kraus basis.

## The entanglement-breaking and nonextreme branches

When q=0 and c!=d, K0,K1 describe measurement in the X basis followed by
two nonorthogonal pure preparations. For B=sigma^-1 the image of L_B is
span{I,X}; positivity of an exact inverse-Gibbs solution therefore requires
rho^-1, and hence rho, to commute with X. Conversely, if rho commutes with
that measurement, the measurement is an energy measurement. Supply the
two fixed pure output states in a finite resource (with a classical flag,
or as two independently stored registers), measure the input energy, and
route the corresponding resource output using controlled swaps between
identical Hamiltonians. The unused registers and input are discarded.
All sharp control blanks are included in the resource. This is a finite
thermal implementation with finite QFI. It proves case 3 without requiring
commensurate input/output gaps.

For the nonextreme rank-two branch, canonical input/output unitaries reduce
the channel to dephasing around one Bloch axis with transverse multiplier
lambda, |lambda|<1. Its Kraus products span only I and that axis. Write the
input Gibbs Bloch vector as r=(r_parallel,r_perp) and the output as
s=(r_parallel,lambda r_perp). Up to common scalar and beta factors,
the transverse component of H_A-Phi^*(H_B) is

    [f(|r|)-lambda^2 f(|s|)] r_perp,
    f(t)=atanh(t)/t, f(0)=1.

The bracket is strictly positive, since f is positive and increasing and
|s|<=|r|. If r_perp!=0 the first-order finite-resource constraint fails.
If r_perp=0 the dephasing map intertwines the two Gibbs Hamiltonians and
is covariant, with zero QFI cost. This proves case 2.

## Limit of the claim

These arguments classify finite exact coherence for qubit channels of
Choi rank at most two, subject to the standard canonical-form coverage.
Higher Choi rank and higher system dimension are not settled by this
document. The general univariate injective criterion has broader scope,
but it also does not remove the underdetermined and multivariate gaps.
