# Full-output simulation of lossy boson sampling — version 2.0

Yuxuan Zhang · 3 November 2026

This supplement accompanies the manuscript for two input models: single-photon Fock inputs at every m >= n, and Gaussian inputs with **every mode equally squeezed**. Transmission is fixed in both main theorems; squeezing is fixed in the Gaussian theorem. Guarantees concern the complete photon-count law and Haar-average total variation. Independent expert review and worldwide priority confirmation remain outstanding.

## Reproduce the finite checks

Use Python 3.10 or later with NumPy and SymPy installed. The tested environment was Python 3.13.5, NumPy 2.1.3 and SymPy 1.13.3. No network access is used by the runner.

```text
python3 reproduce.py
```

The runner verifies every payload hash, executes eight finite check suites, compares their scientific counts and mutation controls, and reaggregates the Gaussian Haar CSV against its recorded statistics. Logs and a receipt appear in `results/`. Rational identities use exact arithmetic; the explicitly identified finite-Fock and prefix comparisons use floating arithmetic.

To rerun both complete recorded Haar grids as well, install Matplotlib and run:

```text
python3 reproduce.py --haar
```

This optional path redraws 1,536 Fock-input and 512 conditional-pair Haar matrices with the recorded seeds. It can take substantially longer. It uses exponential full-Fock enumeration, not the asymptotically efficient sampler. Grid cells sharing a matrix are correlated. The conditional-pair tests do not sample the unbounded squeezed-input number mixture; that tail is controlled analytically in the manuscript.

Regenerate the Gaussian figure from the frozen data with:

```text
python3 code/plot_gaussian.py --data reference/gaussian/E04-haar.csv --out results/gaussian-haar.pdf
```

After the optional Fock replay, `code/analyze_haar.py` produces its figures in `results/haar-tv-results/`.

## Contents and scope

- `manuscript/`: complete LaTeX source and three figures; compile `main.tex` twice with pdfLaTeX.
- The PDF: version 2.0, including the small-photon finite-precision repair.
- `code/`, `checks/`: mathematical controls and replay scripts, not an optimized production sampler.
- `reference/`: frozen raw data and original stage-specific reports. Their historical scope labels describe each check's role, not the final theorem's status.
- `SOURCE-COMPARISON.md`: checked primary-source assumptions and attribution.
- `PROVENANCE.json`: original/public code hashes and AST comparisons; only import roots and output locations were adapted.
- `REVIEW-STATUS.json`: final scoped claims and review limitations.
- `MANIFEST.json`: payload SHA-256 hashes; generated results are outside this manifest.

The identity runner also retains finite fixed-order vacuum-embedding diagnostics from the derivation. Those diagnostics are auxiliary and do not establish a theorem for extra vacuum inputs, unequal squeezing or general Gaussian states. Likewise, no uniform Gaussian eta-to-one theorem or practical runtime improvement is claimed.

Version 1.1's Fock theorem and exact-check functions are retained. The uniform Fock loss–accuracy and orthogonal bad-bit corollaries were previously local additions; version 2.0 publishes them alongside the equal-squeezing Gaussian theorem. These are extensions of this manuscript, not additional counts of solved catalog questions.

AI assistance was used under human direction for derivation, sources, computation, internal review and drafting. The package's multiple computational constructions come from that workflow, not independent expert review.
