"""Exact-identity numerical controls, including complex hopping and odd jumps."""
from pathlib import Path
from functools import reduce
import numpy as np,json
N=4;I=np.eye(2**N);z=np.diag([1.,-1.]);c=np.array([[0.,1.],[0.,0.]])
cs=[reduce(np.kron,[z if j<i else c if j==i else np.eye(2) for j in range(N)]) for i in range(N)]
par=reduce(np.matmul,[I-2*x.T@x for x in cs]);rng=np.random.default_rng(707)
a=rng.normal(size=(N,N))+1j*rng.normal(size=(N,N));m=(a+a.conj().T)/5
e,u=np.linalg.eigh(m);fm=(u*np.exp(-e**2/3+e/4))@u.conj().T;fp=(u*np.exp(-e**2/3-e/4))@u.conj().T
rr=fm@fm+fp@fp
ks=[sum(fm[i,j]*cs[j] for j in range(N)) for i in range(N)]+[sum(fp[j,i]*cs[j].T for j in range(N)) for i in range(N)]
def D(k,o):
 q=k.conj().T@k;return k.conj().T@o@k-(q@o+o@q)/2
def L(o):return sum(D(k,o) for k in ks)
def twist(o):return par@L(par@o)
def der(c,o):return c@o-o@c
a=rng.normal(size=I.shape)+1j*rng.normal(size=I.shape);o=(a+a.conj().T)/2;o=(o+par@o@par)/2
dx=[der(c,o) for c in cs];dy=[der(c.T,o) for c in cs]
errs={'annihilator':max(np.linalg.norm(der(cs[i],L(o))-twist(dx[i])+.5*sum(rr[i,j]*dx[j] for j in range(N))) for i in range(N)),
      'creator':max(np.linalg.norm(der(cs[i].T,L(o))-twist(dy[i])+.5*sum(rr[j,i]*dy[j] for j in range(N))) for i in range(N))}
# A local odd jump on sites0,2 commutes with the derivative off its support,
# provided the RIGHT superoperator is parity twisted.
k=cs[0]+.2*cs[2].T+.1*cs[0]@cs[2].T@cs[2]
errs['outside_local_perturbation']=max(np.linalg.norm(der(cs[i],D(k,o))-par@D(k,par@der(cs[i],o))) for i in [1,3])
assert max(errs.values())<1e-10,errs
out={'status':'pass','errors':{k:float(v) for k,v in errs.items()},'scope':'Numerical algebra control of exact CAR identities, not infinite-volume proof.'}
(Path(__file__).resolve().parent/'CAR-check-results-new.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
