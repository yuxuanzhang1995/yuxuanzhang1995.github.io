"""Plot recorded conditional-pair Haar controls; no new samples generated."""
from pathlib import Path
import argparse,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    with a.data.open() as f: rows=list(csv.DictReader(f))
    groups={}
    for row in rows:
        key=tuple(float(row[x]) for x in ['m','N','eta','r']);groups.setdefault(key,[]).append(row)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,ax=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for eta,color in zip([.5,.8,.95],['#186a96','#ba661a','#65519c']):
        keys=sorted(k for k in groups if k[:3]==(3,8,eta));x=[];y=[];err=[]
        for k in keys:
            vals=np.array([float(r['TV']) for r in groups[k]])
            x.append(k[3]);y.append(vals.mean());err.append(2*vals.std(ddof=1)/np.sqrt(len(vals)))
        ax[0].errorbar(x,y,yerr=err,fmt='o-',capsize=2,color=color,label=rf'$\eta={eta}$',ms=4)
    ax[0].set(xlabel='Retained harmonic degree r',ylabel='Mean full-output TV',title='Pair input: m = 3, N = 8',xticks=[0,2,4,6,8],ylim=(-.01,.4));ax[0].legend(frameon=False)
    for k,rr in groups.items():
        target=float(rr[0]['predicted'])
        if target<1e-20:continue
        vals=np.array([float(r['squared_error']) for r in rr]);se=vals.std(ddof=1)/np.sqrt(len(vals))
        ax[1].errorbar(target,vals.mean(),yerr=2*se,fmt='o',color='#186a96',alpha=.7,ms=3,lw=.7)
    ax[1].plot([0,1.1],[0,1.1],'--',color='0.5',lw=.8)
    ax[1].set(xlabel='Exact Haar second moment',ylabel='Measured second moment',title='All four pair-input geometries',xlim=(-.02,1.1),ylim=(-.02,1.15))
    a.out.parent.mkdir(parents=True,exist_ok=True);fig.savefig(a.out);plt.close(fig)
if __name__=='__main__':main()
