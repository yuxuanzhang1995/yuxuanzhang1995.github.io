import sys,json
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction as F
import qutrit_exact as exact
import qutrit_local as local
root=Path(__file__).resolve().parent
cover=json.loads((root/'cover.json').read_text())
remote={tuple(F(x) for x in row[:4]) for row in cover['passed']}
small={tuple(F(x) for x in row) for row in cover['local']}
assert len(remote)==1006 and len(small)==18 and not cover['failed']
seen=set()
def visit(a,A,b,B):
    if a+b>=4:return
    key=(a,A,b,B)
    if key in remote or key in small:
        seen.add(key)
        if key in small:assert a>=F(7,5) and A<=F(3,2) and b>=F(39,20) and B<=F(41,20)
        return
    assert max(A-a,B-b)>F(1,2**24)
    if A-a>=B-b:
        m=(a+A)/2;visit(a,m,b,B);visit(m,A,b,B)
    else:
        m=(b+B)/2;visit(a,A,b,m);visit(a,A,m,B)
visit(F(1),F(3),F(1),F(3))
assert seen==remote|small
assert len(exact.PART)==280 and len({tuple(map(tuple,p)) for p in exact.PART})==280
for p in exact.PART:assert sorted(sum((list(t) for t in p),[]))==list(range(9))
remote_result=exact.replay();local_result=local.run()
assert exact.Q>0 and exact.Q+exact.e2-exact.e0<2
# Direct Arb control of an integer oracle point, using the same finite search
# but no floor approximation. This controls the representation, not its scope.
a,b=exact.arb(1.5),exact.arb(2)
x=[u*v for u in exact.p0 for v in exact.thermal(a)]
t=exact.thermal(b);cost=sorted([b*j-l for l in (exact.LAM0,exact.arb(3),exact.arb(0)) for j in range(3)],key=lambda z:float(z.mid()))
values=[]
for part in exact.PART:
    rows=[sorted((x[j] for j in block),key=lambda z:float(z.mid()),reverse=True) for block in part]
    mid=[sum(row) for row in rows]
    q1=a*(sum(row[1]+2*row[2] for row in rows)-sum(j*exact.thermal(a)[j] for j in range(3)))
    xx=sorted([u*v for u in mid for v in t],key=lambda z:float(z.mid()),reverse=True)
    values.append(q1+sum(u*v for u,v in zip(xx,cost))-b*(t[1]+2*t[2])-exact.Z)
direct=min(values,key=lambda z:float(z.mid()));integer=exact.value(F(3,2),F(2))
assert direct-integer>0 and direct-integer<exact.arb('1e-12')
# Negative control: lifting the claimed support floor by 0.1 must violate
# this tested point; a checker that ignored the objective would miss it.
assert direct-exact.arb('0.1')<0
print(json.dumps({'status':'pass','cover_complete':True,'remote':remote_result,'local':local_result,'direct_arb_control_error':str(direct-integer),'negative_control':'raised support floor rejected','scope':'complete original candidate; internal arithmetic/proof review only'},indent=2))
