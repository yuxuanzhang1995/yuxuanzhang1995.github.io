# Evidence-mapped outline — eight-copy CCZ concentration (drafting stage 1; prose in eight-copy-ccz-concentration.tex)

Evidence classes: E# = external source (EVIDENCE.json); K = checker line(s) of `check_eight_copy_ccz.py` (tags [G], [C1]..[C9]);
R46 = the round-46 isolated adversarial review; O46 = the orchestrator's independent simulation and PDF reading (round 46);
R45 = internal round 45 (reproduction of the M_8 bound, not new); P = proved in the manuscript.

| ID | Claim | Type | Evidence |
|---|---|---|---|
| C01 | The question, U_8, Eq. (1) target, p_8^*, m_3 and Eq. (2) exactly as in the record | declaration | E1 |
| C02 | RL's "stabilizer protocol" class coincides with U_8 | factual | E2(a), E1 |
| C03 | Baseline: RL's eight-copy protocol has success (2/3) m_3 (Thm 2 / Thm 7); upper bound p_8^* <= (7/6) m_3 (Prop. 1, Eq. (12)); RL say eight-copy optimality is not known | factual | E2(c,d,f); E1 progress |
| C04 | m_3 is RL's M_3^lin, a linearised order-3 stabilizer Renyi entropy | factual | E2(b), E4 |
| C05 | Definitions: sectors of (X^8, Z^8); M_8 (dim 3) with orthonormal basis E_X, E_Y, E_Z, one per sector; f_6 = ab(a^4-b^4) vanishes exactly at the six stabilizer states | declaration + result | E2(e); P (Sec. 2); K [C5] (M_8 line) |
| C06 | Lambda* (Def. 1) lies in U_8: Pauli measurements, feedforward, Cliffords, discarding; no ancilla, no catalyst, input-independent | result | P (Thm 1, step 1); K [C1]; R46 (U_8 membership) |
| C07 | Instrument: every path measures commuting Hermitian Paulis; the 13 leaf projectors sum to I | result | P (Lemma 2); K [C1]; R46 item 1 |
| C08 | Rank one on Sym^8; explicit sector-Z leaf states chi_L; transfer to sectors X, Y by H^8 and R^8; capture 2/7 per leaf | result | P (Lemma 2, Lemma 3); K [C2], [C3]; R46 items 2, 7 |
| C09 | Decoders: explicit Clifford circuits (17, 17, 21 gates) map chi_L to CCZ (x) |0>^5; D_L H^8 and D_L R^{dag 8} for sectors X, Y | result | P (Lemma 4); K [C4]; R46 item 3; O46 (40 random psi, fidelity 1 - 4e-15) |
| C10 | Per-leaf probabilities 4|ab f_6|^2, |(a^2-b^2) f_6|^2, |(a^2+b^2) f_6|^2; 9x9 identity N = 6(v1v1^T + 2v2v2^T + v3v3^T); total 6|f_6|^2 |psi|^4 | result | P (Lemma 5); K [C5], [C6], [C7]; R46 item 4 |
| C11 | Bloch conversion: 6|f_6|^2 = m_3 = (3/2)(1-x^2)(1-y^2)(1-z^2) for normalised psi | result | P (Lemma 6); K [C6]; R46 item 5; R45 (6|f_6|^2 identity) |
| C12 | Theorem 1: every accepted branch outputs exactly |CCZ>; p_{Lambda*}(psi) = m_3(psi) for every pure psi | result | C06-C11 |
| C13 | Corollary 7: Eq. (2) fails at every non-stabilizer psi; m_3 <= p_8^* <= (7/6) m_3; T-type 4/9 vs 8/27, H-type 3/8 vs 1/4 | result | C12, C03, E3; K [C9] |
| C14 | Mechanism: sum_L Pi_Sym Pi_L Pi_Sym = (6/7) Pi_{M_8}; RL's value corresponds to 4/7, reproduced exactly by the A-leaves | result / interpretation | P (Remark 8); K [C3], [C5] (M_8 line), [C8] positive control; E2(c) |
| C15 | The rejected branch (+P^{E1}, +P^{E2}) maps Sym^8 onto the span of two stabilizer states (GHZ-type and chi_C) holding the last 1/7; no stabilizer continuation of it ever accepts | result | P (Proposition 9; support identity Sec. 2, Eq. (7)); K [C8] negative controls; E7 |
| C16 | Exact p_8^* in [m_3, (7/6) m_3] is open | declaration | C13, E2(d) |
| C17 | Literature status: RL v1 is the only version; no follow-up found on 2026-09-28 (search-limited) | factual (search-limited) | E2, E6; R46 verdict D = NEW; O46 |
| C18 | Review status: AI review only (R46 isolated review, O46 simulation); no human review | declaration | INTERNAL_REVIEW.json |
