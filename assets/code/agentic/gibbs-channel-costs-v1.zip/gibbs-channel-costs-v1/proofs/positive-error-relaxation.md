# Consequence for the all-positive-error optimization

24 November 2026. Proof replacement for the approximation step in Section 7
of `run/blocks/R337-R341-20261123/R338/q117-program-proof-v2.md`.
The original finite SDP brackets, their localization proof, and their
predecessor credit are retained. This is not an additional discovery count.

Let \(p\) be a centered probability measure with finite second moment, and
let \(Y\) be a positive input-first Choi-matrix-valued measure such that
\[
 \sum_j [Y(dE-f_j)]_{ij,i'j}=\delta_{ii'}p(dE-e_i).         \tag{1}
\]
Its total matrix \(J=\int Y\) is the Choi matrix of a channel \(\Psi\).
Every such pair can be approximated, in reference-assisted purified channel
distance, by finite physical implementations with limiting QFI at most
\(4\int x^2p(dx)\).

To prove this without Poisson summation, convolve both measures with
\[
 f_h(x)=\frac{2h^3}{\pi(h^2+x^2)^2}.
\]
This has mean zero and variance \(h^2\). The convolved scalar density
\(p_h\) is strictly positive, has fixed-shift ratios bounded uniformly in
\(x\), and retains (1) exactly. Its second moment increases by \(h^2\).

Choose a minimal Kraus family of \(\Psi\), with the matrix of Kraus vectors
\(B\), so \(J=BB^*\). Positivity implies that almost every \(Y(dx)\) has
support inside \(\operatorname{ran}B\): its expectation on any vector in
\(\ker J\) is a nonnegative measure with zero total mass. Thus the smoothed
density has the form
\[
 Y_h(x)=B C_h(x)^T B^*,\qquad C_h(x)\ge0,
 \qquad\int C_h(x)dx=I.
\]
Use the left inverse of \(B\) to obtain its coefficients. The transpose is
required by the Kraus-Gram convention; it preserves positivity and trace.

Equation (1), positivity of its diagonal terms, and summation over input
and output basis labels give
\[
 \operatorname{Tr}Y_h(z)\le\sum_{i,j}p_h(z+f_j-e_i)
                              \le c_h p_h(z).
\]
The fixed Kraus Gram inverse then gives \(\|C_h(z)\|\le c'_h p_h(z)\).
All hypotheses of the translated-fibre lemma hold, with zero continuous
balance residual. That lemma supplies finite implementations tending to
\(\Psi\), with limiting cost at most
\(4\int x^2p(dx)+4h^2\). Let \(h\downarrow0\).

For a target \(\Phi\), impose the exact channel-fidelity condition on \(J\)
from Section 3 of the predecessor. The continuous relaxation therefore
equals the physical cost for every strictly positive error. A boundary
point of the error ball can be handled as follows. Choose one finite
implementation strictly inside the ball; universal finite-clock
approximation supplies it. Mix a vanishing amount of it into the
approximating channels. Concavity of root channel fidelity brings the
mixture inside the closed error ball, and flagged QFI costs average. The
added cost tends to zero.

The finite SDP upper/lower brackets and their convergence then follow
from the predecessor's cube-localization argument. This replacement
removes the incommensurate sampling estimate from that proof as well.

At zero error this argument does not produce a finite exact implementation.
The relaxed value describes the positive-error limit; the finite-atomic
criterion remains separate. Neither a bounded universal exact-support
cutoff nor the deterministic-work cost follows from this corollary.
