"""Parent review: exact endpoint containment and full 9! control.

The permutation control is numerical; the general reduction is reviewed
analytically. The complete certificate replay is a separate output file.
"""
from pathlib import Path
from fractions import Fraction
import itertools,sys,json
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'replay-input'))
sys.dont_write_bytecode=True
import qutrit_exact as q
import qutrit_local as loc

def rational(x):
    return q.arb(x.numerator)/x.denominator

assert q.A.lower() <= rational(q.lo).lower()
assert q.A.upper() >= rational(q.hi).upper()
assert q.root_derivative(q.lo)<0 and q.root_derivative(q.hi)>0
checked_intervals=0
for left,right in [(Fraction(7,5),Fraction(3,2)),(Fraction(39,20),Fraction(41,20))]:
    for i in range(20):
        a=left+i*(right-left)/20;b=left+(i+1)*(right-left)/20
        ball=loc.interval(a,b)
        assert ball.lower()<=rational(a).lower() and ball.upper()>=rational(b).upper()
        checked_intervals+=1
assert q.LAM0>3 and q.LAM0<6
assert q.A>1 and q.A<2
assert q.Q+q.e2-q.e0<2

# All first-stage permutations, without row partition symmetry or passive sorting.
perms=np.array(list(itertools.permutations(range(9))),dtype=np.int16)
assert len(perms)==362880
lam=np.array([float(q.LAM0.mid()),3.,0.])
def thermal(g):
    v=np.exp(-g*np.arange(3));return v/v.sum()
controls=[]
for a,b in [(1.,1.),(1.5,2.),(1.25,2.5),(2.,1.5)]:
    p0=thermal(1);p1=thermal(a);p2=thermal(b)
    initial=np.outer(p0,p1).ravel()
    rows=initial[perms].reshape(-1,3,3)
    machine_mean=(rows.sum(axis=1)*np.arange(3)).sum(axis=1)
    q1=a*(machine_mean-p1@np.arange(3))
    mid=rows.sum(axis=2)
    joint=(mid[:,:,None]*p2).reshape(-1,9)
    joint.sort(axis=1)
    costs=np.sort((b*np.arange(3)[None,:]-lam[:,None]).ravel())
    values=q1+(joint[:,::-1]*costs).sum(axis=1)-b*(p2@np.arange(3))
    full=float(values.min())-float(q.Z.mid())
    reduced=float(q.value(Fraction(a),Fraction(b)).mid())
    assert abs(full-reduced)<1e-12,(a,b,full,reduced)
    controls.append({'gaps':[a,b],'full_9_factorial_support_minus_Z':full,
                     'reduced_integer_lower':reduced,'absolute_difference':abs(full-reduced)})
out={'status':'pass','root_bracket_containment':'exact endpoints enclosed',
     'local_coordinate_intervals_checked':checked_intervals,'permutations':len(perms),
     'full_permutation_controls':controls,
     'error_allowance_ratio':str(Fraction(1000,127)),
     'limits':'Permutation enumeration checks only these four gap pairs in binary64. General quantum coverage and semiconcavity are analytic; complete continuum bounds are separately replayed.'}
(HERE/'targeted-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
