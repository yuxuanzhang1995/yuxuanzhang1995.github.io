"""Finite-ring hafnian evaluator vs independent rotated Fock-state reductions."""
from pathlib import Path
import sys, itertools, json, time
from math import factorial, comb
from fractions import Fraction as F
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
sys.path.insert(0,str(ROOT/'code'))
from r138_p60_evaluator import Ring, top_coeff, t, choose
from haar_tv import Geometry, haar
from pair_spectrum import rise, fall, pair_vector

def monic_beta(m,j):
    moments=[F(factorial(k))/rise(F(m+1,2),k) for k in range(2*j+1)]
    polys=[]
    def inner(p,q):return sum(x*y*moments[a+b] for a,x in enumerate(p) for b,y in enumerate(q))
    for d in range(j+1):
        p=[F(0)]*d+[F(1)]
        for q in polys:
            scale=inner(p,q)/inner(q,q)
            for a,x in enumerate(q):p[a]-=scale*x
        polys.append(p)
    return polys[-1]

def coherent_coeff(m,N,l,a):
    if l-a>N//2:return F(0)
    return F(factorial(l)**2,4**a*factorial(a)**2*factorial(l-2*a))*F(fall(N//2,l-a))*rise(F(m+N,2),a)/(rise(F(m,2),l)*fall(N,l))

def pair_operator_coeff(m,N,l):
    assert l%2==0
    c=coherent_coeff(m,N,l,l//2)
    return [c*x/fall(l,2*a) for a,x in enumerate(monic_beta(m,l//2))]

class PairRing(Ring):
    def mul(self,a,b):
        out={}
        for (x,y,z,w),v in a.items():
            for (xx,yy,zz,ww),vv in b.items():
                if x&xx or y+yy>self.l//2 or w+ww>self.l:continue
                zsum=tuple(i+j for i,j in zip(z,zz))
                if any(i>j for i,j in zip(zsum,self.b)):continue
                k=(x|xx,y+yy,zsum,w+ww);out[k]=out.get(k,0)+v*vv
        return {k:v for k,v in out.items() if abs(v)>1e-24}

    def inverse_sqrt_det(self,M,mutate=False):
        P=M;S={}
        for a in range(1,self.l//2+1):
            tr={}
            for i in range(len(M)):tr=self.add(tr,P[i][i])
            S=self.add(S,self.scale(tr,(1 if mutate else .5)/a))
            if a<self.l//2:P=self.matmul(P,M)
        out=self.one;power=self.one
        for a in range(1,self.l//2+1):
            power=self.mul(power,S);out=self.add(out,self.scale(power,1/factorial(a)))
        return out

def evaluator(U,N,l,Dcut,h,go,mutation=None):
    m=len(U);ell=sum(h);c=top_coeff(m,l);d=pair_operator_coeff(m,N,l)
    B=U@U.T;total=0j;patterns=0;largest=0
    for q in range(min(Dcut-1,l//2)+1):
        for H in itertools.combinations(range(m),q):
            for b in itertools.product(range(2,l+1),repeat=q):
                if sum(b)>l or sum(x-1 for x in b)>=Dcut:continue
                s=l-sum(b);ps=factorial(s)/s**s if s else 1;R=PairRing(l,s,b);Z=[];P=R.one
                for i in range(m):
                    if i in H:
                        zz=[0]*q;zz[H.index(i)]=1;Z.append(R.mono(z=zz))
                    elif s:
                        bit=1<<go[s][i];zi=R.add(R.mono(x=bit),R.mono(x=bit,w=1,c=h[i]));Z.append(zi)
                        P=R.mul(P,R.add(R.one,zi))
                    else:Z.append({})
                for i,bi in zip(H,b):
                    f={R.zero:1}
                    for j in range(1,min(bi,h[i])+1):f=R.add(f,R.mono(w=j,c=comb(bi,j)*comb(h[i],j)))
                    P=R.mul(P,f)
                M=[[{} for _ in range(m)] for _ in range(m)]
                for a in range(m):
                    for bb in range(m):
                        val={}
                        for v in range(m):val=R.add(val,R.scale(Z[v],B[a,v]*B[v,bb].conjugate()))
                        M[a][bb]=R.mul(R.mono(y=1),R.mul(Z[a],val))
                G=R.mul(P,R.inverse_sqrt_det(M,mutation=='det_power'));patterns+=1;largest=max(largest,len(G))
                for (xb,a,zv,j),val in G.items():
                    if xb!=(1<<s)-1:continue
                    cw=np.prod([comb(bi,ui) for bi,ui in zip(b,zv)])
                    if mutation=='heavy_binomial':cw=1
                    fac=1 if mutation=='pair_factor' else 4**a*factorial(a)**2
                    weight=float(d[a])*fac*cw*float(c[j])/(comb(l,j)*comb(ell,j)*ps)
                    total+=val*weight
    return total/float(t(m,ell,l,l)),patterns,largest

def direct(g,U,N,l,Dcut,h,go,mutation=None):
    reps=g.representations(U);_,v=pair_vector(g.m,N)
    p=g.red[N,l]@(abs(reps[N]@v)**2)
    Z=g.proj[l,l]@p;mask=[]
    for v in g.occ[l]:
        support=[i for i,x in enumerate(v) if x];S=[i for i,x in enumerate(v) if x==1];s=len(S)
        ps=factorial(s)/s**s if s else 1
        mask.append(float(l-len(support)<Dcut and (not s or len({go[s][i] for i in S})==s))/ps)
    A=np.array(mask)*Z
    if mutation!='outer_projection':A=g.proj[l,l]@A
    beta=np.array([choose(h,v)/comb(sum(h),l) for v in g.occ[l]])
    return float(beta@A/float(t(g.m,sum(h),l,l)))

def main():
    rng=np.random.default_rng(20261103);rows=[];start=time.time();detected={k:0 for k in ['det_power','heavy_binomial','pair_factor','outer_projection']}
    cases=[(3,4,2,1,(2,1,1)),(3,4,2,2,(3,1,0)),(4,4,2,2,(2,2,0,0)),
           (4,6,4,2,(2,2,1,1)),(3,6,4,4,(4,2,0)),(3,6,6,6,(2,2,2)),(2,6,6,6,(5,1))]
    for m,N,l,dc,h in cases:
        g=Geometry(m,N);U=haar(rng,m)
        go={s:list(map(int,rng.integers(s,size=m))) for s in range(1,l+1)}
        expected=direct(g,U,N,l,dc,h,go);actual,pat,size=evaluator(U,N,l,dc,h,go)
        err=abs(actual-expected);assert err<2e-9,(m,N,l,actual,expected,err)
        mutation_errors={}
        for mut in detected:
            bad=direct(g,U,N,l,dc,h,go,mut) if mut=='outer_projection' else evaluator(U,N,l,dc,h,go,mut)[0]
            mutation_errors[mut]=float(abs(bad-expected))
            detected[mut]+=int(abs(bad-expected)>1e-8)
        rows.append({'m':m,'N':N,'l':l,'D':dc,'prefix':h,'expected':expected,'actual':float(actual.real),'error':float(err),'patterns':pat,'largest_ring':size,'mutation_errors':mutation_errors})
        print(json.dumps(rows[-1]),flush=True)
    assert all(x>0 for x in detected.values()),detected
    report={'cases':rows,'mutations_detected':detected,'max_error':max(x['error'] for x in rows),'seconds':time.time()-start,'limits':'Float controls through l=6; proof is the formal generating-function argument, not this finite test. No practical runtime claim.'}
    (Path(__file__).resolve().parents[1]/'results/E03-prefix-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'}))

if __name__=='__main__':main()
