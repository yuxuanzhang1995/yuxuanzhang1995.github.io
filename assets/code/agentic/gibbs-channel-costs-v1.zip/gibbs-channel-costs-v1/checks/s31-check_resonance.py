"""Check the Laurent obstruction, raw finite repair and explicit physical channel."""
from collections import defaultdict
from fractions import Fraction as Q
from math import comb

import numpy as np
import sympy as sp


def add(first, second, factor=1):
    out = defaultdict(Q, first)
    for key, value in second.items():
        out[key] += factor*value
    return {k: v for k,v in out.items() if v}


def conv(first, second):
    out = defaultdict(Q)
    for (i,j), value in first.items():
        for (k,l), other in second.items():
            out[i+k,j+l] += value*other
    return {k: v for k,v in out.items() if v}


def normalized(p):
    return {n:v/sum(p.values()) for n,v in p.items()}


u = {(0,0):Q(2), (1,0):Q(1), (-1,0):Q(1)}
v = {(0,0):Q(6,5), (0,1):Q(1), (0,-1):Q(1)}
h = add(u,conv(v,v))
a = {(0,0):Q(1)}
for _ in range(8):
    a = conv(a,u)
delta = Q(1,10**22)
h2 = add(h,a,delta)
assert sum(h.values()) == Q(356,25) and len(h2) == 21
phase = (-3+4*sp.I)/5
for poly in (h,h2):
    assert sp.simplify(sum(p*(-1 if i%2 else 1)*phase**j for (i,j),p in poly.items())) == 0
    assert min(poly.values()) > 0 and poly[0,0] > 1
x,y = sp.symbols("x y",nonzero=True)
hc = sp.expand(sum(p*x**(i+1)*y**(j+2) for (i,j),p in h.items()))
assert sp.gcd(hc,(x+1)**16) == 1

constants = [1]
for j in range(1,7):
    constants.append(32**j + sum(comb(j,i)*32**i*constants[j-i] for i in range(1,j+1)))
kbound = 16**7 + 80*constants[6]*16
assert kbound == 12872532650622976
assert 4*delta*kbound*401 < Q(1,100)
assert 160 + 65*delta*4**8 < 200 and 2/Q(22,7)**2 > Q(1,5)

# Force a signed defect and reconstruct the two normalized probability branches.
q = {(0,0):Q(1), (3,-2):Q(-1,3), (-2,1):Q(1,3)}
f1,f2 = conv(h,q),conv(h2,q)
repair = {n:max(0,-f1.get(n,0),-f2.get(n,0)) for n in f1.keys()|f2.keys()}
assert sum(repair.values()) > 0
f1,f2 = add(f1,conv(h,repair)),add(f2,conv(h2,repair))
assert min(f1.values()) > 0 and min(f2.values()) > 0
assert conv(h2,f1) == conv(h,f2)
b1,b2 = normalized(h),normalized(h2)
c11,c22 = normalized(f2),normalized(f1)
p = conv(b1,c11)
assert p == conv(b2,c22)
energy_ratio = sp.symbols("alpha", real=True)


def variance(prob):
    mean = sum(v*(i+energy_ratio*j) for (i,j),v in prob.items())
    return sp.expand(sum(v*(i+energy_ratio*j)**2 for (i,j),v in prob.items())-mean**2)


assert sp.simplify(variance(p)-variance(b1)-variance(c11)) == 0
assert sp.simplify(variance(b1)-(2+sp.Rational(64,5)*energy_ratio**2)/sp.Rational(356,25)) == 0

labels = sorted(b2)
b = len(labels)
probs = np.array([[float(mu.get(n,0)) for n in labels] for mu in (b1,b2)])
psis = np.sqrt(probs)
phases = np.exp(2j*np.pi*np.outer(np.arange(b),np.arange(b))/b)
preparations = np.vstack([phases*state for state in psis])
averaged = preparations.T @ preparations.conj()/b
assert np.max(np.abs(averaged-np.diag(probs.sum(axis=0)))) < 1e-13
for ratio in (.51,np.arccos(-.6)/np.pi,np.sqrt(.5),.99):
    energies = np.array([i+ratio*j for i,j in labels])
    gibbs = np.exp(-energies)
    gibbs /= gibbs.sum()
    mass = np.exp(-24)/(1+2*b*np.exp(-24))
    flag = (gibbs-b*mass*probs.sum(axis=0))/(1-2*b*mass)
    assert flag.min()>0 and abs(flag.sum()-1)<1e-14
    output = b*mass*averaged+(1-2*b*mass)*np.diag(flag)
    assert np.max(abs(output-np.diag(gibbs))) < 1e-14
print("PASS: exact algebraic common zero and gcd, rational Fourier/repair constant, "
      "signed-site repair, full polynomial-in-energy variance identity and exact "
      "baseline. Numerical 43-to-21 GP and stationary flag checks at four spectra.")
