"""Exact finite controls; not a proof certificate for the all-size theorem."""
from pathlib import Path
from itertools import permutations, combinations, product
from math import comb, factorial
import json
import sympy as S

def permutation_matrix(n, perm):
    states = list(product(range(2), repeat=n))
    where = {b: i for i, b in enumerate(states)}
    P = S.zeros(2**n)
    for j, bits in enumerate(states):
        P[where[tuple(bits[k] for k in perm)], j] = 1
    return P

def twisted_ground_transform(N, m, k):
    holesL = list(combinations(range(N), N-m))
    holesR = list(combinations(range(N), N-k))
    charges = [(frozenset(a), frozenset(b)) for a in holesL for b in holesR]
    pos = {a: i for i, a in enumerate(charges)}
    d = 2**(m+k)
    eye = S.eye(d)
    # Source ket spins rotate first-to-last; the energy's R is its adjoint.
    perm = tuple(range(1, m))+(0,)+tuple(range(m+1, m+k))+(m,)
    R = permutation_matrix(m+k, perm).T
    edges = []
    for x, (a, b) in enumerate(charges):
        for side in range(2):
            h = (a, b)[side]
            for j in range(N-1):
                if (j in h) == (j+1 in h):
                    continue
                hh = h.symmetric_difference({j, j+1})
                target = (hh, b) if side == 0 else (a, hh)
                y = pos[target]
                if x < y:
                    edges.append((x, y, eye))
        if N-1 in a and 0 not in a and N-1 in b and 0 not in b:
            y = pos[(a.symmetric_difference({0, N-1}),
                     b.symmetric_difference({0, N-1}))]
            edges.append((x, y, R))
    L = S.zeros(len(charges))
    H = S.MutableSparseMatrix(len(charges)*d, len(charges)*d, {})
    weighted = S.MutableSparseMatrix(H.rows, H.cols, {})
    wrong = S.MutableSparseMatrix(H.rows, H.cols, {})
    u = S.Matrix([1+S.Rational(i+1, len(charges)+2) for i in range(len(charges))])
    for x, y, U in edges:
        L[x,x] += 1; L[y,y] += 1; L[x,y] -= 1; L[y,x] -= 1
        for a in range(d):
            for b in range(d):
                for M, w in [(H, S.Integer(1)), (weighted, u[x]*u[y]),
                             (wrong, u[x]**2)]:
                    if a == b:
                        M[x*d+a,x*d+b] += w
                        M[y*d+a,y*d+b] += w
                    M[x*d+a,y*d+b] -= w*U[a,b]
                    M[y*d+a,x*d+b] -= w*S.conjugate(U[b,a])
    V = S.Matrix([-z/u[i] for i,z in enumerate(L*u)])
    assert L*u+S.diag(*V)*u == S.zeros(len(charges), 1)
    du = S.diag(*[u[i] for i in range(len(charges)) for _ in range(d)])
    vp = S.diag(*[V[i] for i in range(len(charges)) for _ in range(d)])
    transformed = du*(H+vp)*du
    assert transformed == weighted
    assert transformed != wrong  # The endpoint product cannot be u(x)^2.
    return {'N': N, 'particles': [m,k], 'dimension': H.rows,
            'edges': len(edges), 'exact_nonconstant_transform': True,
            'wrong_edge_weight_detected': True,
            'scope': 'twisted kinetic identity; artificial scalar potential fixes a prescribed u, not a thermal simulation'}

def q048_constants():
    n = 2**30
    assert 3*256+6*128*256**2 <= 2**26  # Loose common coefficient for N>=1.
    assert 2*16+2*128*16**2 <= 2**17
    assert 6*2**27+S.Rational(1,4) <= 2**30
    assert S.Rational(1,2**38*n**3)-S.Rational(1,4096*n**4) >= S.Rational(1,2**39*n**3)
    assert 3*S.Rational(64,63) < 4  # e^(1/64)<=64/63.
    assert S.Rational(4,13) < S.Rational(1,2)  # e^4 >=1+4+4^2/2.
    assert 1+S.Rational(3,2)+S.Rational(9,8) > 3  # ln3<3/2.
    assert S.Rational(129,1394) < S.Rational(3,16)  # Entropy-loss margin.
    return 8

if __name__ == "__main__":
    result={'status':'PASS','q048_all_size_constant_controls':q048_constants(),'q048_twisted_ground_transform':[twisted_ground_transform(3,1,2),twisted_ground_transform(3,2,2)]}
    Path("controls-result.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
