"""Compare the candidate colored prefix evaluator with direct Fock operators.

This small implementation is an algebraic control, not a production sampler.
It retains both harmonic projectors, repeated modes, and spectator modes.
"""
from pathlib import Path
from math import comb,factorial
from fractions import Fraction as F
import itertools,json,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def fall(a,b):return factorial(a)//factorial(a-b)
def B(m,k,l):return factorial(l)**2*comb(m+k+l-1,k-l)
def t(m,k,j,l):return F(fall(j,l)**2*B(m,k,l),fall(k,l)**2*B(m,j,l))
def top_coeff(m,l):
    c=[F(0)]*(l+1);c[l]=F(1)
    for j in range(l-1,-1,-1):c[j]=-sum(c[a]*t(m,l,a,j) for a in range(j+1,l+1))/t(m,l,j,j)
    for j in range(l+1):assert sum(c[a]*t(m,l,a,j) for a in range(j,l+1))==int(j==l)
    return c
def fock(m,k):
    if m==1:return [(k,)]
    return [(i,)+x for i in range(k+1) for x in fock(m-1,k-i)]
def per(a):
    if not len(a):return 1
    return sum(np.prod(a[np.arange(len(a)),p]) for p in itertools.permutations(range(len(a))))
def multi_factorial(v):return np.prod([factorial(x) for x in v])
def choose(v,u):return np.prod([comb(x,y) for x,y in zip(v,u)]) if all(y<=x for x,y in zip(v,u)) else 0
def reduction(m,k,j):
    return np.array([[choose(v,u)/comb(k,j) for v in fock(m,k)] for u in fock(m,j)])

class Ring:
    def __init__(self,l,s,b):self.l=l;self.s=s;self.b=tuple(b);self.zero=(0,0,(0,)*len(b),0);self.one={self.zero:1.0}
    def add(self,a,b):
        z=a.copy()
        for k,v in b.items():z[k]=z.get(k,0)+v
        return {k:v for k,v in z.items() if abs(v)>1e-25}
    def scale(self,a,c):return {k:v*c for k,v in a.items() if abs(v*c)>1e-25}
    def mul(self,a,b):
        out={}
        for (x,y,z,w),v in a.items():
            for (xx,yy,zz,ww),vv in b.items():
                if x&xx or y&yy or w+ww>self.l:continue
                zsum=tuple(i+j for i,j in zip(z,zz))
                if any(i>j for i,j in zip(zsum,self.b)):continue
                k=(x|xx,y|yy,zsum,w+ww);out[k]=out.get(k,0)+v*vv
        return {k:v for k,v in out.items() if abs(v)>1e-25}
    def mono(self,x=0,y=0,z=None,w=0,c=1):return {(x,y,(0,)*len(self.b) if z is None else tuple(z),w):c}
    def matmul(self,a,b):
        n=len(a);out=[[{} for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                for k in range(n):out[i][j]=self.add(out[i][j],self.mul(a[i][k],b[k][j]))
        return out
    def inverse_det(self,M):
        P=M;S={}
        for a in range(1,self.l+1):
            tr={}
            for i in range(len(M)):tr=self.add(tr,P[i][i])
            S=self.add(S,self.scale(tr,1/a))
            if a<self.l:P=self.matmul(P,M)
        out=self.one;power=self.one
        for a in range(1,self.l+1):
            power=self.mul(power,S);out=self.add(out,self.scale(power,1/factorial(a)))
        return out

def evaluator(U,n,l,D,h,hi,go):
    m=len(U);ell=sum(h);c=top_coeff(m,l);N=[hi.count(a) for a in range(l)];pl=factorial(l)/l**l;total=0j;patterns=0;largest=0
    for q in range(min(D-1,l//2)+1):
        for H in itertools.combinations(range(m),q):
            for b in itertools.product(range(2,l+1),repeat=q):
                if sum(b)>l or sum(x-1 for x in b)>=D:continue
                s=l-sum(b);ps=factorial(s)/s**s if s else 1;R=Ring(l,s,b);Z=[];P=R.one
                for i in range(m):
                    if i in H:
                        zz=[0]*q;zz[H.index(i)]=1;Z.append(R.mono(z=zz))
                    elif s:
                        xbit=1<<go[s][i];zi=R.add(R.mono(x=xbit),R.mono(x=xbit,w=1,c=h[i]));Z.append(zi);P=R.mul(P,R.add(R.one,zi))
                    else:Z.append({})
                for i,bi in zip(H,b):
                    Fh={R.zero:1}
                    for j in range(1,min(bi,h[i])+1):Fh=R.add(Fh,R.mono(w=j,c=comb(bi,j)*comb(h[i],j)))
                    P=R.mul(P,Fh)
                M=[[{} for _ in range(n)] for _ in range(n)]
                for a in range(n):
                    ya=R.mono(y=1<<hi[a])
                    for bb in range(n):
                        val={}
                        for i in range(m):val=R.add(val,R.scale(Z[i],U[i,a].conjugate()*U[i,bb]))
                        M[a][bb]=R.mul(ya,val)
                G=R.mul(P,R.inverse_det(M));largest=max(largest,len(G));patterns+=1
                for (xb,yb,zv,j),val in G.items():
                    if xb!=(1<<s)-1:continue
                    a=yb.bit_count();unused=np.prod([N[col] for col in range(l) if not (yb>>col)&1])
                    cw=np.prod([comb(bi,ui) for bi,ui in zip(b,zv)])
                    weight=float(c[a])*float(c[j])*unused*cw/(pl*comb(n,l)*comb(l,a)**2*comb(l,j)*comb(ell,j)*ps)
                    total+=val*weight
    return total/float(t(m,ell,l,l)),patterns,largest

def direct(U,n,l,D,h,hi,go):
    m=len(U);ell=sum(h);occ=fock(m,l);c=top_coeff(m,l)
    Pi=sum(float(c[j])*(reduction(m,l,j).T@reduction(m,l,j)) for j in range(l+1))
    assert np.linalg.norm(Pi@Pi-Pi)<1e-10
    pl=factorial(l)/l**l;X=[];mask=[]
    for v in occ:
        I=[i for i,x in enumerate(v) if x]
        good=max(v)<=1 and all(i<n for i in I) and len({hi[i] for i in I})==l
        X.append(1/(pl*comb(n,l)) if good else 0)
        S=[i for i,x in enumerate(v) if x==1];s=len(S);ps=factorial(s)/s**s if s else 1
        mask.append(float(l-len(I)<D and (not s or len({go[s][i] for i in S})==s))/ps)
    G=np.empty((len(occ),len(occ)),complex)
    for i,v in enumerate(occ):
        rows=[a for a,x in enumerate(v) for _ in range(x)]
        for j,w in enumerate(occ):
            cols=[a for a,x in enumerate(w) for _ in range(x)]
            G[i,j]=per(U[np.ix_(rows,cols)])/np.sqrt(multi_factorial(v)*multi_factorial(w))
    assert np.linalg.norm(G.conj().T@G-np.eye(len(occ)))<1e-9
    diagonal=Pi@(np.array(mask)*(abs(G)**2@(Pi@np.array(X))))
    beta=np.array([choose(h,v)/comb(ell,l) for v in occ])
    return beta@diagonal/float(t(m,ell,l,l))

def main():
    rng=np.random.default_rng(138);rows=[];start=time.time()
    cases=[(3,3,1,1,(2,1,0),False),(3,3,2,1,(1,1,1),False),(3,3,2,2,(2,1,0),False),(4,4,3,1,(2,1,1,0),False),(4,4,3,2,(3,1,0,0),False),(4,4,3,3,(2,2,0,0),False),(3,3,3,3,(3,0,0),False),(3,3,3,3,(2,1,0),True),(4,4,4,1,(1,1,1,1),False),(4,4,4,2,(2,1,1,0),False),(4,4,4,3,(2,2,0,0),False),(4,4,4,4,(4,0,0,0),False),(5,4,3,3,(0,0,1,3,0),False)]
    for m,n,l,D,h,empty in cases:
        z=rng.normal(size=(m,m))+1j*rng.normal(size=(m,m));U=np.linalg.qr(z)[0]
        hi=[i%l for i in range(n)]
        if empty:hi=[0]*(n-1)+[1]
        go={s:[int(x) for x in rng.permutation(np.arange(m)%s)] for s in range(1,l+1)}
        expected=direct(U,n,l,D,h,hi,go);actual,patterns,size=evaluator(U,n,l,D,h,hi,go);err=abs(actual-expected)
        assert err<1e-9,(m,l,D,actual,expected,err)
        rows.append(dict(m=m,n=n,l=l,cutoff=D,prefix=list(h),empty_input_color=empty,direct=float(expected),coefficient_real=float(actual.real),coefficient_imag=float(actual.imag),error=float(err),patterns=patterns,max_ring_coefficients=size))
    out={'controls':rows,'elapsed_seconds':time.time()-start,'scope':'Direct Fock-operator comparison against a separately implemented coefficient evaluator. Finite controls, not independent mathematical review.'}
    (ROOT/'results/fock-prefix-checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'cases':len(rows),'max_error':max(x['error'] for x in rows),'seconds':out['elapsed_seconds']}))
if __name__=='__main__':main()
