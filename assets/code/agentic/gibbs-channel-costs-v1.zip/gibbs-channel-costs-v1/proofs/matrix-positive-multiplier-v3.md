# Matrix Handelman criterion with Newton kernel compatibility

24 November 2026. Same-root proof candidate. No independent verification
or first-priority claim. This closes the fixed-matrix multiplier bridge
left open in v1 and v2, not the selection of a sector solution in an
arbitrary channel module.

Let F=sum_alpha F_alpha x^alpha be a finite Hermitian Laurent matrix
polynomial, F(1)>0. For a nonzero constant complex vector v put f_v=v*Fv.
The following are equivalent:

(1) Some nonzero real Laurent q makes every coefficient of qF PSD.
(2) Such a q exists with nonnegative coefficients.
(3) For every nonzero v:
    (A) every Newton face polynomial of f_v is strictly positive on the
        positive orthant;
    (B) N(Fv)=N(f_v), where vector Newton support means the convex hull
        of all exponents with nonzero vector coefficient.
(4) F(x)>=epsilon sum_alpha |F_alpha|x^alpha for all x>0 and some epsilon>0.

Equivalence (3)<->(4) was proved in `matrix-relative-positivity-v2.md`.
The new step here is (3)->(2). It is a dimension induction followed by a
finite cover of the unit sphere, not an assumption that scalar multipliers
for different vectors are automatically the same.

## Scalar domination lemma

If a scalar Laurent f has every Newton face strictly positive, and g has
nonnegative coefficients with N(g) contained in N(f), then for some c>0
and nonzero h with nonnegative coefficients,

    h(c f-g) has nonnegative coefficients.                (5)

To verify this, scalar face positivity gives a uniform comparison
f>=epsilon sum |f_alpha|x^alpha (the scalar case of v2). Every monomial
of g lies in N(f), and weighted AM-GM bounds it by a constant times this
positive coefficient sum. The same argument on each of finitely many
faces shows that c f-g has every Newton face strictly positive once c is
large enough. A face of N(f) on which g has no term causes no difficulty.
Use scalar Handelman's theorem, in the version giving a NONNEGATIVE
multiplier h. Consequently the coefficients of c h f dominate those of
h g. This is the required support-preserving strictness, not just h f>=0.

## Necessity

If G=qF has PSD coefficients, then G(1)=q(1)F(1)>0 and G(x)>0 on the
positive orthant. Therefore q(x)>0 and F(x)>0 there. For each v, q f_v has
nonnegative coefficients, so scalar Handelman gives (A). At every
coefficient, v*G_alpha v=0 iff G_alpha v=0. Hence N(Gv)=N(v*Gv).
Multiplication by q adds N(q) to vector and scalar Newton polytopes;
Minkowski cancellation gives (B). This works even for initially signed q.

## Sufficiency: construct a multiplier valid near each vector

Induct on the matrix size r. The r=1 assertion is scalar Handelman.
Fix a unit vector v and let P compress onto v^perp. The (r-1)-dimensional
matrix F_perp=P F P* satisfies (3): for w in v^perp its scalar form is
unchanged, while

 N(w*F w) subset N(P F w) subset N(F w)=N(w*F w).

It also has F_perp(1)>0. By induction there is q_0>=0 coefficientwise,
nonzero, such that q_0 F_perp has PSD coefficients. Put H=q_0 F and
f=v*H v. Its Newton faces are strictly positive, because those of q_0 and
f_v are positive. Moreover N(Hv)=N(f).

Let g=sum_(alpha in support(Hv)) x^alpha. Apply (5) to f,g. Then for a
nonnegative multiplier h and c>0,

    [x^alpha](c h f) >= [x^alpha](h g) >= 0.              (6)

Set Q_v=h q_0 and write M_alpha=[x^alpha](Q_v F). Their compressions to
v^perp are PSD, since h has nonnegative coefficients. Their quadratic
forms at v are nonnegative by (6).

If v*M_alpha v=0, (6) forces [x^alpha](h g)=0. Each coefficient of h and
g is nonnegative, and g includes EVERY exponent where H_alpha v!=0.
Therefore [x^alpha](h Hv)=M_alpha v=0. A Hermitian matrix annihilating v
and PSD on v^perp is PSD on the entire space.

For each remaining coefficient M_alpha, v*M_alpha v>0, so its quadratic
form remains strictly positive on an open neighborhood of v on the unit
sphere. There are only finitely many coefficients. Their neighborhoods
have a common open neighborhood U_v. On U_v ALL scalar coefficients of
w*Q_v Fw are nonnegative: the zero-at-v cases were already PSD globally.

## Sufficiency: one common multiplier

The U_v cover the compact complex unit sphere. Choose a finite subcover
U_(v_1),...,U_(v_k), and put Q=product_i Q_(v_i). Every factor has
nonnegative coefficients and is nonzero. Given any unit w, choose i with
w in U_(v_i). The scalar polynomial w*Q_(v_i)F w has nonnegative
coefficients; multiplication by the remaining nonnegative factors preserves
that property. Thus w*[x^alpha](QF)w>=0 for every w and alpha. Each matrix
coefficient of QF is PSD, proving (2).

## Effective content and the unresolved physical step

For a FIXED finite F with algebraic coefficients, (3) is a finite real
quantifier-elimination test: enumerate possible supports of f_v inside
support(F), their finitely many faces, and quantify over v and positive x.
Kernel compatibility uses the same finite supports. If the test succeeds,
enumeration of finite scalar multiplier supports with semidefinite
feasibility eventually finds a witness. The proof gives no useful degree
bound and makes no polynomial-time claim.

For Q117, an injective polynomial sector map can determine a unique
rational matrix ratio C/p. Once a scalar denominator has been chosen so
that its positivity can be handled, this theorem tests its matrix positive
multiple. In an underdetermined sector module, choosing a polynomial F
with the required conditions is still a separate issue. This theorem
must not be labelled a full arbitrary-support finite-resource criterion.

## Primary ingredients and credit

Scalar positive multiples are Handelman's theorem, using the explicit
nonnegative-multiplier form in De Angelis--Tuncel,
https://vdeangel.xula.edu/Publications/htheorem.pdf . Compactness, scalar
AM-GM and semialgebraic curve selection are established tools. Matrix
Pólya/Handelman results with strict positivity on compact polyhedra include
https://arxiv.org/abs/1603.07611 . The singular-face kernel compatibility
and induction above require separate source comparison before novelty is
claimed. No existing theorem with weaker hypotheses is being silently
substituted for this proof.
