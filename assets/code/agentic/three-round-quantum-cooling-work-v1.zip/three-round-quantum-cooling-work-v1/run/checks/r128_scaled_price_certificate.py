from pathlib import Path
import itertools,json
from p11_rational_quantum_certificate_common import I,D,q,p,E
old=json.loads(Path('run/checks/r125_first_stage.result.json').read_text())['price'];new=json.loads(Path('run/checks/r127_suffix_diagnostics.result.json').read_text())['price'];a=I('.999');errors=[I(str(y))-a*I(str(x)) for x,y in zip(old,new)];osc=I(max(e.a for e in errors)-min(e.b for e in errors),max(e.b for e in errors)-min(e.a for e in errors));Zsm=(1+q+q*q)*(1+q);works=[]
for profile in set(itertools.permutations(E)):
 if profile==tuple(E):continue
 w=sum(E[i]*(q**profile[i]/Zsm-p[i]) for i in range(6));assert w.a>0;works.append(w)
cmin=I(min(w.a for w in works),min(w.b for w in works));margin=(1-a)*cmin-osc;assert margin.a>D('.0000416')
out=dict(scale='.999',price_error_intervals=[e.pair() for e in errors],error_oscillation=osc.pair(),minimum_active_first_work=cmin.pair(),strict_transfer_margin=margin.pair(),scope='every active history with old price<=0 remains strictly negative at the stored new price;35 representative unresolved suffixes remain sufficient after rounding')
Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
