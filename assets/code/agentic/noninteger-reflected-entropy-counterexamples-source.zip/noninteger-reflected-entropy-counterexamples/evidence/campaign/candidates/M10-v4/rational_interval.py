"""Elementary outward intervals using only exact Python integer arithmetic.

The square-root enclosure follows by squaring integer endpoints. exp(-1/2)
uses the alternating-series remainder. No floating-point solver is trusted.
"""
from fractions import Fraction as F
from math import isqrt, factorial
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING

class I:
    def __init__(self,lo,hi=None):
        self.lo=F(lo); self.hi=F(lo if hi is None else hi)
        assert self.lo<=self.hi
    def __add__(self,b):
        b=as_i(b);return I(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,b):return self+-as_i(b)
    def __rsub__(self,b):return as_i(b)+-self
    def __mul__(self,b):
        b=as_i(b);v=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi];return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=as_i(b);assert not (b.lo<=0<=b.hi)
        return self*I(1/b.hi,1/b.lo)
    def __rtruediv__(self,b):return as_i(b)/self
    def __pow__(self,k):
        assert isinstance(k,int) and k>=0
        r=I(1)
        for _ in range(k):r=r*self
        return r
    def sqrt(self,digits=60):
        assert self.lo>=0
        q=10**digits
        lower=isqrt(self.lo.numerator*q*q//self.lo.denominator)
        upper=isqrt(self.hi.numerator*q*q//self.hi.denominator)
        if F(upper*upper,q*q)!=self.hi:upper+=1
        result=I(F(lower,q),F(upper,q))
        assert result.lo**2<=self.lo and result.hi**2>=self.hi
        return result
    def positive_part(self):return I(max(0,self.lo),max(0,self.hi))
    def decimal(self,digits=45):
        out=[]
        for x,rounding in [(self.lo,ROUND_FLOOR),(self.hi,ROUND_CEILING)]:
            with localcontext() as ctx:
                ctx.prec=digits;ctx.rounding=rounding
                out.append(str(Decimal(x.numerator)/Decimal(x.denominator)))
        return out

def as_i(x):return x if isinstance(x,I) else I(x)

def exp_minus_half(terms=90):
    assert terms%2==0
    upper=sum((F((-1)**k,2**k*factorial(k)) for k in range(terms+1)),F(0))
    lower=upper-F(1,2**(terms+1)*factorial(terms+1))
    return I(lower,upper)

def determinant3(a):
    return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
           -a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
           +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))
