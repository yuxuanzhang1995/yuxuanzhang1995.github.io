# Newton tests exactly characterize uniform matrix relative positivity

24 November 2026. Same-root proof candidate. This proves the intermediate
claim left open in `matrix-newton-route-working.md`. It does NOT yet prove
a matrix positive-coefficient multiplier theorem or arbitrary-support
finite implementability.

Let F(x)=sum_alpha F_alpha x^alpha be Hermitian with F(1)>0, and define

    A(x)=sum_alpha |F_alpha| x^alpha,

where |F_alpha| is its positive matrix modulus. Then A(x)>0 for all
positive x: a common coefficient kernel would contradict F(1)>0.
For each nonzero constant v put f_v=v*Fv. The following are equivalent:

(i) Every Newton face polynomial of f_v is strictly positive on the
    positive orthant, and N(Fv)=N(f_v), for every v!=0.
(ii) There is a constant epsilon>0 with F(x)>=epsilon A(x) for all x>0.

Condition (i) is a finite semialgebraic decision condition for a fixed F,
as explained in the working file. Hermitian coefficients can be treated
in real and imaginary coordinates. The comparison is relative to A;
ordinary uniform positive definiteness on an unbounded orthant is not
being asserted.

## Necessity of the tests from relative domination

For each v, a_v=v*A v has nonnegative coefficients; its support is exactly
the set of alpha for which F_alpha v!=0. Since v*F_alpha v!=0 implies
F_alpha v!=0, N(f_v) is contained in N(a_v). If strict containment held,
a separating rational direction w and a substitution x_i=t^(w_i) would
make f_v/a_v tend to zero at zero or infinity, contradicting domination.
Thus the two Newton polytopes agree. Taking any exposed face by such a
scaling, at any positive leading coefficient tuple a, gives
(f_v)_face(a)>=epsilon (a_v)_face(a)>0. This proves both tests.

## Sufficiency by a semialgebraic curve and constant kernel flags

If (ii) fails, the semialgebraic function

    lambda(x)=lambda_min(A(x)^(-1/2) F(x) A(x)^(-1/2))

has infimum zero (it is positive by the full-face case of (i)).
Semialgebraic curve selection after compactification gives a positive
curve x(t), t down to zero, along which lambda tends to zero. Each
coordinate has a Puiseux leading term

    x_i(t)=t^(w_i) a_i(t),   a_i(t)->a_i>0,

with rational w_i. All real matrix entries are fixed parameters; the
curve-selection argument does not require rational coefficients.

Group the finite exponent support by weight mu=w dot alpha, in increasing
order. We construct a flag K_mu, starting with the whole vector space.
Assume all coefficients of smaller weight annihilate the current K. On K
consider

    B_mu(a)=compression_K sum_(w dot alpha=mu) a^alpha F_alpha.

For v in K, either all scalar coefficients of this group vanish, or this
group is the w-minimal face of f_v. In the latter case (i) says
v*B_mu(a)v>0; in the former it is zero. Consequently B_mu(a)>=0.
If v belongs to its kernel, the entire scalar group vanishes. The Newton
identity N(Fv)=N(f_v) then implies F_alpha v=0 at every exponent of this
group: otherwise the vector polynomial would have a smaller w-degree
than f_v. Thus the next kernel is the intersection of K with the kernels
of all coefficient matrices in the group. In particular it is independent
of the positive tuple a. The same assertions hold for a(t).

Split the space orthogonally into the nonzero successive flag quotients
V_mu. On V_mu, B_mu(a)>0. Every block (F_alpha)_(V_mu,V_nu) vanishes when
w dot alpha < max(mu,nu); this follows from the coefficient annihilation
just proved and Hermiticity. Rescale the V_mu block by t^(-mu/2). The
rescaled F(x(t)) converges to the positive definite block diagonal matrix
with blocks B_mu(a). Blocks at larger weight vanish, and an off-diagonal
block between distinct weights gains t^(abs(mu-nu)/2).

The coefficient moduli |F_alpha| have exactly the same kernels as F_alpha.
The same block argument therefore applies to A(x(t)): its rescaling
converges to a positive definite block diagonal matrix. The flags exhaust
the space, since their final kernel is the common coefficient kernel,
which is zero. Hence the two rescaled matrices have a fixed strictly
positive comparison constant for all sufficiently small t. Congruence
undoes the rescaling and gives F(x(t))>=c A(x(t)), contradicting lambda->0.
This proves (ii).

## What this does and does not remove

The Newton tests now control all varying input vectors and all curved
paths to the boundary, not only fixed rays. The matrix coefficient
multiplier implication still needs an ordered-module or coefficient
argument. It is invalid to assume that relative positivity alone has
already supplied that theorem. Selecting a solution of the physical
channel's polynomial module is a further unresolved step.

A useful exact control is

    F=(1-xy+x^2 y^2) I + x P + y Q,

for distinct noncommuting rank-one PSD projections P,Q. Here q=1+xy gives
PSD coefficients exactly. On a vector in ker P, a multiplier built only
from powers of the global support sum can fail: in the direction x/y,
the multiplier's exposed face can be a monomial, leaving the scalar
negative xy coefficient untouched. A scalar multiplier with the needed
face direction is essential; a universal rectangular/global-support
power is not justified.
