"""Seeded finite full-Fock experiment; not an efficient all-size sampler.

Harmonic projectors are reconstructed from row spaces of particle reduction.
Bosonic representations are built by creation-operator recursion, not permanents.
All outputs and all survivor sectors are enumerated. Color draws are iid uniform.
Reported mean conditional-TV upper-bounds the TV of the color-mixture algorithm.
"""
from pathlib import Path
from math import comb, factorial, sqrt
import argparse, csv, hashlib, itertools, json, time, sys
import numpy as np

BASE=Path(__file__).resolve().parents[1]/'results'
ROOT=Path(__file__).resolve().parents[1]

def fock(m,k):
    if m==1:return [(k,)]
    return [(i,)+v for i in range(k+1) for v in fock(m-1,k-i)]

class Geometry:
    def __init__(self,m,n):
        self.m,self.n=m,n
        self.occ=[fock(m,k) for k in range(n+1)]
        self.ix=[{v:i for i,v in enumerate(o)} for o in self.occ]
        self.red={};self.proj={};self.lift={};self.rho=[];self.children=[]
        self.max_residual=0.
        for k in range(n+1):
            self.rho.append(np.array([float(max(v)<=1 and not any(v[n:]))/comb(n,k) for v in self.occ[k]]))
            prior=np.zeros((len(self.occ[k]),len(self.occ[k])))
            for l in range(k+1):
                R=np.array([[np.prod([comb(x,y) for x,y in zip(v,u)])/comb(k,l) if all(y<=x for x,y in zip(v,u)) else 0. for v in self.occ[k]] for u in self.occ[l]])
                self.red[k,l]=R
                Q=np.linalg.qr(R.T,mode='reduced')[0]
                current=Q@Q.T
                self.proj[k,l]=current-prior
                self.lift[k,l]=np.linalg.solve(R@R.T,R).T
                self.max_residual=max(self.max_residual,float(np.max(abs(current@current-current))))
                prior=current
            if k<n:
                self.children.append(np.array([[self.ix[k+1][tuple(x+int(j==a) for j,x in enumerate(v))] for a in range(m)] for v in self.occ[k]]))
        assert self.max_residual<1e-10

    def representations(self,U):
        out=[np.ones((1,1),complex)]
        for k in range(1,self.n+1):
            G=np.zeros((len(self.occ[k]),len(self.occ[k])),complex)
            for col,w in enumerate(self.occ[k]):
                j=next(j for j,x in enumerate(w) if x)
                prev=list(w);prev[j]-=1;pc=self.ix[k-1][tuple(prev)]
                for row,v in enumerate(self.occ[k]):
                    for a,x in enumerate(v):
                        if x:
                            u=list(v);u[a]-=1
                            G[row,col]+=U[a,j]*sqrt(x/w[j])*out[-1][self.ix[k-1][tuple(u)],pc]
            out.append(G)
        return out

    def sample_laws(self,q):
        laws=[np.ones(1)];res=0.
        for ell in range(self.n):
            weights=np.maximum(q[ell+1][self.children[ell]],0)* (np.array(self.occ[ell])+1)
            denom=weights.sum(axis=1)
            active=laws[-1]>1e-14
            assert np.all(denom[active]>0)
            cond=np.divide(weights,denom[:,None],out=np.full_like(weights,1/self.m),where=denom[:,None]>0)
            nxt=np.zeros(len(self.occ[ell+1]))
            np.add.at(nxt,self.children[ell].ravel(),(laws[-1][:,None]*cond).ravel())
            laws.append(nxt)
            res=max(res,float(np.max(abs(self.red[ell+1,ell]@q[ell+1]-q[ell]))))
        assert res<2e-8,res
        assert max(abs(x.sum()-1) for x in laws)<1e-10
        return laws,res

def haar(rng,m):
    z=rng.normal(size=(m,m))+1j*rng.normal(size=(m,m))
    q,r=np.linalg.qr(z);d=np.diag(r)
    return q*(d/abs(d))[None,:]

def colors(g,rng,l,T,transition,collision_mode):
    m,n=g.m,g.n;occ=g.occ[l];p=factorial(l)/l**l
    hi=rng.integers(l,size=(T,n));X=np.zeros((len(occ),T))
    for i,v in enumerate(occ):
        inds=[j for j,x in enumerate(v) if x]
        if max(v)<=1 and not any(v[n:]):
            X[i]=np.array([len(set(row[inds]))==l for row in hi])/(p*comb(n,l))
    mask=np.zeros_like(X)
    go={s:rng.integers(s,size=(T,m)) for s in range(1,l+1)}
    for i,v in enumerate(occ):
        single=[j for j,x in enumerate(v) if x==1];s=len(single)
        if collision_mode=='omit_harmonic_collisions' and max(v)>1:continue
        mask[i]=1 if not s else np.array([len(set(row[single]))==s for row in go[s]])/(factorial(s)/s**s)
    P=g.proj[l,l]
    return P@(mask*(transition@(P@X)))

def controls(g,U,G):
    # Direct permanents are a separate control for the representation recursion.
    rng=np.random.default_rng(991+g.m*10+g.n);err=0.
    for k in range(1,g.n+1):
        for _ in range(8):
            i=int(rng.integers(len(g.occ[k])));j=int(rng.integers(len(g.occ[k])))
            v,w=g.occ[k][i],g.occ[k][j]
            rows=[a for a,x in enumerate(v) for _ in range(x)];cols=[a for a,x in enumerate(w) for _ in range(x)]
            a=U[np.ix_(rows,cols)]
            per=sum(np.prod(a[np.arange(k),perm]) for perm in itertools.permutations(range(k)))
            expected=per/sqrt(np.prod([factorial(x) for x in v+w]))
            err=max(err,float(abs(expected-G[k][i,j])))
    # Existing closed-form projector is compared against the new QR construction.
    sys.path.insert(0,str(ROOT/'code'))
    from r138_p60_evaluator import top_coeff,t,evaluator
    pe=0.;le=0.;ce=0.
    for l in range(1,g.n+1):
        c=top_coeff(g.m,l)
        P=sum(float(c[a])*g.red[l,a].T@g.red[l,a] for a in range(l+1))
        pe=max(pe,float(np.max(abs(P-g.proj[l,l]))))
        for k in range(l,g.n+1):
            expected=g.red[k,l].T@g.proj[l,l]/float(t(g.m,k,l,l))
            le=max(le,float(np.max(abs(expected-g.lift[k,l]@g.proj[l,l]))))
    # A fixed-color coefficient oracle is compared with the direct matrix law.
    l=min(2,g.n);hi=[i%l for i in range(g.n)];go={s:[i%s for i in range(g.m)] for s in range(1,l+1)}
    X=[];mask=[]
    for v in g.occ[l]:
        I=[i for i,x in enumerate(v) if x];S=[i for i,x in enumerate(v) if x==1];s=len(S)
        good=max(v)<=1 and not any(v[g.n:]) and len({hi[i] for i in I})==l
        X.append(float(good)/(factorial(l)/l**l*comb(g.n,l)))
        mask.append(1 if not s else float(len({go[s][i] for i in S})==s)/(factorial(s)/s**s))
    A=g.proj[l,l]@(np.array(mask)*(abs(G[l])**2@(g.proj[l,l]@X)))
    for h in g.occ[g.n][::max(1,len(g.occ[g.n])//3)]:
        actual=evaluator(U,g.n,l,l,h,hi,go)[0]
        direct=(g.lift[g.n,l]@A)[g.ix[g.n][h]]
        ce=max(ce,float(abs(actual-direct)))
    assert max(err,pe,le,ce)<1e-8,(err,pe,le,ce)
    return dict(permanent=err,projector=pe,lift=le,coefficient=ce)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--draws',type=int,default=256);ap.add_argument('--out',default='haar-tv-results');a=ap.parse_args()
    out=BASE/a.out;out.mkdir(exist_ok=True)
    config={'seed':20261101,'haar_draws_per_geometry':a.draws,'geometries':[(2,2),(3,3),(4,3),(6,3),(4,4),(5,4)],'eta':[.25,.5,.75,.9],'T':[1,4,16,64,256],'cutoffs':'all r=0,...,n','collision_modes':['full','omit_harmonic_collisions'],'arithmetic':'numpy complex128; finite experiments, not interval-certified','reported_TV':'E_(U,colors) TV(S_(U,colors),p_U), a Jensen upper bound on color-mixture TV','scope':'All survivor numbers and all Fock collision patterns. Full Fock enumeration is exponential and is only a small-system validation backend. T and r varied independently; not a claim to run the very large worst-case epsilon prescription.'}
    (out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    rng=np.random.default_rng(config['seed']);start=time.time();control_rows=[];max_compat=0.;max_positive_bound_slack=-1e99;max_unitarity=0.
    rows=[];moment_rows=[]
    for m,n in config['geometries']:
        g=Geometry(m,n)
        for draw in range(a.draws):
            U=haar(rng,m);G=g.representations(U);trans=[abs(x)**2 for x in G]
            max_unitarity=max(max_unitarity,max(float(np.max(abs(x.conj().T@x-np.eye(len(x))))) for x in G))
            true=[trans[k]@g.rho[k] for k in range(n+1)]
            if draw==0:control_rows.append({'m':m,'n':n,**controls(g,U,G)})
            weight={eta:np.array([comb(n,k)*eta**k*(1-eta)**(n-k) for k in range(n+1)]) for eta in config['eta']}
            for r in range(n+1):
                q=[trans[k]@sum(g.proj[k,l]@g.rho[k] for l in range(min(k,r)+1)) for k in range(n+1)]
                S,res=g.sample_laws(q);max_compat=max(max_compat,res)
                l1=np.array([np.sum(abs(q[k]-true[k])) for k in range(n+1)])
                tv=np.array([.5*np.sum(abs(S[k]-true[k])) for k in range(n+1)])
                l2=np.array([len(g.occ[k])*np.sum((q[k]-true[k])**2) for k in range(n+1)])
                pred=np.array([len(g.occ[k])*sum(np.dot(g.proj[k,l]@g.rho[k],g.proj[k,l]@g.rho[k])/(len(g.occ[l])+len(g.occ[l-1])) for l in range(r+1,k+1)) for k in range(n+1)])
                for eta,w in weight.items():
                    bound=sqrt(sum(eta**l for l in range(r+1,n+1)))
                    rows.append([m,n,draw,eta,r,0,'ideal',float(w@tv),float(w@l1),bound/2])
                    moment_rows.append([m,n,draw,eta,r,float(w@l2),float(w@pred)])
                assert np.max(tv-.5*l1)<1e-9
            for mode in config['collision_modes']:
                A={l:np.cumsum(colors(g,rng,l,256,trans[l],mode),axis=1) for l in range(1,n+1)}
                taus={l:float(np.mean([max(v)>1 for v in g.occ[l]])) if mode!='full' else 0. for l in range(1,n+1)}
                for T in config['T']:
                    q=[np.full(len(g.occ[k]),1/len(g.occ[k])) for k in range(n+1)]
                    for r in range(1,n+1):
                        for k in range(r,n+1):q[k]=q[k]+g.lift[k,r]@(A[r][:,T-1]/T)
                        S,res=g.sample_laws(q);max_compat=max(max_compat,res)
                        l1=np.array([np.sum(abs(q[k]-true[k])) for k in range(n+1)])
                        tv=np.array([.5*np.sum(abs(S[k]-true[k])) for k in range(n+1)])
                        slack=float(np.max(tv-.5*l1));max_positive_bound_slack=max(max_positive_bound_slack,slack)
                        assert slack<1e-8,slack
                        for eta,w in weight.items():
                            bound=.5*(sqrt(sum(eta**l for l in range(r+1,n+1)))+sqrt(3*sum(taus[l]*eta**l for l in range(1,r+1)))+sqrt(sum(np.exp(2*l)*eta**l for l in range(1,r+1))/T))
                            rows.append([m,n,draw,eta,r,T,mode,float(w@tv),float(w@l1),bound])
        print(json.dumps({'geometry':[m,n],'haar_draws':a.draws,'elapsed_seconds':time.time()-start}),flush=True)
    with (out/'raw.csv').open('w') as f:
        wr=csv.writer(f);wr.writerow(['m','n','draw','eta','r','T','mode','TV','signed_L1','mean_TV_upper_bound']);wr.writerows(rows)
    with (out/'moments.csv').open('w') as f:
        wr=csv.writer(f);wr.writerow(['m','n','draw','eta','r','weighted_squared_error','predicted_Haar_mean']);wr.writerows(moment_rows)
    groups={}
    for row in rows:groups.setdefault(tuple(row[i] for i in [0,1,3,4,5,6]),[]).append(row)
    summary=[]
    for key,values in groups.items():
        v=np.array([x[7] for x in values]);l1=np.array([x[8] for x in values]);se=float(v.std(ddof=1)/sqrt(len(v))) if len(v)>1 else 0.
        summary.append(dict(zip(['m','n','eta','r','T','mode'],key),draws=len(v),mean_TV=float(v.mean()),standard_error=se,empirical_q95=float(np.quantile(v,.95)),max_TV=float(v.max()),mean_signed_L1=float(l1.mean()),theoretical_mean_TV_bound=values[0][9]))
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    report={'status':'completed','haar_matrices':a.draws*len(config['geometries']),'TV_rows':len(rows),'control_comparisons':control_rows,'max_unitarity_residual':max_unitarity,'max_prefix_consistency_residual':max_compat,'max_signed_sampling_inequality_slack':max_positive_bound_slack,'elapsed_seconds':time.time()-start,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limits':'No all-size certification, no independent expert review, no runtime benchmark of the theorem algorithm; float error checked by residuals and separate formulas, not enclosed rigorously.'}
    (out/'checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)

if __name__=='__main__':main()
