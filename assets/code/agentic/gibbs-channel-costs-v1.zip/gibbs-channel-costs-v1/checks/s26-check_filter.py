"""Exact controls for singular nontrivial characters and physical variance."""
from fractions import Fraction as Q

import sympy as sp


x, y = sp.symbols("x y", nonzero=True)
generator = sp.Matrix([1-y, x+1])
row = sp.Matrix([[x+1, y-1]])
assert (row * generator).applyfunc(sp.expand) == sp.zeros(1, 1)
dual_row = generator.subs({x: 1/x, y: 1/y}).T
projection = generator * dual_row
h = (dual_row * generator)[0]
assert (projection * generator - h * generator).applyfunc(sp.simplify) == sp.zeros(2, 1)
assert (row * projection).applyfunc(sp.expand) == sp.zeros(1, 2)
assert h.subs({x: -1, y: 1}) == 0 and h.subs({x: 1, y: 1}) == 4


def convolution(first, second):
    result = {}
    for (a, b), mass in first.items():
        for (c, d), other_mass in second.items():
            loc = (a+c, b+d)
            result[loc] = result.get(loc, 0) + mass*other_mass
    return result


def variance(weights):
    energies = {n: n[0] + sp.sqrt(2)*n[1] for n in weights}
    mean = sum(weight*energies[n] for n, weight in weights.items())
    return sp.expand(sum(weight*(energies[n]-mean)**2 for n, weight in weights.items()))


initial = {(0, 0): Q(1, 3), (1, 0): Q(1, 4), (0, 2): Q(5, 12)}
p, q = 1, 1
previous = 1
for j in range(8):
    assert abs(p*p-2*q*q) == 1 and p % 2
    filt = {(0, 0): Q(1, 2), (p, -q): Q(1, 4), (-p, q): Q(1, 4)}
    # At the bad circle the third coordinate is free.
    assert sum((-1 if i % 2 else 1)*mass for (i, _), mass in filt.items()) == 0
    assert sum(abs(m - int(n == (0, 0))) for n, m in filt.items()) == 1
    energy_variance = variance(filt)
    assert (previous-energy_variance).is_positive
    assert sp.simplify(energy_variance - sp.Rational(1, 2)/(p+q*sp.sqrt(2))**2) == 0
    assert sp.expand(variance(convolution(initial, filt)) - variance(initial) - energy_variance) == 0
    previous = energy_variance
    p, q = p+2*q, p+q

# A one-dimensional transverse-width integral: the common factor cancels for
# a product wave packet with a compact Sobolev bump (the proof uses C-infinity).
t, u, a, width, duration = sp.symbols("t u a width duration", positive=True)
shape = (1-t**2)**2
rate = sp.integrate(sp.diff(shape, t)**2, (t, -1, 1))/sp.integrate(shape**2, (t, -1, 1))
norm = width*duration*sp.integrate((1-u**2)**4, (u, -1, 1))*sp.integrate(shape**2, (t, -1, 1))
dirichlet = width/duration*sp.integrate((1-u**2)**4, (u, -1, 1))*sp.integrate(sp.diff(shape, t)**2, (t, -1, 1))
assert sp.simplify(dirichlet/norm - rate/duration**2) == 0
print("PASS: singular row and minor identity, eight exact near-neutral Pell filters "
      "vanishing on an entire bad circle, eight physical variance addition tests, "
      "and exact transverse-width cancellation.")
