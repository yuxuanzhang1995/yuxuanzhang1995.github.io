"""Exact rational Farkas certificate construction/checking.

Checking uses no SDP solver. Coefficients are regenerated; float values in the
report are display only. The mathematical necessity of this relaxation is a
separate argument, not established by this program.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,time,json,pickle
import numpy as np
import gmpy2 as g
from moment3 import exact_system,enumerator_inequalities
from ppt3 import transfer

base=Path(__file__).resolve().parent
def mp(x):
    if isinstance(x,F):return g.mpq(x.numerator,x.denominator)
    return g.mpq(x)
def rounded(x):return F(round(float(x)*10**10),10**10)
def ldl(M):
    s=len(M);L=[[g.mpq(int(i==j)) for j in range(s)] for i in range(s)];ds=[]
    for i in range(s):
        d=M[i][i]-sum((L[i][k]**2*ds[k] for k in range(i)),g.mpq(0))
        if d<=0:raise ValueError(f'nonpositive exact LDL pivot {i}: {float(d)}')
        ds.append(d)
        for z in range(i+1,s):L[z][i]=(M[z][i]-sum((L[z][k]*L[i][k]*ds[k] for k in range(i)),g.mpq(0)))/d
    return ds

def data(n,clean=False):
    cache=base/f'data-n{n}-d4.pkl'
    if cache.exists() and not clean:return pickle.loads(cache.read_bytes())
    blocks,labels,variables,A,b=exact_system(n,4);G,EA=enumerator_inequalities(n,blocks,variables)
    return blocks,labels,variables,A,b,G,EA

def make(n):
    blocks,labels,variables,A,b,G,EA=data(n)
    num=json.loads((base/f'numerical-dual-ppt-n{n}.json').read_text())
    y=[F(0)]*len(A)
    for row,v in zip(num['rows'],num['y']):y[row]=rounded(v)/max(abs(x) for x in A[row])
    lam=[rounded(v)/max(abs(x) for x in row) for row,v in zip(G,num['lam'])]
    Q=[dict(block=q['block'],parity=q['parity'],indices=q['indices'],matrix=[[str(rounded(v)) for v in row] for row in q['matrix']]) for q in num['Q']]
    cert=dict(n=n,depth=4,K=2,y=[str(v) for v in y],lam=[str(v) for v in lam],Q=Q)
    # Never label it certified before exact verification.
    return cert

def check(cert,clean=False,mutation=None):
    t=time.time();n=cert['n'];assert cert['K']==2 and cert['depth']==4 and 9<=n<=18
    blocks,labels,variables,A,b,G,EA=data(n,clean)
    y=[mp(x) for x in cert['y']];lam=[mp(x) for x in cert['lam']]
    assert len(y)==len(A) and len(lam)==len(G)
    assert min(lam)>0
    rhs=sum((v*mp(bb) for v,bb in zip(y,b)),g.mpq(0))
    assert rhs<0,('nonnegative Farkas right hand side',rhs)
    Q=[np.full((len(bl['aa']),len(bl['aa'])),g.mpq(0),dtype=object) for bl in blocks]
    qpiv=[];seen=set()
    for q in cert['Q']:
        bi=q['block'];ii=q['indices'];key=(bi,q['parity']);assert key not in seen;seen.add(key)
        assert ii==[i for i,a in enumerate(blocks[bi]['aa']) if a%2==q['parity']]
        mat=[[mp(v) for v in row] for row in q['matrix']]
        assert all(mat[i][j]==mat[j][i] for i in range(len(ii)) for j in range(len(ii)))
        qpiv.extend(ldl(mat));Q[bi][np.ix_(ii,ii)]=mat
    expected={(bi,p) for bi,bl in enumerate(blocks) for p in [0,1] if any(a%2==p for a in bl['aa'])}
    assert seen==expected
    # Adjoint of partial time reversal in rationally scaled SU(2) blocks.
    D=[np.full(q.shape,g.mpq(0),dtype=object) for q in Q]
    for a in range(n+1):
        for bb in range(a,n+1):
            if (a-bb)%2:continue
            ss,T=transfer(blocks,a,bb)
            qq=[Q[bi][blocks[bi]['aa'].index(a),blocks[bi]['aa'].index(bb)] for bi in ss]
            for k,bi in enumerate(ss):
                val=sum((mp(T[i,k])*qq[i] for i in range(len(ss))),g.mpq(0))
                ia=blocks[bi]['aa'].index(a);ib=blocks[bi]['aa'].index(bb)
                D[bi][ia,ib]=D[bi][ib,ia]=val
    v=[]
    for ci in range(len(variables)):
        v.append(sum((mp(A[r,ci])*yy for r,yy in enumerate(y)),g.mpq(0))-
                 sum((mp(G[r,ci])*ll for r,ll in enumerate(lam)),g.mpq(0)))
    S=[np.full((len(bl['keep']),len(bl['keep'])),g.mpq(0),dtype=object) for bl in blocks]
    for (bi,u,w),val in zip(variables,v):S[bi][u,w]=S[bi][w,u]=val/(1 if u==w else 2)
    for bi,bl in enumerate(blocks):
        for W in bl['W']:
            W=np.array([[mp(v) for v in row] for row in W],dtype=object)
            S[bi]-=W.T@D[bi]@W/g.mpq(6)
    spiv=[]
    for bi,slack in enumerate(S):
        try:spiv.extend(ldl(slack.tolist()))
        except ValueError as e:raise ValueError(f'n={n}, seed block {bi}: {e}') from e
    return dict(n=n,passed=True,arithmetic='exact rational',farkas_rhs=str(rhs),scalar_multiplier_count=len(lam),
                PT_positive_LDL_pivots=len(qpiv),seed_slack_positive_LDL_pivots=len(spiv),
                min_PT_LDL_pivot_display=float(min(qpiv)),min_seed_slack_LDL_pivot_display=float(min(spiv)),
                elapsed_seconds=time.time()-t,
                scope='infeasibility of the specified necessary third-moment PPT relaxation, not independent mathematical review')

if __name__=='__main__':
    n=int(sys.argv[1]);verify='--verify' in sys.argv;clean='--clean' in sys.argv
    path=base/f'certificate-ppt-n{n}.json'
    cert=json.loads(path.read_text()) if verify else make(n)
    out=check(cert,clean=clean)
    if not verify:path.write_text(json.dumps(cert,indent=2)+'\n')
    (base/f'check-ppt-n{n}{"-clean" if clean else ""}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
