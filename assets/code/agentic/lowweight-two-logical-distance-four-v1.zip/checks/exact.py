"""Exact binary/phase checks and integer enumerator identities for the paper."""
import gzip,hashlib,itertools,json,math,re
from collections import Counter
from pathlib import Path

HERE=Path(__file__).parent
ROOT=HERE.parent
DATA=ROOT/'data'
OUT=ROOT/'build'
OUT.mkdir(exist_ok=True)

def reduce_basis(rows):
    b={}
    for x in rows:
        while x:
            j=(x&-x).bit_length()-1
            if j in b:x^=b[j]
            else:
                b[j]=x
                break
    return b

def nullspace(rows,width):
    a=list(rows);piv=[];r=0
    for j in range(width):
        match=next((i for i in range(r,len(a)) if (a[i]>>j)&1),None)
        if match is None:continue
        a[r],a[match]=a[match],a[r]
        for i in range(len(a)):
            if i!=r and (a[i]>>j)&1:a[i]^=a[r]
        piv.append(j);r+=1
    out=[]
    for f in range(width):
        if f in piv:continue
        x=1<<f
        for i,p in enumerate(piv):
            if (a[i]>>f)&1:x|=1<<p
        assert all((x&row).bit_count()%2==0 for row in rows)
        out.append(x)
    return out

def span(rows):
    out=[0]
    for r in rows:out += [x^r for x in out]
    return set(out)

def wt(v,n):return ((v&((1<<n)-1))|(v>>n)).bit_count()

def parse(word):
    n=len(word)
    return sum((int(c in 'XY')<<i)|(int(c in 'ZY')<<(i+n)) for i,c in enumerate(word))

def symp(a,b,n):
    mask=(1<<n)-1
    return (((a&mask)&(b>>n)).bit_count()+((b&mask)&(a>>n)).bit_count())%2

def poly_mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return c

def kernel(n,i):
    p=[1]
    for _ in range(i):p=poly_mul(p,[1,-1])
    for _ in range(n-i):p=poly_mul(p,[1,3])
    return p

def identities():
    out={}
    for n in (10,11):
        size=2**(n-2);res=[]
        for i in range(n+1):
            K=kernel(n,i);delta=lambda j:int(i==j)
            L=-size*int(1<=i<=5)
            if n==11:
                R=5120*delta(0)-19-9*(K[1]-size*delta(1))-3*(K[2]-size*delta(2))-(K[3]-size*delta(3))
                R+=(-1)**i*(14+4*K[1]+2*K[2])+1024*delta(3)
            else:
                R=5120*delta(0)-28-12*(K[1]-size*delta(1))-4*(K[2]-size*delta(2))-(K[3]-size*delta(3))
                R+=(-1)**i*(8+4*K[1])+size*(delta(1)+3*delta(2)+3*delta(3)+delta(4))
            res.append(L-R)
        assert not any(res)
        out[n]={'integer_residuals':res,'cleared_denominator':size}
    return out

def code_check(words):
    n=len(words[0]);g=[parse(w) for w in words];mask=(1<<n)-1
    commutes=all(not symp(a,b,n) for a,b in itertools.combinations(g,2))
    rank=len(reduce_basis(g));S=span(g)
    dualgens=nullspace([((x&mask)<<n)|(x>>n) for x in g],2*n)
    D=span(dualgens)
    A=[sum(wt(x,n)==i for x in S) for i in range(n+1)]
    B=[sum(wt(x,n)==i for x in D) for i in range(n+1)]
    assert all(len(S)*B[j]==sum(kernel(n,i)[j]*A[i] for i in range(n+1)) for j in range(n+1))
    # Preserve true Pauli phases rather than simply assuming positive products.
    phases={0:0}
    phase_consistent=True
    for row,word in zip(g,words):
        phase=word.count('Y')%4
        old=list(phases.items())
        for x,p in old:
            y=x^row;v=(p+phase+2*((x>>n)&(row&mask)).bit_count())%4
            if y in phases and phases[y]!=v:phase_consistent=False
            phases[y]=v
    logical=[x for x in D if x not in S]
    d=min((wt(x,n) for x in logical),default=None)
    low_ranks=[len(reduce_basis([x for x in S if wt(x,n)<=w])) for w in range(n+1)]
    return {'n':n,'rank':rank,'k':n-rank,'commutes':commutes,'minus_identity_absent':phase_consistent and phases[0]==0,
            'distance':d,'enumerator':A,'dual_enumerator':B,'logical_weight_four':sum(wt(x,n)==4 for x in logical),
            'optimal_basis_weight':next((w for w,r in enumerate(low_ranks) if r==rank),None),'low_weight_ranks':low_ranks,
            'displayed_max_weight':max(wt(x,n) for x in g),'dual_space_size':len(D),'group_size':len(S)}


def extract_source():
    archive=DATA/'thebigselfdualfile.txt.gz'
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest=='75af3203e86e6ac5726795c84bdacd32f1d13d7c0f1f84b8e3a664724b8d5855'
    counts=Counter();dist=Counter();mass=Counter()
    outputs={n:(OUT/f'parents-n{n}.g6').open('w') for n in (11,12)}
    try:
        with gzip.open(archive,'rt') as stream:
            for line in stream:
                a=line.strip().split('\t');assert len(a)==9
                n=int(a[0]);counts[n]+=1
                if n not in outputs:continue
                dist[n,int(a[1])]+=1;den=int(a[5]);num=6**n*math.factorial(n)
                assert num%den==0;mass[n]+=num//den
                outputs[n].write(a[8]+'\n')
    finally:
        for f in outputs.values():f.close()
    assert counts[11]==45144 and counts[12]==1323363
    for n in (11,12):assert mass[n]==math.prod(2**j+1 for j in range(1,n+1))
    return {'archive_sha256':digest,'counts':{n:counts[n] for n in (11,12)},
            'orbit_mass':{n:str(mass[n]) for n in (11,12)},
            'distance_histogram':{n:{d:dist[n,d] for d in range(1,7) if dist[n,d]} for n in (11,12)}}

def main():
    codes=json.loads((DATA/'witnesses.json').read_text());positive={}
    for key,words in codes.items():
        n=int(key);result=code_check(words)
        assert len(words)==n-2 and result['rank']==n-2
        assert result['commutes'] and result['minus_identity_absent']
        assert result['distance']==4 and result['optimal_basis_weight']==5
        positive[key]=result
    padded=code_check([w+'I' for w in codes['11']]+['I'*11+'Z'])
    assert padded['enumerator'][1]==1 and padded['distance']==4 and padded['k']==2
    invalid=code_check(['I'*j+'Z'+'I'*(10-j) for j in range(9)])
    assert invalid['distance']==1 and invalid['k']==2
    dropped=code_check(codes['11'][:-1]);assert dropped['rank']==8 and dropped['k']==3
    public={}
    for name in ('12-2-4.json','12-2-4-b.json'):
        obj=json.loads((DATA/name).read_text());words=[]
        for label,checks in obj['checks'].items():
            for sites in checks:words.append(''.join(label if j in sites else 'I' for j in range(obj['n'])))
        public[name]=code_check(words);assert public[name]['optimal_basis_weight']==6
    output={'identity_checks':identities(),'witnesses':positive,'degenerate_control':padded,
            'invalid_distance_control':{'actual_distance':invalid['distance'],'rejected_as_distance_four':True},
            'dropped_generator_control':{'actual_k':dropped['k'],'rejected_as_k_two':True},
            'public_code_comparisons':public,'source':extract_source()}
    (OUT/'exact-checks.json').write_text(json.dumps(output,indent=2)+'\n')
    print('Exact witnesses, full duals, shadow identities, controls and source integrity: PASS')
if __name__=='__main__':main()
