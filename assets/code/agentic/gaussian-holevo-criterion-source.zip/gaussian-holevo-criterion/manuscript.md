---
title: "A finite certificate for Gaussian attainment of the Holevo bound"
author: "Yuxuan Zhang"
date: "24 September 2026"
geometry: margin=1in
fontsize: 11pt
header-includes:
  - \usepackage{amsmath,amssymb}
  - \usepackage{microtype}
  - \allowdisplaybreaks
---

\begin{center}\small
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland\\
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA
\end{center}

**Working manuscript.** This complete proof candidate passed two separate internal AI reviews. External expert confirmation and literature priority remain unverified. The exact computations in the accompanying archive check examples; the general theorem rests on the written proof.

## Abstract

We give a finite necessary-and-sufficient certificate for a single-copy Gaussian measurement to attain the Holevo bound of a faithful Gaussian statistical model. The certificate depends only on local first and second moments, their first derivatives, and a positive weight matrix. It combines a compact parametrization of measurement precision with the pulled-back classical score and a dual certificate for the Holevo semidefinite program. Feasibility supplies an attaining measurement using finitely many Gaussian ancillary modes, a Gaussian unitary, and homodyne detection. Singular precision matrices are included, and the Gaussian infimum is always attained under the stated assumptions. The criterion covers arbitrary finite numbers of modes and parameters. It is implicit semialgebraic feasibility, with no claim of efficient solution or a closed-form geometric classification.

## 1. The question and the contribution

The Holevo bound quantifies the effect of measurement incompatibility in local multiparameter estimation. Computing that bound does not by itself tell us whether a restricted measurement can attain it. For Gaussian state models, the restriction to Gaussian measurements is natural: prepare independent Gaussian ancillary modes, apply a Gaussian unitary, measure commuting quadratures by homodyne detection, and process the outcomes classically.

Chang, Genoni, and Albarelli [2] reduced the Holevo optimization exactly to a finite space of linear and quadratic observables and gave a semidefinite program (SDP). Their result is an input here. Gaussian attainability for displacement-only models is also established [3]. The general structure and finite dilation of Gaussian observables have been studied by Holevo [4]. We do not claim these ingredients as new.

The question considered here is QIQCOP problem `op_8f1853475db7ea27` [1]: characterize equality between the optimal Gaussian-measurement cost and the Holevo bound, using only local moment data. The proposed answer is an explicit feasibility system. It contains no unknown optimal value. Its variables specify a physical measurement, its efficient local estimator, and a dual witness that proves global Holevo optimality. Covariance derivatives and singular homodyne boundaries enter the same system as displacement derivatives.

The result should be read at that level of generality and specificity. It resolves the literal equality question through an algebraic certificate. It does not supply a short geometric classification or a polynomial-time procedure for finding the certificate. Whether this formulation is new relative to all prior literature remains an open verification question.

## 2. Local data and the certificate

Fix a point of a smooth faithful $n$-mode Gaussian family $\rho_\theta$, with $p$ real parameters. Let $k=2n$, set $r=R-d$, and use

$$
[R_a,R_b]=i\Omega_{ab},\qquad
\Omega=\bigoplus_{a=1}^n\begin{pmatrix}0&1\\-1&0\end{pmatrix}.
$$

The covariance is $V_{ab}=\operatorname{Tr}(\rho\{r_a,r_b\})/2$. All data below are evaluated at the fixed point:

$$
m_j=\partial_jd,\qquad D_j=\partial_jV,\qquad
\Gamma=V+\frac{i}{2}\Omega. \tag{1}
$$

Assume nonsingular symmetric-logarithmic-derivative (SLD) Fisher information and a real symmetric weight $W\succ0$. Define

$$
C_G=\inf_{M\ \mathrm{Gaussian}}\operatorname{tr}(WF_M^{-1}), \tag{2}
$$

assigning infinite cost when $F_M$ is singular. Measurement settings, including the centering and normalization of outcomes, are held fixed when differentiating. Classical processing is parameter independent.

For a tuple of Hermitian, centered, locally unbiased observables $X_j$, write

$$
Z_{j\ell}=\operatorname{Tr}(\rho X_jX_\ell),\qquad
\operatorname{Tr}((\partial_\ell\rho)X_j)=\delta_{j\ell}.
$$

The Holevo bound is the infimum over such finite-second-moment tuples of

$$
\Phi_W(Z)=\operatorname{tr}(W\operatorname{Re}Z)
 +\|\sqrt W\operatorname{Im}Z\sqrt W\|_1. \tag{3}
$$

Real and imaginary parts are entrywise. A transpose is denoted by $\mathsf T$ and an adjoint by $\dagger$.

Choose a trace-orthonormal real basis $B_\alpha$ of the symmetric $k\times k$ matrices. Set $h=k+k(k+1)/2$, and collect the following centered observables in a vector $T$:

$$
T_a=r_a,\qquad
T_{k+\alpha}=r^{\mathsf T}B_\alpha r-\operatorname{tr}(B_\alpha V).
$$

Define a Hermitian matrix $S\in\mathbb C^{h\times h}$ and a real matrix $J\in\mathbb R^{h\times p}$ by

$$
\begin{aligned}
S_{ab}&=\Gamma_{ab}, & S_{a,k+\alpha}&=S_{k+\alpha,a}=0,\\
S_{k+\alpha,k+\beta}&=2\operatorname{tr}(B_\alpha\Gamma B_\beta\Gamma^{\mathsf T}),\\
J_{aj}&=(m_j)_a, & J_{k+\alpha,j}&=\operatorname{tr}(B_\alpha D_j).
\end{aligned} \tag{4}
$$

The transpose $\Gamma^{\mathsf T}$ in (4) is intentional; replacing it by an adjoint changes the matrix. Under the assumptions, $S\succ0$ and $J$ has full column rank. Thus the real orthogonal projector

$$
P=I_h-J(J^{\mathsf T}J)^{-1}J^{\mathsf T} \tag{5}
$$

is well defined.

The unknowns in the certificate are real symmetric matrices $G\in\mathbb R^{k\times k}$ and $E\in\mathbb R^{p\times p}$, and a Hermitian matrix $Y\in\mathbb C^{p\times p}$. From $G$ form

$$
\begin{aligned}
F_{j\ell}(G)&=m_j^{\mathsf T}Gm_\ell
   +\frac12\operatorname{tr}(GD_jGD_\ell),\\
L_{aj}(G)&=(Gm_j)_a,\\
L_{k+\alpha,j}(G)&=\frac12\operatorname{tr}(B_\alpha GD_jG),\\
A&=L(G)E,\qquad Q=E-A^{\mathsf T}SA.
\end{aligned} \tag{6}
$$

**Theorem 1 (Gaussian equality certificate).** Under the preceding assumptions, $C_G=C_H$ if and only if the following finite system is feasible:

$$
\begin{aligned}
G&\succeq0, & \Gamma^{-1}-G&\succeq0,\\
F(G)E&=I_p, & Q&\succeq0,\\
Y&\succeq0, & \operatorname{Re}Y&=W,\\
YQ&=0, & P\operatorname{Re}(SAY)&=0.
\end{aligned} \tag{7}
$$

All complex matrix inequalities in (7) are Hermitian positive-semidefinite inequalities. For a feasible triple, the common value is $\operatorname{tr}(WE)$. An attaining Gaussian measurement has commuting, locally centered output

$$
y=Hr+z,\qquad H=G^{1/2}, \tag{8}
$$

where the independent Gaussian ancillary quadratures $z$ have covariance and commutator

$$
N=I_k-HVH^{\mathsf T},\qquad
[z_a,z_b]=-i(H\Omega H^{\mathsf T})_{ab}. \tag{9}
$$

These ancillary quadratures admit an exact realization with finitely many Gaussian modes, including when $G$ is singular. Moreover, the infimum defining $C_G$ is always attained by a measurement in the stated class, whether or not $C_G=C_H$.

The roles of the conditions are distinct. The first line makes $G$ a physically realizable measurement precision. The second line makes $E$ the inverse Fisher matrix and controls the noise lost when an estimator is pulled back to the system. The last two lines supply a dual Holevo witness. They certify global optimality, rather than only a stationary point of the Gaussian cost.

## 3. The finite polynomial space

Gaussian Wick contraction gives

$$
S_{uv}=\operatorname{Tr}(\rho T_uT_v),
$$

with the entries in (4). Centered odd moments vanish, and the two crossed contractions in the quadratic block give the factor of two. Faithfulness implies $\Gamma\succ0$. It also makes $S$ strictly positive: a zero-norm complex linear combination of the $T_u$ would vanish on a faithful state and hence be the zero polynomial operator. Centered symmetric quadratic and linear polynomials are linearly independent.

The matrix $J$ records the derivatives of the expectations of the fixed observables $T_u$. The Gaussian SLDs lie in their real span, with coefficient matrix $(\operatorname{Re}S)^{-1}J$. Their Fisher matrix is therefore $J^{\mathsf T}(\operatorname{Re}S)^{-1}J$. Its nonsingularity implies that $J$ has full column rank.

We use the exact invariant-space reduction of [2, Derivations and Eqs. (36), (72)]. The relevant mechanism can be seen in Williamson coordinates. A faithful Gaussian state is a product of thermal states, with density proportional to $\exp(-\sum_a\epsilon_a a_a^\dagger a_a)$ and $\epsilon_a>0$. Modular action preserves the linear and quadratic monomials. The bounded real commutation operator $\mathcal D$ defined by

$$
\operatorname{Re}\operatorname{Tr}(\rho U\mathcal D(V_0))
 =\operatorname{Im}\operatorname{Tr}(\rho UV_0)
$$

therefore preserves the real Hermitian span of the $T_u$. Its coefficients on a monomial and its adjoint are hyperbolic tangents of half the corresponding modular frequency.

Project a locally unbiased tuple onto this span using the real SLD inner product. Since the SLDs are in the span, projection preserves the derivative constraints. Invariance under $\mathcal D$ makes the residual orthogonal for the imaginary inner product as well. The complex Gram matrix consequently splits into the projected Gram matrix plus a positive-semidefinite residual. The representation of $\Phi_W$ proved in Section 6 shows that adding this residual cannot lower the objective.

It follows that the unrestricted Holevo optimization is exactly the optimization over real coefficient matrices $A\in\mathbb R^{h\times p}$ satisfying

$$
J^{\mathsf T}A=I_p,\qquad Z=A^{\mathsf T}SA. \tag{10}
$$

The transpose convention in (10) follows from $Z_{j\ell}=\operatorname{Tr}(\rho X_jX_\ell)$. This fixes the imaginary signs throughout the certificate.

## 4. Compact measurement precision and exact realization

Before classical processing, a Gaussian measurement has output mean $Kd+c$ and covariance

$$
C=KVK^{\mathsf T}+N_0,\qquad
N_0-\frac{i}{2}K\Omega K^{\mathsf T}\succeq0. \tag{11}
$$

Indeed, its commuting measured quadratures are real linear combinations of the system quadratures and independent ancillary quadratures. The ancillary uncertainty relation gives (11).

Remove deterministic redundant outputs. Their support is parameter independent: $V$ is real positive definite, so a zero-variance output direction has zero system coefficient and zero ancillary variance. The remaining $C$ is positive definite. Normalize at the fixed local point by setting $H_0=C^{-1/2}K$. Equation (11) becomes

$$
I-H_0\Gamma H_0^{\mathsf T}\succeq0.
$$

The two Schur complements of the block matrix with diagonal blocks $\Gamma^{-1}$ and $I$ give

$$
\begin{aligned}
G&=H_0^{\mathsf T}H_0\in\mathcal K,\\
\mathcal K&=\{G\in\mathbb R^{k\times k}:G=G^{\mathsf T},\ 0\preceq G\preceq\Gamma^{-1}\}.
\end{aligned}
\tag{12}
$$

Differentiating the Gaussian distribution while keeping this normalization fixed gives exactly $F(G)$ in (6). A parameter-independent stochastic processing of the outcomes cannot increase Fisher information: its score is the conditional expectation of the original score. Hence such processing cannot improve the cost for $W\succ0$.

Conversely, let $G\in\mathcal K$, set $H=G^{1/2}$, and use $N$ from (9). The same Schur-complement argument gives

$$
N+\frac{i}{2}C_z\succeq0,\qquad C_z=-H\Omega H^{\mathsf T}. \tag{13}
$$

We give the finite realization explicitly, so that the boundary of (12) needs no infinite squeezing. Positivity in (13) implies $\ker N\subseteq\ker C_z$. To see this, a real vector in $\ker N$ has zero quadratic form in the positive matrix in (13), and must belong to its kernel.

On the support of $N$, whiten the covariance to $I$, and put the resulting real skew-symmetric commutator matrix in orthogonal block form. Each nonzero block is $c\Omega_2$, with

$$
\Omega_2=\begin{pmatrix}0&1\\-1&0\end{pmatrix},\qquad |c|\le2.
$$

Realize this block using one ancillary Gaussian mode of covariance $I_2/|c|$, multiplying its quadratures by $\sqrt{|c|}$ and choosing the orientation for the sign of $c$. This mode is physical because $1/|c|\ge1/2$. A zero commutator block consists of commuting unit-variance coordinates; each can be supplied by a scaled position quadrature of a separate vacuum mode. Zero-variance coordinates are zero operators. Undoing the transformations constructs $z$ with precisely the covariance and commutator in (9). This is a concrete use of the finite Gaussian-observable structure in [4].

The rows defining $y=Hr+z$ commute, and they are independent because the output covariance is $I_k$. Every independent isotropic row system in a finite symplectic space extends to a symplectic basis. A Gaussian unitary followed by homodyne detection therefore measures these outputs exactly. Its Fisher matrix is $F(G)$.

Finally, $\mathcal K$ is compact. It contains $G=\varepsilon I_k$ for sufficiently small $\varepsilon>0$. At this point, for a real parameter vector $u$,

$$
u^{\mathsf T}F(G)u
 =\varepsilon\Big\|\sum_j u_jm_j\Big\|^2
  +\frac{\varepsilon^2}{2}\operatorname{tr}\Big[\Big(\sum_j u_jD_j\Big)^2\Big].
$$

Full column rank of $J$ makes this strictly positive for $u\ne0$. Thus finite Gaussian cost is possible. The function $F$ is continuous on $\mathcal K$, and

$$
\operatorname{tr}(WF^{-1})\ge
\frac{\lambda_{\min}(W)}{\lambda_{\min}(F)}. \tag{14}
$$

A bounded-cost sequence cannot approach singular $F$. Compactness now gives a minimizing precision with nonsingular Fisher matrix. The finite realization above proves attainment of $C_G$, including singular-$G$ boundaries. Allowing limiting measurement sequences does not enlarge the set of achievable optimal costs.

## 5. Pulling the efficient estimator back to the system

For the normalized measurement in (8), the local output covariance is $I_k$. Its classical score is

$$
s_j(y)=(Hm_j)^{\mathsf T}y+\frac12\left[
y^{\mathsf T}HD_jH^{\mathsf T}y-\operatorname{tr}(HD_jH^{\mathsf T})\right]. \tag{15}
$$

Its covariance is $F(G)$. Take the ancillary expectation of (15). The ancillary covariance cancels the constant term left after centering the system quadratic, and the system first moment is

$$
\sum_u T_u L_{uj}(G),
$$

with $L$ exactly as in (6). If $F(G)$ is invertible, the efficient local estimator $t=Es$, where $E=F(G)^{-1}$, has covariance $E$. It is locally unbiased and its pulled-back system observables have coefficient matrix $A=L(G)E$. Direct substitution in (4) and (6) gives

$$
J^{\mathsf T}L(G)=F(G),\qquad J^{\mathsf T}A=I_p. \tag{16}
$$

The pullback from classical functions of the outcomes to system operators is a unital completely positive map. Its matrix Schwarz inequality yields

$$
Q=E-A^{\mathsf T}SA\succeq0. \tag{17}
$$

One can also obtain (17) as the Gram matrix of the residual estimator in the commuting measurement dilation. Thus $Q$ measures what is lost when the efficient classical estimator is represented by system observables. These statements use a fixed local estimator and fixed measurement settings; no derivative of an optimized setting enters.

## 6. Holevo duality and complementarity

For every Hermitian $Z$, the functional in (3) has the representation

$$
\begin{aligned}
\Phi_W(Z)
 &=\min_{U=U^{\mathsf T}\in\mathbb R^{p\times p},\ U\succeq Z}\operatorname{tr}(WU)\\
 &=\max_{Y\succeq0,\ \operatorname{Re}Y=W}\operatorname{tr}(YZ).
\end{aligned} \tag{18}
$$

For the first equality, subtract $\operatorname{Re}Z$ and conjugate by $\sqrt W$. It remains to minimize $\operatorname{tr}U_0$ over real symmetric $U_0\succeq iB$, where $B$ is real skew symmetric. Complex conjugation also gives $U_0\succeq-iB$. Taking traces against the positive and negative spectral projectors of $iB$, and against its zero spectral projector, gives $\operatorname{tr}U_0\ge\|iB\|_1$. Equality holds for the real symmetric matrix $U_0=|iB|$. The second equality is SDP duality; a sufficiently large real multiple of the identity is strictly primal feasible. In particular, (18) proves monotonicity under positive-semidefinite additions to $Z$.

Together with Section 3, (18) gives the finite Holevo SDP

$$
\begin{aligned}
\text{minimize }&\operatorname{tr}(WU)\\
\text{subject to }&J^{\mathsf T}A=I_p,\qquad
M(U,A)=\begin{pmatrix}U&A^{\mathsf T}\\A&S^{-1}\end{pmatrix}\succeq0,
\end{aligned} \tag{19}
$$

where $U$ and $A$ are real and $U$ is symmetric. This is the known polynomial-space SDP [2], written in a linearly independent basis and in our Gram convention.

The choice $A_0=J(J^{\mathsf T}J)^{-1}$ and $U=tI_p$ with $t>\lambda_{\max}(A_0^{\mathsf T}SA_0)$ is strictly feasible. The objective is bounded below by zero, so finite-dimensional SDP strong duality gives an attained dual optimum. A primal optimum exists as well. A bounded objective bounds $U\succeq0$ because $W\succ0$, while the Schur complement $U\succeq A^{\mathsf T}SA$ bounds $A$ because $\operatorname{Re}S\succ0$. A bounded minimizing sequence has a convergent feasible subsequence.

Let $D\succeq0$ be the Hermitian block multiplier for $M$. Stationarity in real $U$ and in real feasible variations of $A$ gives

$$
\operatorname{Re}D_{11}=W,\qquad P\operatorname{Re}D_{21}=0. \tag{20}
$$

Complementarity is $DM=0$. At $U=E$, set $Y=D_{11}$. Its block equations imply

$$
\begin{aligned}
D_{12}&=-YA^{\mathsf T}S,&D_{21}&=-SAY,\\
D_{22}&=SAYA^{\mathsf T}S,&Y(E-A^{\mathsf T}SA)&=0.
\end{aligned} \tag{21}
$$

Equations (20)--(21) are exactly the last two lines of (7). Conversely, the multiplier with these blocks is positive semidefinite since

$$
D=\begin{pmatrix}I_p\\-SA\end{pmatrix}
Y\begin{pmatrix}I_p&-A^{\mathsf T}S\end{pmatrix}. \tag{22}
$$

This calculation establishes the signs in (7) and explains why dual attainment is available. It is not an assumption about an optimizer at a singular boundary.

## 7. Proof of Theorem 1

Suppose first that $C_G=C_H$. Section 4 supplies an optimal Gaussian precision $G$ with $F(G)\succ0$. Section 5 supplies $E=F(G)^{-1}$ and $A=L(G)E$, making $(E,A)$ feasible for (19) with objective $C_G=C_H$. It is consequently a Holevo optimum. The attained dual multiplier of Section 6 supplies $Y$ satisfying all of (7).

Conversely, suppose (7) has a solution. The formula in (6) makes $F(G)$ positive semidefinite. The equation $F(G)E=I_p$ makes it invertible, hence $F(G)\succ0$ and $E=F(G)^{-1}$. Equation (16) gives $J^{\mathsf T}A=I_p$.

Let $A'$ be any real coefficient matrix with $J^{\mathsf T}A'=I_p$, and write $\Delta=A'-A$. Then $P\Delta=\Delta$, and

$$
\begin{aligned}
&\operatorname{tr}(Y{A'}^{\mathsf T}SA')-\operatorname{tr}(YA^{\mathsf T}SA)\\
&\quad=2\operatorname{tr}\!\left[\Delta^{\mathsf T}\operatorname{Re}(SAY)\right]
       +\operatorname{tr}(Y\Delta^{\mathsf T}S\Delta)\ \ge\ 0.
\end{aligned} \tag{23}
$$

The first term vanishes by (7), while the second is nonnegative because $S,Y\succeq0$. Also, $YQ=0$ gives

$$
\operatorname{tr}(YA^{\mathsf T}SA)=\operatorname{tr}(YE)=\operatorname{tr}(WE). \tag{24}
$$

The dual expression in (18) shows that every feasible Holevo tuple has objective at least $\operatorname{tr}(WE)$. On the other hand, $E\succeq A^{\mathsf T}SA$ makes $E$ feasible in the primal expression in (18), giving the reverse inequality. Thus $C_H=\operatorname{tr}(WE)$. The exact Gaussian realization of $G$ has the same cost, proving $C_G=C_H$ and the measurement assertion. The independent attainment claim was proved in Section 4.

Finally, write $Y=Y_R+iY_I$, with $Y_R$ symmetric and $Y_I$ skew symmetric. A Hermitian inequality $U+iV\succeq0$ is equivalent to the real block inequality

$$
\begin{pmatrix}U&-V\\V&U\end{pmatrix}\succeq0.
$$

After this replacement, (7) consists of finitely many polynomial equations and positive-semidefinite inequalities in the entries of $G,E,Y_R,Y_I$. All coefficients are fixed by the local data. This establishes the claimed semialgebraic character. For exact algebraic input data, it is an exact real-algebraic feasibility question; approximate experimental data require a separate treatment of uncertainty. No complexity bound is asserted.

## 8. Two exact examples

The accompanying `check.py` verifies the following instances using symbolic arithmetic. Both use one mode, $V=I_2$, and the trace-orthonormal basis

$$
B_1=\begin{pmatrix}1&0\\0&0\end{pmatrix},\quad
B_2=\begin{pmatrix}0&0\\0&1\end{pmatrix},\quad
B_3=\frac1{\sqrt2}\begin{pmatrix}0&1\\1&0\end{pmatrix}.
$$

**Displacement example.** Set $p=2$, $m_1=(1,0)^{\mathsf T}$, $m_2=(0,1)^{\mathsf T}$, $D_1=D_2=0$, and $W=I_2$. A certificate is

$$
G=\frac23 I_2,\qquad E=\frac32 I_2,\qquad Y=I_2+i\Omega_2.
$$

The conditions hold exactly and give $C_G=C_H=3$. This is a consistency example of the established displacement attainability result [3].

**Singular-precision example with mixed derivatives.** Set $p=1$, $m_1=(1,0)^{\mathsf T}$, $D_1=\operatorname{diag}(1,-1/4)$, and $W=1$. Take

$$
G=\operatorname{diag}(1,0),\qquad E=\frac23,\qquad Y=1.
$$

Here $F=3/2$, and the certificate gives $C_G=C_H=2/3$. The informative output is noiseless $q$-homodyne; the second normalized output in (8) is independent ancillary noise and can be discarded. This checks that singular precision need not mean singular Fisher information. The specified local data are realized, for example, by $d_\theta=(\theta,0)^{\mathsf T}$ and $V_\theta=I_2+\theta\operatorname{diag}(1,-1/4)$ for sufficiently small $|\theta|$.

## 9. Verification, scope, and provenance

The round-42 proof passed an initial internal mathematical review and a separate frozen review. Both found no gap in the stated all-mode, all-parameter certificate. The reviews explicitly checked the compact precision domain, singular-boundary realization, fixed-setting score derivatives, dual signs, attainment, and the distinction between an equality certificate and a comparison of unknown optimal values. They are AI reviews, not external refereeing or formal proof-assistant verification.

The frozen symbolic checker asserts positive-semidefinite eigenvalue conditions, exact zero residuals, and the two costs in Section 8. It was rerun twice in isolated processes for this release. Supplementary exact and floating-point controls are included with their recorded outputs. Those computations can reveal implementation and transcription errors in the cases they cover. They cannot establish the universal quantifiers in Theorem 1.

The archive retains the unchanged round-42 claim and proof, the original problem statement, both reviews, the checker and expected output, and the source of this manuscript. The prior public note on restricted one-mode classifications was withdrawn as incomplete for the original question. This manuscript concerns the subsequent general certificate; it does not reinstate that partial submission.

The theorem assumes faithful Gaussian states, nonsingular SLD Fisher information, strictly positive weights, and the local measurement class defined in Section 2. Rank-deficient states, singular weights, efficiency guarantees, and simplified closed-form classifications are outside the claim. The elementary displacement example and the background SDP and Gaussian-dilation results are attributed to the literature. A targeted source comparison has not established publication priority for the combined certificate.

**AI assistance and authorship.** The author is Yuxuan Zhang. The proof candidate, internal reviews, code, and manuscript preparation used the project's AI research workflow. K-Dense's scientific-writing skill [5], at local revision `330c8e764435`, helped organize the evidence and exposition. This is an author-hosted working manuscript awaiting independent specialist review, not a journal submission or a claim of QIQCOP acceptance.

\clearpage

## References

1. *Gaussian-measurement equality with the Holevo bound*, Quantum Information and Quantum Computation Open Problem Zoo, problem `op_8f1853475db7ea27`. <https://qiqc-op.com/problem/op_8f1853475db7ea27/>. Statement accessed 24 September 2026.
2. S. Chang, M. G. Genoni, and F. Albarelli, *Efficiently evaluating Holevo, RLD and SLD Cramér-Rao bounds for multiparameter quantum estimation with Gaussian states*, Communications Physics **9**, 126 (2026). <https://doi.org/10.1038/s42005-026-02550-6>. Invariant polynomial space in Derivations; finite SDP in Eqs. (36) and (72).
3. M. Bradshaw, P. K. Lam, and S. M. Assad, *Ultimate precision of joint quadrature parameter estimation with a Gaussian probe*, Physical Review A **97**, 012106 (2018). <https://doi.org/10.1103/PhysRevA.97.012106>; <https://arxiv.org/abs/1710.04817>. Sec. III.B and Appendix C.
4. A. S. Holevo, *The structure of general quantum Gaussian observable*, Proceedings of the Steklov Institute of Mathematics **313**, 70--77 (2021). <https://doi.org/10.1134/S0081543821020085>; <https://arxiv.org/abs/2007.02340>. Gaussian observable structure and finite Naimark dilation.
5. T. Kassis, V. Agarwal, Y. He, D. Patel, and A. M. Brueckner, *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents* (2026). <https://doi.org/10.48550/arXiv.2609.00065>. Bibliographic record checked 24 September 2026; current arXiv revision v2.
