"""Verify the eleven-vector Schur Gram and effective tail estimates."""

from fractions import Fraction
import sympy as sp


def gram(t):
    pair = t*(5*t-1)/4
    base = sp.Matrix(6, 6, lambda i, j: 1 if i == j == 0 else
                     t if min(i, j) == 0 or i == j else pair)
    e = sp.eye(6)
    unitaries = [2*e[:, j]-e[:, 0] for j in range(1, 6)]
    columns = sp.Matrix.hstack(e[:, 0], *unitaries,
                              *((u+sp.I*e[:, 0])/sp.sqrt(2) for u in unitaries))
    return base, (columns.H*base*columns).T.applyfunc(sp.simplify)


for t in [sp.Rational(1, 2), sp.Rational(17, 32), sp.Rational(9, 16),
          sp.Rational(1, 2)+sp.sqrt(2)/64]:
    base, b = gram(t)
    # All-ones component is fixed by the scalar sum of the five projections.
    kernel = sp.Matrix([-5*t]+[1]*5)
    assert (base*kernel).applyfunc(sp.simplify) == sp.zeros(6, 1)
    for j in range(2, 6):
        d = sp.eye(6)[:, 1]-sp.eye(6)[:, j]
        assert (d.H*base*d)[0].simplify().is_positive
    assert b == b.H and list(b.diagonal()) == [1]*11 and b.rank() == 5
    assert sp.simplify(b[6, 0]-(2*t-1+sp.I)/sp.sqrt(2)) == 0
    assert b[0, 6] != b[6, 0]  # catches an unnoticed transpose


def encode(events):
    value = Fraction(1, 2)
    position = 4
    for j, stage in enumerate(events, 1):
        position = max(position+j+1, stage+4)
        value += Fraction(1, 2**(position+4))
    return value


for events in [list(range(80)), [5, 18, 62, 74], [0, 41, 42, 60]]:
    total = encode(events)
    assert Fraction(1, 2) < total < Fraction(9, 16)
    for stage in range(81):
        prefix = encode([e for e in events if e <= stage])
        assert 0 <= total-prefix < Fraction(1, 2**(stage+7))
print("PASS: four exact 11-dimensional correlation Grams including an "
      "irrational parameter, complex-orientation mutation and 243 rational tail checks.")
