QAOA energy bounds at large interaction order
Yuxuan Zhang — EPFL; Princeton
Version 1, 26 October 2026

STATUS: proof candidate, sequentially audited. No independent review of the
complete manuscript, external peer review, formal certificate, or catalog
acceptance is claimed.

Build: run latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
inside manuscript/. A current LaTeX installation with the standard listed
packages suffices. The PDF is included for version identification.

review.json pins the manuscript, PDF, original target and research records.
research-records/ preserves the original relative paths and historical
qualifiers. Older records are provenance and may be superseded by the
manuscript and the corrections listed in review.json; they are not
additional independent reviews.

Claim: Large-q fixed-depth dense energy obstruction, including odd q; sparse logarithmic-depth refinement.
Limits: q=3; instance-dependent angles; dense logarithmic-depth transfer; general quantum hardness.

Primary sources are linked in the manuscript and review.json. No third-party
source-paper copies are redistributed in this archive.
