# Exact-QFI cost from localization in the sector module

On a finite-feasible target with independent Kraus support \(S\), form the real Laurent module \(M_0=\ker L\) of the homogeneous *sector equations only*, on ambient tuples \(f=(p,C)\) represented as \(\operatorname{diag}(p,C)\). A nonnegative tuple means \(p_n\ge0,C_n\succeq0\) coefficientwise. Keep the target condition \(C(1)=T p(1)\) outside this module. This detail allows different localized branches to represent different channels on \(S\), while their weighted mixture still implements the specified target exactly.

**Result.** If \(M_0\) is a direct summand of the ambient real Laurent module, the arbitrary-support exact QFI infimum has computable finite upper and lower brackets with width \(O(1/L)\) and no channel error. This includes every finite-feasible one-generator system, at arbitrary dimension and Choi support. A second sufficient condition, in any number of energy variables, is that the matrix of Laurent generators of \(M_0\) has its generic column rank everywhere on the unit character torus. This gives arbitrarily tight finite brackets, with an effective relationship between the requested precision and the energy box. A fixed physical sector witness and the exact energy presentation are input, with the algebraic encoding of F22 for effective coefficient operations. The result allows noninvariant Choi supports.

## Two preparatory bounds

Find a finite feasible seed and convolve it with a fixed normalized lattice box. Translate it so there is a coefficient \(s_0\succeq\lambda I,\ \lambda>0\) in the **whole augmented tuple**. This is possible since its total is \(\operatorname{diag}(1,T)\succ0\). Denote the resulting tuple by \(s\) and its probability polynomial by \(p_s\). Its total is still \((1,T)\); record its variance and support. This finite seed provides an upper bound \(B\) on the optimal QFI.

A near-optimal initial protocol can be an ensemble of normalized, positive, finite tuples \(f^j\in M_0\) with probabilities \(c_j\). For a single pure program pinch distinct lattice cosets; the induced channel is unchanged and the average of the conditional variances cannot increase. A mixed input first has the exact finite optimized purification. Every conditional channel has support inside \(S\), since their positive average has support \(S\). Write \(\mu_j=\sum_n (\omega\cdot n)p^j_n\) after translating its coset to the lattice. Then \(\sum_j c_j C^j(1)=T\); the branch totals need not equal \(T\).

For each branch write \(v=\operatorname{Var}(p)\), \(\mu=\mathbb E_p[\omega\cdot n]\) and \(w_\mu(n)=1+(\omega\cdot n-\mu)^2\). There is a fixed computable \(A\) such that
\[
 \sum_n w_\mu(n)\|f_n\|\le A(1+v)
\]
in the operator norm of the block diagonal tuple. Indeed the unnormalized Choi coefficients equal \(Y_n=K C_n^{\mathsf T} K^*\) for the fixed injective column matrix of Kraus vectors. Hence \(\|C_n\|\le\operatorname{Tr}Y_n/\sigma_{\min}(K)^2\). Diagonal energy balance gives \((Y_n)_{ib,ib}\le p_{n+f_b-e_i}\). Summing and translating these finitely many terms proves the bound. One may use \(w_\mu(n+u)\le 2(1+|\omega\cdot u|^2)w_\mu(n)\) throughout.

## A finite-range repair that stays on the Choi face

Take a Laurent matrix \(P=\sum_u P_u x^u\) mapping the ambient module to \(M_0\) and acting as identity on \(M_0\). View these real coefficient-space maps with their induced tuple norm. Use the window \(g_t(n)=L^{-d}{\bf1}_{[0,L-1]^d}(n-t)\) for each integer translate. Define a compactly supported *exact sector solution* by \(h_t=P(g_t f)\), where the product by \(g_t\) is pointwise on coefficients. Its defect from the positive window is
\[
 r_{t,n}=(h_t)_n-g_t(n)f_n
   =\sum_uP_u\,[g_t(n-u)-g_t(n)]f_{n-u}.
\]
For each \(n,u\), the sum over \(t\) of the absolute window difference is at most \(2\|u\|_1/L\). A weighted bound follows:
\[
 \sum_{t,n}w_\mu(n)\|r_{t,n}\|\le A K_P(1+v)/L,\qquad
 K_P=4\sum_u\|P_u\|\,\|u\|_1(1+|\omega\cdot u|^2).
\]
Add to \(h_t\), for each occupied defect site \(n\), a translated copy \(x^ns\) with coefficient \(a_{tn}=\|r_{t,n}\|/\lambda\). At site \(n\) this addition dominates its possibly negative residual; at every other site it adds a PSD coefficient. The resulting \(h'_t\) is positive and still solves all sector equations. Its support is in a translate of the original width-\(L\) box enlarged by the finite sets \(\{0\}\cup\operatorname{supp}P\) and \(\{0\}\cup\operatorname{supp}s\). These enlargements are independent of the original packet size.

Summing the uncorrected \(h_t\) over all translates gives \(Pf=f\) exactly. On summing also over the original ensemble, the unnormalized probability and Gram totals after repair are \((1+\bar a)(1,T)\), where \(\bar a=\sum_j c_j\sum_{t,n}a^j_{tn}\). Normalize globally, then normalize each packet by its probability mass and use that mass as its classical mixing weight. A zero-mass packet has zero Gram by diagonal balance and can be omitted. This constructs an ensemble of CPTP channels whose average equals the *original* target.

For its cost, each localized packet's variance is at most its second moment about the mean \(\mu_j\) of its original branch. The translated repair probability has second moment about this mean bounded by \(K_s w_{\mu_j}(n)\), where \(K_s=2(1+\sum_b |\omega\cdot b|^2(p_s)_b)\). Hence before the final division the average second moment grows by at most \(K_s A K_P(1+\sum_j c_j v_j)/(\lambda L)\). The final division is by at least one. Let \(C_{L+R}\) denote the optimal exact cost of ensembles using translated boxes of that width, where \(R\) is the known coordinate-width enlargement. Passing to the near-optimal limit yields
\[
 C_{L+R}-\frac{4K_s A K_P(1+B/4)}{\lambda L}
 \ \le F_c^0(\Phi)\le C_{L+R}.
\]
This concerns variance of the original physical energy even for correlated lattice coordinates. Carathéodory and the finite covariant-Choi optimization in F23 evaluate \(C_{L+R}\) to specified tolerance. Each branch can be translated into the same box because translation changes neither its variance nor the covariance constraint on its processor.

## When a projection is available

Write \(L\) for the polynomial matrix of the sector constraints. Over \(\mathbb R[x,x^{-1}]\), its image is a finitely generated submodule of a free module over a PID, hence free. The sequence from the ambient free module onto this free image splits. Subtract a right inverse on the image composed with \(L\) from the identity. This gives the required polynomial retraction onto \(\ker L\). Smith normal form computes it for any one-gap presentation. In several variables a direct-summand retraction can be found by solving linear polynomial module equations. For a generator matrix \(G\) of \(M_0\), one equivalent test is existence of a Laurent matrix \(B_1\) with \(GB_1G=G\), since \(P=GB_1\).

More generally, let \(r\) be the rational-function rank of \(G\). For each nonzero \(r\)-by-\(r\) minor \(d_I\), selecting those columns and rows and using an adjugate gives an endomorphism with image inside \(M_0\) acting on \(M_0\) as \(d_I I\). Sum these endomorphisms with multipliers \(d_I^*(x)=d_I(x^{-1})\), using real coefficient data. The result \(P\) acts as \(hI\) there, where \(h=\sum_I d_I^*d_I\). If rank is constant on the unit torus, \(h\) is strictly positive there. Its reciprocal is analytic in a product annulus containing that torus; the Fourier–Laurent coefficients decay exponentially by Cauchy's estimate on slightly smaller annuli. Thus for any \(\eta>0\) we can find a real Laurent polynomial \(b\) with \((bh)(1)=1\) and
\[
 \sum_u(1+|\omega\cdot u|^2)|[x^u](bh-1)|<\eta .
\]
This is effective without a precomputed annulus width: enumerate finite rational Laurent approximants, normalize by their nonzero value times \(h(1)\), and check the finite weighted strict inequality. A coordinate norm overestimate with rational constants can be used when the physical frequencies are computable. The nonvanishing rank condition itself is real semialgebraic on the compact torus.

Replace the retraction by \(P'=bP\), and let \(k=bh\). Now \(\sum_t h_t=k*f\), and the residual formula has one extra term \(g_t(n)[(k-1)*f]_n\). Its summed weighted norm is at most \(2A\eta(1+v)\). The signed reference \(k*f\) has exactly the same total target and probability as \(f\). Its probability second moment about \(\mu\) exceeds that of \(f\) by at most \(2\eta(1+v)\) by the same translate inequality. The repaired packets remain positive and exact. In the width estimate replace the defect factor \(K_P/L\) by \(K_{P'}/L+2\eta\) and allow the additional \(8\eta(1+B/4)\) in QFI for the signed reference. Choose \(\eta\) first and \(L\) second. This supplies arbitrarily sharp finite brackets on this larger class.

## Obstruction to extending this proof unchanged

There are kernels of linear Laurent maps whose field image cannot be projected onto continuously at certain unit-torus characters. For the row \((x-1,y-1)\) the kernel is generated by \((1-y,x-1)^{\mathsf T}\). Its line along \(y=1,x\ne1\) and along \(x=1,y\ne1\) has two different limits at \((1,1)\). A continuous retraction acting as identity on these lines with image in the module fibers would have to vanish at that point yet have a nonzero limit along both curves. Free positive diagonal coordinates can be adjoined to this relation on two cross coordinates of a Hermitian matrix. F11 can encode such a linear sector relation in a GP channel. This excludes a retraction for that presented module; it does not establish that the corresponding channel has a discontinuous QFI value or that no smaller observable quotient can suffice.

The direct repair of negative *sector coefficients* is what permits noninvariant supports here. Sine-window phase damping, the finite-sector reduction, and the existence of a coefficientwise interior buffer were available in the [earlier optimization](multiple-gaps.md) and [normalization argument](kernel-module-classification-v2.md). The new cutoff uses a module projection and tracks its commutator with the spatial window, including weighted errors and exact restoration of the target.
