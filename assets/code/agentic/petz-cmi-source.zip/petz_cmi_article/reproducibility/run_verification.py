"""Reproduce the numerical checks and the exact-arithmetic certificate."""
from pathlib import Path
import json
import numpy as np
import verify_from_printed_coefficients as numerical
import choi_implementation as choi
import certify_counterexample as certificate

if not __debug__:
    raise RuntimeError('Run without -O so verification assertions are enabled.')


def cross_check():
    v=np.array([[complex(float(a),float(b)) for a,b in col]
                for col in numerical.VECTORS]).T
    g=v*np.sqrt(np.asarray(numerical.WEIGHTS,dtype=float))
    g/=np.sqrt(np.trace(g.conj().T@g).real)
    rho=g@g.conj().T
    direct=numerical.recovery(rho)
    independent=choi.apply_petz_to_BC(rho,[2,2,2])
    discrepancy=float(np.max(np.abs(direct-independent)))
    assert discrepancy<1e-13
    result=dict(max_entry_discrepancy=discrepancy,
                choi_cmi=choi.cmi(rho,[2,2,2]),
                choi_recovery_term=float(-np.log2(choi.fidelity_sq(rho,independent))),
                gram_recovery_term=float(-np.log2(numerical.fidelity_from_factor(g,direct))))
    assert abs(result['choi_recovery_term']-result['gram_recovery_term'])<1e-7
    (Path(__file__).parent/'choi_cross_check.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Independent Choi cross-check:',json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    numerical.numpy_check()
    cross_check()
    for precision in (50,80):
        numerical.high_precision_check(precision)
    certificate.main()
    print('All checks passed. The certified gap is strictly negative.',flush=True)
