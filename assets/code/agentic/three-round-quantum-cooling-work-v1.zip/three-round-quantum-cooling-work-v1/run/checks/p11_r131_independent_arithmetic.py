"""Distinct dyadic arithmetic/state propagation for the frozen P11 witness.

Same agent, new implementation; not an independent human or agent review.
No imports from the original probability, rotation or interval evaluators.
"""
from pathlib import Path
from fractions import Fraction as F
import json,math,time,copy

BITS=192;SCALE=1<<BITS

class J:
    def __init__(self,a=0,b=None,raw=False):
        if raw:self.lo,self.hi=int(a),int(b);return
        a=F(a);b=a if b is None else F(b)
        self.lo=(a.numerator*SCALE)//a.denominator
        self.hi=-((-b.numerator*SCALE)//b.denominator)
    def __add__(self,other):
        o=cv(other);return J(self.lo+o.lo,self.hi+o.hi,True)
    __radd__=__add__
    def __neg__(self):return J(-self.hi,-self.lo,True)
    def __sub__(self,o):return self+-cv(o)
    def __rsub__(self,o):return cv(o)+-self
    def __mul__(self,other):
        o=cv(other);p=[a*b for a in [self.lo,self.hi] for b in [o.lo,o.hi]]
        return J(min(p)//SCALE,-((-max(p))//SCALE),True)
    __rmul__=__mul__
    def __truediv__(self,other):
        o=cv(other);assert o.lo*o.hi>0
        vals=[F(a*SCALE,b) for a in [self.lo,self.hi] for b in [o.lo,o.hi]]
        low,high=min(vals),max(vals)
        return J(low.numerator//low.denominator,-((-high.numerator)//high.denominator),True)
    def __pow__(self,n):
        out=J(1)
        for _ in range(n):out=out*self
        return out
    def pair(self):return [format(self.lo/SCALE,'.17g'),format(self.hi/SCALE,'.17g')]
    def exact_bounds(self):return dict(lower_numerator=str(self.lo),upper_numerator=str(self.hi),denominator=str(SCALE))

def cv(o):return o if isinstance(o,J) else J(o)
def exp_negative(t,N):
    t=F(t);assert 0<=t<=1
    lower=sum((t**k/F(math.factorial(k)) for k in range(N+1)),F(0))
    tail=t**(N+1)/F(math.factorial(N+1))/(1-t/F(N+2))
    return J(1)/J(lower,lower+tail)

E=[0,1,1,2,2,3]
q=exp_negative(1,100);Z=1+q+q*q
p=[q**e/(Z*(1+q)) for e in E];bath=[q**r/Z for r in range(3)]

def zero(n):return [[J(0) for _ in range(n)] for _ in range(n)]
def energy(rho):return sum(e*rho[i][i] for i,e in enumerate(E))

def act(rho,perm,rotations,collision):
    n=len(rho);assert sorted(perm)==list(range(n))
    energies=[E[i//3]+i%3 for i in range(n)] if collision else E
    if collision:assert all(energies[i]==energies[perm[i]] for i in range(n))
    out=zero(n)
    for i in range(n):
        for j in range(n):out[perm[i]][perm[j]]=rho[i][j]
    for rec in rotations:
        assert not rec['imaginary'];i,j=rec['i'],rec['j'];t=F(rec['value'])
        assert rec['kind'] in ['tan','cot']
        c=(1-t*t)/(1+t*t) if rec['kind']=='tan' else (t*t-1)/(1+t*t)
        s=2*t/(1+t*t);assert c*c+s*s==1
        if collision:assert energies[i]==energies[j]
        c,s=J(c),J(s);a,b=out[i][:],out[j][:]
        out[i]=[c*x-s*y for x,y in zip(a,b)];out[j]=[s*x+c*y for x,y in zip(a,b)]
        for k in range(n):
            x,y=out[k][i],out[k][j];out[k][i]=c*x-s*y;out[k][j]=s*x+c*y
    return out

def trajectory(rec):
    controls=rec.get('controls',rec.get('population_base_controls'))
    rho=zero(6)
    for i in range(6):rho[i][i]=p[i]
    works=[]
    for stage in range(3):
        before=energy(rho)
        rho=act(rho,controls[stage]['V'],[r for r in rec.get('rotations',[]) if r['stage']==2*stage],False)
        works.append(energy(rho)-before)
        joint=zero(18)
        for a in range(6):
            for b in range(6):
                for r in range(3):joint[3*a+r][3*b+r]=rho[a][b]*bath[r]
        joint=act(joint,controls[stage]['U'],[r for r in rec.get('rotations',[]) if r['stage']==2*stage+1],True)
        rho=[[sum(joint[3*a+r][3*b+r] for r in range(3)) for b in range(6)] for a in range(6)]
    cost=sum(J(max(0,w.lo),max(0,w.hi),True) for w in works)
    trace=sum(rho[i][i] for i in range(6));assert trace.lo<=SCALE<=trace.hi
    return [rho[i][i] for i in range(6)],cost,works

def solve(A,v):
    rows=[[A[i][j] for j in range(5)]+[v[i]] for i in range(5)]
    for k in range(5):
        pivot=max(range(k,5),key=lambda j:abs(rows[j][k].lo+rows[j][k].hi))
        rows[k],rows[pivot]=rows[pivot],rows[k];z=rows[k][k];assert z.lo*z.hi>0
        rows[k]=[x/z for x in rows[k]]
        for i in range(5):
            if i!=k:
                z=rows[i][k];rows[i]=[x-z*y for x,y in zip(rows[i],rows[k])]
    return [row[-1] for row in rows]

if __name__=='__main__':
    start=time.time();witness=json.loads(Path('run/checks/r131_p11_witness.json').read_text())
    qg=q*exp_negative(F(1,100000),20);Zg=1+qg+qg*qg
    target=[qg**(i//2)*q**(i%2)/(Zg*(1+q)) for i in range(6)]
    results={}
    for cls in ['population','quantum']:
        columns=[];costs=[];works=[]
        for rec in witness[cls]['protocols']:
            out,c,ws=trajectory(rec);columns.append([out[i]-p[i] for i in range(6)]);costs.append(c);works.append([w.pair() for w in ws])
        A=[[columns[j][i] for j in range(5)] for i in range(6)]
        alpha=solve(A,[target[i]-p[i] for i in range(6)])
        assert all(a.lo>0 for a in alpha) and sum(alpha).hi<SCALE
        sixth=sum(alpha[j]*columns[j][5] for j in range(5))-(target[5]-p[5]);assert sixth.lo<=0<=sixth.hi
        work=sum(a*c for a,c in zip(alpha,costs))
        results[cls]=dict(work=work.exact_bounds(),work_decimal_display=work.pair(),
            weights=[a.exact_bounds() for a in alpha],identity_weight=(1-sum(alpha)).exact_bounds(),branch_signed_works=works)
    lower=sum(J(str(y))*(target[i]-p[i]) for i,y in enumerate(witness['price']))
    upper=J(int(results['quantum']['work']['lower_numerator']),int(results['quantum']['work']['upper_numerator']),True)
    gap=lower-upper;assert gap.lo>J('0.000000006').hi
    # Known valid identity and a deliberately invalid energy-changing collision.
    identity={'controls':[dict(V=list(range(6)),U=list(range(18))) for _ in range(3)]}
    out,c,_=trajectory(identity);assert all((out[i]-p[i]).lo<=0<=(out[i]-p[i]).hi for i in range(6))
    bad=copy.deepcopy(identity);bad['controls'][0]['U'][0:2]=[1,0]
    try:trajectory(bad)
    except AssertionError:invalid_rejected=True
    else:raise AssertionError('invalid collision accepted')
    report=dict(bits=BITS,results=results,population_lower=lower.exact_bounds(),
        strict_gap=gap.exact_bounds(),gap_decimal_display=gap.pair(),
        identity_control_passed=True,invalid_collision_rejected=invalid_rejected,seconds=time.time()-start,
        scope='Distinct state propagation and directed dyadic arithmetic support the finite witness and gap; the universal population converse is separately proved by the frozen exhaustive certificate. Same-agent review only.')
    Path(__file__).with_suffix('.result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
