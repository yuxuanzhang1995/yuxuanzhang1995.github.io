# Published-version comparison for the Gaussian two-parameter Holevo expression

Primary source: Chang, Genoni and Albarelli, Communications Physics9,126 (2March2026), https://www.nature.com/articles/s42005-026-02550-6 , Eq76 and Supplementary Note6. The previously seeded arXiv2504.17873 HTML serves v1 and lacks this published subsection. The publisher uses sigma=2V.

For our canonical family, s=v²−1/4,t=v²+1/4,K=t+a²s,delta=detW, choose the centered quadratic basis(T,A,S). Its complex covariance Gram matrix is diag(s, [t,iv;-iv,t]) up to the inconsequential sign of its imaginary block, and the derivative pairing matrix has columns(1,a,0) and(0,0,1). Hence

CS=W11*s*t/K+W22*t.
barCH=CS+2*sqrt(delta)*abs(a)*v*s/K.
CR=CS−W22*v²/K+2*sqrt(delta)*abs(a)*v*s/K.

The published Eq76 sets CH=CR when CR≥(barCH+CS)/2, equivalently s*abs(a)≥v*W22/sqrt(delta). Otherwise CH=CS+(barCH−CS)²/[4*(barCH−CR)]. Since barCH−CR=W22*v²/K, this branch is W11*s+W22*t−W12²*a²*s²/(W22*K). Combining both branches yields EXACTLY our round39 formula with the squared positive-part correction.

Thus the round39 exact-Holevo formula is an explicit corollary of published Eq76, independently derived in the project. It is not a novel general method or novel analytic Holevo formula. Its validity and role as a baseline are unaffected. The source does not in this subsection provide a necessary-and-sufficient Gaussian-measurement equality classification; its conclusion identifies Gaussian-restricted multiparameter estimation as a further direction. The separate collective-Gaussian gap argument should be assessed on its own, without attributing novelty to the known Holevo part.

Next stages must seed the FINAL PUBLISHED full text, not just v1, and review progress against the above algebraic identification. This source observation is not a new theorem or a new full original solution. No external notification has been sent.
