# Matrix positive multiples: necessary Newton conditions and unresolved bridge

24 November 2026. Prospective arbitrary-support route. This working file
does NOT assert the sufficiency of the conditions below.

Let F=sum_alpha F_alpha x^alpha be Hermitian, with F(1)>0. Suppose a
nonzero scalar Laurent polynomial q makes every coefficient of qF PSD.
For every nonzero constant vector v, put f_v=v*Fv and let N_v be its
Newton polytope. Then:

(A) Every Newton-face polynomial of f_v is strictly positive on the
    positive orthant.
(B) Every exponent in the vector polynomial Fv belongs to N_v.

(A) follows from scalar Handelman positivity: q f_v is coefficientwise
nonnegative and nonzero. The sign is fixed by F(1)>0. For (B), put G=qF.
Since G_alpha>=0, v*G_alpha v=0 iff G_alpha v=0. Thus the Newton polytope
of Gv equals that of v*Gv. Multiplication by q adds N(q) to both vector
and scalar Newton polytopes (use a generic scalar functional on the vector
coefficients to avoid finite leading cancellations). Cancellation of a
common Minkowski summand gives N(Fv)=N(f_v), proving (B).

These conditions reject the inherited matrix
[[1,x],[x,x^2+x]]: for v=(1,0), N(f_v)={0} but Fv contains exponent one.
Condition (A) alone does not reject it. The multivariate scalar example
1-xy+x^2 y^2 continues to forbid a universal rectangular multiplier.

For fixed finite F, (A) and (B) can be expressed by finitely many
semialgebraic formulas: enumerate subsets of the finite coefficient
support and their faces, describe the support of f_v by quadratic
equalities/nonzero tests in Re(v),Im(v), and quantify over positive x.
This is only decidability of the necessary tests, not yet an existence
criterion for a matrix multiplier.

Potential sufficiency bridge: show a uniform matrix-positive multiplier
from (A),(B). A proposed intermediate statement is a uniform domination
F(x)>=epsilon sum_alpha |F_alpha| x^alpha, epsilon>0, using a semialgebraic
curve at infinity and endpoint kernel flags. Even if that domination is
established, converting it to coefficient positivity needs a valid
ordered-module argument. Scalar positivity, variable-dependent matrix
diagonalization, or a pointwise positive Gram factor does not supply it.

Relevant primary interfaces, newly consulted in this block:

- Einsiedler--Mouat--Tuncel, *When does a submodule ... contain a positive
  element?*, Monatsh. Math. 140 (2003), 267--283,
  https://people.math.ethz.ch/~einsiedl/module.pdf . Theorem 1.3 and Section
  6 give a finite procedure for tuples with scalar nonnegative coefficients.
  This is not a theorem for PSD matrix coefficients. The continuous-offset
  condition in Theorems 1.1--1.2 cannot be discarded.
- Colin Tan, arXiv:1706.05624v5 (2023), Theorems 1--2,
  https://arxiv.org/html/1706.05624v5 . The module representation theorem
  requires an actual order unit and an Archimedean scalar semiring.
  Those hypotheses must be constructed for the singular matrix boundary;
  the theorem is not permission to assume the desired positive element.

Even a full fixed-matrix multiplier theorem would leave the selection of
a polynomial sector solution in an underdetermined channel module. That
second bridge is part of the original deliverable, not an optional extra.
