"""Finite-size algebra controls; do not substitute for uniform analytic proof."""
from pathlib import Path
import json
import numpy as np
from functools import reduce
N=4;I=np.eye(2**N);Z=np.diag([1.,-1.]);ann=np.array([[0.,1.],[0.,0.]])
cs=[reduce(np.kron,[Z if j<i else ann if j==i else np.eye(2) for j in range(N)]) for i in range(N)]
zs=[I-2*c.T@c for c in cs];par=reduce(np.matmul,zs)
rng=np.random.default_rng(470321);o=rng.normal(size=I.shape)+1j*rng.normal(size=I.shape);o=(o+o.conj().T)/2;o=(o+par@o@par)/2
def D(k,a):
    kk=k.conj().T@k;return k.conj().T@a@k-(kk@a+a@kk)/2
def T(i,a):
    c=cs[i];x=c+c.T;y=1j*(c.T-c)
    return (a+x@a@x+y@a@y+zs[i]@a@zs[i])/4
def P(i,a):return (a+zs[i]@a@zs[i])/2
def delta(i,a):return a-T(i,a)
def dp(i,a):return delta(i,P(i,a))
def dq(i,a):return delta(i,a-P(i,a))
errs={}
errs['free_P_identity']=max(np.linalg.norm(dp(i,D(cs[i],o))+dp(i,o)) for i in range(N))
errs['free_Q_identity']=max(np.linalg.norm(dq(i,D(cs[i],o))+.5*dq(i,o)) for i in range(N))
k=cs[0]+.31*cs[2]+.17*cs[2].T
def E(a):return D(k,a)-D(cs[0],a)
errs['outside_commutation']=max(np.linalg.norm(T(i,E(o))-E(T(i,o))) for i in [1,3])
errs['local_annihilation']=np.linalg.norm(E(T(0,T(2,o))))
m=np.diag([-1.5,-.8,.9,1.7])+np.diag([.13,.09,.11],1)+np.diag([.13,.09,.11],-1)
ev,v=np.linalg.eigh(m);pm=(v*(ev<0))@v.T;pp=I[:N,:N]-pm
ds=[sum(pp[i,j]*cs[j]+pm[i,j]*cs[j].T for j in range(N)) for i in range(N)]
errs['CAR']=max(np.linalg.norm(ds[i]@ds[j].T+ds[j].T@ds[i]-(I if i==j else 0)) for i in range(N) for j in range(N))
ab=(v*abs(ev))@v.T
h=sum(m[i,j]*cs[i].T@cs[j] for i in range(N) for j in range(N))
hp=sum(ab[i,j]*ds[i].T@ds[j] for i in range(N) for j in range(N))+sum(ev[ev<0])*I
errs['Hamiltonian_identity']=np.linalg.norm(h-hp)
es,u=np.linalg.eigh(h)
def filt(a):
    aa=u.T@a@u; freq=es[:,None]-es[None,:]
    aa=aa*((freq<-.1)&(freq>-3.));return u@aa@u.T
phys=sum(D(filt(c),o)+D(filt(c.T),o) for c in cs)
errs['same_physical_generator']=np.linalg.norm(phys-sum(D(d,o) for d in ds))
assert max(errs.values())<1e-10,errs
out={'status':'pass','errors':{k:float(v) for k,v in errs.items()},'scope':'Finite-dimensional floating algebra controls, not proof of uniform stability.'}
(Path(__file__).resolve().parent/'check-results-new.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
