"""Fresh targeted controls, written after analytic review of the frozen proofs.
These finite checks do not certify universal theorems or asymptotic complexity.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json, math, numpy as np, sympy as sp

out = {}

# M15: a cyclic latent-bit law, with actual h=2 support truncation.  This is
# an independent general-dependency control, not a claimed new quantum circuit.
n=6; vertices=frozenset(range(n))
rates=[F(2,5),F(1,11),F(1,13),F(1,17),F(1,19),F(1,23)]
laws={frozenset(i for i,y in enumerate(z) if y):F(0) for z in product([0,1],repeat=n)}
for z in product([0,1],repeat=n):
    weight=math.prod(rates[i] if z[i] else 1-rates[i] for i in range(n))
    y=[z[i]^z[(i+1)%n] for i in range(n)]
    y[2]=z[2]|z[3]
    laws[frozenset(i for i in range(n) if y[i])]+=weight
assert sum(laws.values())==1
def subsets(s):
    a=sorted(s)
    return [frozenset(a[i] for i,b in enumerate(z) if b) for z in product([0,1],repeat=len(a))]
def neighbors(s):
    return s|frozenset(j for i in s for j in [(i-1)%n,(i+1)%n])
def comps(s):
    rem=set(s); ans=[]
    while rem:
        c={min(rem)}
        while True:
            nxt=set(neighbors(frozenset(c)))&rem
            if nxt==c:break
            c=nxt
        ans.append(frozenset(c));rem-=c
    return ans
mu={s:sum(p for y,p in laws.items() if s<=y) for s in subsets(vertices)}
for s in mu:assert mu[s]==math.prod(mu[c] for c in comps(s))
H=frozenset([0,5]);good=vertices-H;h=2
polymers=[s for s in subsets(good) if s and len(s)<=h and len(comps(s))==1]
cores=[(j,d) for j in subsets(H) for d in subsets(good) if len(d)<=h and all(neighbors(c)&H for c in comps(d))]
nu=F(1,1024)
up=lambda v:nu*(v//nu+2)
ac={c:up(mu[c[0]|c[1]]) for c in cores};ap={c:up(mu[c]) for c in polymers}
A=sum(ac.values());norm=A*math.prod(1+a for a in ap.values())
got={y:F(0) for y in laws};representations={y:0 for y in laws};valid=F(0);invalid=F(0)
for (j,d),aa in ac.items():
    for z in product([0,1],repeat=len(polymers)):
        active=[c for c,b in zip(polymers,z) if b]
        pr=aa/A*math.prod(ap[c]/(1+ap[c]) if b else 1/(1+ap[c]) for c,b in zip(polymers,z))
        s=d|frozenset().union(*active)
        ok=len(s)<=h and all(not (c&neighbors(H|d)) for c in active)
        ok=ok and all(not(c&neighbors(dd)) for k,c in enumerate(active) for dd in active[k+1:])
        if not ok:invalid+=pr;continue
        y=j|s;w=aa*math.prod(ap[c] for c in active)
        assert norm*pr==w and w>=mu[y]>=laws[y]
        got[y]+=norm*pr*laws[y]/w;representations[y]+=1;valid+=pr
assert valid+invalid==1 and invalid>0
assert all(representations[y]==(1 if len(y&good)<=h else 0) for y in laws)
assert all(got[y]==(laws[y] if len(y&good)<=h else 0) for y in laws)
tail=sum(p for y,p in laws.items() if len(y&good)>h)
cutoffs=[]
for R in [0,1,2,4]:
    err=F(0)
    for y,p in laws.items():
        s=y&good;u=y&H
        if len(s)>h:continue
        B=H|s;value=F(0)
        for t in subsets(good-s):
            if len(t)>R or not all(neighbors(c)&B for c in comps(t)):continue
            outside=vertices-neighbors(B|t)
            mixed=sum(pp for yy,pp in laws.items() if yy&H==u and s|t<=yy)
            zeros=sum(pp for yy,pp in laws.items() if not yy&outside)
            value+=(-1)**len(t)*mixed*zeros
        err+=abs(value-p)
    regroup=sum(2**len(d)*mu[d] for d in subsets(good) if len(d)>R)
    moment=F(1,2**R)*sum(p*5**len(y&good) for y,p in laws.items())
    assert err<=regroup<=moment
    cutoffs.append(dict(R=R,L1=str(err),regrouped=str(regroup),moment=str(moment)))
out['M15']={'law':'cycle of six independent latent Bernoulli bits; XOR outputs except one OR output',
 'h':h,'H':sorted(H),'core_count':len(cores),'polymer_count':len(polymers),
 'unique_valid_outputs':sum(representations.values()),'omitted_mass':str(tail),
 'invalid_proposal_probability':str(invalid),'cutoffs':cutoffs,
 'scope':'Exact rational finite support-truncation, rejection and global L1 controls.'}

# M24: use a new rational q,t and a local qp shear, then check both a strictly
# physical saturated covariance and the boundary failure of the inward argument.
I=sp.eye(2);Z=sp.diag(1,-1);J2=sp.Matrix([[0,1],[-1,0]])
J=sp.diag(J2,J2,J2);q=sp.Rational(3,5);t=sp.Rational(7,10)
c=sp.Rational(5,4);s=sp.Rational(3,4)
S=sp.diag(sp.BlockMatrix([[c*I,s*Z],[s*Z,c*I]]).as_explicit(),I)
seed=S*S.T;eta=q/(2*(t-q)*(1-t*q))
W0=sp.diag(eta*sp.BlockMatrix([[t*t*I,-t*Z],[-t*Z,I]]).as_explicit(),sp.zeros(2))
B=W0[:,:2];P=B*(B.T*B).inv()*B.T
v=sp.Matrix([1,2,-1,3,-2,1]);D=(sp.eye(6)-P)*(sp.eye(6)+v*v.T/9)*(sp.eye(6)-P)
V=seed+D
assert W0*D==sp.zeros(6)
assert all((V+sp.I*J)[:i,:i].det().is_positive for i in range(1,7))
# Local Bob Gaussian shear p_B <- p_B + C q_B, C symmetric.
L=sp.eye(6);L[3,2]=sp.Rational(1,2);L[3,4]=sp.Rational(2,3)
L[5,2]=sp.Rational(2,3);L[5,4]=sp.Rational(-1,3)
assert L*J*L.T==J
Vcross=L*V*L.T;seedcross=L*seed*L.T;Wcross=L.inv().T*W0*L.inv()
assert Wcross*(Vcross-seedcross)==sp.zeros(6)
assert any(Vcross[i,j]!=0 for i in [0,2,4] for j in [1,3,5])
Dt=S.inv()*D*S.inv().T;Wt=S.T*W0*S;K=Wt[:,:2];PK=K*(K.T*K).inv()*K.T
X0=J*PK*J.T-PK;compression=K.T*X0*K
assert X0*J+J*X0==sp.zeros(6)
assert compression[0,0]<0 and compression.det()>0
assert Wt.rank()==2 and (Wt-J*Wt*J.T).rank()==4
G=S.T*sp.diag(sp.Rational(1,2),sp.Rational(1,2),0,0,0,0)*S
assert Wt+G==J*(Wt+G)*J.T
expect=sp.trace(W0*V)/(4*eta)+(1-t*t)/2
assert expect==(1-t*q)**2/(1-q*q)
# Negative control: pure boundary has D=0, K=whole space and X0=0.
assert J*sp.eye(6)*J.T-sp.eye(6)==sp.zeros(6)
out['M24']={'q':str(q),'t':str(t),'EPR_expectation':str(expect),
 'physical_leading_minors':[str((V+sp.I*J)[:i,:i].det()) for i in range(1,7)],
 'inward_compression':str(compression),'arbitrary_qp_local_shear':True,
 'pure_boundary_negative_control':'X0=0; strict-physicality KKT argument cannot be used there',
 'scope':'Exact rational covariance algebra; external affine theorem remains an imported theorem.'}

# M05: actual 4x4 compiled filtering/amplification map, as opposed to merely
# checking the scalar failure-polynomial identity. The filter and its inverse
# preparation are explicitly in the multiplied matrices.
omega=np.exp(1j*np.pi/3);Pgood=np.diag([1,1,0,0]);Rgood=np.eye(4)+(omega-1)*Pgood
Rzero=np.diag([omega,1,1,1]);filt=np.diag([.21,.63]);comp=np.diag(np.sqrt(1-np.diag(filt)**2))
U=np.block([[filt,comp],[comp,-filt]])
assert np.linalg.norm(U.conj().T@U-np.eye(4))<1e-14
theta=.49;child=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
W=U@np.kron(np.eye(2),child);start=W[:,0];p=np.linalg.norm(start[:2])**2;direction=start[:2]/math.sqrt(p)
amps=[]
for j in range(4):
    st=W[:,0];failure=np.linalg.norm(st[2:])**2
    expected=(1-p)**(3**j)
    assert abs(failure-expected)<5e-14
    success=st[:2]/np.linalg.norm(st[:2]);phase=np.vdot(direction,success)
    assert np.linalg.norm(success-phase*direction)<1e-13
    amps.append(dict(level=j,calls=3**j,failure=failure,expected=expected))
    W=W@Rzero@W.conj().T@Rgood@W
out['M05']={'explicit_filter_amplification':amps,
 'good_direction_preserved':True,'scope':'Floating matrix control with 1e-13 tolerance; analytic recurrence carries arbitrary-depth complexity.'}
out['status']='PASS: exact rational M15/M24 controls; floating M05 diagnostic'
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
