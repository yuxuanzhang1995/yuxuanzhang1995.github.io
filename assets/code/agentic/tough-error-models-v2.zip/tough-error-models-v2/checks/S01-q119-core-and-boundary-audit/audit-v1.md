# Q119 inherited candidate audit and exact boundary interface

Original: Q119 / op_b1b41f737f9b4aeb. This is a same-agent mathematical
reassessment, with a separately written exact matrix-expansion checker.
It is not expert review, a new solution, or a completed million-output round.

## Scope and complete proof audit

The frozen v1.1 manuscript and the complete original statement were read.
The original permits arbitrary complex error spaces of dimension e, with
1 <= e <= n^2, and expressly accepts asymptotically matching bounds together
with explicit tough models. It neither requires the identity among errors nor
a trace-preserving normalization. The inherited result answers that asymptotic
alternative if its proof is correct. Its finite rounding problem is a remaining
stronger question, not a reason to erase the existing asymptotic candidate.

The key steps survive this audit. Compactness is on the complex Stiefel manifold.
For G_j=X^*H_jX, T_j=G_j-tr(G_j)I/k, the objective is sum tr(T_j^2).
Horizontal stationarity yields sum H_j X T_j = X S, with
S=sum G_j T_j Hermitian. Thus M=[X,H_1X,...,H_{D-1}X] has a kernel
containing the columns of B=[-S;T_1;...;T_{D-1}]. At a positive objective,
one traceless Hermitian T_j has rank at least two. Consequently rank M <= Dk-2.
For n >= Dk-1 a common orthogonal unit vector exists. The manuscript's column
rotations have no first-order compression term in that direction. Their summed
second derivative is -4F, contradicting a minimum. This implication is valid;
no assumption about commutation between distinct H_j is used.

The dimension of span{I,A_i^*A_j} is at most e^2+1. Sesquilinearity extends
the basis-product compression equations to every pair of errors. For the upper
model the zero, coordinate, real-pair and imaginary-pair labels recover every
block projection. The rank obstruction applies to arbitrary codes, including
codes crossing blocks. Truncation retains all coordinate labels when e<n.
For e>=n, including the diagonal matrix units forces code dimension one.
The cases D=1, n=e=1, k<2, and k>n are handled in v1.1. Writing
n=q(e^2+1)+r verifies the one-integer gap and the uniform asymptotic claim.

No fatal flaw is identified in the frozen proof by this audit. This remains
fallible author-side support, with independent expert review and complete
priority assessment pending. The old code checks are inherited evidence and
are not rerun or given new contribution credit.

## General horizontal second variation

Use coordinates X=[I_k;0] and
H_j = [[G_j,C_j^*],[C_j,D_j]]. A horizontal tangent is Z=[0;W].
The geodesic has expansion

    X(t) = X + t Z - (t^2/2) X W^*W + O(t^3).

Write L_j=C_j^*W+W^*C_j and L_j^0=L_j-tr(L_j)I/k. Direct differentiation gives

    F''(0) = 2 sum_j ||L_j^0||_F^2
              + 4 sum_j tr(T_j W^*D_j W)
              - 4 tr(S W^*W).

This formula does not require stationarity; stationarity is sum C_j T_j=0.
The first term is nonnegative and cannot be dropped. For a unit horizontal
y and W_a=y e_a^*, also include iW_a. Set z_j=C_j^*y. Summing all 2k
real/imaginary directions cancels the D_j terms and yields the exact identity

    sum_a [Hess(W_a,W_a)+Hess(iW_a,iW_a)]
        = 8 (k-1/k) sum_j ||z_j||^2 - 8F.

Indeed the corresponding sum of squared traceless first derivatives is
4(k-1/k)||z_j||^2 for each observable. This is the useful general interface:
an approximately common orthogonal direction suffices only with a quantitative
bound on its cross terms. At a common orthogonal direction z_j=0 it reduces
to the inherited negative-sum argument, twice over the two phases.

## Exact boundary controls and what they decide

The checker builds full Hermitian matrices and separately obtains the quadratic
term by multiplying the geodesic expansion. It does not call the old derivative
checker. It tests the general formula rather than only its common-orthogonal
specialization.

Let G_1=diag(1,-1), G_2=[[0,1],[1,0]], and take bottom-right blocks zero.

1. At n=3,k=2,D=3, choose C_1=[2,0], C_2=[0,-2]. The point X=[I_2;0]
   is stationary with F=4. Its real horizontal Hessian is
   diag(24,24,8,8), hence it is a positive strict local minimum on the
   Grassmannian. This is below the known sharp n=4 threshold for D=3;
   it does not contradict that theorem or the inherited n=5 sufficient bound.
2. At n=4,k=2,D=3, choose C_1=I_2, C_2=-G_1G_2. Stationarity still holds,
   rank B=2, and rank M=4=Dk-2=n. Thus the inherited rank estimate can be
   attained exactly and leaves no common orthogonal direction. Nevertheless,
   the last two coordinate vectors form an exact scalar compression. The full
   Hessian has negative directions. This separates failure of that proof step
   from failure of the existence claim.
3. Adjoin one zero coordinate to the second control. Now n=Dk-1=5 and a
   common orthogonal direction exists. Its 2k-direction Hessian trace is -8F.

The numerical outputs of the exact checker are evidence for these finite
controls. Neither a local stationary point nor a PSD Hessian would establish
an uncorrectable error model at n=6. The matrices in these controls are general
operator-system observables, not an asserted two-error factorization.

## Next justified obligation

The phase-summed Hessian identity suggests a new, quantitative interface:
bound the common-direction defect using the stationarity residual and the
second singular value of the traceless compression stack. This can test whether
the inherited existence proof has an effective approximate-code consequence.
It is distinct from repeating the failed assumption that stationarity creates
more than two dependencies. Exact rounding still needs another argument.
