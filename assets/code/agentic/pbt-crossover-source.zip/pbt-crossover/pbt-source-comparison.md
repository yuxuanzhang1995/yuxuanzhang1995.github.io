# PBT source comparison, 23 September 2026

The live QIQC statement still asks existence and value of the joint limit for every fixed c>0: https://qiqc-op.com/problem/op_25342dbb8d64e728/ . It explicitly distinguishes fixed-d asymptotics and supplies c/(1+c)<=liminf<=limsup<=min(1,c).

Mozrzymas et al., Optimal Port-based Teleportation, NJP20 (2018)053006, is the source of the finite branching/teleportation matrix characterization. It is an input to both the native sine-Slater bound and the root proposal.

Christandl et al., CMP381(2021)379–451, DOI10.1007/s00220-020-03884-0, Section8 explicitly names the fixed N/d^2 ratio limit as an open direction. Its ordered-simplex Dirichlet result is fixed dimensional. Full text was fetched locally as source1809.10751; the publisher page and repository PDF were also inspected.

Yoshida et al., arXiv2408.11902, one-to-one PBT/unitary-estimation correspondence: local full text discusses 1-F=Theta(d^4/N^2). An order estimate is not the full joint crossover formula. The root proposal neither derives its formula from that estimate nor claims the correspondence is new.

Searches for PBT with fermionic, semiclassical and crossover terms did not locate the proposed formula. This is not an exhaustive priority determination. No external expert confirmation has occurred. The complete root proof and the currently running native promoted attempt have independent provenance; neither should be silently attributed to the other.
