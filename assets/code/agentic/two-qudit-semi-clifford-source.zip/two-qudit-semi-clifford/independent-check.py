"""Independent dense-matrix check over Z[omega], omega^2+omega+1=0.

Does not import or use the submitted monomial checker. No floating arithmetic.
Higher-prime checks verify the conjugation formula and Pauli-image count;
the arbitrary-prime hierarchy claim still rests on the algebraic proof.
"""
import itertools
import json
import numpy as np

N = 9
ROOTS = ((1, 0), (0, 1), (-1, -1))

def mul(U, V):
    a, b = U
    c, d = V
    return (a @ c - b @ d, a @ d + b @ c - b @ d)

def adj(U):
    a, b = U
    return (a.T - b.T, -b.T)

def conjugate(U, V):
    return mul(mul(U, V), adj(U))

def dense(action):
    a = np.zeros((N, N), dtype=np.int64)
    b = np.zeros_like(a)
    for x, y in itertools.product(range(3), repeat=2):
        ox, oy, phase = action(x, y)
        a[3 * (ox % 3) + oy % 3, 3 * x + y], b[3 * (ox % 3) + oy % 3, 3 * x + y] = ROOTS[phase % 3]
    return a, b

def canonical(U):
    a, b = U
    i, j = np.argwhere((a != 0) | (b != 0))[0]
    u, v = int(a[i, j]), int(b[i, j])
    assert (u, v) in ROOTS
    # Multiply by the conjugate of the first nonzero matrix entry.
    c, d = u - v, -v
    return ((a * c - b * d).tobytes(), (a * d + b * c - b * d).tobytes())

labels = list(itertools.product(range(3), repeat=4))
paulis = [dense(lambda x, y, a=a, b=b, c=c, d=d: (x+a, y+b, c*x+d*y)) for a, b, c, d in labels]
pauli_keys = {canonical(P) for P in paulis}
generators = [paulis[labels.index(t)] for t in ((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1))]

def is_pauli(V):
    return canonical(V) in pauli_keys

def is_clifford(V):
    return all(is_pauli(conjugate(V, P)) for P in generators)

def is_c3(V):
    # Clifford group closure makes generator checks sufficient at level 3.
    return all(is_clifford(conjugate(V, P)) for P in generators)

S = dense(lambda x, y: (x, y+x*x, 0))
D = dense(lambda x, y: (x, y, x*y*y))
U = mul(D, S)
identity = (np.eye(N, dtype=np.int64), np.zeros((N, N), dtype=np.int64))
assert canonical(mul(U, adj(U))) == canonical(identity)
assert is_clifford(identity) and is_c3(S) and is_c3(D)
assert not is_c3(U)
assert all(is_c3(conjugate(U, P)) for P in paulis)
preserved = [list(t) for t, P in zip(labels, paulis) if is_pauli(conjugate(U, P))]
assert preserved == [[0,0,c,0] for c in range(3)]

prime_checks = []
for p in (3, 5, 7, 11):
    points = list(itertools.product(range(p), repeat=2))
    good = []
    for a, b, c, d in itertools.product(range(p), repeat=4):
        values = []
        permutation = []
        for x, y in points:
            # Follow U-dagger, P, then U on a basis vector, independently
            # of the closed-form formula in the candidate proof.
            x0, y0 = x, (y-x*x) % p
            phase = (-x*y*y+c*x0+d*y0) % p
            x1, y1 = (x0+a) % p, (y0+b) % p
            ox, oy = x1, (y1+x1*x1) % p
            phase = (phase+ox*oy*oy) % p
            assert (ox, oy) == ((x+a) % p, (y+b+2*a*x+a*a) % p)
            assert phase == (c*x+d*(y-x*x)+(x+a)*(y+b+2*a*x+a*a)**2-x*y*y) % p
            permutation.append(((ox-x) % p, (oy-y) % p))
            values.append(phase)
        linear_x, linear_y = (values[p]-values[0]) % p, (values[1]-values[0]) % p
        if len(set(permutation)) == 1 and all(v == (values[0]+linear_x*x+linear_y*y) % p for (x,y),v in zip(points,values)):
            good.append([a,b,c,d])
    assert good == [[0,0,c,0] for c in range(p)]
    prime_checks.append({'prime':p,'pauli_labels_checked':p**4,'basis_points_per_label':p**2,'pauli_images':len(good)})

print(json.dumps({'arithmetic':'exact cyclotomic integer matrices and modular integers',
                  'qutrit_controls':'identity, cubic diagonal, nonlinear shear passed',
                  'qutrit_candidate':{'unitary':True,'C4_all_81_paulis':True,'C3':False,'pauli_preserving_labels':preserved,'semi_clifford':False},
                  'direct_conjugation_checks':prime_checks},indent=2))
