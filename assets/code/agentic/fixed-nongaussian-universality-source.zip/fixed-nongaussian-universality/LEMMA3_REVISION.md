# Lemma 3 clarification, 21 September 2026

The revised manuscript writes out the telescoping identity for a product of unitary groups. Each difference quotient acts on the same fixed vector in the common domain; only bounded unitary prefixes act on its limit. Invariance of the core under individual factors is not required.

The proof also checks the full derivative's generator condition. If C = T'(+0), differentiating the inner product preserved by T(s), against vectors in the core D, gives C contained in -(iA restricted to D)* = iA. Since C extends iA restricted to D, its closure is iA. Proposition 1.1 of Zagrebnov's *Notes on the Chernoff Product Formula*, arXiv:1911.09480, then applies.

The theorem, assumptions, and uses of Lemma 3 are unchanged. The previous published proof abbreviated this as “telescoping”; the revision makes the argument explicit. It is an internal analytic clarification, not a new externally reviewed result. The finite algebra/filter diagnostics remain supplementary and cannot certify the infinite-dimensional theorem.

The earlier published PDF had SHA-256 `31de9a29699595e1cf1a15782328071db9569ec2a7e98cb635e60e8666896a72`. The source and PDF in this archive are the revised version; `MANIFEST.sha256` records their current hashes. The existing audit summary refers to its original dated argument; no new independent model referee pass is implied by this revision.
