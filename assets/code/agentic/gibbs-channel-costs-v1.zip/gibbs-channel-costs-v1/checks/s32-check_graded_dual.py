"""Check graded ranks, transposed Gram, disconnected shells, and boundary faces."""
import sympy as sp


z = sp.symbols("z", positive=True)  # exp(-u Delta)
k0 = sp.diag(1,sp.sqrt(3)/2)
k1 = sp.Matrix([[0,sp.Rational(1,2)],[0,0]])
assert k0.H*k0+k1.H*k1 == sp.eye(2)
for m in (1,2,5):
    # Two orthogonal output grades for input multiplicity m.
    eq = sp.kronecker_product(k0.H*k0,sp.eye(m))+sp.kronecker_product(k1.H*k1,sp.eye(m))
    assert eq == sp.eye(2*m)
    assert sp.simplify((sp.eye(m).rank()+z*sp.eye(m).rank())/m-(1+z)) == 0
    assert sp.eye(m).trace()/m == 1
# Same-frequency complex Gram: conjugating the wrong coefficient swaps the output.
a = [sp.Matrix([[1]]),sp.Matrix([[sp.I]])]
k = [sp.eye(2)/sp.sqrt(2),sp.diag(1,-1)/sp.sqrt(2)]
V = sum((v[0]*s for s,v in zip(k,a)),sp.zeros(2))
assert sp.simplify(V.H*V) == sp.eye(2)
T = sp.Matrix(2,2,lambda i,j:(a[i].H*a[j]).trace())
X = sp.Matrix([[1,1],[1,1]])/2
actual = V*X*V.H
calc = sum((T[j,i]*k[i]*X*k[j].H for i in range(2) for j in range(2)),sp.zeros(2))
wrong = sum((T[i,j]*k[i]*X*k[j].H for i in range(2) for j in range(2)),sp.zeros(2))
assert sp.simplify(calc-actual)==sp.zeros(2) and sp.simplify(wrong-actual)!=sp.zeros(2)
# Convex mixing of single-temperature shape ratios on disconnected cosets.
q = sp.symbols("q",positive=True)
ratio = (2+2*z+q*3)/(2+3*q)
assert sp.simplify(ratio-((2/(2+3*q))*(1+z)+(3*q/(2+3*q))*1))==0
# A closed ball touching only one exposed endpoint demands a new relative
# face. Convex closure on the full segment incorrectly lowers the endpoint.
def boundary_cost(t):
    return sp.Integer(3) if t==0 else 1+t**2

for n in (2,4,16):
    assert 1 < boundary_cost(sp.Rational(1,n)) < boundary_cost(0)
assert boundary_cost(0) == 3 and sp.limit(1+q**2,q,0)==1
print("PASS: three graded rank ratios, exact complex Choi orientation mutation, "
      "disconnected-shell partition identity, and closed-ball face mutation.")
