# A fixed-source gap above the Holevo rate for visible quantum compression

Yuxuan Zhang. Version 1.0, 16 November 2026.

The paper proves, for a fixed 510-state four-qubit Pauli ensemble, that the
visible compression rate with arbitrary independent shared classical
randomness is at least (2/3) log2(170/53) = 1.1209803210... qubits per signal,
strictly above its Holevo information of one bit. The finite-block bound
allows arbitrary mixed messages and collective CPTP decoders. The shared
seed is averaged before the trace-distance error.

The exact optimum is not determined. The proof is analytic. Finite checks
below are diagnostics, not an exhaustive proof over codes or blocklengths.

- `manuscript.tex`: complete paper source; compile twice with pdflatex.
- `checks/`: original numerical checker and separately implemented exact
  rational audit, together with their expected outputs.
- `review/`: sequential mathematical review, source comparison and the
  frozen original derivation. References to campaign paths in the audit
  identify provenance; they are not needed to run this package.
- `original-statement.json`: the pinned input problem record.
- `MANIFEST.json`: SHA-256 hashes of the package files.

From a Python environment with NumPy and SymPy installed, run:

```text
python reproduce.py
```

The checker requires no network access and writes only to a temporary
directory. It verifies the file hashes, four Pauli-basis controls, seven
arbitrary-decoder cases, the original adverse mutations, and an exact
36-label collective-channel calculation with two additional adverse
mutations. The original numerical checker also tests extremal Choi matrices
and the distinction between averaging the seed before or after the error.

Review status: internally checked complete proof candidate. The additional
checker was implemented separately by the same agent. Neither it nor the
fresh-directory replay constitutes independent expert review. Priority and
external acceptance are unconfirmed.

The manuscript was developed with AI assistance for derivation, literature
comparison, computations and drafting under the author's research direction.
No new license is assigned to the original problem or third-party sources.

Website: https://yuxuanzhang1995.github.io/agentic-research/visible-compression-holevo-gap/

Original question: https://qiqc-op.com/problem/op_1ab8b10386bddd66/
