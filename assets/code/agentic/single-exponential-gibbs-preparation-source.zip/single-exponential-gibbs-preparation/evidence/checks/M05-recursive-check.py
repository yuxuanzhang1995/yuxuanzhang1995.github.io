"""Exact budget/phase checks and floating, labelled QBP/ordering controls.
No dense diagnostic is asserted to implement the efficient quantum algorithm.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools, math, json, sys
import numpy as np
import sympy as sp
from scipy.linalg import expm
from scipy.integrate import solve_ivp

out = {}
q = sp.symbols('q', real=True)
w = (1 + sp.sqrt(3)*sp.I)/2
factor = 1+(w-1)*(w*(1-q)+q)
assert sp.simplify(factor+(w-1)**2*q)==0
assert sp.simplify(factor*sp.conjugate(factor)-q*q)==0
out['exact_pi_over_3'] = 'bad amplitude modulus squared multiplies by q^2; failure q -> q^3'

budgets=[]
for kappa in [1,2,5,12]:
    for bits in [4,20,80]:
        eta=F(1,2**bits); D=8*kappa*kappa
        K=6*kappa+bits+4
        tail=2*F(kappa**(K+1),math.factorial(K+1))
        target=8*D*3**kappa/eta
        M=1
        while M<target:M*=2
        grid=F(D*3**kappa,2*M)
        rho=eta/(16*kappa*3**kappa)
        oracle=kappa*3**kappa*rho
        assert K+1>=2*kappa
        assert tail<=eta/8 and grid<=eta/16 and oracle<=eta/16
        budgets.append(dict(kappa=kappa,bits=bits,K=K,time_bits=M.bit_length()-1,
                            tail_over_eta=str(tail/eta),grid_over_eta=str(grid/eta)))
out['exact_positive_error_budgets']=budgets

# Exact repeated-time ordered-cube identity, for genuinely noncommuting data.
X=sp.Matrix([[0,1],[1,0]]); Z=sp.diag(1,-1)
M=3; K=4
As=[X/5+F(2*j+1,2*M)*Z/7 for j in range(M)]
dp=[sp.eye(2)]+[sp.zeros(2) for _ in range(K)]
for A in As:
    series=[(A/M)**j/sp.factorial(j) for j in range(K+1)]
    dp=[sum((series[j]*dp[k-j] for j in range(k+1)),sp.zeros(2)) for k in range(K+1)]
for k in range(K+1):
    cube=sp.zeros(2)
    for inds in itertools.product(range(M),repeat=k):
        prod=sp.eye(2)
        for i in sorted(inds):prod=As[i]*prod
        cube+=prod
    cube/=M**k*sp.factorial(k)
    assert cube==dp[k]
out['exact_repeated_tuple_identity']='PASS for k=0..4, M=3; no collision terms omitted'

xn=np.array([[0,1],[1,0]],complex); yn=np.array([[0,-1j],[1j,0]],complex)
zn=np.diag([1,-1]).astype(complex); eye=np.eye(2,dtype=complex)
def coef(t):return .23*xn + .31*t*zn + .1*t*t*yn
def ode(t,y):return (coef(t)@y.reshape(2,2)).reshape(-1)
ref=solve_ivp(ode,(0,1),np.eye(2,dtype=complex).reshape(-1),rtol=2e-12,atol=2e-13).y[:,-1].reshape(2,2)
order=[]
for M in [8,32,128]:
    fwd=np.eye(2,dtype=complex);rev=fwd.copy()
    for j in range(M):
        E=expm(coef((j+.5)/M)/M)
        fwd=E@fwd;rev=rev@E
    err=np.linalg.norm(fwd-ref,2); wrong=np.linalg.norm(rev-ref,2)
    assert err < 2/M and wrong>1e-2
    order.append(dict(M=M,ordered_error=float(err),reverse_order_error=float(wrong)))
assert order[-1]['ordered_error']<order[0]['ordered_error']/100
out['floating_time_order_controls']=order

def kron_all(xs):
    r=np.array([[1]],complex)
    for a in xs:r=np.kron(r,a)
    return r
def local(n,i,a):return kron_all([a if j==i else eye for j in range(n)])
def thermal(H,beta):
    es,vs=np.linalg.eigh(H); ws=np.exp(-beta*(es-es.min()));ws/=ws.sum()
    return (vs*ws)@vs.conj().T
def flow(H0,V,beta,half_wrong=False,reverse=False):
    n=H0.shape[0]
    def rhs(s,y):
        es,vs=np.linalg.eigh(H0+(1-s if reverse else s)*V)
        # Correct full-temperature merge uses p_(2 beta).
        z=(beta/4 if half_wrong else beta/2)*(es[:,None]-es[None,:])
        f=np.ones_like(z);mask=np.abs(z)>1e-12;f[mask]=np.tanh(z[mask])/z[mask]
        A=-(beta/4 if half_wrong else beta/2)*vs@(f*(vs.conj().T@V@vs))@vs.conj().T
        if reverse:A=-A
        return (A@y.reshape(n,n)).reshape(-1)
    sol=solve_ivp(rhs,(0,1),np.eye(n,dtype=complex).reshape(-1),rtol=8e-11,atol=1e-12)
    assert sol.success
    return sol.y[:,-1].reshape(n,n)

transport=[]
for scale in [1,16,64]:
    beta=.7
    H0=scale*np.kron(zn,eye)+.37*np.kron(eye,xn)
    V=.3*np.kron(xn,xn)+.2*np.kron(zn,zn)
    O=flow(H0,V,beta); inv=flow(H0,V,beta,reverse=True)
    inverse_error=np.linalg.norm(inv@O-np.eye(4),2)
    assert inverse_error<2e-9
    old=thermal(H0,beta); target=thermal(H0+V,beta)
    got=O@old@O.conj().T;got/=np.trace(got)
    err=np.linalg.norm(got-target,1)
    J=np.linalg.norm(V,2);gamma=beta*J/2
    assert err<2e-9
    assert max(np.linalg.norm(O,2),np.linalg.norm(inv,2))<math.exp(gamma)+2e-9
    wrong=flow(H0,V,beta,half_wrong=True);wrong=wrong@old@wrong.conj().T;wrong/=np.trace(wrong)
    bad=np.linalg.norm(wrong-target,1);assert bad>1e-4
    transport.append(dict(onsite_scale=scale,transport_error=float(err),inverse_error=float(inverse_error),half_temperature_wrong_error=float(bad)))
out['floating_QBP_transport']=transport

# Four sites: two noncommuting interacting children and a middle boundary merge.
beta=.8;n=4
H=sum((c*local(n,j,zn)+.13*local(n,j,xn) for j,c in enumerate([.4,1.2,2.1,.7])),np.zeros((16,16),complex))
Vterms=[]
for j in range(3):
    V=.18*local(n,j,xn)@local(n,j+1,xn)+.11*local(n,j,zn)@local(n,j+1,zn)
    Vterms.append(V);H+=V
middle=Vterms[1]; H0=H-middle
O=flow(H0,middle,beta)
def child_amplitude(a,b):
    Ha=a*zn+.13*xn;Hb=b*zn+.13*xn
    amplitudes=[]
    for onsite in [Ha,Hb]:
        es,vs=np.linalg.eigh(thermal(onsite,beta))
        amplitudes.append((vs*np.sqrt(np.maximum(es,0)))@vs.conj().T)
    Hchild0=np.kron(Ha,eye)+np.kron(eye,Hb)
    Vchild=.18*np.kron(xn,xn)+.11*np.kron(zn,zn)
    amp=flow(Hchild0,Vchild,beta)@np.kron(*amplitudes)
    return amp/np.linalg.norm(amp,'fro')
amplitude=np.kron(child_amplitude(.4,1.2),child_amplitude(2.1,.7))
amp=O@amplitude;amp/=np.linalg.norm(amp,'fro')
got=amp@amp.conj().T;error=np.linalg.norm(got-thermal(H,beta),1)
assert error<2e-9
out['floating_interacting_child_merge_error']=float(error)

# Logarithmic precision multiplication is explicit, not hidden in a constant.
rec=[]
for kappa in [1,3]:
    for h in [1,4,9]:
        z=20.0
        zs=[z+j*(math.log(32)+2*kappa) for j in range(h+1)]
        qcalls=[3**math.ceil(math.log(4*math.exp(4*kappa)*math.log(128*math.exp(2*s)),3)) for s in zs[:-1]]
        lhs=sum(math.log(qc) for qc in qcalls)
        maxbound=3*4*math.exp(4*kappa)*math.log(128*math.exp(2*zs[-1]))
        assert lhs<=h*math.log(maxbound)+1e-10
        rec.append(dict(kappa=kappa,height=h,leaf_log_accuracy=zs[-1],log_amplification_product=lhs))
out['charged_recursion_controls']=rec
out['status']='PASS: exact arithmetic identities/budgets and floating diagnostics; not a compiled hardware circuit'
Path(sys.argv[1]).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'])
