"""Run the exact checks and full classification census without network access."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'

def run(args):
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)

def main():
    if sys.flags.optimize:
        raise SystemExit('Run Python without -O: exact certificate assertions are required.')
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for row in manifest['files']:
        path = ROOT / row['path']
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != row['sha256']:
            raise SystemExit('Hash mismatch: ' + row['path'])
    print(f"Verified {len(manifest['files'])} packaged hashes", flush=True)
    BUILD.mkdir(exist_ok=True)
    run([sys.executable, ROOT / 'checks/exact.py'])
    run([sys.executable, ROOT / 'checks/reduction_controls.py'])
    compiler = shutil.which('c++') or shutil.which('g++') or shutil.which('clang++')
    if compiler is None:
        raise SystemExit('A C++17 compiler is needed for the complete nonexistence census.')
    binary = BUILD / 'census'
    run([compiler, '-O3', '-std=c++17', ROOT / 'checks/census.cpp', '-o', binary])
    run([binary, '11', '5', '45144', BUILD / 'parents-n11.g6', BUILD / 'positive.json'])
    positive = json.loads((BUILD / 'positive.json').read_text())
    assert positive['found'] and positive['max_low_rank'] == 9
    run([binary, '12', '4', '1323363', BUILD / 'parents-n12.g6', BUILD / 'negative.json'])
    negative = json.loads((BUILD / 'negative.json').read_text())
    assert negative['source_exhausted'] and not negative['found']
    expected = json.loads((ROOT / 'expected/census-n12.json').read_text())
    for field in ['n', 'cap', 'rows', 'low_rank_pruned', 'planes', 'max_low_rank',
                  'count_survivors', 'max_rank_count_survivors', 'max_low_count']:
        assert negative[field] == expected[field], (field, negative[field], expected[field])
    report = {'status': 'PASS', 'hashes_verified': len(manifest['files']),
              'positive_control': positive, 'full_census': negative,
              'network_used': False, 'classification_regenerated': False,
              'note': 'Exact reproduction, not independent expert proof review.'}
    (BUILD / 'REPRODUCTION.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS: both witnesses, analytic identities, controls and full twelve-qubit exclusion.', flush=True)

if __name__ == '__main__':
    main()
