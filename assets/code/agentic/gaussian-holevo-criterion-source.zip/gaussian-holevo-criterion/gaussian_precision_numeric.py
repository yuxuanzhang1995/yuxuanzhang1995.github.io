import numpy as np,json
from scipy.linalg import expm,block_diag
rng=np.random.default_rng(4224);rows=[]
for n in [1,2,3]:
 q=2*n;O=block_diag(*([np.array([[0.,1.],[-1.,0.]])]*n))
 for mode in ['finite','homodyne']:
  for case in range(8):
   H=rng.normal(size=(q,q));H=(H+H.T)/8;S0=expm(O@H);V=S0@np.diag(np.repeat(.7+rng.random(n),2))@S0.T
   if mode=='finite':
    H=rng.normal(size=(q,q));H=(H+H.T)/8;S1=expm(O@H);N=.5*S1@S1.T;G=np.linalg.inv(V+N);p=min(4,q)
   else:
    K=np.eye(q)[::2];G=K.T@np.linalg.inv(K@V@K.T)@K;p=min(3,n+n*(n+1)//2)
   m=rng.normal(size=(q,p));ds=[]
   for _ in range(p):
    D=rng.normal(size=(q,q));ds.append((D+D.T)/2)
   Bs=[];inds=[]
   for i in range(q):
    for j in range(i,q):
     B=np.zeros((q,q));B[i,j]=B[j,i]=1 if i==j else .5;Bs.append(B);inds.append((i,j))
   Gam=V+1j*O/2;Q=np.array([[2*np.trace(B@Gam@E@Gam.T)for E in Bs]for B in Bs]);gram=block_diag(Gam,Q)
   J=np.vstack((m,np.array([[np.trace(B@D)for D in ds]for B in Bs])))
   L=[]
   for j,D in enumerate(ds):
    C=.5*G@D@G;L.append(np.r_[G@m[:,j],[C[i,k]*(1 if i==k else 2)for i,k in inds]])
   L=np.array(L).T;F=m.T@G@m+np.array([[.5*np.trace(G@D@G@E)for E in ds]for D in ds]);E=np.linalg.inv(F);A=L@E
   err=float(np.max(np.abs(J.T@L-F)));res=E-A.T@gram@A
   vals={'gram_min':float(np.linalg.eigvalsh(gram).min()),'physical_min':float(np.linalg.eigvalsh(np.linalg.inv(Gam)-G).min()),'residual_min':float(np.linalg.eigvalsh(res).min()),'fisher_identity_error':err}
   assert vals['gram_min']>0 and vals['physical_min']>-1e-9 and vals['residual_min']>-1e-8 and err<1e-9
   rows.append({'n':n,'mode':mode,'p':p,**vals})
print(json.dumps({'status':'passed','scope':'48 floating-point controls of Gram/score/compact-precision identities, not proof or exact certificates.','count':len(rows),'minimum_physical_eigenvalue':min(r['physical_min']for r in rows),'minimum_residual_eigenvalue':min(r['residual_min']for r in rows),'max_fisher_identity_error':max(r['fisher_identity_error']for r in rows),'controls':rows},indent=2))
