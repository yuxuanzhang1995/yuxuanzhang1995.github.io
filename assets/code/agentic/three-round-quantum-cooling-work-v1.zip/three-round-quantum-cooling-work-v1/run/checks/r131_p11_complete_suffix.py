"""Exhaust the U2 output quotient and bound the remaining single bath.

Integer coefficient enumeration is exact. Floating scores choose admissible
tilts only; signed fixed-point outward bounds determine certified exclusions.
No assertion that a screen survivor is feasible or violates the price.
"""
from pathlib import Path
from decimal import ROUND_FLOOR, ROUND_CEILING
import argparse, itertools, json, time
import numpy as np
from p11_free_pulses_common import E, p, b, blocks
from p11_rational_quantum_certificate_common import I, q as qi, p as pi, bath as bi

S = 2**28
PRICE = json.loads(Path('run/checks/r127_suffix_diagnostics.result.json').read_text())['price']
Y = np.array(PRICE)
YI = [I(str(v)) for v in PRICE]
ZI = 1+qi+qi*qi
BASISI = [qi**k/(ZI*ZI*ZI*(1+qi)) for k in range(8)]
OLDI = [qi**k/(ZI*ZI*(1+qi)) for k in range(6)]
BASIS = np.array([float(v.a) for v in BASISI])
P6 = np.array(list(itertools.permutations(range(6))))

def lo(x, scale=S):
    return int((x*scale).a.to_integral_value(rounding=ROUND_FLOOR))

def hi(x, scale=S):
    return int((x*scale).b.to_integral_value(rounding=ROUND_CEILING))

def poly(c, basis):
    return sum(int(v)*a for v,a in zip(c,basis))

def enumerate_outputs(N):
    incoming=np.zeros((18,8),dtype=np.int16)
    for s in range(6):
        for r in range(3): incoming[3*s+r,r:r+6]=N[s]
    groups=[]
    for block in blocks:
        unique, labels=np.unique(incoming[block],axis=0,return_inverse=True)
        pats=sorted(set(itertools.permutations(labels.tolist())))
        outputs=[]; controls=[]
        for pat in pats:
            out=np.zeros((6,8),dtype=np.int16); u=np.arange(18,dtype=np.int8)
            sources={j:list(block[labels==j]) for j in set(pat)}
            for dest,label in zip(block,pat):
                out[dest//3]+=unique[label]; u[sources[label].pop()]=dest
            outputs.append(out.ravel()); controls.append(u)
        outputs=np.array(outputs)
        unique, ix=np.unique(outputs,axis=0,return_index=True)
        groups.append((unique,np.array(controls)[ix],len(pats)))
    shape=tuple(len(a) for a,u,raw in groups)
    indices=np.array(list(itertools.product(*(range(n) for n in shape))),dtype=np.int16)
    out=np.zeros((len(indices),48),dtype=np.int16)
    for j,(a,u,raw) in enumerate(groups): out+=a[indices[:,j]]
    out, ix=np.unique(out,axis=0,return_index=True)
    controls=np.tile(np.arange(18,dtype=np.int8),(len(ix),1))
    for j,((a,u,raw),block) in enumerate(zip(groups,blocks)):
        controls[:,block]=u[indices[ix,j]][:,block]
    assert np.all(out>=0)
    return out.reshape(-1,6,8),controls,dict(
        formal_U2_permutations=518400,
        equal_input_block_assignments=[r for a,u,r in groups],
        distinct_block_outputs=list(shape),combinations_before_global_quotient=len(indices),
        distinct_post_U2_states=len(out))

def tilt_data():
    energies=np.array([int(E[s])+r for s in range(6) for r in range(3)])
    rewards=np.repeat(Y,3); knots={0.,1.}
    for i in range(18):
        for j in range(i):
            if energies[i]!=energies[j]:
                z=(rewards[i]-rewards[j])/(energies[i]-energies[j])
                if 0<z<1:knots.add(float(z))
    knots=np.array(sorted(knots))
    obs=np.array([np.sort(rewards-z*energies) for z in knots])
    return knots,obs

def one_bath_bound(N,paid):
    rho=N@BASIS; knots,obs=tilt_data(); indices=[]; scores=[]
    for start in range(0,len(rho),8192):
        r=rho[start:start+8192]
        spec=np.sort((r[:,:,None]*b).reshape(-1,18),axis=1)
        vals=spec@obs.T+(r@E+b@np.arange(3))[:,None]*knots-float(paid.a)-Y@p
        ix=np.argmin(vals,axis=1);indices.extend(ix.tolist());scores.extend(vals[np.arange(len(r)),ix].tolist())
    indices=np.array(indices); scores=np.array(scores)
    bl=np.array([lo(a) for a in BASISI],dtype=np.int64)
    bh=np.array([hi(a) for a in BASISI],dtype=np.int64)
    rl=N.astype(np.int64)@bl;rh=N.astype(np.int64)@bh
    bil=np.array([lo(a) for a in bi],dtype=np.int64)
    bih=np.array([hi(a) for a in bi],dtype=np.int64)
    sl=np.sort((rl[:,:,None]*bil//S).reshape(-1,18),axis=1)
    sh=np.sort(((rh[:,:,None]*bih+S-1)//S).reshape(-1,18),axis=1)
    numerators=np.zeros(len(N),dtype=np.int64)
    eb=sum(r*bi[r] for r in range(3));yp=sum(a*v for a,v in zip(YI,pi))
    for k in np.unique(indices):
        z=I(str(knots[k])); assert 0<=z.a<=z.b<=1
        oh=np.array(sorted(hi(YI[s]-z*(int(E[s])+r)) for s in range(6) for r in range(3)),dtype=np.int64)
        choose=indices==k
        # All products are bounded by 6*S^2; the sum by 32*S^2 < 2^63.
        num=(np.where(oh>=0,sh[choose],sl[choose])*oh).sum(axis=1)
        num+=hi(z)*(rh[choose]@E.astype(np.int64))
        num+=hi(z*eb-yp-paid,S*S)
        numerators[choose]=num
    assert np.all(numerators.astype(float)/(S*S)>=scores-1e-12)
    return numerators,indices,scores,knots

def exact_tail_float(states,paid):
    maxima=[];choices=[]
    reward_sorted=[np.sort(Y[B//3]) for B in blocks]
    for start in range(0,len(states),32):
        rho=states[start:start+32];r=rho[:,P6]
        x=(r[:,:,:,None]*b).reshape(len(rho),720,18)
        val=np.zeros((len(rho),720))
        for B,reward in zip(blocks,reward_sorted):val+=np.sort(x[:,:,B],axis=2)@reward
        val-=np.maximum(0,r@E-(rho@E)[:,None])+float(paid.a)+Y@p
        ix=np.argmax(val,axis=1); maxima.extend(val[np.arange(len(ix)),ix].tolist()); choices.extend(ix.tolist())
    return np.array(maxima),np.array(choices)

def run_one(frontier):
    start=time.time(); N,U,counts=enumerate_outputs(np.array(frontier['post_V2_coefficients'],dtype=np.int16))
    paid=poly(frontier['paid_work_coefficients'],OLDI)
    bounds,tilts,scores,knots=one_bath_bound(N,paid)
    survivors=np.flatnonzero(bounds>=0)
    result=dict(frontier=frontier['id'],**counts,one_bath_tilts=len(knots),
        one_bath_certified_negative=int((bounds<0).sum()),one_bath_survivors=len(survivors),
        largest_one_bath_upper=float(bounds.max()/S**2),smallest_one_bath_upper=float(bounds.min()/S**2))
    if len(survivors):
        values, choices=exact_tail_float(N[survivors]@BASIS,paid)
        best=int(np.argmax(values));ix=int(survivors[best]);perm=P6[choices[best]]
        rho=N[ix]@BASIS;r=rho[perm];x=np.kron(r,b);ut=np.arange(18)
        for B in blocks:
            src=B[np.argsort(x[B],kind='stable')];dst=B[np.argsort(Y[B//3],kind='stable')];ut[src]=dst
        controls=[frontier['first'],dict(V=frontier['V2'],U=U[ix].tolist()),dict(V=np.argsort(perm).tolist(),U=ut.tolist())]
        result.update(exact_tail_floating_max=float(values[best]),best_controls=controls,
            exact_tail_floating_nonnegative=int((values>=0).sum()),exact_tail_status='floating only; directed replay required')
    tag=f"run/checks/r131_p11_frontier_{frontier['id']:02d}"
    np.savez_compressed(tag+'.npz',coefficients=N,controls=U,upper_numerators=bounds,
        tilt_indices=tilts,tilts=knots,survivors=survivors,
        tail_maxima=values if len(survivors) else np.array([]),
        tail_permutations=choices if len(survivors) else np.array([]))
    result['seconds']=time.time()-start
    Path(tag+'.result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--frontier',type=int,default=0)
    ap.add_argument('--all',action='store_true')
    args=ap.parse_args();frontier=json.loads(Path('run/checks/r130_p11_frontier.result.json').read_text())['frontier']
    if args.all:
        rows=[]
        for f in frontier:
            checkpoint=Path(f"run/checks/r131_p11_frontier_{f['id']:02d}.result.json")
            rows.append(json.loads(checkpoint.read_text()) if checkpoint.exists() else run_one(f))
        aggregate=dict(frontiers=len(rows),complete_one_bath_frontiers=sum(r['one_bath_survivors']==0 for r in rows),
            distinct_states=sum(r['distinct_post_U2_states'] for r in rows),
            certified_negative=sum(r['one_bath_certified_negative'] for r in rows),
            remaining_states=sum(r['one_bath_survivors'] for r in rows),results=rows,
            scope='Every formal U2 covered through exact coefficient quotient; remaining tail states need directed replay')
        Path('run/checks/r131_p11_all_frontiers.result.json').write_text(json.dumps(aggregate,indent=2)+'\n')
        print(json.dumps({k:v for k,v in aggregate.items() if k!='results'}),flush=True)
    else:run_one(frontier[args.frontier])
