"""Compare the subcode criterion with direct physical errors in small graphs."""
import itertools,json,random
from pathlib import Path
HERE=Path(__file__).resolve().parent.parent/'build'
HERE.mkdir(exist_ok=True)
def dot(a,b):return (a&b).bit_count()%2
def span_basis(vs):
    piv={}
    for v in vs:
        while v:
            j=v.bit_length()-1
            if j in piv:v^=piv[j]
            else:piv[j]=v;break
    return list(piv.values())
def test(n,adj,u,v,d):
    M=1<<n
    def gx(x):
        z=0
        for j in range(n):
            if x>>j&1:z^=adj[j]
        return z
    cs={t:(t,gx(t))for t in range(M)}
    coeff=[t for t in range(M)if dot(t,u)==dot(t,v)==0]
    S={cs[t]for t in coeff};basis=[cs[t]for t in span_basis(coeff)]
    condition2=all(dot(t,u)==dot(t,v)==0 for t,(x,z)in cs.items()if (x|z).bit_count()<d)
    forbidden=set();physical=True
    for w in range(1,d):
        for inds in itertools.combinations(range(n),w):
            for letters in itertools.product(((1,0),(0,1),(1,1)),repeat=w):
                x=sum(a<<j for j,(a,b)in zip(inds,letters));z=sum(b<<j for j,(a,b)in zip(inds,letters));forbidden.add(z^gx(x))
                if all((dot(x,b)+dot(z,a))%2==0 for a,b in basis)and (x,z)not in S:physical=False
    condition1=not ({u,v,u^v}&forbidden)
    return condition1 and condition2,physical,condition1
def main():
    rng=random.Random(269325);checked=0
    for n in (3,4,5):
        for gi in range(4):
            adj=[0]*n
            for i in range(n):
                for j in range(i):
                    if rng.randrange(2):adj[i]|=1<<j;adj[j]|=1<<i
            for u in range(1,1<<n):
                for v in range(u+1,1<<n):
                    if u^v<=v:continue
                    for d in (2,3,4):
                        reduced,physical,_=test(n,adj,u,v,d);assert reduced==physical;checked+=1
    reduced,physical,missing_condition=test(8,[0]*8,15,240,4)
    assert not reduced and not physical and missing_condition
    out={'direct_physical_comparisons':checked,'all_agree':True,'zero_syndrome_degeneracy_mutation_detected':True,'degeneracy_control':{'graph':'empty','n':8,'u':15,'v':240,'wrong_criterion_accepts':True,'actual_distance':1},'independent_review':False}
    (HERE/'reduction-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
