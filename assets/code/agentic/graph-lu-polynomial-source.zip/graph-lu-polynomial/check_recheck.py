"""Exact recheck of the graph-LU candidate; Python 3 + SymPy, run without -O.

This implementation does not import the earlier checkers. Kernel generators
come from an integer dual lattice, not modular pivot elimination. The graph
checks cover a reduction primitive, not the full MLS standardization algorithm.
"""
import hashlib
import itertools as it
import json
import math
import time
from functools import lru_cache
from pathlib import Path

import sympy
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form


def hnf(rows, m, q):
    if m == 0:
        return Matrix(0, 0, [])
    rows = list(rows) + [[q * (i == j) for j in range(m)] for i in range(m)]
    return hermite_normal_form(Matrix(rows).T).T


def product_row(a, subset, m):
    return [math.prod(a[j][i] for j in subset) for i in range(m)]


def literal_rows(a, m, r):
    return [[(1 << (k - 2 + (k == 2))) * x for x in product_row(a, subset, m)]
            for k in range(2, min(len(a), r + 1) + 1)
            for subset in it.combinations(range(len(a)), k)]


def closure(a, m, r, seed_sizes=(2, 3), factor=2):
    q = 1 << r
    rows = [[2 * x for x in product_row(a, subset, m)]
            for k in seed_sizes for subset in it.combinations(range(len(a)), k)]
    H = hnf(rows, m, q)
    changes = 0
    while True:
        rows = H.tolist()
        nxt = hnf(rows + [[factor * av[i] * row[i] for i in range(m)]
                         for av in a for row in rows], m, q)
        assert all(0 <= x <= q for x in nxt)
        if nxt == H:
            return H, changes
        H = nxt
        changes += 1
        assert changes <= r * m


def dual_kernel(H, q):
    """Hs=0 (mod q) iff s=q H^-1 z for an integer column z."""
    m = H.rows
    if m == 0:
        return []
    K = q * H.inv()
    assert all(x.is_Integer for x in K)
    assert H * K == q * sympy.eye(m)
    return [tuple(int(K[i, j]) % q for i in range(m)) for j in range(m)]


def image(a, s, r):
    q, h = 1 << r, 1 << (r - 1)
    result = 0
    for bit, (u, v) in enumerate(it.combinations(range(len(a)), 2)):
        value = sum(a[u][i] * a[v][i] * s[i] for i in range(len(s))) % q
        assert value in (0, h)
        result |= (value // h) << bit
    return result


def image_basis(a, generators, r):
    """Reduced binary basis, carrying preimages by ADDITION modulo q."""
    q = 1 << r
    piv = {}
    for g in generators:
        v, s = image(a, g, r), g
        while v:
            p = v.bit_length() - 1
            if p not in piv:
                piv[p] = (v, s)
                break
            row, pre = piv[p]
            v ^= row
            s = tuple((x + y) % q for x, y in zip(s, pre))
    for p in sorted(piv):
        row, pre = piv[p]
        for j in sorted(piv):
            if j != p and (piv[j][0] >> p) & 1:
                v, s = piv[j]
                piv[j] = (v ^ row, tuple((x + y) % q for x, y in zip(s, pre)))
    out = [piv[p] for p in sorted(piv)]
    assert all(image(a, s, r) == v for v, s in out)
    return out


def binary_span(rows):
    out = {0}
    for row in rows:
        out |= {v ^ row for v in tuple(out)}
    return out


def modular_span(gens, m, q):
    out = {(0,) * m}
    for g in gens:
        out = {tuple((x + c * y) % q for x, y in zip(v, g))
               for v in out for c in range(q)}
    return out


def from_edges(n, edges):
    adj = [0] * n
    for u, v in edges:
        adj[u] |= 1 << v
        adj[v] |= 1 << u
    return tuple(adj)


def graph_from_bits(n, bits):
    return from_edges(n, [e for k, e in enumerate(it.combinations(range(n), 2))
                          if (bits >> k) & 1])


def connected(adj):
    if not adj:
        return False
    reached, boundary = 1, 1
    while boundary:
        nxt = 0
        for i in range(len(adj)):
            if (boundary >> i) & 1:
                nxt |= adj[i]
        boundary = nxt & ~reached
        reached |= boundary
    return reached == (1 << len(adj)) - 1


def lc(adj, vertex):
    out = list(adj)
    neighbors = [i for i in range(len(adj)) if (adj[vertex] >> i) & 1]
    for u, v in it.combinations(neighbors, 2):
        out[u] ^= 1 << v
        out[v] ^= 1 << u
    return tuple(out)


@lru_cache(None)
def orbit(adj, allowed):
    found, queue = {adj}, [adj]
    for current in queue:
        for v in allowed:
            nxt = lc(current, v)
            if nxt not in found:
                found.add(nxt)
                queue.append(nxt)
    return frozenset(found)


def nullspace(equations, variables):
    piv = {}
    for row in equations:
        while row:
            p = row.bit_length() - 1
            if p not in piv:
                piv[p] = row
                break
            row ^= piv[p]
    basis = []
    for j in range(variables):
        if j in piv:
            continue
        v = 1 << j
        for p in sorted(piv):
            if (piv[p] & v).bit_count() & 1:
                v ^= 1 << p
        assert all((row & v).bit_count() % 2 == 0 for row in equations)
        basis.append(v)
    return basis


def lc_equations(g, h, constraints=(), exhaustive_limit=12):
    """CP Prop. 3.1 equations; Prop. 3.5 search where its hypotheses hold.

    For small nullspaces, independently compare the weight-at-most-two search
    with enumeration of the entire linear solution space.
    """
    n = len(g)
    equations = list(constraints)
    for u in range(n):
        for v in range(n):
            row = (g[u] & h[v]) << n
            if (g[u] >> v) & 1:
                row ^= 1 << v  # A_v
            if (h[u] >> v) & 1:
                row ^= 1 << (3 * n + u)  # D_u
            if u == v:
                row ^= 1 << (2 * n + u)  # C_u
            equations.append(row)
    basis = nullspace(equations, 4 * n)
    mask = (1 << n) - 1

    def determinant(v):
        a, b, c, d = [(v >> (k * n)) & mask for k in range(4)]
        return ((a & d) ^ (b & c)) == mask

    if len(basis) <= 4:
        candidates = binary_span(basis)
    else:
        assert connected(g) and connected(h)
        assert any(v.bit_count() % 2 == 0 for v in g)
        assert any(v.bit_count() % 2 == 0 for v in h)
        candidates = basis + [a ^ b for a, b in it.combinations(basis, 2)]
    answer = any(determinant(v) for v in candidates)
    exhaustive = len(basis) <= exhaustive_limit
    if exhaustive:
        assert answer == any(determinant(v) for v in binary_span(basis))
    return answer, len(basis), exhaustive


def restrict(adj, labels):
    return tuple(sum(((adj[u] >> v) & 1) << j for j, v in enumerate(labels))
                 for u in labels)


def gadget(ygraph, toggle_basis, z):
    pairs = list(it.combinations(range(len(ygraph)), 2))
    groups = [[pairs[k] for k in range(len(pairs)) if (row >> k) & 1]
              for row in toggle_basis]
    assert all(groups)
    n = len(ygraph) + sum(map(len, groups))
    edges = [(u, v) for u, v in pairs if (ygraph[u] >> v) & 1]
    constraints = [1 << (n + u) for u in z]
    index = len(ygraph)
    for group in groups:
        first = index
        for u, v in group:
            edges += [(index, u), (index, v)]
            constraints.append(1 << (2 * n + index))
            if index != first:
                constraints.append((1 << (n + first)) ^ (1 << (n + index)))
            index += 1
    return from_edges(n, edges), tuple(constraints)


def toggle(adj, bits):
    out = list(adj)
    for k, (u, v) in enumerate(it.combinations(range(len(adj)), 2)):
        if (bits >> k) & 1:
            out[u] ^= 1 << v
            out[v] ^= 1 << u
    return tuple(out)


def actual_support_conditions(a, m, r):
    """Definition 2.1 literally on the bipartite graph, for each support."""
    t = len(a)
    adj = from_edges(m + t, [(x, m + y) for x in range(m) for y in range(t) if a[y][x]])
    by_support = {}
    for support in range(1 << m):
        outside = [v for v in range(m + t) if not (support >> v) & 1]
        rows = []
        for j in range(r):
            divisor = 1 << (r - j - (j == 0))
            for K in it.combinations(outside, j + 2):
                common = (1 << m) - 1
                for v in K:
                    common &= adj[v]
                rows.append((common, divisor))
        by_support[support] = rows
    return by_support


def test_large_moduli():
    cases = []
    for t in (4, 5):
        columns = list(it.product((0, 1), repeat=t))
        a = [tuple(v[j] for v in columns) for j in range(t)]
        m = 1 << t
        for r in (1, 2, 3, 4, 8, 32, 128, 256):
            H, rounds = closure(a, m, r)
            assert H == hnf(literal_rows(a, m, r), m, 1 << r)
            assert rounds == max(0, min(r - 2, t - 3))
            dual_kernel(H, 1 << r)
            cases.append(dict(t=t, m=m, r=r, strict_enlargements=rounds))
    mutations = []
    for t, r, kwargs, name in [(3, 2, dict(seed_sizes=(2,)), 'omit triple seeds'),
                               (4, 3, dict(factor=1), 'omit factor two in the maps')]:
        columns = list(it.product((0, 1), repeat=t))
        a = [tuple(v[j] for v in columns) for j in range(t)]
        wrong, _ = closure(a, 1 << t, r, **kwargs)
        assert wrong != hnf(literal_rows(a, 1 << t, r), 1 << t, 1 << r)
        mutations.append(name)
    return dict(cases=cases, mutations_detected=mutations)


def test_complete_images():
    systems = vectors = witness_combinations = zero_images = 0
    for entries in it.product((0, 1), repeat=9):
        a = [entries[3 * i:3 * i + 3] for i in range(3)]
        for r in (2, 3):
            q = 1 << r
            H, rounds = closure(a, 3, r)
            assert rounds == 0
            gens = dual_kernel(H, q)
            basis = image_basis(a, gens, r)
            conditions = actual_support_conditions(a, 3, r)
            exact_kernel, exact_image = set(), set()
            for s in it.product(range(q), repeat=3):
                support = sum((x != 0) << i for i, x in enumerate(s))
                valid = all(sum(s[i] for i in range(3) if (row >> i) & 1) % d == 0
                            for row, d in conditions[support])
                assert valid == all(sum(int(H[j, i]) * s[i] for i in range(3)) % q == 0
                                    for j in range(3))
                if valid:
                    exact_kernel.add(s)
                    exact_image.add(image(a, s, r))
                vectors += 1
            assert modular_span(gens, 3, q) == exact_kernel
            assert binary_span([v for v, _ in basis]) == exact_image
            for bits in it.product((0, 1), repeat=len(basis)):
                s = tuple(sum(b * row[i] for b, (_, row) in zip(bits, basis)) % q
                          for i in range(3))
                v = 0
                for b, (row, _) in zip(bits, basis):
                    if b:
                        v ^= row
                assert s in exact_kernel and image(a, s, r) == v
                witness_combinations += 1
            zero_images += exact_image == {0}
            systems += 1
    return dict(systems=systems, multiplicity_vectors=vectors,
                carried_witness_combinations=witness_combinations, zero_images=zero_images)


def test_general_dual_kernel():
    systems = nonfree = 0
    for entries in it.product(range(4), repeat=4):
        rows = [entries[:2], entries[2:]]
        H = hnf(rows, 2, 4)
        expected = {s for s in it.product(range(4), repeat=2)
                    if all(sum(x * y for x, y in zip(row, s)) % 4 == 0 for row in rows)}
        assert modular_span(dual_kernel(H, 4), 2, 4) == expected
        systems += 1
        nonfree += len(expected) in (2, 8)
    for m, q in ((0, 4), (3, 2), (3, 16)):
        H = hnf([], m, q)
        assert modular_span(dual_kernel(H, q), m, q) == set(it.product(range(q), repeat=m))
    return dict(all_two_by_two_mod4_matrices=systems, nonfree_kernels=nonfree,
                unconstrained_boundary_cases=3)


def test_small_graphs():
    cases = positive = negative = nullspace_exhaustions = zero_branches = 0
    ordinary_checks = ordinary_positive = ordinary_negative = 0
    max_gadget = max_nullity = 0
    incidence_cache = {}
    for n in range(2, 5):
        graphs = [graph_from_bits(n, v) for v in range(1 << math.comb(n, 2))]
        graphs = [g for g in graphs if connected(g)]
        for g in graphs:
            # Ordinary LC is checked by all-vertex graph BFS on every pair.
            expected_orbit = orbit(g, tuple(range(n)))
            for h in graphs:
                if all(x.bit_count() % 2 for x in g) or all(x.bit_count() % 2 for x in h):
                    continue  # constrained algorithm's even-degree hypothesis
                observed, _, _ = lc_equations(g, h)
                assert observed == (h in expected_orbit)
                ordinary_checks += 1
                ordinary_positive += observed
                ordinary_negative += not observed
            for xmask in range(1, (1 << n) - 1):
                X = tuple(v for v in range(n) if (xmask >> v) & 1)
                if any(g[x] & xmask for x in X):
                    continue
                Y = tuple(v for v in range(n) if not (xmask >> v) & 1)
                Z = tuple(j for j, v in enumerate(Y) if g[v] & xmask)
                W = tuple(j for j in range(len(Y)) if j not in Z)
                a = tuple(tuple((g[v] >> x) & 1 for x in X) for v in Y)
                yg = restrict(g, Y)
                for r in (1, 2, 3):
                    key = (a, len(X), r)
                    if key not in incidence_cache:
                        H, _ = closure(a, len(X), r)
                        incidence_cache[key] = image_basis(a, dual_kernel(H, 1 << r), r)
                    rows = [v for v, _ in incidence_cache[key]]
                    if not rows:
                        zero_branches += 1
                        continue  # general zero branch relies on standard form, not arbitrary X
                    allowed_images = binary_span(rows)
                    directly_reachable = set()
                    for v in allowed_images:
                        directly_reachable.update(orbit(toggle(yg, v), W))
                    gg, constraints = gadget(yg, rows, Z)
                    assert connected(gg) and any(v.bit_count() % 2 == 0 for v in gg)
                    max_gadget = max(max_gadget, len(gg))
                    for bits in range(1 << math.comb(len(Y), 2)):
                        yh = graph_from_bits(len(Y), bits)
                        original_edges = [(u, v) for u, v in it.combinations(range(n), 2)
                                          if ((u in X) or (v in X)) and (g[u] >> v) & 1]
                        original_edges += [(Y[u], Y[v]) for u, v in it.combinations(range(len(Y)), 2)
                                           if (yh[u] >> v) & 1]
                        if not connected(from_edges(n, original_edges)):
                            continue
                        gh, same_constraints = gadget(yh, rows, Z)
                        assert constraints == same_constraints and connected(gh)
                        observed, nullity, exhaustive = lc_equations(gg, gh, constraints)
                        assert observed == (yh in directly_reachable), (g, X, r, yh, rows)
                        cases += 1
                        positive += observed
                        negative += not observed
                        nullspace_exhaustions += exhaustive
                        max_nullity = max(max_nullity, nullity)
    return dict(gadget_comparisons=cases, positive=positive, negative=negative,
                maximum_gadget_order=max_gadget, maximum_nullity=max_nullity,
                full_nullspace_crosschecks=nullspace_exhaustions,
                zero_image_supports_skipped=zero_branches,
                ordinary_lc_bfs_comparisons=ordinary_checks,
                ordinary_positive=ordinary_positive, ordinary_negative=ordinary_negative,
                scope='All connected labelled graphs of orders 2-4, independent supports, levels 1-3; '
                      'gadget primitive only. Zero-image non-standard supports skipped. '
                      'Ordinary LC comparison requires even-degree vertices for this implementation.')


def test_higher_level():
    subsets = list(it.combinations(range(6), 4)) + list(it.combinations(range(6), 5))
    m, r = len(subsets), 2
    a = [tuple(int(v in subset) for subset in subsets) for v in range(6)]
    g = from_edges(27, [(x, m + v) for x, subset in enumerate(subsets) for v in subset])
    h = from_edges(27, [(x, m + v) for x, subset in enumerate(subsets) for v in subset]
                   + [(m + u, m + v) for u, v in it.combinations(range(6), 2)])
    assert connected(g) and connected(h)
    # Every X-star is a minimal local set with unique stabilizer generator X_x.
    # The stars therefore form a common MLS cover whose types are exactly X/Z.
    # Solve for stabilizers supported inside each star, without a 2^27 enumeration.
    minimal_star_checks = 0
    for graph in (g, h):
        for x in range(m):
            star = (1 << x) | graph[x]
            equations = [row for v in range(27) if not (star >> v) & 1
                         for row in (1 << v, graph[v])]
            generators = nullspace(equations, 27)
            assert generators == [1 << x]
            minimal_star_checks += 1
    pair_counts = [sum(a[u][x] * a[v][x] for x in range(m))
                   for u, v in it.combinations(range(6), 2)]
    triple_counts = [sum(a[u][x] * a[v][x] * a[w][x] for x in range(m))
                     for u, v, w in it.combinations(range(6), 3)]
    assert set(pair_counts) == {10} and set(triple_counts) == {6}
    H, _ = closure(a, m, r)
    ones = (1,) * m
    assert all(v % 4 == 0 for v in H * Matrix(ones))
    target = (1 << 15) - 1
    assert image(a, ones, r) == target
    basis = image_basis(a, dual_kernel(H, 4), r)
    remaining, witness = target, (0,) * m
    for row, pre in reversed(basis):
        p = row.bit_length() - 1
        if (remaining >> p) & 1:
            remaining ^= row
            witness = tuple((x + y) % 4 for x, y in zip(witness, pre))
    assert remaining == 0 and image(a, witness, r) == target
    ordinary, nullity, exhaustive = lc_equations(g, h, exhaustive_limit=22)
    assert not ordinary
    rows = [v for v, _ in basis]
    gg, constraints = gadget((0,) * 6, rows, tuple(range(6)))
    gh, _ = gadget(graph_from_bits(6, target), rows, tuple(range(6)))
    generalized, gadget_nullity, gadget_exhaustive = lc_equations(gg, gh, constraints)
    assert generalized
    return dict(vertices=27, independent_support=21, outside_vertices=6, level=2,
                construction='Bipartite incidence of all 4- and 5-subsets of six vertices; '
                             'second graph adds the clique on those six vertices.',
                pair_common_neighbors=10, triple_common_neighbors=6,
                explicit_multiplicity=list(ones), recovered_multiplicity=list(witness),
                image_dimension=len(rows), ordinary_lc=False, ordinary_linear_nullity=nullity,
                ordinary_search_exhaustive=exhaustive, generalized_gadget_accepts=True,
                gadget_vertices=len(gg), gadget_linear_nullity=gadget_nullity,
                gadget_search_exhaustive=gadget_exhaustive,
                common_standard_form=True, minimal_local_star_checks=minimal_star_checks,
                scope='Diagnostic LU-but-not-LC control; no novelty claim for this construction.')


if __name__ == '__main__':
    started = time.monotonic()
    result = dict(status='IN_PROGRESS', sympy_version=sympy.__version__, human_verified=False,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  full_graph_lu_implementation=False)
    output = Path(__file__).with_name('recheck-results.json')
    for key, test in [('large_moduli', test_large_moduli), ('general_dual_kernel', test_general_dual_kernel),
                      ('complete_images', test_complete_images),
                      ('small_graphs', test_small_graphs), ('higher_level_control', test_higher_level)]:
        step_start = time.monotonic()
        result[key] = test()
        result[key]['elapsed_seconds'] = round(time.monotonic() - step_start, 3)
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({key: result[key]}), flush=True)
    result['status'] = 'PASS'
    result['elapsed_seconds'] = round(time.monotonic() - started, 3)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print('ALL RECHECKS PASSED', flush=True)
