Heisenberg-scaling sparse Hamiltonian learning with a fixed minimum query duration
Yuxuan Zhang
Version 1.0, 1 October 2026

Reporting manuscript: fixed-duration-hamiltonian-learning.tex
Website: https://yuxuanzhang1995.github.io/agentic-research/fixed-duration-hamiltonian-learning/
PDF: https://yuxuanzhang1995.github.io/assets/pdf/agentic/fixed-duration-hamiltonian-learning.pdf
Original problem: https://qiqc-op.com/problem/op_30954594cf01ebb3/

The manuscript gives the full original-scope proof candidate, including explicit
constants, unknown support, success probability and resource accounting.
Compile the standalone source with a standard LaTeX distribution, running
pdflatex twice to resolve cross-references.

proof/ preserves the original analytic candidate and resource supplement.
verification/frozen-reviews.json preserves the selected frozen claims and their
internal model reviews. The two reviews used fresh contexts within the same
model family. They do not establish external expert confirmation.

verification/diagnostics/ contains finite numerical controls and their saved
outputs. These Python scripts require NumPy and SciPy. They check specified
identities and examples, not the universal theorem or its computational
complexity. Their limitations are recorded in the outputs.

source-comparison.json describes the five checked primary-source interfaces.
The inherited methods are attributed in the paper. Historical novelty remains
unverified beyond this targeted comparison.

Human and AI contributions and affiliations are stated in the manuscript.
This package is a website release, not a Zenodo deposit or catalog acceptance.
