from fractions import Fraction as F
# Exact canonical equality example: V=I, means e_q,0,
# covariance derivatives 0,diag(1,-1/4), weight [[2,1],[1,3]].
v=F(1); w11=F(2); w12=F(1); w22=F(3)
assert v>F(1,2)
assert w11*w22-w12*w12>0
assert -F(1,4)==-1/(4*v*v)
print("faithfulness margin = 1/2 > 0: PASS")
print("weight determinant = 5 > 0: PASS")
print("canonical covariance residual = 0 == 0: PASS")
cost=v*w11+2*v*v*w22
assert cost==8
print("homodyne cost = SLD lower bound = 8: PASS")
# Strict homodyne first derivatives, using the analytic directions in proof.
e=F(1,3)
d=-8*e*v*v*w22
assert d==-8 and d<0
print("off-diagonal descent derivative = -8 < 0: PASS")
f=F(0)
d=-w22*(4*f*v*v+1)
assert d==-3 and d<0
print("variance-ratio descent derivative = -3 < 0: PASS")
b=F(1,2);h=F(1,3)
r=(v*b,2*v*v*h)
z=(w11*r[0]+w12*r[1],w12*r[0]+w22*r[1])
d=-2*(z[0]*z[0]+z[1]*z[1])
assert d==-F(325,18) and d<0
print("mean-misalignment descent derivative = -325/18 < 0: PASS")
# PSD real rank-one noise component gives strictly positive slack.
c=(F(1),F(-1));kappa=F(3)
slack=kappa*(w11*c[0]**2+2*w12*c[0]*c[1]+w22*c[1]**2)
assert slack==9 and slack>0
print("real rank-one noise slack = 9 > 0: PASS")
