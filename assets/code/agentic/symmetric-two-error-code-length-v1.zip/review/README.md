# Independent review

REVIEW.md and SOURCES.md give the analytic and literature assessments.
ASSESSMENT.json records scope, limitations, exact input hashes and outcomes.
The original input paths identify the research workspace; the release
copies the three computation modules into ../checks/ and the frozen proof
into ../candidate-reviewed.md.

The reviewer wrote independent_controls.py and check_coefficients.py in a
fresh model context. They construct their comparison targets independently
of the author's coefficient formulas. Their unchanged scripts expect a
clean-replay/ directory next to them containing moment3.py, ppt3.py and
certify_dual.py.

To rerun them without modifying this release, copy the review scripts into
a fresh directory, place the three modules from ../checks/ in its
clean-replay/ subdirectory, and execute:

~~~sh
python independent_controls.py
python check_coefficients.py
~~~

The first program includes the exact 21-qubit erasure calculation and direct
moment construction. It can take several minutes. Floating diagnostic values
may vary by platform; its tolerance is not used by the exact exclusion
checker. The raw ill-scaled residual retained in the diagnostic JSON is
explained in REVIEW.md.

The review reports an additional negative control: a generic complex
five-qubit projector, tested at detection depth one, violates the lifted
constraint. Its measured output is preserved in NEGATIVE-CONTROL.json;
the two commands above rerun the positive controls and coefficient audit,
not that separate invocation.

ASSESSMENT.json and INPUT-MANIFEST.json retain the original review record.
The review identifies four nonfatal presentation/attribution issues; the
public main.tex resolves them. The frozen candidate is preserved unchanged.
