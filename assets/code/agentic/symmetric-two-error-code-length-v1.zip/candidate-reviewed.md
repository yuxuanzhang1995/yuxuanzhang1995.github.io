# Minimum length nineteen for two-error-correcting symmetric qubit codes

Candidate v1, 10 November 2026. This is a computer-assisted proof candidate,
supported by same-agent derivation and exact rational certificates. Independent
proof review and a comprehensive priority assessment are pending. No release
or catalog-status change is implied.

## Statement and original scope

Let Q be a two-dimensional subspace of Sym^n(C^2) that detects every Pauli
operator of weight at most four. Then n >= 19.

Combined with the nineteen-qubit construction of Aydin, Alekseyev and Barg,
this gives n_min^PI(2) = 19, as asked in Q005, permanent original
op_a72722e455d85d55. The lower bound covers arbitrary complex Dicke
coefficients, both parities of n, degeneracy, and codes without an imposed
logical symmetry. It is a statement about pointwise symmetric codewords.
It is not a lower bound on general, nonsymmetric quantum codes, nor a proof
of the analogous conjecture for all numbers of correctable errors.

Lengths n <= 8 are excluded by the quantum Singleton bound
n >= 2(d-1) + log_2 K = 9. Equivalently, for 5 <= n <= 8, correcting any
four erasures would permit recovery from either of two disjoint sets of
n-4 qubits, contradicting no-cloning. For n <= 4, detecting the entire
operator algebra already precludes a two-dimensional code.
Sections below exclude each n = 9,...,18
individually. No monotonicity in the length of a symmetric code is assumed.
The existence construction at nineteen is inherited, not new work here.

## 1. A necessary three-copy moment

Write j=n/2, V=V_j=Sym^n(C^2), N=n+1, K=2, and let P be the
orthogonal projector onto Q. Choose the Condon--Shortley angular-momentum
bases throughout. The irreducible tensor operators T_{lq} on V are
Hilbert--Schmidt orthonormal, with entries

    (T_{lq})_{m,m'} = (-1)^(j-m') <j,m; j,-m' | l,q>.

Tensor rank l is contained in the span of degree-l polynomials in collective
spin components. Expanding these polynomials into single-qubit Pauli products
shows that rank l <= 4 is in the compressed weight-at-most-four error space.
Consequently the original Knill--Laflamme conditions imply

    P E P = Tr(P E) P / K,             E in span{T_lq: 0 <= l <= 4}.    (1)

Only this necessary direction is used. The full intrinsic-depth/distance
correspondence is also established by Kubischta--Teixeira, Proposition B2.

Let U denote the spin-j representation of SU(2), and define the unnormalized
moment

    Omega = integral (U P U*) tensor (U P U*) tensor (U P U*) dU.       (2)

Then Omega is positive, has trace K^3=8, commutes with SU(2) and the
permutations S3 of the three copies, and vanishes on the fully antisymmetric
three-copy subspace. The last assertion follows from rank(P)=2:
the third exterior power of its range is zero. This is not a symmetric-
subspace restriction on the three copies: the standard S3 representation
must be retained.

For F13 swapping copies 1 and 3, direct index contraction gives

    Tr_3[(I tensor I tensor E) F13 P^tensor3] = P E P tensor P.

Equation (1), its invariance under spin rotations, and integration therefore
give the operator identity

    Tr_3[(I tensor I tensor E)(F13 - I/K) Omega] = 0
                     for every tensor rank 0 <= l <= 4.              (3)

The l=0 identities retain the projector/idempotence information; they are
not dropped as redundant normalization conditions.

There is one further necessary positivity condition. Let C be the unitary
spin-flip matrix, C|j,m> = (-1)^(j+m)|j,-m>, and put

    Theta_3(Omega) = (I tensor I tensor C) Omega^(T_3)
                                      (I tensor I tensor C*).

Each term in (2) is a tensor product of positive matrices, so

    Theta_3(Omega) >= 0.                                                 (4)

Theta_3 is partial time reversal. It preserves rotational invariance and
acts on a rank-l tensor on copy 3 by (-1)^l. Condition (4) is stronger than
ordinary positivity of Omega and the scalar two-copy shadow constraints.

All coefficients below are real in the chosen coupled basis. If P is complex,
complex conjugation maps (2) to the moment of P-bar, because U-bar again
ranges over SU(2), and conjugates the whole error space into itself. Average
these two *moments*. Positivity, (3), (4), trace and permutation properties
are preserved. Thus a real symmetric moment is necessary even for a complex
code. We never replace P by its real part or assume real codewords.

## 2. Complete finite block parametrization

Couple the first two spins to a=0,...,n, and then couple a with j to total J.
The basis is |((j j)a,j)J,M>. Let

    I_J = {a integer: |J-j| <= a <= min(n,J+j)}.

J runs from 0 or 1/2 to 3j in unit steps. Rotational invariance gives

    Omega = direct_sum_J (X_J tensor I_(2J+1)),     X_J >= 0.           (5)

The swap F12 acts by D_J(a,a)=(-1)^(n-a); the swap F13 acts by

    R_J(a,b) = (-1)^n sqrt((2a+1)(2b+1)) { j j a ; j J b }.           (6)

Braces denote a Wigner 6j symbol. The six matrices generated by D_J,R_J
represent S3. We retain every multiplicity, including the standard component.

Here is an exact parametrization of the S3-invariant positive blocks with no
sign representation. Let E_J select the +1 eigenspace of D_J. For a positive
matrix H_J on that space take the group average of E_J H_J E_J*. Every
required block is obtained this way. To see surjectivity, decompose an
invariant X into X_triv + X_std, with no sign component. The positive seed
X_triv + 2 E_J X_std E_J twirls to X. In a standard S3 irrep the +1
eigenspace of a transposition has dimension one out of two. Thus this
parametrization introduces no hidden ansatz and discards no complex code.

We rescale it rationally for exact certification. Define

    Delta(a,b,c)^2 = (a+b-c)!(a-b+c)!(-a+b+c)!/(a+b+c+1)!;
    t_Ja = sqrt(2a+1) Delta(j,j,a) Delta(j,J,a).

All factorial arguments are nonnegative integers in an allowed triangle.
Choose a positive power of two q_Ja so that d_Ja=(t_Ja q_Ja)^2 is in [1,4).
Set s_Ja=t_Ja q_Ja and X_J=diag(s_J) Z_J diag(s_J). The conjugated swap

    R'_J = diag(s_J)^(-1) R_J diag(s_J)

is rational: writing the 6j symbol as the product of its four triangle
factors and its Racah factorial sum cancels all radicals. Let W_{J,g}
be the columns in the D_J=+1 sector of the corresponding rational S3 matrix.
The variable used in the certificate is H_J >= 0 and

    Z_J = (1/6) sum_g W_{J,g} H_J W_{J,g}^T.                          (7)

In these scaled coordinates the trace condition is

    sum_J (2J+1) sum_(a in I_J) d_Ja (Z_J)_aa = 8.                    (8)

## 3. Lifted detection equations

Let A_ab^(lq): V_b -> V_a be the normalized rank-l tensor with entries
(-1)^(b-m_b)<a,m_a; b,-m_b|l,q>. It exists when |a-b| <= l <= a+b.
Contract (3) with A_ab^(l0) on the first two copies. Summing over M gives

    h_Jab^l = (2J+1)(-1)^(b+j+J) { a j J ; j b l },

    sum_J h_Jab^l [X_J R_J - X_J/K]_(b,a) = 0.                      (9)

Rotational covariance makes q=0 sufficient: the invariant contraction pairs
only equal tensor ranks, and all q components have the same reduced equation.
All allowed l=0,...,4 and all a,b are used, not just the diagonal tests.

For exact rational arithmetic set

    kappa_ab,l = sqrt((2a+1)(2b+1)) Delta(j,j,a) Delta(j,j,b)
                                          Delta(a,b,l) Delta(j,j,l),
    c_Jab,l = h_Jab^l s_Ja s_Jb / kappa_ab,l.

The c's are rational. Explicitly they are (2J+1)(-1)^(b+j+J) times
Delta(j,J,a)^2 Delta(j,J,b)^2 times the Racah sum for {a j J;j b l},
times q_Ja q_Jb. Since kappa is positive for every allowed test, (9) becomes

    sum_J c_Jab,l [Z_J (R'_J)^T - Z_J/K]_(b,a) = 0.                 (10)

The transpose in (10) is required by the nonorthogonal rational scaling.
The checker retains it explicitly.

## 4. Scalar and shadow inequalities, and partial time reversal

We also retain the inherited scalar necessary inequalities; they do not
assume purity of the error model. With unnormalized enumerators

    A_l = sum_q |Tr(P T_lq)|^2,
    B_l = sum_q Tr(P T_lq* P T_lq),

one has A_l >= 0, B_l - A_l/K >= 0. The latter is the Hilbert--Schmidt
Cauchy--Schwarz inequality on the K-dimensional code subspace. The
MacWilliams transform in this normalization is B=M A, where

    M_la = (-1)^(n+a+l)(2l+1) { j j a ; j j l }.                     (11)

Using Tr_3(Omega)/K and (5), the enumerators are linear functions of H:

    A_l = (1/K) sum_J (2J+1) sum_a f_la d_Ja (Z_J)_aa,
    f_la = (-1)^(n+a)(2l+1) { j j a ; j j l }.                       (12)

Time reversal of P preserves positivity and multiplies its Hermitian
rank-l component by (-1)^l. The polarized CP-twirl enumerators therefore give
the further inequalities M diag((-1)^l) A >= 0. Formula (11) and these
quadratic bounds are established enumerator tools. In particular the
normalization is A_0=K^2/N and sum_l A_l=K, not sum normalized-A=K.

To impose (4), write Y_J for the scaled blocks of Theta_3(Omega). For each
fixed a,b, they are obtained from the X_J blocks by the recoupling transform

    (Theta_3 X)_J,ab = sum_J' L_ab(J,J') X_J',ab,
    L_ab(J,J') = sum_l (-1)^l (2l+1) h_Jab^l h_J'ab^l /(2J+1).       (13)

Here |a-b| <= l <= min(n,a+b). To derive (13), expand an invariant operator
in the scalar contractions sum_q (-1)^q A_ab^(lq) tensor T_l,-q.
Their reduced matrix elements are (2l+1)h_Jab^l/(2J+1), and 6j
orthogonality inverts the expansion. Time reversal contributes (-1)^l.

In rational coordinates the transfer matrix is

    T_ab(J,J') = sum_l (-1)^l(2l+1) kappa_ab,l^2 c_Jab,l c_J'ab,l
                                      /[(2J+1)d_Ja d_Jb],
    (Y_J)_ab = sum_J' T_ab(J,J') (Z_J')_ab.                          (14)

All entries in (14) are rational. The transfer is involutive. Since partial
time reversal on copy 3 commutes with F12, Y_J is block diagonal in the two
parities of a. Both parity blocks must be positive. Unlike Omega, Y is not
required to have no sign representation or to commute with all of S3.

Equations (7),(8),(10),(12),(14) give a finite SDP containing every actual
code moment. The proof only requires this containment, not sufficiency for
constructing a code from a feasible moment.

## 5. Exact infeasibility certificates

Flatten the independent upper-triangular entries of the seed matrices H_J
into x. Equations (8),(10) are A x=b, where b=(8,0,...,0). Let G x>=0
collect A_l, B_l-A_l/K, and the shadow inequalities from Section 4, and
let L_k(x) be each parity block of Y_J. Necessary feasibility is

    A x=b, G x>=0, H_J(x)>=0, L_k(x)>=0.                             (15)

Each file certificate-ppt-nN.json contains rational y, nonnegative rational
lambda, and rational positive matrices Q_k. Define the seed slack matrices
S_J by the exact adjoint identity, valid for all symmetric seed matrices:

    y^T A x - lambda^T G x - sum_k Tr(Q_k L_k(x))
                                           = sum_J Tr(S_J H_J(x)).  (16)

The checker constructs S_J from the left side; S_J is not trusted input.
For off-diagonal seed variables it divides the linear coefficient by two,
as required by the trace pairing. It verifies

    lambda >= 0, Q_k > 0, S_J > 0, and y^T b < 0                   (17)

using rational arithmetic only. Positive definiteness is certified by exact
LDL pivots, without numerical eigenvalue thresholds. For a feasible x,
(15)--(17) would give y^T b >= 0, a contradiction.

All ten lengths have passed these tests:

| n | scalar multipliers | positive Q pivots | positive seed-slack pivots |
|---|---:|---:|---:|
| 9 | 30 | 75 | 40 |
| 10 | 33 | 91 | 48 |
| 11 | 36 | 108 | 57 |
| 12 | 39 | 127 | 67 |
| 13 | 42 | 147 | 77 |
| 14 | 45 | 169 | 88 |
| 15 | 48 | 192 | 100 |
| 16 | 51 | 217 | 113 |
| 17 | 54 | 243 | 126 |
| 18 | 57 | 271 | 140 |

There are 2,496 positive matrix pivots and 435 nonnegative multipliers.
Every right-hand side is a negative rational close to -1. For n=18 it is

    -247588007857138991185537236974901 /
      247588007857076054979824844800000.

The decimal margins are not used in the proof. certificate-summary.json
records the full exact values and individual check outputs. Numerical
solver statuses were often 'optimal_inaccurate'; none of those statuses is
used as a certificate. Rounding was followed by exact recomputation of all
dual slacks and their signs.

Without (4), the base three-copy PSD relaxation still has an exact feasible
n=18 point: certificate-base-n18.json. Thus the failed scalar/shadow route
is not being re-credited, and ordinary third-moment positivity alone is not
the claimed exclusion mechanism.

## 6. Controls, reproduction, and limits

The supplied controls include direct Clebsch--Gordan contractions checking
the swap and reduced-tensor conventions, including seven exact contractions
at lengths 9, 10, 17 and 18; independent partial-transpose
construction in small full tensor spaces; and exact erasure Gram checks on
actual 7-qubit distance-three and 21-qubit distance-five codes. A direct
third moment of the 7-qubit code passes the equations. Direct complex-projector
controls also verify the scalar transform, trace normalization and shadow
signs independently of the rational coefficient generator. The 19-qubit SDP is
numerically feasible; this is a diagnostic control, while the existence
theorem comes from the published construction.

The certificate checker needs no optimizer and can regenerate all rational
coefficients from n. A clean reproduction must copy only the frozen proof,
checker modules and ten certificate JSON files into an empty directory,
then execute certify_dual.py N --verify --clean for N=9,...,18. It must not
load the cached matrices or rerun a numerical search. The release manifest
and clean-reproduction record identify the exact versions used.

The bottleneck for human review is the necessity and completeness of the
reduction, especially (3), the S3 seed parametrization, the all-complex
argument and the scaled partial-time-reversal map (14). Arithmetic success
alone does not establish these facts. They are justified above, but have
only same-agent review in this run.

## Primary-source attribution

* Aydin--Alekseyev--Barg, [Quantum 8, 1321 (2024)](https://doi.org/10.22331/q-2024-04-30-1321),
  [arXiv:2310.05358v3](https://arxiv.org/html/2310.05358v3), Section 7:
  inherited computer-assisted existence at nineteen; Theorem 5.3 and
  Example 5 give the explicit 21-qubit control. Their nonexistence comment
  concerns a restricted parity form and supplies no all-complex proof.
* Bond et al., [arXiv:2603.10981v1](https://arxiv.org/html/2603.10981v1),
  Conjecture 3.1 and Section 3.1: numerical minimum-length conjecture.
* Kubischta--Teixeira, [arXiv:2604.16023v2](https://arxiv.org/html/2604.16023v2),
  Appendix A and Proposition B2: intrinsic enumerators, SU(2) transform and
  distance correspondence. Their matrix-valued theory addresses a different
  source of multiplicities; its SU(2) symmetric-power application is scalar.
* Teixeira, [arXiv:2605.15372v1](https://arxiv.org/html/2605.15372v1),
  Corollary 1: the inherited Racah-polynomial form of the scalar transform.
* Angles Munne--Huber, [arXiv:2603.19901v1](https://arxiv.org/html/2603.19901v1):
  exact certificates for general quantum-code SDPs. Rigorous rational SDP
  certification and higher-moment coding bounds are established methodology.
  Their displayed bounds do not prove the symmetric distance-five minimum.

The proposed new contribution is the original-specific exclusion through
eighteen, with the three-copy PPT reduction and the accompanying certificates.
A bounded primary-source search did not locate the same result. This is not
an exhaustive novelty certification. Full-original coverage and novelty are
separate judgments; independent review remains the next step.
