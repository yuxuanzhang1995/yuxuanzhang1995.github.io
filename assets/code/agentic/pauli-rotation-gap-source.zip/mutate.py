#!/usr/bin/env python3
"""Mutation test for check_pauli_rotation_gap.py (standard library only).

Each mutant is ONE single-point text edit of the checker (the old text must occur exactly once).  Every mutant must
exit nonzero.  Mutants run from memory (source piped to the interpreter on stdin), so the only file written is
MUTATION_REPORT.txt.  Exit status 1 if any mutant survives or if the unmutated checker does not reproduce
expected_stdout.txt byte for byte.
"""
import subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = (HERE / "check_pauli_rotation_gap.py").read_text()
EXPECTED = (HERE / "expected_stdout.txt").read_text()

MUTANTS = [  # (tag aimed at, description, old text, new text)
    ("[B1]", "Baer-Haah lower bound: numerator 4^n+16 -> 4^n+15",
     "return Fr(q + 16, 16 * (q - 1))", "return Fr(q + 15, 16 * (q - 1))"),
    ("[W1]", "witness: one of the 30 hyperplane wedges dropped",
     "W = {HM[h]: 1 for h in HYP}", "W = {HM[h]: 1 for h in HYP[1:]}"),
    ("[W1]", "affine-flat test uses OR instead of XOR",
     "if all((lm >> (u ^ v)) & 1 for u in lin for v in lin):", "if all((lm >> (u | v)) & 1 for u in lin for v in lin):"),
    ("[W2]", "Z-charge: factor 2 dropped (c_s = |m| - |m & odd_s|)",
     "return popc(m) - 2 * popc(m & ODD[s])", "return popc(m) - popc(m & ODD[s])"),
    ("[W3]", "echelon coordinates: delete the highest instead of the lowest set bit of s",
     "p = (s & -s).bit_length() - 1  # lowest set bit", "p = s.bit_length() - 1  # lowest set bit"),
    ("[W3]", "GL(3,2) enumeration admits singular matrices (c2 = c0 + c1)",
     "if c1 == c0 or c2 in (c0, c1, c0 ^ c1):", "if c1 == c0 or c2 in (c0, c1):"),
    ("[W4]", "wedge-sign parity test inv & 1 -> inv & 2",
     "if inv & 1:", "if inv & 2:"),
    ("[W5]", "RM(1,3) built from half of the linear parts",
     "for s in range(8) for c in (0, 1)})", "for s in range(4) for c in (0, 1)})"),
    ("[W6]", "Hadamard sign dropped (sqrt2 H -> all-ones block)",
     "(x | bj, (-1, 0) if x & bj else (1, 0))", "(x | bj, (1, 0) if x & bj else (1, 0))"),
    ("[W6]", "wedge sorting sign ignored (every permutation even)",
     "return (-1 if inv & 1 else 1), tuple(sorted(seq))", "return (1 if inv & 1 else 1), tuple(sorted(seq))"),
    ("[W6]", "CNOT_ct replaced by a Toffoli gate (a non-affine permutation) for most pairs",
     "return lambda x: [(x ^ (((x >> c) & 1) << t), (1, 0))]",
     "return lambda x: [(x ^ (((x >> c) & (x >> (3 - t)) & 1) << t), (1, 0))]"),
    ("[W7]", "local reduction of Y uses sqrt2 H only (S omitted)",
     '(1, 1): "HS"}', '(1, 1): "H"}'),
    ("[W7]", "Pauli phase i^{a.b} dropped in P_{a,b} (Y -> XZ, not Hermitian)",
     "return x ^ a, (popc(a & b) + 2 * dot(b, x)) & 3", "return x ^ a, (2 * dot(b, x)) & 3"),
    ("[W8]", "neutral count uses charge >= 0 instead of charge == 0",
     "neutral = {s: sum(1 for h in HYP if charge(s, HM[h]) == 0)", "neutral = {s: sum(1 for h in HYP if charge(s, HM[h]) >= 0)"),
    ("[W9]", "fermionic hopping sign dropped in H_P",
     "s = (popc(m & ((1 << hi) - (1 << (lo + 1)))) + dot(b, x)) & 1", "s = dot(b, x) & 1"),
    ("[W9]", "H_P^2 = (-1)^{a.b} H'^2: the sign (-1)^{a.b} dropped",
     "    sg = -1 if popc(a & b) & 1 else 1\n    y = vec", "    sg = 1\n    y = vec"),
    ("[W9]", "Pi_0 polynomial lacks the charge +-8 factor (c = 2, 4, 6 only)",
     "CSQ8 = (4, 16, 36, 64)", "CSQ8 = (4, 16, 36)"),
    ("[W9]", "claimed eigenvalue 238/255 -> 237/255",
     "total == {m: 147456 * 238 for m in W}", "total == {m: 147456 * 237 for m in W}"),
    ("[W10]", "claimed Casimir value 1088 -> 1089",
     "== {m: 1088}", "== {m: 1089}"),
    ("[S1]", "divisibility modulus 2^m -> 2^(m+1)",
     "all(k % 2 ** m == 0 for zm", "all(k % 2 ** (m + 1) == 0 for zm"),
    ("[S2]", "Bose-Burton: forbidden subspace dimension shifted by one",
     "for v in range(dm, n):", "for v in range(dm + 1, n):"),
    ("[S2]", "S_j replaced by Z_j (phase i -> -1)",
     "[(x, (0, 1) if x & bj else (1, 0))]", "[(x, (-1, 0) if x & bj else (1, 0))]"),
    ("[S3]", "Lambda^4 C^8 constant 3456 (= 64*63*6/7) -> 3455",
     "(3456 if i == j else 0) - T[i][j]", "(3455 if i == j else 0) - T[i][j]"),
    ("[S4]", "corollary margin (4^n - 3*2^n - 8) -> (4^n - 3*2^n - 7)",
     "top - b2 == Fr(d * d - 3 * d - 8,", "top - b2 == Fr(d * d - 3 * d - 7,"),
    ("[C1]", "code wedges selected by a 3-element XOR test",
     "if el[0] ^ el[1] ^ el[2] ^ el[3]:", "if el[0] ^ el[1] ^ el[2]:"),
    ("[N1]", "random sign patterns degenerate to all +1 (the witness itself)",
     "qs.append(rq_lie({HM[h]: (-1 if (bits >> i) & 1 else 1)", "qs.append(rq_lie({HM[h]: (1 if (bits >> i) & 1 else 1)"),
    ("[N2]", "weight-then-binary order degenerates to the binary order",
     '("weight-then-binary", [(popc(x), x) for x in range(D)])', '("weight-then-binary", [(0, x) for x in range(D)])'),
    ("[N3]", "neutrality test == 0 -> != 0",
     "z = sum(1 for s in range(1, D) if charge(s, m) == 0)", "z = sum(1 for s in range(1, D) if charge(s, m) != 0)"),
    ("[E1]", "theta grid 17 -> 8 angles (aliases the frequency-8 terms)",
     "E1_THETAS = 17", "E1_THETAS = 8"),
    ("[E1]", "eigenvalue 14/15 -> 13/15",
     "abs(Kf - (14 / 15) * f0)", "abs(Kf - (13 / 15) * f0)"),
    ("[E1]", "f(1) evaluated with B0 = {1,...,8} (not a hyperplane)",
     "[[1.0 if r == c else 0.0 for c in range(8)]", "[[1.0 if r == c + 1 else 0.0 for c in range(8)]"),
    ("[T]", "claimed norm 14/15 -> 13/15",
     "norm = Fr(14, 15)", "norm = Fr(13, 15)"),
]


NOTES = [
    "Notes.",
    "- The round-49 frozen checker's surviving mutant (fermionic hopping sign dropped) is killed here (the hopping-sign",
    "  mutant above): [W9] pins the hopping signs against the Leibniz-rule wedge expansion of drho(P).",
    "- Equivalent edits, which no correct checker can detect, were deliberately not included: e^{i theta P} ->",
    "  e^{-i theta P} in [E1] (the theta-average is symmetric); any other grid of N equally spaced angles with N not",
    "  dividing 2, 4, 6 or 8 (N = 5, 7 or N >= 9; only the frequencies +-2, +-4, +-6, +-8 occur); a global sign on a",
    "  Clifford generator (Lambda^8(-C) = Lambda^8(C)); the bit-reversed or Gray-code order in place of the binary order",
    "  (shown to give the same w in [W4]); re-listing the 30 hyperplanes in another order.",
]


def run(src):
    r = subprocess.run([sys.executable, "-"], input=src, capture_output=True, text=True, cwd=HERE, timeout=900)
    fails = [l for l in r.stdout.splitlines() if l.startswith("FAIL ")]
    err = r.stderr.strip().splitlines()
    return r.returncode, r.stdout, fails, (err[-1] if err else "")


def main():
    code, out, fl, _ = run(SRC)
    base_ok = code == 0 and out == EXPECTED and not fl
    lines = ["Mutation report for check_pauli_rotation_gap.py: %d single-point mutants; each must exit nonzero." % len(MUTANTS),
             "baseline (unmutated): exit %d, FAIL lines %d, stdout identical to expected_stdout.txt: %s"
             % (code, len(fl), "yes" if out == EXPECTED else "NO"), ""]
    survivors = []
    for n, (tag, name, old, new) in enumerate(MUTANTS, 1):
        assert SRC.count(old) == 1, old
        src = SRC.replace(old, new)
        code, out, fl, err = run(src)
        if code == 0:
            survivors.append("M%02d" % n)
        tags = " ".join(l.split()[1] for l in fl)
        lines += ["M%02d %s %s" % (n, tag, name), "    edit: %r -> %r" % (old, new),
                  "    exit %d | FAIL lines %d%s" % (code, len(fl), (" | failing: " + tags) if fl else
                                                     (" | stderr: " + err[:120] if err else ""))]
        print(lines[-3], "->", "killed" if code else "SURVIVED", flush=True)
    lines += ["", "summary: %d/%d mutants exit nonzero; survivors: %s" % (len(MUTANTS) - len(survivors), len(MUTANTS),
                                                                       " ".join(survivors) if survivors else "none")]
    summary = lines[-1]
    (HERE / "MUTATION_REPORT.txt").write_text("\n".join(lines + [""] + NOTES) + "\n")
    print(summary)
    sys.exit(0 if base_ok and not survivors else 1)


if __name__ == "__main__":
    main()
