"""Targeted review controls, distinct from the candidate's Fock backend.

Build exact probabilities from powers of a rational complex quadratic form.
Use hypergeometric reduction matrices and kernel projectors, not the candidate
reduction spectrum or triangular projector formula, for the oracle comparison.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb, factorial
from functools import lru_cache
import json, sys, time
import numpy as np
import sympy as sp

BASE=Path(__file__).resolve().parents[1]/'results'
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from gaussian_prefix import evaluator  # implementation under test only

def add(a,b):return (a[0]+b[0],a[1]+b[1])
def mul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def norm(a):return a[0]**2+a[1]**2
def conj(a):return (a[0],-a[1])
zero=(F(0),F(0));one=(F(1),F(0))

@lru_cache(None)
def occ(m,n):
    if m==1:return ((n,),)
    return tuple((a,)+tail for a in range(n+1) for tail in occ(m-1,n-a))

def facvec(v):
    z=1
    for a in v:z*=factorial(a)
    return z

def choose(v,u):
    z=1
    for a,b in zip(v,u):
        if b>a:return 0
        z*=comb(a,b)
    return z

def rise(a,n):
    z=F(1)
    for k in range(n):z*=a+k
    return z

def fall(a,n):return 0 if n>a else factorial(a)//factorial(a-n)

def unitary(m):
    U=[[one if i==j else zero for j in range(m)] for i in range(m)]
    for i in range(m-1):
        a,b=U[i][:],U[i+1][:]
        U[i]=[add(mul((F(3,5),F(0)),x),mul((F(4,5),F(0)),y)) for x,y in zip(a,b)]
        U[i+1]=[add(mul((F(-4,5),F(0)),x),mul((F(3,5),F(0)),y)) for x,y in zip(a,b)]
    phases=[one,(F(3,5),F(4,5)),(F(0),F(1)),(F(5,13),F(12,13))]
    U=[[mul(x,phases[j%len(phases)]) for j,x in enumerate(row)] for row in U]
    for i in range(m):
        for j in range(m):
            s=zero
            for k in range(m):s=add(s,mul(U[i][k],conj(U[j][k])))
            assert s==(one if i==j else zero)
    return U

def quadratic_powers(U,p):
    m=len(U);q={}
    for i in range(m):
        for j in range(m):
            b=zero
            for k in range(m):b=add(b,mul(U[i][k],U[j][k]))
            v=[0]*m;v[i]+=1;v[j]+=1;v=tuple(v)
            q[v]=add(q.get(v,zero),b)
    powers=[{(0,)*m:one}]
    for a in range(p):
        out={}
        for u,x in powers[-1].items():
            for v,y in q.items():
                w=tuple(i+j for i,j in zip(u,v));out[w]=add(out.get(w,zero),mul(x,y))
        powers.append(out)
    return powers

def probabilities(m,N,powers):
    denom=4**(N//2)*factorial(N//2)*rise(F(m,2),N//2)
    p={v:norm(powers[N//2].get(v,zero))*facvec(v)/denom for v in occ(m,N)}
    assert sum(p.values())==1 and min(p.values())>=0
    return p

def reduced(p,N,j):
    m=len(next(iter(p)))
    return {u:sum(pv*choose(v,u) for v,pv in p.items())/comb(N,j) for u in occ(m,j)}

@lru_cache(None)
def reduction(m,k,j):
    return sp.Matrix([[sp.Rational(choose(v,u),comb(k,j)) for v in occ(m,k)] for u in occ(m,j)])

@lru_cache(None)
def kernel_projector(m,l):
    R=reduction(m,l,l-1)
    return sp.eye(len(occ(m,l)))-R.T*(R*R.T).inv()*R

def c_coherent(m,N,l,a):
    return F(factorial(l)**2,4**a*factorial(a)**2*factorial(l-2*a))*fall(N//2,l-a)*rise(F(m+N,2),a)/(rise(F(m,2),l)*fall(N,l))

def pair_diagonal(powers,v,coeff):
    return sum(c*sum(choose(v,u)*norm(z)*facvec(u) for u,z in powers[a].items()) for a,c in enumerate(coeff))

def beta_monic(m,j):
    moments=[sp.Rational(factorial(a))/sp.rf(sp.Rational(m+1,2),a) for a in range(2*j+1)]
    if j==0:return [F(1)]
    G=sp.Matrix([[moments[a+b] for b in range(j)] for a in range(j)])
    rhs=sp.Matrix([-moments[a+j] for a in range(j)])
    return [F(x) for x in G.inv()*rhs]+[F(1)]

def oracle_control(m,N,l,dc,h):
    U=unitary(m);powers=quadratic_powers(U,N//2);p=probabilities(m,N,powers)
    P=kernel_projector(m,l)
    red=reduced(p,N,l);vred=sp.Matrix([sp.Rational(red[v]) for v in occ(m,l)])
    W=P*vred
    d=[c_coherent(m,N,l,l//2)*a/fall(l,2*j) for j,a in enumerate(beta_monic(m,l//2))]
    expected_top=sp.Matrix([sp.Rational(pair_diagonal(powers,v,d)) for v in occ(m,l)])
    assert W==expected_top
    go={s:[i%s for i in range(m)] for s in range(1,l+1)}
    masked=[]
    for v,w in zip(occ(m,l),W):
        S=[i for i,x in enumerate(v) if x==1];s=len(S)
        keep=l-sum(x>0 for x in v)<dc and (s==0 or len({go[s][i] for i in S})==s)
        masked.append(w*sp.Rational(s**s,factorial(s)) if keep and s else (w if keep else 0))
    A=P*sp.Matrix(masked);ell=sum(h);R=reduction(m,ell,l)
    # Recover the lift singular value directly on a nonzero kernel vector.
    witness=next(P[:,i] for i in range(P.cols) if P[:,i].dot(P[:,i])!=0)
    t=(R.T*witness).dot(R.T*witness)/witness.dot(witness)
    expected=(R[:,occ(m,ell).index(h)].T*A)[0]/t
    Uf=np.array([[complex(float(a),float(b)) for a,b in row] for row in U])
    actual,patterns,size=evaluator(Uf,N,l,dc,h,go)
    error=abs(complex(actual)-float(expected))
    assert error<2e-10,(m,N,l,expected,actual,error)
    return {'m':m,'N':N,'l':l,'deficit_cutoff':dc,'prefix':h,'exact_prefix':str(expected),'float_error':error,'occupations':len(red),'ring_max':size,'top_projection_exact':True}

def symbolic_checks():
    m,N,k,l=sp.symbols('m N k l',positive=True)
    b=(m-1)/2
    rc=(l+1)**2*(N+m+l)/((m+2*l)*(m+2*l+2)*(N-l-1))
    rh=(l+b)/(l+b+2)*(((l/2+1)*(l/2+b))/((l+b)*(l+b+1)))**2
    rf=((l+1)*(l+2))**2/sp.prod(m+2*l+i for i in range(4))
    rb=(l+1)**2*(m+l-1)**2*(N+m+l)**2/((N-l-1)**2*sp.prod(m+2*l+i for i in (-1,0,1,2)))
    assert sp.factor(rc**2*rh/rf-rb)==0
    ratio_measure=(l+1)*(l+2)*(m+2*l-1)/((m+l)*(m+l-1)*(m+2*l+3))
    ratio_reduce=((l+1)*(l+2))**2*(m+k+l)*(m+k+l+1)/((k-l)*(k-l-1)*sp.prod(m+2*l+i for i in range(4)))
    expected=(l+1)/(l+2)*(m+l-1)/(m+l)*(k-l)*(k-l-1)/(N-l-1)**2*(N+m+l)**2/((m+k+l)*(m+k+l+1))
    assert sp.factor(rb*ratio_measure/ratio_reduce-expected)==0
    # Source T4 normalization equals the candidate f_l for symbolic dimensions.
    source_over_fl=(m-1)/(2*l+m-1)*(m+l-1)/(m-1)*(m+2*l-1)/(m+l-1)
    assert sp.factor(source_over_fl-1)==0
    return 3

def moment_controls():
    rows=[]
    for m,N in [(2,10),(3,10),(5,6)]:
        powers=quadratic_powers(unitary(m),N//2);p=probabilities(m,N,powers);count=0
        for l in range(N+1):
            d=[c_coherent(m,N,l,a)/fall(l,2*a) for a in range(l//2+1)]
            red=reduced(p,N,l)
            for v in occ(m,l):
                assert pair_diagonal(powers,v,d)==red[v],(m,N,l,v)
                count+=1
        rows.append({'m':m,'N':N,'exact_occupation_comparisons':count})
    return rows

def rounding_control():
    # Nearest 3-bit dyadic entries of the real 3/5,4/5 rotation.
    vnorm=F(5,8)**2+F(6,8)**2
    parent=F(1,2);children=vnorm**2/2
    assert parent-children==F(375,8192)>0
    return {'m':2,'N':2,'encoded_column_norm_squared':str(vnorm),'one_photon_prefix':str(parent),'sum_two_photon_children':str(children),'inconsistency':str(parent-children),'meaning':'Small-photon raw formulas lose exact consistency after matrix rounding. This is an implementation-proof omission, not a counterexample to the sampling theorem; a stability bound repairs it.'}

def main():
    start=time.time();report={'symbolic_identities':symbolic_checks(),'exact_reductions':moment_controls()}
    report['prefix_controls']=[oracle_control(*x) for x in [(3,8,8,8,(4,3,1)),(5,6,4,2,(2,1,1,1,1)),(4,8,4,2,(3,2,1,2))]]
    report['small_branch_rounding']=rounding_control();report['elapsed_seconds']=time.time()-start
    report['status']='pass';report['limits']='Exact finite controls and symbolic rational identities, not an independent expert review. Float oracle comparison is not an interval certificate.'
    (BASE/'bottleneck-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__=='__main__':main()
