"""Independent verification from the exact decimal coefficients printed in the PDF.

Uses a Gram-matrix fidelity calculation to avoid spurious eigenvalues of a
rank-deficient 8x8 density matrix. Does not import the attachment's checker.
Run with Python and NumPy. Pass --high-precision for mpmath at 50 and 80 digits.
"""
from pathlib import Path
import json
import sys
import numpy as np

WEIGHTS = ['0.0383477362', '0.9616522638']
VECTORS = [
    [('-0.6104357345', '0'), ('0.0063927953', '-0.0044244357'),
     ('0.0026075606', '-0.0150331220'), ('-0.0001180574', '-0.0002823919'),
     ('-0.0118114830', '0.0054943442'), ('-0.0003861017', '-0.0098540922'),
     ('0.7842448379', '-0.1079189498'), ('-0.0061499192', '0.0091457466')],
    [('-0.0465530650', '0'), ('-0.0377544806', '-0.0978816076'),
     ('0.8582239838', '-0.4826969158'), ('-0.0132291583', '0.0104067043'),
     ('0.0018681142', '0.0014701336'), ('-0.0012199090', '0.0109247234'),
     ('-0.0488402257', '-0.0085549482'), ('-0.0582671635', '-0.1049688866')],
]


def hermitian(x):
    return (x + x.conj().T) / 2


def power(x, exponent):
    w, u = np.linalg.eigh(hermitian(x))
    if np.iscomplexobj(exponent) or exponent.real < 0:
        if w.min() <= 0:
            raise ValueError('This calculation requires a positive definite matrix.')
    return (u * np.maximum(w, 0) ** exponent) @ u.conj().T


def entropy_eigenvalues(w):
    w = np.asarray(w)
    w = w[w > 0]
    return float(-np.dot(w, np.log2(w)))


def entropy(x):
    return entropy_eigenvalues(np.linalg.eigvalsh(hermitian(x)))


def marginals(rho):
    r = rho.reshape(2, 2, 2, 2, 2, 2)
    ac = np.einsum('abcdbe->acde', r).reshape(4, 4)
    bc = np.einsum('abcade->bcde', r).reshape(4, 4)
    c = np.einsum('abcabd->cd', r)
    return ac, bc, c


def recovery(rho, t=0.0):
    """Uses the manuscript convention: AC exponent = (1 + i*t)/2."""
    ac, bc, c = marginals(rho)
    left_ac = power(ac, 0.5 + 0.5j * t) @ np.kron(np.eye(2), power(c, -0.5 - 0.5j * t))
    # Identity on spectator B, in the canonical A,B,C order.
    left_abc = np.einsum('acde,bf->abcdfe', left_ac.reshape(2, 2, 2, 2), np.eye(2)).reshape(8, 8)
    return hermitian(left_abc @ np.kron(np.eye(2), bc) @ left_abc.conj().T)


def fidelity_from_factor(g, recovered):
    """rho = G G*, F = (tr sqrt(G* recovered G))**2."""
    k = hermitian(g.conj().T @ recovered @ g)
    if k.shape == (2, 2):
        determinant = float((k[0, 0]*k[1, 1] - k[0, 1]*k[1, 0]).real)
        if determinant <= 0:
            raise ValueError('The compressed fidelity matrix must be positive definite.')
        return float(np.trace(k).real + 2 * np.sqrt(determinant))
    return float(np.linalg.svd(power(recovered, 0.5) @ g, compute_uv=False).sum() ** 2)


def numpy_check():
    v = np.array([[complex(float(a), float(b)) for a, b in col] for col in VECTORS]).T
    g = v * np.sqrt(np.array(WEIGHTS, dtype=float))
    raw_trace = np.trace(g.conj().T @ g).real
    g = g / np.sqrt(raw_trace)
    rho = g @ g.conj().T
    ac, bc, c = marginals(rho)
    rec = recovery(rho)
    entropies = dict(AC=entropy(ac), BC=entropy(bc), C=entropy(c), ABC=entropy(g.conj().T @ g))
    cmi = entropies['AC'] + entropies['BC'] - entropies['C'] - entropies['ABC']
    fidelity = fidelity_from_factor(g, rec)
    rhs = -np.log2(fidelity)
    s = power(ac, 0.5)
    ci = power(c, -0.5)
    kraus = [s @ np.kron(np.eye(2)[:, i:i+1], ci) for i in range(2)]
    choi = sum(np.outer(k.T.reshape(-1), k.T.reshape(-1).conj()) for k in kraus)
    result = dict(raw_trace=float(raw_trace), vector_gram_real=(v.conj().T @ v).real.tolist(),
                  vector_gram_imag=(v.conj().T @ v).imag.tolist(), entropies=entropies,
                  cmi=cmi, fidelity_squared=fidelity, recovery_term=float(rhs), gap=float(cmi-rhs),
                  spectrum_AC=np.linalg.eigvalsh(ac).tolist(), spectrum_BC=np.linalg.eigvalsh(bc).tolist(),
                  spectrum_C=np.linalg.eigvalsh(c).tolist(), spectrum_recovered=np.linalg.eigvalsh(rec).tolist(),
                  recovered_trace=float(np.trace(rec).real),
                  trace_preservation_residual=float(np.linalg.norm(sum(k.conj().T @ k for k in kraus)-np.eye(2))),
                  reference_recovery_residual=float(np.linalg.norm(sum(k @ c @ k.conj().T for k in kraus)-ac)),
                  choi_min_eigenvalue=float(np.linalg.eigvalsh(hermitian(choi)).min()))
    scans = []
    for t in [-4, -2, -1.6, -0.8, -0.4, -0.02, 0, 0.02, 0.4, 0.8, 1.6, 2, 4]:
        scans.append(dict(t=t, recovery_term=float(-np.log2(fidelity_from_factor(g, recovery(rho,t))))))
    result['rotation_scan'] = scans
    # Gaussian quadrature; |t| > 12 has beta_0 mass below 8.5e-17.
    averaged = {}
    for n in [240, 480]:
        nodes, weights = np.polynomial.legendre.leggauss(n)
        nodes, weights = nodes * 12, weights * 12
        weights *= (np.pi/2)/(np.cosh(np.pi * nodes)+1)
        avg = sum(w * recovery(rho, float(t)) for t, w in zip(nodes, weights))
        averaged[f'quadrature_{n}'] = dict(recovery_term=float(-np.log2(fidelity_from_factor(g,avg))),
                                         trace=float(np.trace(avg).real))
    result['averaged_rotations'] = averaged
    noisy = []
    for epsilon in [1e-6, 1e-4, 1e-3, 1e-2]:
        state = (1-epsilon)*rho+epsilon*np.eye(8)/8
        noisy_g = np.column_stack([np.sqrt(1-epsilon)*g, np.sqrt(epsilon/8)*np.eye(8)])
        acn,bcn,cn=marginals(state)
        info=entropy(acn)+entropy(bcn)-entropy(cn)-entropy(state)
        term=-np.log2(fidelity_from_factor(noisy_g,recovery(state)))
        noisy.append(dict(epsilon=epsilon,cmi=info,recovery_term=float(term),gap=float(info-term)))
    result['white_noise_checks']=noisy
    (Path(__file__).parent/'numpy_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


def high_precision_check(dps):
    import mpmath as mp
    mp.mp.dps = dps
    v=mp.matrix([[mp.mpc(*VECTORS[j][i]) for j in range(2)] for i in range(8)])
    g=v*mp.diag([mp.sqrt(mp.mpf(x)) for x in WEIGHTS])
    raw_trace=sum(abs(g[i,j])**2 for i in range(8) for j in range(2))
    g=g/mp.sqrt(raw_trace)
    rho=g*g.H
    def fun(x,f):
        ev,u=mp.eighe(x)
        return u*mp.diag([f(w) for w in ev])*u.H
    def trace(x): return sum(x[i,i] for i in range(x.rows))
    def ent(x):
        ev=mp.eighe(x,eigvals_only=True)
        assert min(ev)>0
        return -sum(w*mp.log(w,2) for w in ev)
    ac=mp.matrix(4);bc=mp.matrix(4);c=mp.matrix(2)
    for a in range(2):
        for b in range(2):
            for z in range(2):
                for aa in range(2):
                    for zz in range(2):
                        ac[2*a+z,2*aa+zz]+=rho[4*a+2*b+z,4*aa+2*b+zz]
                for bb in range(2):
                    for zz in range(2):
                        bc[2*b+z,2*bb+zz]+=rho[4*a+2*b+z,4*a+2*bb+zz]
                for zz in range(2):
                    c[z,zz]+=rho[4*a+2*b+z,4*a+2*b+zz]
    sac=fun(ac,mp.sqrt);ci=fun(c,lambda x:1/mp.sqrt(x))
    k=mp.matrix(4)
    for a in range(2):
        for z in range(2):
            for zz in range(2): k[2*a+z,2*a+zz]=ci[z,zz]
    left=sac*k
    l=mp.matrix(8);q=mp.matrix(8)
    for i in range(8):
        a,b,z=i//4,(i//2)%2,i%2
        for j in range(8):
            aa,bb,zz=j//4,(j//2)%2,j%2
            if b==bb: l[i,j]=left[2*a+z,2*aa+zz]
            if a==aa: q[i,j]=bc[2*b+z,2*bb+zz]
    rec=l*q*l.H
    gram=g.H*rec*g
    fidelity=mp.re(trace(gram)+2*mp.sqrt(mp.det(gram)))
    ents=dict(AC=ent(ac),BC=ent(bc),C=ent(c),ABC=ent(g.H*g))
    info=ents['AC']+ents['BC']-ents['C']-ents['ABC']
    term=-mp.log(fidelity,2)
    result=dict(digits=dps,raw_trace=mp.nstr(raw_trace,dps),
                entropies={k:mp.nstr(x,dps-8) for k,x in ents.items()},
                cmi=mp.nstr(info,dps-8), fidelity_squared=mp.nstr(fidelity,dps-8),
                recovery_term=mp.nstr(term,dps-8),gap=mp.nstr(info-term,dps-8),
                recovered_trace_error=mp.nstr(abs(trace(rec)-1),10))
    (Path(__file__).parent/f'high_precision_{dps}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    if '--high-precision' in sys.argv:
        for digits in [50,80]: high_precision_check(digits)
    else:
        numpy_check()
