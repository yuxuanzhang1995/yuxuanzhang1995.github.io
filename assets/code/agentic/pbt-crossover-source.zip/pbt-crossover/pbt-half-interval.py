"""Rational enclosure for the displayed formula, conditional on its theorem."""
from fractions import Fraction as F
from math import factorial
import json
def C(x):return (F(x),F(x))
def add(x,y):return(x[0]+y[0],x[1]+y[1])
def neg(x):return(-x[1],-x[0])
def sub(x,y):return add(x,neg(y))
def mul(x,y):
    v=[a*b for a in x for b in y];return(min(v),max(v))
def div(x,y):
    assert y[0]>0
    return mul(x,(1/y[1],1/y[0]))
def atan(x,N):
    s=sum(((-1)**k*x**(2*k+1)/F(2*k+1)for k in range(N)),F(0))
    t=(-1)**N*x**(2*N+1)/F(2*N+1)
    return(min(s,s+t),max(s,s+t))
pi=sub(mul(C(16),atan(F(1,5),50)),mul(C(4),atan(F(1,239),15)))
def trig(x,sine):
    s=sum((F((-1)**k)*x**(2*k+int(sine))/F(factorial(2*k+int(sine)))for k in range(21)),F(0))
    t=-x**(42+int(sine))/F(factorial(42+int(sine)))
    return(s+t,s)
def integrals(t,s,co):
    I1=div(sub(s,mul(co,t)),pi)
    I2=div(sub(mul(add(C(F(1,2)),mul(co,co)),t),mul(C(F(3,2)),mul(co,s))),pi)
    return I1,I2
lo=F(19797622064,10**10);hi=F(19797622066,10**10)
def ratio(t):
    a,b=integrals(C(t),trig(t,True),trig(t,False))
    return div(b,mul(C(2),mul(a,a)))
# M decreases with theta, as proved analytically in the frozen claim.
assert ratio(lo)[0]>1 and ratio(hi)[1]<1
s=(trig(hi,True)[0],trig(lo,True)[1]);co=(trig(hi,False)[0],trig(lo,False)[1])
a,b=integrals((lo,hi),s,co)
q=add(co,div(b,a));assert q[0]>0
phi=mul(q,q)
assert F(472865,10**6)<phi[0] and phi[1]<F(472867,10**6)
print(json.dumps({'status':'passed','scope':'Rational evaluation of the candidate formula,not a separate proof of the PBT asymptotic theorem','theta_bracket':[str(lo),str(hi)],'root_bracketing_assertion':'M(theta_low)>1>M(theta_high): exact interval PASS','fidelity_assertion':'472865/1000000 < phi(1/2) < 472867/1000000: exact interval PASS','display_approximate_interval':[float(phi[0]),float(phi[1])]},indent=2))
