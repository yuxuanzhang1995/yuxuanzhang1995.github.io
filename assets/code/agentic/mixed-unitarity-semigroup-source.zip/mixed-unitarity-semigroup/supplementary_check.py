import numpy as np
from scipy.linalg import expm

# Supplementary deterministic check; the claim is proved analytically.
d = 3
I = np.eye(d, dtype=complex)
R = np.array([[0., -1.], [1., 0.]], dtype=complex)
B = np.zeros((3, 3), dtype=complex)
B[0, 0] = 1
B[1:, 1:] = R
H = np.diag([30., 0., 0.]).astype(complex)
Q = np.diag([-1., 1., 1.]).astype(complex)
C = B.copy()
C[0, 0] = -1
basis = [np.eye(9, dtype=complex)[k].reshape(3, 3) for k in range(9)]

def superop(f):
    return np.column_stack([f(E).reshape(-1) for E in basis])

def generator(X):
    return (np.trace(X)*I-B@X.T@B.conj().T)/2-X-1j*(H@X-X@H)

def averaged(X):
    Y = np.zeros((3, 3), dtype=complex)
    Y[0, 0] = np.trace(X[1:, 1:])/2-X[0, 0]
    Y[0, 1:] = -X[0, 1:]
    Y[1:, 0] = -X[1:, 0]
    Y[1:, 1:] = X[0, 0]*np.eye(2)/2-X[1:, 1:]/2
    return Y

jumps = []
for a in (1, 2):
    E = np.zeros((3, 3), dtype=complex)
    E[0, a] = 1
    jumps.extend([(E+E.conj().T)/2, 1j*(E-E.conj().T)/2])
jumps.append(np.diag([0., 1., 1.])/np.sqrt(2))

def hermitian_jump_sum(X):
    Y = np.zeros_like(X)
    for V in jumps:
        Y += V@X@V-(V@V@X+X@V@V)/2
    return Y

L = superop(generator)
D0 = superop(averaged)
assert np.max(np.abs(D0-superop(hermitian_jump_sum))) < 1e-14
s = 2*np.pi/np.sqrt(3601.)
t = 3*np.pi/np.sqrt(3601.)
assert 0 < s < t
assert np.max(np.abs(expm(s*L)-superop(lambda X: Q@X@Q.conj().T)@expm(s*D0))) < 1e-12

S = expm(t*L)
J = np.zeros((9, 9), dtype=complex)
for i in range(3):
    for j in range(3):
        J[3*i:3*i+3, 3*j:3*j+3] = S[:, 3*i+j].reshape(3, 3)/3
F = np.zeros((9, 9), dtype=complex)
for i in range(3):
    for j in range(3):
        F[3*i+j, 3*j+i] = 1
IC = np.kron(I, C)
W = IC@F@IC.conj().T+np.eye(9)/3
value = np.trace(W@J)
formula = (2+np.exp(-3*t/2)-3*np.exp(-t/2)-4*np.exp(-t)/np.sqrt(3601.))/3
assert np.max(np.abs(J-J.conj().T)) < 1e-12
assert np.linalg.eigvalsh(J).min() > -1e-12
assert abs(np.trace(J)-1) < 1e-12
assert abs(value-formula) < 1e-12
assert value.real < -456/38125
print('Endpoint identity and negative separating-witness formula verified.')
