"""Independent finite review controls; imports no author code.

The manuscript's numbers are transcribed separately, then compared with the
certificate. Local models are checked in all four conditional probabilities,
not merely the author's compressed coordinate representation. Modular ranks
provide rigorous rational rank lower bounds; the explicit supporting normal
provides the matching upper bound for each facet rank.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import copy
import json

HERE = Path(__file__).resolve().parent
CERTIFICATE = HERE / "five-setting-certificate.json"
H = ((-1, -1, 0, 1, 1), (1, 0, -1, 1, 1), (0, 1, 1, 1, 1))
A = tuple(Q(n, 10000) for n in (5000, 5001, 5002))
B = tuple(Q(n, 10000) for n in (5000, 5000, 5000, 3501, 6502))
C = tuple(tuple(Q(n, 10000) for n in row) for row in
          ((3501, 3501, 2500, 499, 1999),
           (1499, 2500, 3501, 499, 1999),
           (2500, 1499, 1499, 499, 1999)))


def bell(a, b, c):
    return 3 - a[1] - 2*a[2] - b[3] - 2*b[4] + sum(
        H[x][y] * c[x][y] for x in range(3) for y in range(5))


def table(a, b, c):
    # Index order (a_out,b_out) = (0,0), (0,1), (1,0), (1,1).
    return (1-a-b+c, b-c, a-c, c)


def rank_mod(rows, prime=1000003):
    m = [[int(z) % prime for z in row] for row in rows]
    rank = 0
    for col in range(len(m[0])):
        pivot = next((j for j in range(rank, len(m)) if m[j][col]), None)
        if pivot is None:
            continue
        m[rank], m[pivot] = m[pivot], m[rank]
        inverse = pow(m[rank][col], -1, prime)
        m[rank] = [(z * inverse) % prime for z in m[rank]]
        for j in range(rank+1, len(m)):
            factor = m[j][col]
            if factor:
                m[j] = [(u-factor*v) % prime for u, v in zip(m[j], m[rank])]
        rank += 1
        if rank == len(m):
            break
    return rank


def check_models(cert):
    checked = 0
    summaries = []
    assert len(cert['deletion_local_models']) == 5
    assert sorted(m['deleted_bob_setting'] for m in cert['deletion_local_models']) == list(range(5))
    for model in cert['deletion_local_models']:
        keep = tuple(j for j in range(5) if j != model['deleted_bob_setting'])
        assert tuple(model['kept_bob_settings']) == keep
        terms = [(tuple(t['alice']), tuple(t['bob']), Q(t['weight'])) for t in model['terms']]
        assert all(len(a) == 3 and len(b) == 4 and set(a+b) <= {0, 1} and w >= 0
                   for a, b, w in terms)
        assert sum(w for _, _, w in terms) == 1
        for x in range(3):
            for j, y in enumerate(keep):
                observed = table(A[x], B[y], C[x][y])
                for k, (a_out, b_out) in enumerate(product((0, 1), repeat=2)):
                    rebuilt = sum(w for a, b, w in terms if a[x] == a_out and b[j] == b_out)
                    assert rebuilt == observed[k], (x, y, a_out, b_out, rebuilt, observed[k])
                    checked += 1
        alice_distribution = [sum(w for a, _, w in terms if a == alpha)
                              for alpha in product((0, 1), repeat=3)]
        summaries.append({'deleted_setting_zero_based': model['deleted_bob_setting'],
                          'terms': len(terms), 'smallest_weight': str(min(w for _, _, w in terms)),
                          'alice_distribution': list(map(str, alice_distribution))})
    return checked, summaries


def multioutcome_gluing():
    # Mixed cardinalities, a deterministic Alice marginal, and zero atoms.
    alice_atoms = tuple(product(range(2), range(3)))
    masses = (Q(1, 3), Q(0), Q(2, 3), Q(0), Q(0), Q(0))
    bob_cardinalities = (1, 2, 3, 4, 2, 3)
    q = []
    for y, cardinality in enumerate(bob_cardinalities):
        by_atom = []
        for i, mass in enumerate(masses):
            numerators = [1+(i+2*y+b) % 5 for b in range(cardinality)]
            total = sum(numerators)
            by_atom.append(tuple(mass*Q(z, total) for z in numerators))
        q.append(by_atom)
    conditionals = [[tuple(z/masses[i] for z in by_atom[i]) if masses[i] else
                     tuple(Q(b == 0) for b in range(bob_cardinalities[y]))
                     for i in range(len(masses))] for y, by_atom in enumerate(q)]
    joint = []
    for i, alpha in enumerate(alice_atoms):
        for beta in product(*(range(k) for k in bob_cardinalities)):
            weight = masses[i]
            for y, b in enumerate(beta):
                weight *= conditionals[y][i][b]
            assert weight >= 0
            joint.append((i, alpha, beta, weight))
    assert sum(t[3] for t in joint) == 1
    checked = 0
    for y, cardinality in enumerate(bob_cardinalities):
        for i in range(len(masses)):
            for b in range(cardinality):
                assert sum(w for j, _, beta, w in joint if j == i and beta[y] == b) == q[y][i][b]
                checked += 1
    return {'alice_cardinalities': [2, 3], 'bob_cardinalities': bob_cardinalities,
            'zero_mass_atoms': masses.count(0), 'joint_atoms_including_zero': len(joint),
            'exact_joint_marginal_equalities': checked}


def main():
    cert = json.loads(CERTIFICATE.read_text())
    paper_behavior = [Q(1), *A, *B, *(z for row in C for z in row)]
    paper_normal = [3, 0, -1, -2, 0, 0, 0, -1, -2, *(z for row in H for z in row)]
    assert list(map(Q, cert['behavior'])) == paper_behavior
    assert cert['normal_h'] == paper_normal
    rows, saturating, profile = [], [], []
    for a in product((0, 1), repeat=3):
        scores = []
        for b in product((0, 1), repeat=5):
            c = tuple(tuple(a[x]*b[y] for y in range(5)) for x in range(3))
            score = bell(a, b, c)
            row = [1, *a, *b, *(z for r in c for z in r)]
            rows.append(row)
            scores.append(score)
            assert score >= 0
            if score == 0:
                saturating.append(row)
        profile.append({'alice': a, 'minimum': min(scores), 'saturated_bob_assignments': scores.count(0)})
    assert rank_mod(rows) == 24
    assert rank_mod(saturating) == 23
    assert all(sum(h*v for h, v in zip(paper_normal, row)) == 0 for row in saturating)
    probabilities = [z for x in range(3) for y in range(5) for z in table(A[x], B[y], C[x][y])]
    assert min(probabilities) == Q(99, 2000)
    assert bell(A, B, C) == Q(-11, 5000)
    checked, models = check_models(cert)
    bad = copy.deepcopy(cert)
    bad['deletion_local_models'][0]['terms'][0]['weight'] = '0'
    try:
        check_models(bad)
    except AssertionError:
        mutated_model_rejected = True
    else:
        raise AssertionError('Damaged local model passed')
    # The normal has a nonzero mixed coefficient in every Bob column.
    # In this independent no-signalling chart, no affine identity can erase one.
    assert all(any(H[x][y] != 0 for x in range(3)) for y in range(5))
    report = {'status': 'pass', 'arithmetic': 'exact fractions and integer modular ranks',
              'independence': 'no import of author verifier; explicit paper coefficients; direct conditional table reconstruction',
              'vertices': len(rows), 'saturating_vertices': len(saturating),
              'augmented_vertex_rank_lower_bound_mod_1000003': rank_mod(rows),
              'augmented_saturating_rank_lower_bound_mod_1000003': rank_mod(saturating),
              'saturating_rank_upper_bound_from_nonzero_normal': 23,
              'deterministic_minimum_profile': profile,
              'nonlocal_slack': str(bell(A, B, C)), 'minimum_probability': str(min(probabilities)),
              'direct_model_probability_equalities': checked, 'local_models': models,
              'mutated_model_rejected': mutated_model_rejected,
              'mixed_output_and_zero_mass_gluing': multioutcome_gluing(),
              'not_certified': ['all finite facets or all six orbits', 'analytic Helly theorem', 'novelty or priority']}
    (HERE/'independent-control-results.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
