#!/usr/bin/env python3
"""Independent finite diagnostics; analytic proof carries the uniform theorem."""
import json
import math
from fractions import Fraction
import mpmath as mp
import numpy as np
from scipy.integrate import quad
from scipy.linalg import expm

def ceil_log2_fraction(x):
    k=max(0,x.numerator.bit_length()-x.denominator.bit_length())
    while Fraction(2)**k < x:
        k+=1
    while k>0 and Fraction(2)**(k-1)>=x:
        k-=1
    return k

results={"purpose":"diagnostics, not a global complexity certificate"}
mp.mp.dps=90
rows=[]
for onsite_bits in [0,20,200,2000]:
    E=Fraction(2)**onsite_bits; B=Fraction(3); beta=Fraction(7,5)
    eta=Fraction(1,10**7)
    nu=1+beta*E*B/eta; a=1/(64*nu)
    U=2+ceil_log2_fraction(128*B/eta)
    r=ceil_log2_fraction(1/a)+2; alpha=2*B*(r+1)
    n=ceil_log2_fraction(128*alpha*E*beta*U/eta)
    to_mp=lambda x:mp.mpf(x.numerator)/x.denominator
    aa=to_mp(a);la=mp.log(mp.tanh(aa/2));lu=mp.log(mp.tanh(mp.mpf(U)/2))
    I=lu-la
    err=mp.mpf(0)
    for v in [mp.mpf(0),mp.mpf(1)/17,mp.mpf('0.5'),mp.mpf(16)/17,mp.mpf(1)]:
        w=(1-v)*la+v*lu
        u=mp.log1p(2*mp.exp(w)/(-mp.expm1(w)))
        got=(mp.log(mp.tanh(u/2))-la)/I
        err=max(err,abs(got-v))
        assert aa*(1-mp.mpf('1e-70')) <= u <= U*(1+mp.mpf('1e-70'))
    assert err<mp.mpf('1e-70')
    assert I<=mp.log(4/aa)
    assert to_mp(B)*I/mp.pi<=to_mp(alpha)
    small=to_mp(beta*E*B*a)/mp.pi**2
    tail=4*to_mp(B)*mp.exp(-U)/mp.pi
    grid=2*to_mp(alpha*E*beta*U)/2**n
    assert small<=to_mp(eta)/64
    assert tail<to_mp(eta)/64
    assert grid<=to_mp(eta)/64
    assert n<onsite_bits+130
    rows.append({"onsite_bits":onsite_bits,"index_qubits":n,"alpha_G":str(alpha),
                 "cdf_roundtrip_error":mp.nstr(err,8),
                 "cutoff_error_over_eta":mp.nstr((small+tail)/to_mp(eta),10)})
results['binary_CDF']=rows

# Noncommuting qubit target fixes both sign and factor-of-two convention.
X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1.,-1.]); beta=1.4
rows=[]
for omega in [0.,1.,7.,31.]:
    f=lambda u: -(beta*omega/(2*math.pi**2)) if u==0 else -math.sin(beta*omega*u/(2*math.pi))/(math.pi*math.sinh(u))
    integral,quaderr=quad(f,0,45,epsabs=2e-12,epsrel=2e-12,limit=300)
    exact=-.5*math.tanh(beta*omega/4)
    assert abs(integral-exact)<2e-10
    if omega:
        t=.123;Umat=expm(1j*t*omega*Z/2)
        assert np.linalg.norm(Umat@X@Umat.conj().T-(math.cos(omega*t)*X-math.sin(omega*t)*Y))<1e-13
    rows.append({'omega':omega,'integral':integral,'exact':exact,'error':abs(integral-exact)})
assert abs(rows[2]['integral']-(-rows[2]['exact']))>.9
results['scalar_correction_and_wrong_sign_control']=rows

# Direct retained integral vs quantile averages. These are modest diagnostic
# grids; the algorithm uses an index register, never this host enumeration.
a=2e-5;U=16.;omega=7.;beta=1.4
la=np.log(np.tanh(a/2));lu=np.log(np.tanh(U/2));I=lu-la
retained=quad(lambda u:-np.sin(beta*omega*u/(2*np.pi))/(np.pi*np.sinh(u)),a,U,
              epsabs=1e-12,limit=250)[0]
rows=[]
for Q in [1024,4096,16384]:
    v=(np.arange(Q)+.5)/Q;w=(1-v)*la+v*lu
    u=np.log1p(np.exp(w))-np.log(-np.expm1(w))
    val=-I/np.pi*np.mean(np.sin(beta*omega*u/(2*np.pi)))
    bound=(I/np.pi)*omega*(beta*U/(2*np.pi))/Q
    assert abs(val-retained)<=bound
    rows.append({'Q':Q,'error':abs(val-retained),'W1_bound':bound})
assert rows[-1]['error']<rows[0]['error']
results['midpoint_quantiles']=rows

# The wrapper is EXACTLY an involution algebraically. Floating random control
# verifies the correct placement of U/U* and that it takes the Hermitian part.
rng=np.random.default_rng(7603)
A=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4))
W,_=np.linalg.qr(A)
Had=np.array([[1,1],[1,-1]])/math.sqrt(2)
zero=np.zeros_like(W)
J=np.block([[zero,W],[W.conj().T,zero]])
K=np.kron(Had,np.eye(4));F=K@J@K
assert np.linalg.norm(F-F.conj().T)<1e-14
assert np.linalg.norm(F@F-np.eye(8))<1e-14
assert np.linalg.norm(F[:4,:4]-(W+W.conj().T)/2)<1e-14
results['wrapper']={'Hermiticity_error':float(np.linalg.norm(F-F.conj().T)),
                    'involution_error':float(np.linalg.norm(F@F-np.eye(8)))}

# Error-budget arithmetic for the local nearby-generator interface.
for T in [Fraction(1,10),Fraction(1),Fraction(2)**30]:
    for alphaV in [Fraction(1),Fraction(2)**20]:
        delta=Fraction(1,10**8)
        eG=delta/(32*(1+T));eV=delta/(64*(1+T)*(1+alphaV))
        perturb=T*(2*eG+2*(2*alphaV+eV)*eV)
        assert perturb<delta/4
results['exact_rational_generator_budgets']='PASS'
results['status']='PASS'
print(json.dumps(results,indent=2,sort_keys=True))
