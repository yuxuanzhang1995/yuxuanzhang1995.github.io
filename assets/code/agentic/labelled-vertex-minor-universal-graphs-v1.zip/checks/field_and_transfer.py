from itertools import product, permutations
import json,random
from pathlib import Path
rng=random.Random(359)
def mul(a,b):
    c=0
    while b:
        if b&1: c^=a
        b>>=1; a<<=1
        if a&16:a^=19
    return c
def power(a,k):
    val=1
    for _ in range(k): val=mul(val,a)
    return val
def rank(M,field):
    M=[row[:] for row in M]
    if not M:return 0
    k=0
    for j in range(len(M[0])):
        i=next((i for i in range(k,len(M)) if M[i][j]),None)
        if i is None:continue
        M[k],M[i]=M[i],M[k]
        inv=power(M[k][j],field-2) if field==16 else 1
        M[k]=[mul(x,inv) for x in M[k]]
        for i,row in enumerate(M):
            if i!=k and row[j]:
                c=row[j];M[i]=[x^mul(c,y) for x,y in zip(row,M[k])]
        k+=1
    return k
def trace(x):return x^power(x,4)
trace_checks=0
for n in [1,2,3,4]:
    for _ in range(240):
        V=[[rng.randrange(16) for j in range(n)] for i in range(n)]
        if rank(V,16)!=n:continue
        deficits=sum(n-rank([[trace(mul(a,x)) for x in row] for row in V],16) for a in range(16))
        assert deficits<=4*n
        trace_checks+=1
def parity(x):return x.bit_count()%2
def quad(x,A):
    return sum((x>>i&1)*(x>>j&1)*b for i,j,b in A)&1
def app(rows,x): return sum(parity(r&x)<<i for i,r in enumerate(rows))
def binrank(rows,n):return rank([[(x>>i)&1 for i in range(n)] for x in rows],2)
branches=0
for p,l,h in product(range(3),repeat=3):
    k=p+l+h
    if k>5:continue
    y=l+h
    for _ in range(4):
        D=[rng.randrange(1<<y) for j in range(y)]
        while binrank(D,y)!=y:D=[rng.randrange(1<<y) for j in range(y)]
        rowsB=[rng.randrange(1<<p) for j in range(y)]
        E=[rng.randrange(1<<h) for j in range(l)]
        A=[(i,j,rng.randrange(2)) for i in range(k) for j in range(i)]
        for out in range(1<<k):
            x=out% (1<<p); u=(out>>p)% (1<<l); v=out>>(p+l)
            b=app(rowsB,x)^u^app(E,v)^(v<<l)
            total=0
            for z in range(1<<y):
                for yy in range(1<<y):
                    total+=(-1)**(quad(x|(z<<p),A)^parity((app(D,z)^b)&yy))
            allowed=[z for z in range(1<<y) if app(D,z)==b]
            assert len(allowed)==1 and total==(1<<y)*(-1)**quad(x|(allowed[0]<<p),A)
            branches+=1
print(json.dumps(dict(field_projection_tests=trace_checks,mixed_Fourier_amplitudes=branches,base_field='GF(16) to GF(4)',full_asymptotic_generator_tested=False),indent=2))
