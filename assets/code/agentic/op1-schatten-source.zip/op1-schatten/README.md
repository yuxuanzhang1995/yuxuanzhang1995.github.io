# Alhejji–Knill word-trace counterexample

Yuxuan Zhang. Revision: 22 September 2026.

This package accompanies *Word-trace dominance does not imply fractional Schatten-norm dominance*. It gives a negative answer to Section VI, question 1 of Mohammad A. Alhejji and Emanuel Knill, *Towards a resolution of the spin alignment problem*, Communications in Mathematical Physics 405, 119 (2024), https://doi.org/10.1007/s00220-024-04980-1. The exact source statement is at https://arxiv.org/html/2307.06894v3#S6.

## Contents and reproduction

- `op1-schatten.pdf`: the three-page note with the complete analytic arguments.
- `op1-schatten.tex`: LaTeX source. Build twice with `pdflatex op1-schatten.tex`.
- `verify_schatten.py`: diagnostics using only Python 3's standard library. Run `python3 verify_schatten.py` without the `-O` flag.
- `verification-results.json`: the expected exact checker output. Running the script also regenerates this file next to the script.
- `evidence.json`: source comparison, claim-to-evidence mapping, and review limitations.
- `SHA256SUMS`: hashes of the other files in this package.

The small witness has diagonal entries only in {0, 1, 2}. Its decisive comparison at p = 3/2 is 10 < 6 sqrt(3), certified by 100 < 108. The earlier integer witness gives power traces 4951 < 5103. The checker prints these comparisons explicitly and checks every binary word of length at most 12, including the empty word, for each witness (8,191 words per witness).

The universal word condition follows from the analytic ratio bound in the note. Finite enumeration is only a diagnostic. The interval 1 < p < 2 and dimension minimality are proved analytically; they are not certified by enumerating finitely many words.

## Revision and scope

Both examples appeared in the earlier note dated 17 June 2026. This revision writes out the all-word, failure-interval, and minimal-dimension proofs. It supersedes the earlier claim that a kernel lemma still had to be established for the displayed diagonal construction. It does not rely on the earlier, incompletely documented noncommuting example or on a broader diagonal-family assertion.

The result concerns the proposed word-trace implication. It does not refute the spin-alignment conjecture or give a quantum-capacity formula. AI-assisted source checking and exact arithmetic diagnostics are documented; independent human expert review, historical priority, and QIQC acceptance are not asserted.

## Writing provenance

Scientific Agent Skills supplied guidance for evidence tracking and exposition, not mathematical verification. The local guidance used the `scientific-writing` skill from https://github.com/K-Dense-AI/scientific-agent-skills at revision `330c8e764435`.

Citation: T. Kassis, V. Agarwal, Y. He, D. Patel, and A. M. Brueckner, *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents* (2026), https://doi.org/10.48550/arXiv.2609.00065.

No third-party papers or third-party skill text are redistributed in this archive.
