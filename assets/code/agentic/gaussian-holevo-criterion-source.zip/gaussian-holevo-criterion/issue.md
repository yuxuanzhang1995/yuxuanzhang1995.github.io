### Problem ID

op_8f1853475db7ea27

### Type of update

Complete proof or counterexample

### Author

Yuxuan Zhang

### Exact claim

I am submitting a candidate answer to the complete stated Gaussian-measurement equality question, for every faithful finite-mode Gaussian local model with nonsingular SLD Fisher information and real positive-definite weight. This is an implicit finite semialgebraic certificate, together with an attaining measurement. It is not a claim of an efficient algorithm or a closed-form geometric classification.

The result arose in round 42 of an AI-assisted research campaign and passed two separate internal AI reviews. External specialist confirmation and literature priority remain unverified.

Write $m_j=\partial_jd$, $D_j=\partial_jV$, and $\Gamma=V+i\Omega/2$. The manuscript defines the moment Gram matrix $S$, derivative matrix $J$, and $P=I-J(J^{\mathsf T}J)^{-1}J^{\mathsf T}$ in Eqs. (4)--(5). With $G,E$ real symmetric and $Y$ Hermitian, form

$$F_{j\ell}=m_j^{\mathsf T}Gm_\ell+\tfrac12\operatorname{tr}(GD_jGD_\ell),\qquad A=L(G)E,\qquad Q=E-A^{\mathsf T}SA,$$

where $L(G)$ is the explicit linear/quadratic score coefficient matrix in Eq. (6). The claimed necessary-and-sufficient conditions for $C_G=C_H$ are

$$G\succeq0,\quad \Gamma^{-1}-G\succeq0,\quad FE=I,\quad Q\succeq0,$$

$$Y\succeq0,\quad\operatorname{Re}Y=W,\quad YQ=0,\quad P\operatorname{Re}(SAY)=0.$$

No optimal cost is an input to these equations. A feasible triple gives the common cost $\operatorname{tr}(WE)$ and an attaining measurement with centered commuting output $y=G^{1/2}(R-d)+z$. The ancillary covariance is $I-G^{1/2}VG^{1/2}$ and its commutator cancels the system contribution. The manuscript constructs this measurement with finitely many Gaussian ancillary modes, a Gaussian unitary, and homodyne detection, even for singular $G$.

The proof also establishes attainment of the Gaussian infimum for every model under the assumptions. Thus the equality criterion includes the limiting measurement sequences admitted in the original statement, as well as arbitrary parameter-independent classical processing.

### Primary sources and reproducibility

- [Full manuscript](https://yuxuanzhang1995.github.io/assets/pdf/agentic/gaussian-holevo-criterion.pdf), dated 24 September 2026.
- [Website article](https://yuxuanzhang1995.github.io/agentic-research/gaussian-holevo-criterion/).
- [Unchanged round-42 proof, original statement, two internal reviews, exact checker, diagnostic controls, and manuscript source](https://yuxuanzhang1995.github.io/assets/code/agentic/gaussian-holevo-criterion-source.zip).
- [Original QIQCOP statement](https://qiqc-op.com/problem/op_8f1853475db7ea27/).

The exact checker verifies all certificate conditions for a displacement example (common cost 3) and a mixed mean/covariance example with singular precision (common cost 2/3). Two isolated publication reruns matched the expected output exactly. Six supplementary symbolic examples and 48 floating-point controls test further ingredients. These checks do not establish the theorem's universal quantifiers; the analytic argument is the basis of the claim.

### Relation to the cited progress

The invariant linear/quadratic space and finite Holevo SDP of [Chang, Genoni, and Albarelli, Communications Physics 9, 126 (2026)](https://doi.org/10.1038/s42005-026-02550-6), the displacement attainability result of [Bradshaw, Lam, and Assad, PRA 97, 012106 (2018)](https://doi.org/10.1103/PhysRevA.97.012106), and the [Gaussian-observable structure of Holevo (2021)](https://doi.org/10.1134/S0081543821020085) are attributed background.

The proposed general equality argument couples the physically realizable precision domain to the efficient Gaussian-score pullback and Holevo dual complementarity. This is what replaces comparison of two unknown optimization values and supplies a realizing measurement. Independent source comparison is particularly welcome on whether the combined certificate is already in the literature.

### Relation to withdrawn issue #101

Issue #101 reported only restricted one-mode cases and was withdrawn under the author's complete-results-only publication policy. It remains withdrawn. This is a subsequent, different claim covering arbitrary finite mode and parameter counts; it is not a request to reinstate the partial note.

### Remaining gap

No mathematical gap was identified by the two internal AI reviews. Independent specialist review and novelty assessment are requested before any catalog resolution. Posting this candidate does not assert QIQCOP acceptance, formal verification, or independent human peer review.

### Submission checks

- [x] The AI assistant opened and compared the cited sources under the author's authorization.
- [x] The claim was compared with the archived statement and its quantifiers.
- [x] This original issue text is contributed under CC BY 4.0 under the repository's contribution policy. Linked third-party sources retain their own terms and their full texts are not redistributed.

The author authorized this AI-assisted report; these checks do not represent independent human peer review.
