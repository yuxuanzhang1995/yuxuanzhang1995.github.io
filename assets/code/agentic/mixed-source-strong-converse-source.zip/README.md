# An exponential strong converse for general mixed-state quantum compression

Yuxuan Zhang. Manuscript version 1.0, 29 September 2026.
EPFL is the first affiliation; Princeton is the second.

The PDF and matching LaTeX source report a complete proof candidate for QIQCOP
op_c9b532d3a7389c77. The squared reference-preserving fidelity of every CPTP
code below the full irredundant Koashi–Imoto entropy is at most 16 exp(-n gamma),
with a positive source- and rate-dependent gamma. There is no decoder unitality
restriction, free classical side channel, or shared entanglement.

The all-blocklength conclusion rests on the analytic proof, not finite testing.
The frozen claim and proof are preserved, along with the actual native and two
frozen model reviews. These are AI reviews, not external peer review or a formal
proof. Novelty and catalog acceptance remain unconfirmed.

The diagnostic Python controls require NumPy, SciPy and SymPy as used in the
existing qiqc-sandbox:v1 environment. The multi-block control includes complex
noncommuting reference filters and actual encoder/decoder Kraus factorizations.
The saved outputs identify their finite scope. claim-check.py is the original
claim's reproducibility check; it is not a verifier of the general theorem.

Compile mixed-source-strong-converse.tex using standard LaTeX. The native editor
compiled successfully; the existing pdflatex installation exported the supplied
PDF. All eight pages were rendered and visually inspected. No clipping,
overlap, unresolved references, or missing mathematical glyphs were found.

Source-comparison.json identifies the primary sources and the exact interfaces
used. Their papers are cited in the bibliography and are not bundled here.
In particular, van Luijk–Wilming's sufficiency theorem is an imported result.
The present manuscript, rather than those background references, reports the
compression strong-converse claim. Existing rights are retained; no blanket
reuse license is added.
