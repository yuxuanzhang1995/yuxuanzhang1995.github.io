"""Exact finite parent witness; no asymptotic theorem inferred from this alone."""
import json
from pathlib import Path
import sympy as s
D=Path(__file__).resolve().parent;I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Z=s.diag(1,-1)
tau=I/2+s.Rational(3,20)*(X+Z);root=(tau+s.sqrt(82)*I/20)/s.sqrt(1+s.sqrt(82)/10)
psi=s.Matrix(list(root));P=psi*psi.T
E=[I/2+s.Rational(3,2)/s.sqrt(82)*(Z-X),I/2-s.Rational(3,2)/s.sqrt(82)*(Z-X)]
W=[5*Z-4*X,5*X-4*Z];Y=-s.Rational(94,41)*I+s.Rational(20,41)*(X+Z)
G=sum([s.kronecker_product(w,e)for w,e in zip(W,E)],s.zeros(4))+s.kronecker_product(I,Y)
assert s.simplify(root*root-tau)==s.zeros(2)
assert s.simplify(G*psi-psi)==s.zeros(4,1)
eig=G.eigenvals();assert eig=={s.Integer(1):1,-s.Rational(229,41):1,(-94+s.sqrt(14945))/41:1,(-94-s.sqrt(14945))/41:1}
gap_comparator=s.Rational(1227,410)**2-s.Rational(14945,41**2)
assert gap_comparator==s.Rational(11029,168100)>0
assert s.simplify(s.trace(tau*Y))==-2
out={'scope':'exact local matrices only; independent proof still needed for tensor-block strong converse','parent_eigenvalues':[str(v)for v in eig],'purification_eigenvalue':1,'kappa':'3/10','decisive_other_eigenvalue_comparator':str(gap_comparator)+' > 0','W_norm_bound':'sqrt(41) < 7','Y_norm_bound':'(94+20sqrt(2))/41 < 3 because 800 < 841','reference_Y_mean':-2,'observed_W_mean':3,'all_assertions_passed':True}
(D/'compression-marginal-parent-exact.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
