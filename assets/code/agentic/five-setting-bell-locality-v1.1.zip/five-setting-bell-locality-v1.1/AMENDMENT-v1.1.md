# Targeted amendment review: manuscript v1.1

Date: 2026-11-19. This is an addendum to the independent review of frozen v1, not a second full mathematical review.

**Judgment: the required attribution and positioning revisions are satisfied. Release of the checked v1.1 source as a research/working draft is supported, within the limitations of REVIEW.md.** There is no remaining specific mathematical or attribution blocker identified by this review. Global priority and external expert acceptance remain unconfirmed.

## Checked input and scope

- Old source: `run/manuscripts/five-setting-bell-locality/v1/paper.tex`
- Old SHA-256: `7365097f6cffa612ffbbc84f16fe102bd9fc54449c5cd18b9bd28b0436e077a7`
- Revised source: `publication/bell-five-settings-v1.1/manuscript/paper.tex`
- Revised SHA-256: `4203f0a948c9ca3eb1161305ca2859ec58dbcda3d6c18c5ed66b9ef5166547fd`

The complete source diff is preserved in `v1-to-v1.1.diff`. All 16 theorem, corollary, equation, and align environments are byte-identical between these inputs, as recorded in `AMENDMENT-v1.1.json`. I also read the prose diff. The changes are authorship/version labeling, bibliography, attribution, source pinpointing, and review-status/priority wording. The load-bearing proofs and numerical example have not changed, so the mathematical assessment in REVIEW.md applies.

## Findings

1. **Pironio 2014:** The introduction and compatibility equivalence now explicitly cite *All CHSH polytopes*, Lemma 5. Attribution of the finite-output compatibility interface is accurate. Theorem 1 is correctly identified as the stronger CHSH classification for the two-binary-measurement special case. The bound's contribution is accurately positioned as an application of standard convex geometry to inherited compatibility sets.

2. **Finite source:** Both relevant Jesus–Zambrini Cruzeiro citations now identify Section IV.B and Appendix B.2. The text continues to state that complete finite enumeration is imported. The reviewer orbit checks are not represented as a complete new enumeration.

3. **Thesis and witness:** The reference now gives *Semi-device Independent Protocols for Quantum Key Distribution*, J. Diogo da Costa Jesus, MSc in Engineering Physics, Instituto Superior Técnico, December 2022. The linked primary PDF's title page supports this metadata. Section 5.4 and Table A.4 are the correct locations. The new statement identifying the displayed facet as a relabeling of the source $I_{5322}$ is supported by `source-facet-control-results.json`.

4. **Review and novelty:** The source identifies the reviewer as a separate AI reviewer and explicitly distinguishes this additional internal review from external specialist validation. It says that no prior statement was located in the targeted comparison and that first priority is not confirmed. This is a faithful description of the audit; it does not convert a negative literature search into a first-discovery certification.

5. **Scope:** The unchanged theorem resolves the exact asymmetric source conjecture, conditional on the declared finite classification input. It does not claim all Bell scenarios in Q066 or a quantum realization of the rational no-signalling witness.

## Packaging boundary

This amendment checks the revised TeX source and its diff. It does not certify a newly built PDF, archive download, website rendering, upload, or submission. Those release checks remain with the parent agent. No release was performed by this reviewer.

A public copy of the independent control may adapt its certificate path from the workspace location to a package-relative location. That mechanical adaptation does not change the audited mathematics or calculations, provided the copied certificate is unchanged and the modified script is rerun. The package should identify that adaptation and hash its actual files; it must not attach the original script's hash to altered bytes. The frozen review originals remain in this directory.

Input/output/reasoning-token use and cost remain **unknown**; no reliable usage telemetry was available.

