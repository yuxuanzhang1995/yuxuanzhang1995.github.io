# A sharp lower-bound dual at zero channel error

Assume a finite exact seed for a channel on its minimal Kraus support. Units of cost throughout are energy variance, one quarter of the charged SLD QFI. Write \(D=\mathbb R\oplus\operatorname{Herm}_s\) with its scalar and matrix PSD cone, pairing scalar multiplication plus matrix trace. Let \(G_j=\sum_a g_{ja}x^a\) be finite real-coordinate generators of the *sector-only* module \(M_0\) in [F25](sector-retraction.md), let \(e_a=\omega\cdot a\), and let \(p(d)\) be the scalar program coordinate. For a finite tuple \(f\) write \(B(f)=\sum C_f-T\sum p_f\) for the terminal Gram discrepancy.

**Dual theorem.** The exact cost divided by four is the largest real \(c\) for which there are a finite Hermitian linear functional \(\lambda\) on terminal discrepancies and a field \(Y:\mathbb R\to D_+\) satisfying, for every real \(x\) and each of the finitely many generators,
\[
 \sum_a\langle g_{ja},Y(x+e_a)\rangle
  =\sum_a ((x+e_a)^2-c)p(g_{ja})+\lambda(B(G_j)).                 \tag{1}
\]
There is an a priori quadratic growth bound on a feasible field with a fixed seed. At the optimum a measurable version satisfies (1) almost everywhere. The same supremum is obtained with smooth bandlimited fields, for which the equality holds everywhere. This last claim is about approaching the supremum.

## Why arbitrary real energies and branch centering are allowed

Work with all finite \(D\)-valued atomic measures on \(\mathbb R\), as an ordered real vector space with pointwise cone. The sector equations involve shifts in the system energy lattice. Decomposing by its cosets shows that their nullspace consists exactly of finite linear combinations of *real translates* of the integral-lattice generators \(G_j\). Impose the terminal equation \(B(f)=0\) only on the total. An individual coset need not have the target Gram. Every nonzero positive tuple in this subspace has strictly positive program mass by sector trace balance. After dividing by this mass it is precisely a finite program for the target under the inherited finite-sector equivalence. Translation of the entire energy support by the same real constant changes neither the processor equations nor the implemented channel. Each physical program may therefore be centered at zero. Its minimal squared second moment is its variance. Mixed resources are already covered by optimized finite purification. [Finite atomic physical equivalence](q117-program-proof-v2.md)

For \(c\) below or equal to the true cost in variance units, the functional
\[
 \ell_c(f)=\sum_x (x^2-c)p(f_x)
\]
is positive on the ordered terminal-constrained subspace. Conversely positivity there is a lower bound on every finite program, by translating to its mean. This argument does not take a weak closure of the set of clocks.

## Positivity extension and a field of controlled size

Smooth one normalized finite positive seed by finite convolution so its coefficient at zero dominates \(\delta I\) on all of \(D\), with \(\delta>0\). For any finitely supported ambient tuple \(g\), a sum of translated seeds with weights \(\|g_x\|/\delta\) bounds \(g\) both above and below in the pointwise order. The terminal-constrained subspace therefore majorizes the ordered ambient space. To see the extension directly, put
\[
 u(g)=\inf\{\ell_c(m):m\ \text{in that subspace},\ m\succeq g\}.
\]
The upper and lower majorants make this finite. It is sublinear and agrees with \(\ell_c\) on its subspace. Real Hahn–Banach gives a linear extension dominated by \(u\); at \(-g\) for \(g\succeq0\) this proves positivity. Its values at a single real location are represented by \(Y(x)\in D_+\). On the full sector nullspace its difference from \(\ell_c\) vanishes on the kernel of \(B\), hence factors through one functional \(\lambda\) on the finite-dimensional image of \(B\). Applying it to translated generators gives (1). Conversely these generator equations imply the equality on every finite sum, so contracting with a positive exact-target tuple proves the lower bound. The extension at the infimum itself gives attainment in this unrestricted dual.

For the normalized translated seed with program mean \(\mu_s\) and variance \(v_s\), positivity and \(s_0\succeq\delta I\) give
\[
 \delta\|Y(x)\|\le (x+\mu_s)^2+v_s-c.
\]
This also bounds all finite restrictions. Existence on every finite subset alone gives compactness of the fields but yields upper approximations of the cost when maximized over relaxations. Its numerical direction must be kept explicit.

## Obtaining a measurable field without assuming the extension measurable

Use lattice boxes \(I_R=[-R,R]^d\cap\mathbb Z^d\), enlarged by the finitely many generator offsets. For each real parameter \(u\), choose a solution \(Y^u_m\) on the enlarged box, satisfying the above bounds at \(u+e_m\) and (1) on all needed interior sites. It exists by restriction of the arbitrary field. The finite PSD system is semialgebraic in \(u\) and has bounded closed fibers. It admits a Borel choice, for example the unique minimum squared Euclidean norm in the fiber with its semialgebraic graph.

Define the measurable positive field
\[
 Y_R(x)=|I_R|^{-1}\sum_{m\in I_R}Y^{x-e_m}_m .
\]
It satisfies the same quadratic size bound uniformly. In equation (1) for \(Y_R(x+e_a)\), replace the index \(m\) by \(n+a\). All terms on the common interior then come from a *single* finite system at \(u=x-e_n\). Replacing each shifted index set by \(I_R\) costs \(O((1+x^2)/R)\) because the symmetric differences have this relative size and the shifts \(a\) are fixed. The right side on every exact system is identical at the physical energy \(x\). Taking a weak-star subsequence in bounded \(L^\infty\) balls on compact intervals and a diagonal limit gives a measurable PSD field satisfying (1) almost everywhere. Closedness of the cone follows by testing against nonnegative scalar functions and a countable dense family of vectors.

Convolve in \(x\) with an even nonnegative Schwartz probability of variance \(\sigma^2\) and compactly supported Fourier transform. For instance take the squared modulus of the inverse Fourier transform of a smooth compactly supported even bump, normalize, and scale. All equations now hold everywhere, \(c\) changes to \(c-\sigma^2\), and \(\lambda\) stays the same. Such smoothing has arbitrarily small variance and gives a bandlimited field of at most quadratic growth. This is a one-dimensional dual even when the energy group of the system is dense and the sector module is singular.

## A dual with a strict positive margin

There exists a fixed real quadratic-polynomial field \(Y_b(x)\) solving (1) at some \(c_b<0\), with \(Y_b(x)\succeq\delta_b(1+x^2)I\) globally. To construct it use the diagonal trace of the actual sector equations. Weight each total-energy equation by \(1+E^2\) and sum. For a sector tuple this gives
\[
 \sum_{z,b} [1+(z+f_b)^2]\operatorname{Tr}[(I\otimes |b\rangle\langle b|)J_z]
   =\sum_{x,i} [1+(x+e_i)^2]p_x .
\]
Here \(e_i,f_b\) are input and output energies and \(J_z\) is the Choi congruence of \(C_z\) by the fixed independent Kraus columns (including the chosen transpose convention). Add a small positive multiple of the left minus the right to the functional with program coefficient \(x^2-c_b\). The new matrix coefficient dominates a fixed positive multiple of \(1+x^2\), since the Kraus column map is injective. Choose the multiple small enough to keep a positive leading scalar coefficient and \(c_b\) sufficiently negative for a global scalar margin. This identity has \(\lambda=0\). Mixing a small fraction of \(Y_b\) with the optimizing field and convolving as above produces lower bounds arbitrarily close to optimal with a strictly positive quadratic margin. The construction uses the *physical* sector structure in addition to the abstract Laurent module.

This sharp dual yields new lower witnesses at singularities, but an arbitrary infinite field is not yet a finite numerical lower certificate. The next proof target is approximation by finite polynomial–exponential fields, preserving the exact finite-difference identities and the positivity margin. No independent review or priority claim.
