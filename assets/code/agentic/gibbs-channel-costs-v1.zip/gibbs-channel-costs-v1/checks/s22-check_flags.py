"""Exact controls for flag reduction, graph tangents, and rational-shift descent."""
from collections import defaultdict, deque
from fractions import Fraction as Q
from itertools import product
from sympy import I, Matrix, Rational, diag, eye, zeros


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def vector_op(x, y, sign=1):
    return tuple(a + sign*b for a, b in zip(x, y))


def subspace_kernel(matrices):
    return Matrix.vstack(*matrices).nullspace()


def good_flag(polynomial, direction):
    size = next(iter(polynomial.values())).rows
    surviving = eye(size)
    heights = sorted({dot(a, direction) for a in polynomial}, reverse=True)
    for height in heights:
        leading = [f for a, f in polynomial.items() if dot(a, direction) == height]
        columns = [f * surviving for f in leading]
        for column in columns:
            compression = surviving.H * column
            if compression.is_positive_semidefinite is not True:
                return False
            if any(column*v != zeros(size, 1) for v in compression.nullspace()):
                return False
        kernel = subspace_kernel(columns)
        if not kernel:
            return True
        surviving = surviving * Matrix.hstack(*kernel)
    return False


def active_graph(generators, v, levels):
    """An entry is (matrix grade, exponent). Different nonzero coords can share labels."""
    adjacency = defaultdict(list)
    edges = []
    for j, entries in enumerate(generators):
        top = max(dot(v, a) - levels[g] for g, a in entries)
        for g, a in entries:
            if dot(v, a) - levels[g] == top:
                i, k = ('g', g), ('j', j)
                adjacency[i].append((k, a))
                adjacency[k].append((i, a))
                edges.append((i, k, a))
    potentials = {}
    for start in adjacency:
        if start in potentials:
            continue
        potentials[start] = (0,)*len(v)
        pending = deque([start])
        while pending:
            i = pending.popleft()
            for j, alpha in adjacency[i]:
                if j not in potentials:
                    potentials[j] = vector_op(alpha, potentials[i], -1)
                    pending.append(j)
    residuals = [vector_op(a, vector_op(potentials[i], potentials[j]), -1)
                 for i, j, a in edges]
    assert all(dot(v, a) == 0 for a in residuals)
    return edges, residuals


one, x, y = (0, 0), (1, 0), (0, 1)
pure_plus = Matrix([[1, I], [-I, 1]])
pure_minus = Matrix([[1, -I], [I, 1]])
positive = {y: diag(1, 0), one: pure_plus, x: pure_minus}
rotation = Matrix([[Rational(3, 5), Rational(4, 5)*I],
                   [Rational(4, 5)*I, Rational(3, 5)]])
assert rotation.H * rotation == eye(2)
for normal in product(range(-3, 4), repeat=2):
    if normal != (0, 0):
        assert good_flag(positive, normal)
        assert good_flag({a: rotation.H*f*rotation for a, f in positive.items()}, normal)

# Isolate the compatibility that is invisible to a diagonal principal-block test.
bad = {y: diag(1, 0), one: eye(2), (2, 0): diag(1, 0),
       x: Matrix([[0, I], [-I, 0]])}
assert not good_flag(bad, (0, 1))
assert all(m[1, 1] >= 0 for a, m in bad.items() if a[1] == 0)
assert bad[x][0, 1] != 0 and bad[x][1, 1] == 0
# Explicit tangent of a complex upper column with a tied face: active exponents
# of group zero align at y and those of group one at 1 and x.
edges, residuals = active_graph([[(0, y), (0, one), (0, x),
                                   (1, one), (1, x), (1, one), (1, x)]],
                                 (0, 1), [1, 0])
assert len(edges) == 5
assert Matrix(residuals).rank() == 1
assert all(a[1] == 0 for a in residuals)

# A genuine fractional choice in an open chart at an integer primitive normal.
# No integer lies strictly between the required heights 0 and 1.
entries = [[(0, (1,)), (1, (0,))], [(0, (0,)), (1, (0,))]]
edges, residuals = active_graph(entries, (1,), [Q(1, 2), 0])
assert {(i[1], j[1]) for i, j, _ in edges} == {(0, 0), (1, 1)}
assert set(residuals) == {(0,)}
fractional = {Q(1, 2): diag(1, 0), Q(-1, 2): diag(0, 1), Q(0): eye(2)}
descended = {}
for exponent, f in fractional.items():
    translate = Q(1, 2) if exponent.denominator == 2 else 0
    k = exponent + translate
    assert k.denominator == 1
    descended[k] = descended.get(k, zeros(2)) + f
assert descended == {0: diag(1, 2), 1: diag(1, 0)}
assert sum(fractional.values(), zeros(2)) == sum(descended.values(), zeros(2))
print("PASS: 96 exact flag decisions, rejected cross-column mutation, rank-one tangential graph, fractional-height chart with exact integer descent")
