"""Exact graded-energy and all-temperature controls for the work certificate."""
from collections import Counter
from fractions import Fraction as F


# Input/output environments of a valid identity isometry, with one additional
# output state. This deliberately nonoptimal template has an interior maximum.
A = Counter({F(1): 1, F(1, 10): 100})
B = A.copy()
B[F(9, 10)] += 1


def partition(levels, t):
    return sum(weight**t * multiplicity for weight, multiplicity in levels.items())


endpoint = partition(B, 1) / partition(A, 1)
interior_squared = partition(B, 2) / partition(A, 2)
assert endpoint == F(119, 110)
assert interior_squared == F(281, 200)
assert max(B)/max(A) == 1
threshold = F(11, 10)
assert endpoint < threshold and max(B)/max(A) < threshold
assert interior_squared > threshold**2

# Finite norm monotonicity and its reverse with cardinality, without logs.
for counts in (A, B, Counter({F(1): 2, F(2, 7): 3, F(9, 4): 1})):
    n = sum(counts.values())
    for p, q in ((1, 2), (2, 3), (3, 8), (8, 13)):
        # ||x||q <= ||x||p <= n^(1/p-1/q) ||x||q.
        left = partition(counts, q)**p
        middle = partition(counts, p)**q
        assert left <= middle <= n**(q-p) * left

# Energy-compensating SWAP on a nonzero-gap qubit: reconstruct graph offsets,
# measured channel and partition equality at three inverse temperatures.
weights = [F(1), F(2, 5)]
edges = [(i, a, a, i) for i in range(2) for a in range(2)]  # i,a -> j,gamma
assert all(weights[i]*weights[a] == weights[j]*weights[g]
           for i, a, j, g in edges)
u = [w/sum(weights) for w in weights]
for i in range(2):
    output = [sum(u[a] for s,a,b,g in edges if s == i and b == j) for j in range(2)]
    assert output == u
for t in (1, 2, 7):
    before = sum((weights[i]*u[a])**t for i,a,j,g in edges)
    after = sum((weights[j]*u[g])**t for i,a,j,g in edges)
    assert before == after
print("PASS: algebraic interior-temperature obstruction, 12 norm-mesh controls, exact Gibbs SWAP and three all-temperature balances")
