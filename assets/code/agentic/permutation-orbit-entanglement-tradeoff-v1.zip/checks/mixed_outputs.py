"""Two-use noncommuting controls for the entropy sandwich (requires NumPy)."""
import json
import numpy as np


def entropy(state):
    eig = np.linalg.eigvalsh((state + state.conj().T) / 2)
    assert eig[0] > -1e-12
    eig = eig[eig > 1e-14]
    return float(-np.dot(eig, np.log2(eig)))


def channel(state, kraus):
    return sum(op @ state @ op.conj().T for op in kraus)


def complement(state, kraus):
    return np.array([[np.trace(a @ state @ b.conj().T) for b in kraus] for a in kraus])


def run():
    rng = np.random.default_rng(115)
    swap = np.eye(4)[[0, 2, 1, 3]]
    symmetric = (np.eye(4) + swap) / 2
    antisymmetric = np.eye(4) - symmetric
    omega = symmetric / 6 + antisymmetric / 2
    neg_log_omega = np.log2(6) * symmetric + antisymmetric
    operators = [np.diag([1, np.sqrt(0.71)]), np.array([[0, np.sqrt(0.29)], [0, 0]])]
    kraus = [np.kron(a, b) for a in operators for b in operators]
    count, changed = 0, 0
    for trial in range(64):
        f_orbit, f_ref, ys = [], [], []
        slope = (trial % 9) / 8
        for sample in range(3):
            z = rng.normal(size=(4, 3)) + 1j*rng.normal(size=(4, 3))
            r = z @ z.conj().T
            r /= np.trace(r)
            y, e = channel(r, kraus), complement(r, kraus)
            assert np.allclose(channel(swap @ r @ swap, kraus), swap @ y @ swap)
            assert np.allclose(complement(swap @ r @ swap, kraus), swap @ e @ swap)
            twirl = (y + swap @ y @ swap)/2
            assert np.linalg.eigvalsh(6*omega-twirl)[0] > -1e-12
            linear = (1-slope)*entropy(r)-entropy(e)
            f_orbit.append(entropy(twirl)+linear)
            f_ref.append(np.trace(y @ neg_log_omega).real+linear)
            assert -1e-11 <= f_ref[-1]-f_orbit[-1] <= np.log2(6)+1e-11
            changed += abs(entropy(twirl)-entropy(y)) > 1e-7
            ys.append((y, linear))
        p = [0.2, 0.3, 0.5]
        support = entropy(sum(w*y for w,(y,v) in zip(p, ys)))+sum(w*v for w,(y,v) in zip(p, ys))
        assert support <= np.dot(p, f_ref)+1e-11 <= max(f_orbit)+np.log2(6)+1e-11
        count += 1
    assert changed == 3*count
    return {"two_use_amplitude_damping_ensembles": count, "noninvariant_outputs": changed,
            "schur_domination_constant": 6}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
