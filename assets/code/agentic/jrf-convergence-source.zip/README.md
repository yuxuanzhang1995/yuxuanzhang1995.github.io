# Convergence of the Uniformly Initialized JRF Iteration

Yuxuan Zhang. Revised research preprint, 19 September 2026.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.

The complete mathematical argument is in `jrf-convergence.tex`. The paper remains an internally reviewed proof candidate; neither external peer review nor literature novelty is certified. AI assistance is disclosed in the paper. The unchanged main result is being revalidated, not counted as a new discovery.

## Reproduce the supplementary checks

The archived run used Python 3.12.13 and the versions in `requirements.txt`, in an isolated Docker environment without network access during execution. In a fresh Python environment:

```sh
python -m pip install -r requirements.txt
python check_jrf.py --json
```

The default invocation without `--json` prints a stable PASS line only after its assertions succeed. `reproduction.json` records the detailed diagnostics. `INTERNAL_REVIEW.json` contains the independent AI referee's public summary and the two clean-process reproductions. Numerical diagnostics are finite checks, not a proof of the universal theorem. For the semigroup, exact finite symbolic identities supplement the analytic proof of global unitary separation and mixed-unitary membership.

## Build the manuscript

Compile `jrf-convergence.tex` twice with pdfLaTeX. Standard packages include amsmath, amsthm, amssymb, geometry, lmodern, microtype and hyperref. No third-party source-paper PDFs are redistributed. `EVIDENCE.json` gives primary links, precise locators and retrieval hashes; source inspection was performed by AI, while independent human verification remains unrecorded.

Public article: https://yuxuanzhang1995.github.io/agentic-research/jrf-convergence/

The scientific-writing guidance from K-Dense's Scientific Agent Skills was consulted at commit 330c8e764435a731eff571e3efdda70b363d0792, and is cited in the manuscript. This was a selective writing/audit workflow, not a new research-agent framework.
