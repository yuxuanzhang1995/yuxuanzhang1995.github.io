"""Prospectively registered Q005 three-copy relaxation, exact recoupling data.

Discovery code, not a mathematical validity oracle. Rational coefficient
construction is separate from numerical SDP and later certificate checking.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial, isqrt
import numpy as np
import sympy as sp
from sympy.physics.wigner import clebsch_gordan, wigner_6j


@lru_cache(None)
def delta2(a, b, c):
    x, y, z, w = a+b-c, a-b+c, -a+b+c, a+b+c+1
    if min(x, y, z) < 0 or any(t.denominator != 1 for t in [x,y,z,w]):
        return F(0)
    return F(factorial(int(x))*factorial(int(y))*factorial(int(z)), factorial(int(w)))


@lru_cache(None)
def racah(a, b, c, d, e, f):
    """Rational factorial sum in {a b c; d e f}, without four triangle factors."""
    if not all(delta2(*t) for t in [(a,b,c),(a,e,f),(d,b,f),(d,e,c)]):
        return F(0)
    lo = [a+b+c, a+e+f, d+b+f, d+e+c]
    hi = [a+b+d+e, a+c+d+f, b+c+e+f]
    assert all(t.denominator == 1 for t in lo+hi)
    out = F(0)
    for z in range(int(max(lo)), int(min(hi))+1):
        den=1
        for t in lo: den*=factorial(int(z-t))
        for t in hi: den*=factorial(int(t-z))
        out += F((-1)**z*factorial(z+1), den)
    return out


def sgn(x):
    assert x.denominator == 1
    return (-1)**int(x)


def matrix_frac(a):
    return np.array([[F(x) for x in row] for row in a], dtype=object)


def recoupling(n):
    """Rationally scaled blocks. X=diag(t*q) Z diag(t*q).

    Z is twirled from H on the +1 swap12 eigenspace. No reality restriction
    on the original code: conjugate-averaging is done on the moment itself.
    """
    j=F(n,2); blocks=[]
    for twiceJ in range(n%2,3*n+1,2):
        J=F(twiceJ,2)
        aa=list(range(int(abs(J-j)),min(n,int(J+j))+1))
        ds=[]; qs=[]
        for a in aa:
            d=F(2*a+1)*delta2(j,j,F(a))*delta2(j,J,F(a))
            # Power-of-two scaling uses rational arithmetic; keeps d*q^2 in [1,4).
            q=F(1)
            while d*q*q < 1: q*=2
            while d*q*q >= 4: q/=2
            ds.append(d); qs.append(q)
        rr=np.array([[sgn(F(n))*racah(j,j,F(a),j,J,F(b)) for b in aa] for a in aa],dtype=object)
        R=np.array([[rr[u,v]*ds[v]*qs[v]/qs[u] for v in range(len(aa))] for u in range(len(aa))],dtype=object)
        D=np.diag([F((-1)**(n-a)) for a in aa])
        I=np.eye(len(aa),dtype=object)
        I[:]=[[F(int(u==v)) for v in range(len(aa))] for u in range(len(aa))]
        assert np.array_equal(R@R,I)
        assert np.array_equal((D@R)@(D@R)@(D@R),I)
        keep=[u for u,a in enumerate(aa) if (n-a)%2==0]
        B=I[:,keep]
        group=[I,D,R,D@R@D,D@R,R@D]
        W=[g@B for g in group]
        blocks.append(dict(n=n,J=J,aa=aa,d=[d*q*q for d,q in zip(ds,qs)],q=qs,R=R,W=W,keep=keep))
    return blocks


def h_rational(block,a,b,l):
    """Reduced coefficient after stripping a common nonzero (a,b,l) factor."""
    n=block['n'];j=F(n,2);J=block['J']
    if a not in block['aa'] or b not in block['aa']: return F(0)
    ia=block['aa'].index(a);ib=block['aa'].index(b)
    return ((2*J+1)*sgn(F(b)+j+J)*delta2(j,J,F(a))*delta2(j,J,F(b))
            *racah(F(a),j,J,j,F(b),F(l))*block['q'][ia]*block['q'][ib])


def basis_transform(block,u,v):
    out=np.zeros((len(block['aa']),len(block['aa'])),dtype=object)
    for W in block['W']:
        out+=np.outer(W[:,u],W[:,v])
        if u!=v:out+=np.outer(W[:,v],W[:,u])
    return out/F(6)


def exact_system(n,depth=4,K=2):
    """A*x=b, where x are independent entries of positive H_J blocks."""
    blocks=recoupling(n)
    labels=[('trace',)]+[(l,a,b) for l in range(depth+1) for a in range(n+1)
                        for b in range(n+1) if abs(a-b)<=l<=a+b]
    columns=[]; variables=[]
    for bi,block in enumerate(blocks):
        aa=block['aa'];ix={a:i for i,a in enumerate(aa)}
        hs={li:h_rational(block,a,b,l) for li,(l,a,b) in enumerate(labels[1:],1) if a in ix and b in ix}
        s=len(block['keep'])
        for u in range(s):
            for v in range(u,s):
                Z=basis_transform(block,u,v)
                # X R in physical coordinates becomes Z R_scaled^T.
                Y=Z@block['R'].T-Z/F(K)
                col=[F(0)]*len(labels)
                col[0]=(2*block['J']+1)*sum(block['d'][a]*Z[a,a] for a in range(len(aa)))
                for li,(l,a,b) in enumerate(labels[1:],1):
                    if a in ix and b in ix:
                        col[li]=hs[li]*Y[ix[b],ix[a]]
                columns.append(col);variables.append((bi,u,v))
    A=np.array(columns,dtype=object).T
    rhs=np.array([F(K**3)]+[F(0)]*(len(labels)-1),dtype=object)
    return blocks,labels,variables,A,rhs


def enumerator_inequalities(n,blocks,variables,K=2):
    j=F(n,2)
    def six(a,l):
        return delta2(j,j,F(a))*delta2(j,j,F(l))*racah(j,j,F(a),j,j,F(l))
    f=np.array([[F((-1)**(n+a)*(2*l+1))*six(a,l) for a in range(n+1)] for l in range(n+1)],dtype=object)
    M=np.array([[F((-1)**(n+a+l)*(2*l+1))*six(a,l) for a in range(n+1)] for l in range(n+1)],dtype=object)
    A=np.zeros((n+1,len(variables)),dtype=object)
    for ci,(bi,u,v) in enumerate(variables):
        block=blocks[bi];Z=basis_transform(block,u,v)
        for l in range(n+1):
            A[l,ci]=(2*block['J']+1)/K*sum(f[l,a]*block['d'][ai]*Z[ai,ai] for ai,a in enumerate(block['aa']))
    B=M@A;S=M@np.diag([F((-1)**l) for l in range(n+1)])@A
    return np.concatenate([A,B-A/F(K),S],axis=0),A


def coupled_matrix(n,J,M):
    """Direct CG construction for independent small-n convention controls."""
    j=sp.Rational(n,2);J=sp.Rational(J);M=sp.Rational(M)
    ms=[-j+i for i in range(n+1)]
    aa=list(range(int(abs(J-j)),min(n,int(J+j))+1))
    C=sp.zeros((n+1)**3,len(aa))
    for i,m1 in enumerate(ms):
        for k,m2 in enumerate(ms):
            m12=m1+m2;m3=M-m12
            if m3 not in ms: continue
            z=ms.index(m3)
            for u,a in enumerate(aa):
                C[(i*(n+1)+k)*(n+1)+z,u]=clebsch_gordan(j,j,a,m1,m2,m12)*clebsch_gordan(a,j,J,m12,m3,M)
    return aa,C


def tensor0(a,b,l):
    a=sp.Rational(a);b=sp.Rational(b)
    return sp.Matrix([[( (-1)**int(b-mb)*clebsch_gordan(a,b,l,ma,-mb,0))
        for mb in [-b+i for i in range(int(2*b)+1)]]
        for ma in [-a+i for i in range(int(2*a)+1)]])


def convention_checks():
    checks=0
    for n in [1,2,3]:
        j=sp.Rational(n,2);N=n+1
        for twiceJ in range(n%2,3*n+1,2):
            J=sp.Rational(twiceJ,2)
            aa,C=coupled_matrix(n,J,J)
            sw=C.copy()
            for i in range(N):
                for k in range(N):
                    for z in range(N): sw[(i*N+k)*N+z,:]=C[(z*N+k)*N+i,:]
            R=sp.simplify(C.T*sw)
            Rf=sp.Matrix([[(-1)**n*sp.sqrt((2*a+1)*(2*b+1))*wigner_6j(j,j,a,j,J,b) for b in aa] for a in aa])
            assert R==Rf,(n,J,R,Rf);checks+=len(aa)**2
            for l in range(min(4,n)+1):
                T=tensor0(j,j,l)
                for a in aa:
                    for b in aa:
                        if not abs(a-b)<=l<=a+b:continue
                        A=tensor0(a,b,l);val=0
                        for twiceM in range(-twiceJ,twiceJ+1,2):
                            M=sp.Rational(twiceM,2)
                            for ma in range(-a,a+1):
                                if not -b<=ma<=b:continue
                                m=M-ma
                                if not -j<=m<=j:continue
                                val+=clebsch_gordan(a,j,J,ma,m,M)*clebsch_gordan(b,j,J,ma,m,M)*A[ma+a,ma+b]*T[int(m+j),int(m+j)]
                        expected=(2*J+1)*(-1)**int(b+j+J)*wigner_6j(a,j,J,j,b,l)
                        assert sp.simplify(val-expected)==0,(n,J,l,a,b,val,expected)
                        checks+=1
    return checks


if __name__=='__main__':
    print({'direct_cg_checks':convention_checks()})
