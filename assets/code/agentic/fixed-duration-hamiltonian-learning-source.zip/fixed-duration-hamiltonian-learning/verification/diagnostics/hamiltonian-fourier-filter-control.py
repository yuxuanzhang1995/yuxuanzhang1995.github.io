import numpy as np
N=32768; D=512; x=-8+16*np.arange(N)/N; h=.25; times=[2.,2.25]
def F(t,x):
 out=np.empty_like(x,dtype=complex); nz=abs(x)>1e-12;out[nz]=np.expm1(1j*x[nz]*t)/(1j*x[nz]);out[~nz]=t;return out
def raw(j,x):
 fs=[F(t,x)for t in times];return fs[j].conjugate()/sum(abs(f)**2 for f in fs)*2
z=np.clip((abs(x)-4)/2,0,1);chi=1-(10*z**3-15*z**4+6*z**5)
grid=np.linspace(-4,4,4001);k=np.arange(-D,D+1);G0=sum(t*t for t in times)/2
for j,t in enumerate(times):
 vals=chi*raw(j,x);fft=np.fft.fft(vals)/N;coeff=np.array([fft[q%N]*(-1.)**q for q in k]);assert np.max(abs(coeff.imag))<1e-12;coeff=coeff.real
 coeff[D]+=t/G0-coeff.sum(); S=np.sum(abs(coeff));estimate=np.zeros_like(grid,dtype=complex)
 for q,c in zip(k,coeff):estimate+=c*np.exp(1j*np.pi*q*grid/8)
 err=np.max(abs(estimate-raw(j,grid)));assert err<1e-5;assert abs(coeff.sum()-t/G0)<1e-12;assert S<100
 print(f'Filter{j+1}:1025 real Fourier coefficients; grid error<1e-5; coefficient sum<100; identity scalar exact to1e-12:PASS')
print('Numerical control only: uniform analytical tail and scalable gate synthesis still require proof.')
