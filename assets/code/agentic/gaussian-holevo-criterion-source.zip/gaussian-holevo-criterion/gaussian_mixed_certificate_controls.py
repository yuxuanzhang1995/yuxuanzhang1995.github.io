import sympy as s,json
I=s.eye(2);O=s.Matrix([[0,1],[-1,0]]);V=I;Gamma=V+s.I*O/2;Z=s.diag(1,-1);X=s.Matrix([[0,1],[1,0]]);Bs=[s.diag(1,0),s.diag(0,1),X/2];S=s.diag(Gamma,s.Matrix([[2*s.trace(B*Gamma*C*Gamma.T)for C in Bs]for B in Bs]));out=[]
R=s.Rational
for name,G,ms,ds,W in [('traceless covariance',R(2,3)*I,s.zeros(2),[Z,X],I),('traceless mixed',R(2,3)*I,I,[Z,X],I),('trace-bearing mixed homodyne',s.diag(1,0),s.Matrix([[0,1],[-R(1,6),0]]),[I+R(5,3)*Z,X],s.diag(R(256,9),1))]:
 J=ms.col_join(s.Matrix([[s.trace(B*D)for D in ds]for B in Bs]));L=s.zeros(5,2)
 for j,D in enumerate(ds):
  b=G*D*G/2;c=G*ms[:,j];L[:,j]=s.Matrix([*c,b[0,0],b[1,1],2*b[0,1]])
 F=s.simplify(J.T*L);E=F.inv();A=L*E;P=s.eye(5)-J*(J.T*J).inv()*J.T;Q=s.simplify(E-A.T*S*A)
 z=s.symbols('z',real=True);Y=W+s.I*z*O;station=s.simplify(P*s.re(S*A*Y));sat=s.simplify(Y*Q);sol=s.solve(list(station)+list(sat),[z]);assert z in sol
 YY=Y.subs(sol);assert all(e>=0 for e in YY.eigenvals()) and all(e>=0 for e in Q.eigenvals())
 assert s.simplify(YY*Q)==s.zeros(2) and s.simplify(P*s.re(S*A*YY))==s.zeros(5,2)
 out.append({'model':name,'cost':str(s.trace(W*E)),'Y_imaginary_parameter':str(sol[z]),'noise_saturation':'exact','projected_stationarity':'exact','Y_positive_semidefinite':'exact'})
print(json.dumps({'status':'passed','scope':'Independent exact nonlinear and mixed-model controls for general criterion. Not a proof of necessity/completeness.','controls':out},indent=2))
