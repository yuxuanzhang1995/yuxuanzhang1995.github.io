import itertools,numpy as np
from p11_free_pulses_common import E,p,b,blocks
q=np.exp(-1);Zsm=(1+q+q*q)*(1+q)
def profile_controls(profile):
 src={int(e):list(np.flatnonzero(E==e)) for e in set(E)};V=np.empty(6,dtype=int)
 for dest,e in enumerate(profile):V[src[e].pop()]=dest
 return V
def profile_blocks(profile):
 incoming=np.array([profile[s]+r for s in range(6) for r in range(3)]);out=[]
 for B in blocks:
  patterns=sorted(set(itertools.permutations(incoming[B].tolist())));rows=[];maps=[]
  for pat in patterns:
   C=np.zeros((6,6),dtype=np.int8);U=np.arange(18,dtype=np.int8);sources={e:list(B[incoming[B]==e]) for e in set(pat)}
   for dest,e in zip(B,pat):C[dest//3,e]+=1;U[sources[e].pop()]=dest
   rows.append(C.ravel());maps.append(U)
  out.append((np.array(rows),np.array(maps)))
 return out
def enumerate_profile(profile):
 groups=profile_blocks(profile);shape=tuple(len(a) for a,u in groups);indices=np.array(list(itertools.product(*(range(n) for n in shape))),dtype=np.int32);N=np.zeros((len(indices),36),dtype=np.int8)
 for j,(a,u) in enumerate(groups):N+=a[indices[:,j]]
 unique,ix=np.unique(N,axis=0,return_index=True);U=np.tile(np.arange(18,dtype=np.int8),(len(ix),1))
 for j,((a,u),B) in enumerate(zip(groups,blocks)):U[:,B]=u[indices[ix,j]][:,B]
 return unique.reshape(-1,6,6),U,dict(block_assignments=list(shape),raw_combinations=len(indices),distinct_states=len(unique))
def suffix_bounds(states,first_work,y):
 """Any remaining quantum unitary on SM plus two fresh baths, tilted energy bound."""
 energies=np.array([E[s]+r+t for s in range(6) for r in range(3) for t in range(3)]);rewards=np.repeat(y,9);knots={0.,1.}
 for i in range(54):
  for j in range(i):
   if energies[i]!=energies[j]:
    z=(rewards[i]-rewards[j])/(energies[i]-energies[j])
    if 0<z<1:knots.add(float(z))
 knots=np.array(sorted(knots));obs=np.array([np.sort(rewards-z*energies) for z in knots]);spec=np.sort((states[:, :,None]*np.outer(b,b).ravel()[None,None,:]).reshape(-1,54),axis=1);energy=states@E+2*b@np.arange(3);vals=spec@obs.T+energy[:,None]*knots[None,:]-first_work-float(y@p);idx=np.argmin(vals,axis=1)
 return vals[np.arange(len(states)),idx],knots,idx
