"""Independent controls: direct CG/product-code construction, then author comparisons.
The control construction imports no author routines. Floats are diagnostics only.
"""
from pathlib import Path
from functools import lru_cache
from itertools import product
from math import comb,sqrt
import sys,json,time
import numpy as np
import sympy as sp
from sympy.physics.wigner import clebsch_gordan,wigner_6j
ROOT=Path(__file__).resolve().parent
R=sp.Rational
@lru_cache(None)
def cg(j1,j2,j,m1,m2,m):
    if m1+m2!=m:return 0.0
    return float(clebsch_gordan(j1,j2,j,m1,m2,m))
def specs(n):
    j=R(n,2)
    return [(R(t,2),list(range(int(abs(R(t,2)-j)),min(n,int(R(t,2)+j))+1))) for t in range(n%2,3*n+1,2)]
def sparse_product(vs):
    ans={}
    for inds in product(*[np.flatnonzero(np.any(abs(v)>1e-15,axis=1)) for v in vs]):
        ans[tuple(map(int,inds))]=np.kron(np.kron(vs[0][inds[0]],vs[1][inds[1]]),vs[2][inds[2]])
    return ans
def direct_blocks(n,vs):
    j=R(n,2);terms=sparse_product(vs);out=[]
    for J,aa in specs(n):
        bm={R(t,2):np.zeros((len(aa),8),complex) for t in range(int(-2*J),int(2*J)+1,2)}
        for (i,k,z),v in terms.items():
            m1,m2,m3=[R(x)-j for x in (i,k,z)];M=m1+m2+m3
            if M not in bm:continue
            for p,a in enumerate(aa):
                bm[M][p]+=cg(j,j,a,m1,m2,m1+m2)*cg(a,j,J,m1+m2,m3,M)*v
        out.append(sum((b@b.conj().T for b in bm.values()),np.zeros((len(aa),len(aa)),complex))/float(2*J+1))
    return out
def flip(n):
    ans=np.zeros((n+1,n+1))
    for w in range(n+1):ans[n-w,w]=(-1)**w
    return ans
def direct_h(n,J,a,b,l):
    j=R(n,2);value=sp.S(0)
    for tM in range(int(-2*J),int(2*J)+1,2):
        M=R(tM,2)
        for m in range(max(-a,-b),min(a,b)+1):
            u=M-m
            if abs(u)>j:continue
            value+=clebsch_gordan(a,j,J,m,u,M)*clebsch_gordan(b,j,J,m,u,M)*(-1)**(b-m)*clebsch_gordan(a,b,l,m,-m,0)*(-1)**int(j-u)*clebsch_gordan(j,j,l,u,-u,0)
    return sp.simplify(value)
def tensors(n):
    j=R(n,2)
    for l in range(n+1):
        ts=[]
        for q in range(-l,l+1):
            t=np.zeros((n+1,n+1))
            for c in range(n+1):
                r=c+q
                if 0<=r<=n:t[r,c]=(-1)**(n-c)*cg(j,j,l,R(r)-j,j-R(c),q)
            ts.append(t)
        yield l,ts
def erasure_exact(n,v,k):
    """Trace-k error Kraus maps in the Dicke basis, exact algebraic arithmetic."""
    mats=[]
    for a in range(k+1):
        e=sp.zeros(n-k+1,n+1)
        for w in range(n+1):
            if 0<=w-a<=n-k:e[w-a,w]=sp.sqrt(R(comb(k,a)*comb(n-k,w-a),comb(n,w)))
        mats.append(e*v)
    checks=0
    for x in mats:
        for y in mats:
            gram=sp.simplify(x.conjugate().T*y)
            assert sp.simplify(gram[0,1])==0 and sp.simplify(gram[1,0])==0 and sp.simplify(gram[0,0]-gram[1,1])==0
            checks+=3
    assert sp.simplify(v.conjugate().T*v)==sp.eye(2)
    return checks

def compare(n,v,depth,label):
    import moment3,ppt3
    bl=moment3.recoupling(n);sx=specs(n);X=direct_blocks(n,[v,v,v]);Y=direct_blocks(n,[v,v,flip(n)@v.conj()])
    Z=[x.real/np.sqrt(np.outer(np.array(b['d'],float),np.array(b['d'],float))) for b,x in zip(bl,X)]
    Yz=[y.real/np.sqrt(np.outer(np.array(b['d'],float),np.array(b['d'],float))) for b,y in zip(bl,Y)]
    worst_pt=0.
    for a in range(n+1):
        for b in range(a,n+1):
            ss,T=ppt3.transfer(bl,a,b)
            if not ss:continue
            inputv=np.array([Z[k][bl[k]['aa'].index(a),bl[k]['aa'].index(b)] for k in ss])
            target=np.array([Yz[k][bl[k]['aa'].index(a),bl[k]['aa'].index(b)] for k in ss])
            worst_pt=max(worst_pt,float(np.max(np.abs(np.array(T,float)@inputv-target))))
    kl=0.;physical_kl=0.;raw_ratio=0.;worst_raw=None
    for l in range(depth+1):
        for a in range(n+1):
            for b in range(n+1):
                if not abs(a-b)<=l<=a+b:continue
                terms=[];physical_terms=[];coeffs=[]
                for blj,z in zip(bl,Z):
                    if a not in blj['aa'] or b not in blj['aa']:continue
                    i=blj['aa'].index(b);k=blj['aa'].index(a)
                    coeff=float(moment3.h_rational(blj,a,b,l));coeffs.append(abs(coeff))
                    terms.append(coeff*(z@np.array(blj['R'],float).T-z/2)[i,k])
                    d=np.sqrt(np.array(blj['d'],float));x=d[:,None]*z*d[None,:];r=d[:,None]*np.array(blj['R'],float)/d[None,:]
                    h=float((2*blj['J']+1)*(-1)**int(R(b)+R(n,2)+blj['J'])*wigner_6j(a,R(n,2),R(blj['J'].numerator,blj['J'].denominator),R(n,2),b,l))
                    physical_terms.append(h*(x@r-x/2)[i,k])
                rr=abs(sum(terms))/max(sum(abs(t) for t in terms),1.0)
                if rr>raw_ratio:raw_ratio=rr;worst_raw=[l,a,b]
                kl=max(kl,abs(sum(terms))/max(coeffs+[1.0]))
                physical_kl=max(physical_kl,abs(sum(physical_terms)))
    # Independently reconstruct a seed by physical S3 projections, and check exact parametrization coverage numerically.
    seed_error=0.;std_trace=0.;sign_trace=0.;min_seed=1.
    for blj,x,z in zip(bl,X,Z):
        d=np.sqrt(np.array(blj['d'],float));r=d[:,None]*np.array(blj['R'],float)/d[None,:]
        D=np.diag([(-1)**(n-a) for a in blj['aa']]);I=np.eye(len(d));grp=[I,D,r,D@r@D,D@r,r@D]
        et=sum(grp)/6;ea=(I-D-r-D@r@D+D@r+r@D)/6
        xt=et@x.real@et;xs=x.real-xt-ea@x.real@ea;keep=blj['keep']
        hh=(xt+2*xs)[np.ix_(keep,keep)]/np.outer(d[keep],d[keep])
        pred=sum(np.array(w,float)@hh@np.array(w,float).T for w in blj['W'])/6
        seed_error=max(seed_error,float(np.max(abs(pred-z))))
        if len(hh):min_seed=min(min_seed,float(np.linalg.eigvalsh(hh).min()))
        std_trace+=float(2*blj['J']+1)*np.trace(xs)
        sign_trace+=float(2*blj['J']+1)*np.trace(ea@x.real@ea)
    P=v@v.conj().T;A=[];B=[]
    for l,ts in tensors(n):
        A.append(sum(abs(np.trace(P@t))**2 for t in ts))
        B.append(sum(np.trace(P@t.conj().T@P@t).real for t in ts))
    j=R(n,2)
    M=np.array([[float((-1)**(n+a+l)*(2*l+1)*wigner_6j(j,j,a,j,j,l)) for a in range(n+1)] for l in range(n+1)])
    moment_A=[]
    for l in range(n+1):
        moment_A.append(sum(float(2*J+1)/2*sum(float((-1)**(n+a)*(2*l+1)*wigner_6j(j,j,a,j,j,l))*X[k][p,p].real for p,a in enumerate(aa)) for k,(J,aa) in enumerate(sx)))
    out=dict(label=label,n=n,depth=depth,trace=sum(float(2*J+1)*np.trace(x).real for (J,_),x in zip(sx,X)),maximum_imaginary_block_entry=max(float(abs(x.imag).max()) for x in X),partial_time_reversal_map_error=worst_pt,lifted_row_coefficient_normalized_error=kl,lifted_physical_absolute_error=physical_kl,unstable_unnormalized_relative_diagnostic=raw_ratio,unstable_diagnostic_worst_row=worst_raw,seed_reconstruction_error=seed_error,minimum_seed_eigenvalue=min_seed,standard_component_trace=float(std_trace),sign_component_trace=float(sign_trace),enumerator_transform_error=float(max(abs(M@A-B))),enumerator_moment_error=float(max(abs(np.array(A)-moment_A))),minimum_shadow=float(min(M@np.diag([(-1)**l for l in range(n+1)])@A)))
    print('DIAGNOSTIC',json.dumps(out),flush=True)
    (ROOT/f'control-diagnostic-n{n}.json').write_text(json.dumps(out,indent=2)+'\n')
    assert abs(out['trace']-8)<1e-10
    assert worst_pt<1e-10 and seed_error<1e-10 and kl<1e-10 and physical_kl<1e-10 and min_seed>-1e-10
    assert out['enumerator_transform_error']<1e-10 and out['enumerator_moment_error']<1e-10 and out['minimum_shadow']>-1e-10
    return out

def main():
    sys.path.insert(0,str(ROOT/'clean-replay'))
    import moment3
    result={'construction':'independent direct CG contractions and product-code factors; author functions used only as comparison targets','controls':[],'exact_h_controls':[]}
    cases=[(9,R(9,2),2,3,1),(10,R(6),4,6,4),(17,R(17,2),7,8,3),(18,R(10),6,8,4),(18,R(9),7,9,2),(9,R(11,2),4,5,3)]
    for n,J,a,b,l in cases:
        actual=direct_h(n,J,a,b,l)
        expected=(2*J+1)*(-1)**int(R(b)+R(n,2)+J)*wigner_6j(a,R(n,2),J,R(n,2),b,l)
        assert sp.simplify(actual-expected)==0
        result['exact_h_controls'].append(dict(n=n,J=str(J),a=a,b=b,l=l,value=str(actual),passed=True))
    rng=np.random.default_rng(7102026)
    for n in [2,3,5]:
        v,_=np.linalg.qr(rng.normal(size=(n+1,2))+1j*rng.normal(size=(n+1,2)))
        o=compare(n,v,0,'generic complex rank-two projector; identity sector only');result['controls'].append(o);print(json.dumps(o),flush=True)
    # Primary AAB explicit d=5 code; no author control code imported.
    v=sp.zeros(22,2)
    v[0,0]=sp.sqrt(R(5,68));v[8,0]=sp.sqrt(R(7,12));v[17,0]=sp.sqrt(R(35,102))
    v[4,1]=sp.sqrt(R(35,102));v[13,1]=-sp.sqrt(R(7,12));v[21,1]=-sp.sqrt(R(5,68))
    result['exact_erasure_21']={'erased_qubits':4,'scalar_and_offdiagonal_identities':erasure_exact(21,v,4),'orthonormal':True}
    print(json.dumps(result['exact_erasure_21']),flush=True)
    o=compare(21,np.array(v,complex),4,'exact AAB 21-qubit distance-five code');result['controls'].append(o);print(json.dumps(o),flush=True)
    (ROOT/'INDEPENDENT-CONTROLS.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
