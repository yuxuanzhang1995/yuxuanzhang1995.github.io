# Finite-density synchronized holes: a candidate beta^(1/4) thermal lower bound

12 November 2026. Full-original proof candidate for Q048/P13, derived and
reviewed by the same agent. Independent review and novelty are unresolved.
This is a modified local Hamiltonian, not a new estimate for the original
one-hole Gottesman–Hastings Hamiltonian. Natural logarithms throughout.

## Theorem and parameters

There are a fixed local dimension, fixed interaction range, uniformly bounded
local terms, and one-dimensional open-chain Hamiltonians H_N, for all sufficiently
large N divisible by four, such that with beta_N=2^44 N^4,

    I(L:R)_(exp(-beta_N H_N)/Tr exp(-beta_N H_N)) >= (log 2) N/8.    (1)

The chain has N sites of dimension nine and L:R is its middle cut. Consequently
Q048's requested lower bound holds with gamma=1/4 and a=0. The constants are
intentionally very loose. No efficient preparation or practical temperature is
claimed. In particular, the proof must control the whole Gibbs state, rather
than a fixed-particle-number projection.

## 1. Actual local Hamiltonian

Begin with two rings, labelled L,R, each containing N qutrits with basis
{x,0,1}. x is a hole and 0,1 carry a qubit. Let q_i=|x><x|_i. Within either
ring include, for i=1,...,N-1, the positive hopping term

    h_i=sum_(a=0,1) (|x a>-|a x>)(<x a|-<a x|)_(i,i+1).          (2)

At the four endpoints (L_N,L_1,R_N,R_1), include

    h_B=sum_(a,b=0,1) |v_ab><v_ab|,
    v_ab=|x a>_(L_N,L_1)|x b>_(R_N,R_1)
          -|a x>_(L_N,L_1)|b x>_(R_N,R_1).                    (3)

Thus a boundary transition requires a genuine particle-hole exchange on BOTH
rings. In particular it vanishes when both endpoints of either ring are holes.
This differs from substituting multiple holes into GH Eq.7: the latter can move
one ring alone when the other has two endpoint holes and destroys the alignment
used below. The distinction is part of the proposed construction.

At (L_1,R_1), use

    h_P=(I-q_L1)(I-q_R1)-|s><s|,
    |s>=(|01>-|10>)/sqrt(2).                                  (4)

Finally put lambda=1/(64 N^4) and

    V=lambda sum_(a=L,R) [sum_(i=1)^N q_(a,i)q_(a,i+1)
                                      -sum_(i=1)^N q_(a,i)],  (5)

where i+1 is cyclic inside each ring. H is the sum of (2)--(5).
All hopping and boundary terms have norm two, h_P has norm one, and the
potential terms have coefficient at most 1/64. Particle counts are conserved.

Fold each ring back on itself, pairing (i,N+1-i) into dimension-nine sites.
Each ring is an open half-chain of N/2 such sites. Join the two folded sites
containing endpoints 1,N at the middle. Every original ring edge becomes an
on-site or nearest-neighbor term. Equations (3),(4) lie on the two middle
sites, and the cyclic pair in (5) is on-site at each folded endpoint.
There are only a bounded number of terms per folded edge/site. This is a
fixed-dimensional finite-range one-dimensional Hamiltonian with uniformly
bounded terms. The middle cut is exactly the original L:R split; no extensive
boundary or blocking across that split is used. This folding geometry is
inherited from GH Section2.

## 2. Exact charge and ordered-spin decomposition

Fix particle counts m,k on the two rings, and set h=N-m, j=N-k. The charge
space is

    Omega=Omega_(N,h) x Omega_(N,j),

where Omega_(N,h) is the set of h-hole subsets. Extract the qubits in their
increasing site order, separately on each ring. This is a unitary identification
of the charge sector with

    l2(Omega) tensor V_(m,k),
    V_(m,k)=(C^2)^tensor m tensor (C^2)^tensor k.                (6)

We use uniform probability pi on Omega in the function representation; the
constant rescaling by sqrt(|Omega|) makes this convention isometric.
Interior hopping swaps adjacent occupation bits and leaves all ordered spin
labels unchanged. Its operator is L_0=L_L+L_R, the sum of two open-path simple
exclusion Laplacians, tensored with identity on V_(m,k).

Let D_+ be the charge event with a hole at N and a particle at 1 on each ring.
Let T exchange occupation bits at 1,N on both rings; it bijects D_+ to D_-.
The transition in (3) moves the first ordered particle to the end in each
ring. Let C_m move the first ket spin to the end, and define
R=C_m* tensor C_k*. The adjoint is required because the form below
compares the source amplitude with the inverse-transported target amplitude.
Its quadratic form is

    E_B(f)=E_pi[1_(D_+) ||f(x)-R f(Tx)||^2].                   (7)

The contact event C is that both sites numbered 1 are occupied. With
P=I-|s><s| on the first ordered pair, (4)'s form is

    E_P(f)=E_pi[1_C ||P f(x)||^2].                            (8)

The potential is the scalar function (5) of x. These statements are literal
matrix identities in every charge sector; no Bell-word ansatz has been imposed.
In zero-particle sectors the relevant boundary/contact terms vanish and only
the scalar estimates used later are needed.

A scalar comparison Laplacian L is obtained by replacing R in (7) by I.
It is L_0 plus additional undirected edges. Its ground vector is constant.
On each nontrivial factor the path-exclusion spectral gap is

    delta_N=2(1-cos(pi/N)) >=4/N^2.                            (9)

This is inherited: the exclusion process is a quotient of the interchange
process, whose gap is the path random-walk gap by Caputo–Liggett–Richthammer,
arXiv:0906.1238v4, Theorem1.1 and Section4.1.1. A one-particle eigenfunction
summed over occupied sites gives the reverse bound. Products preserve the
smallest gap and extra positive edges only increase it. A factor with one
configuration is omitted. If both factors are trivial, L=0 on a one-point
space and its scalar ground energy is evaluated directly.

## 3. Endpoint covariance estimate

For any vector-valued f on Omega, write bar(f)=E_pi f and

    E_0(f)=<f,L_0 f>_pi
          =(1/2) sum_adjacent_edges E_pi ||f(x)-f(s_e x)||^2.  (10)

If F(x) is any of the indicators C,D_+,D_-, then

    ||E_pi[F f]-(E_pi F)bar(f)||^2 <=128 N E_0(f).             (11)

Here is a direct proof, including the transport multiplicity. Independently
in each ring, randomly send the at most two tested sites to a uniformly chosen
ordered set of distinct sites. An extension permutation needs at most two
transpositions in that ring. Averaging F composed with these permutations is
the constant E_pi F because the number of holes is fixed.
A long transposition (u,v) is a word of 2|u-v|-1 adjacent transpositions;
each path edge appears at most twice. Thus the two-ring permutation is a word
of length at most 8N and uses any fixed adjacent edge at most eight times.
Telescoping and Cauchy–Schwarz, followed by invariance of uniform pi under
every prefix permutation, yield

    E_pi ||f-f composed pi_perm||^2 <=128 N E_0(f).            (12)

This calculation takes place on occupation configurations. Every adjacent
swap with equal occupation is the identity, exactly as in (2); ordered spin
coordinates stay fixed throughout. There is no hidden interchange of two
physical qubits in this transport argument.
Changing variables in E_pi[(F composed pi_perm) f] and averaging gives
E_pi[F(f-f composed pi_perm^(-1))] for the covariance in (11). Jensen and
Cauchy–Schwarz, with |F|<=1, prove (11). It applies componentwise and hence
to arbitrary quantum-valued vectors, without a dimension factor.

Now suppose m,k,h,j are all in [N/4,3N/4]. Then

    a=pi(D_+)=pi(D_-)=hmjk/[N^2(N-1)^2] >=1/256,
    c=pi(C)=mk/N^2 >=1/16.                                  (13)

Average (7)'s difference on D_+. The bijection T and (11) show

    ||(I-R)bar(f)||^2 <=2^26 N [E_0(f)+E_B(f)],
    ||P bar(f)||^2 <=2^17 N [E_0(f)+E_P(f)].                  (14)

For explicit constants, the first left side is at most
3 E_B/a+6(128N)E_0/a^2; the second is at most
2 E_P/c+2(128N)E_0/c^2. The larger powers of two displayed in (14) dominate
these expressions. In particular, their sum is at most 2^27 N E(f), where
E=E_0+E_B+E_P. Merely using a global Poincare bound at this step would lose
an extra factor N; the local-event averaging in (11) is necessary.

## 4. Every spin sector, including unequal particle counts

When m=k, identify the spin space with m ordered qubit pairs. In the tensor
Bell basis, P is diagonal: it is zero precisely when the first letter is s.
R cyclically permutes the Bell letters. The common kernel of I-R and P is
therefore the one-dimensional space

    G_m=span{|s>^tensor m}.                                  (15)

Every other cyclic-word orbit has period p<=m and contains a position where
P is one. For coefficients z on that orbit, choose such a position a. The
path telescoping estimate

    sum_r |z_r|^2 <=2p|z_a|^2+2p^2 sum_r |z_(r+1)-z_r|^2

shows, for all v orthogonal to G_m,

    ||v||^2 <=2m^2 [||(I-R)v||^2+||Pv||^2].                  (16)

No assumption is made about a single word: decompose the entire Bell basis
into disjoint cyclic orbits and sum the bounds.

When m!=k and both are positive, let t=min(m,k). R^t returns the shorter
ring's ordered spins to their original positions and moves the first spin of
the longer ring to a different one. Thus P and R^(-t) P R^t penalize failure
to form a singlet between a common qubit and two different partner qubits.
If Q_1,Q_2 are those singlet projectors, then

    Q_1 Q_2 Q_1=Q_1/4,
    ||Q_1+Q_2||=3/2,
    P+R^(-t)P R^t >=I/2.                                   (17)

The first identity follows by contracting the common two-dimensional singlet;
it also gives the second by the two-projection decomposition. Tensoring the
unused qubits changes neither statement. Consequently

    ||v||^2/2 <=||Pv||^2+||P R^t v||^2
               <=3||Pv||^2+2t^2||(I-R)v||^2,

and hence

    ||v||^2 <=6N^2 [||(I-R)v||^2+||Pv||^2].                  (18)

This treats arbitrary coherent states in unequal-count sectors. A longer
least-common-multiple cycle, which would lose extra powers of N, is unnecessary.

For equal counts restrict pointwise f(x) to G_m's orthogonal complement; for
unequal counts take the whole spin space. By (9),

    E_pi||f-bar(f)||^2 <=(N^2/4)E_0(f).

Apply (16) or (18) to bar(f), then (14). For N>=1,

    E_pi||f||^2 <=2^30 N^3 E(f).                             (19)

Thus every unwanted spin sector in the central density band is separated by
at least 2^(-30)N^(-3), before adding the scalar potential. Each projection
onto G_m commutes with all the Hamiltonian terms, so this is a reducing
subspace statement, not a variational ansatz.

## 5. The local potential selects a density band without nonlocal projection

The cyclic occupation expression sum_i q_i q_(i+1)-sum_i q_i is minus the
number of nonempty hole clusters (and is zero for an empty or full ring).
Its value for a ring lies in [-N/2,0]. Thus in the two-ring charge space

    -a_N<=V<=0,   a_N=lambda N=1/(64N^3).                     (20)

Its uniform expectation is exactly

    mu_(h,j)=lambda [F_N(h)+F_N(j)],
    F_N(h)=h(h-N)/(N-1)
           =[(h-N/2)^2-N^2/4]/(N-1).                        (21)

The equality follows from E q_i=h/N and
E q_i q_(i+1)=h(h-1)/[N(N-1)], including h=0,N.
Let e_(h,j) be the ground energy of the scalar operator L+V. The constant
trial state gives e<=mu. Temple's bound and (9),(20) give

    mu_(h,j)-1/(4096N^4) <=e_(h,j)<=mu_(h,j).                 (22)

For clarity, the second eigenvalue is at least 4/N^2-a_N, the trial energy
is between -a_N and zero, and the variance is at most a_N^2. The denominator
in Temple's inequality is at least 3/N^2, so the stated error is conservative.
For a one-point charge space the equality e=mu holds directly. No assumption
about Gaussian occupation fluctuations is needed.

We next control the *pointwise* scalar ground vector, rather than only its
L2 overlap with the constant vector. Normalize its strictly positive vector
u by E_pi u^2=1. The scalar graph is connected. Its heat kernel at time t=N^3
has

    1/(2M) <= [exp(-tL)]_(xy) <=3/(2M),   M=|Omega|<=4^N.     (23)

Indeed the absolute operator-norm deviation from the rank-one stationary
projection is at most exp(-4N); multiplying by M gives a relative error
at most exp[-(4-log4)N]<1/2. The one-point case is immediate.
Finite-state Feynman–Kac, or the elementary product formula, implies
entrywise

    exp(-tL) <= exp[-t(L+V)] <=exp(t a_N) exp(-tL).             (24)

Apply this to u and use exp[-t(L+V)]u=exp(-te)u. Equations (23),(24) imply

    max_x u(x)/min_x u(x) <=3 exp(t a_N)=3 exp(1/64)<4.        (25)

Thus 1/4<u(x)<4 in our normalization.

The exact ground-state transform is valid also for the unitary edge twists:
write the colored vector as psi(x)=u(x)f(x). Subtracting e_(h,j) gives

 <psi,(H-e)psi>_pi
  =sum_(undirected_edges xy) pi(x)u(x)u(y)||f(x)-U_xy f(y)||^2
     +E_pi[u(x)^2 1_C ||P f(x)||^2].                         (26)

Here the edge unitaries are I inside a ring and R or R* at the synchronized
boundary. Diagonal scalar potential terms cancel by (L+V)u=e u.
Since u(x)u(y),u(x)^2>1/16 and E_pi u^2||f||^2<16 E_pi||f||^2,
(19) and (26) give, on every central unwanted spin sector,

    H >=e_(h,j)+2^(-38)N^(-3).                               (27)

The gap is measured relative to the scalar ground energy in that same charge
sector; adding a potential by a crude operator-norm perturbation of (19)
would be insufficient.

For any charge sector, even noncentral, the vector-valued diamagnetic
inequality gives H>=e_(h,j): replace psi(x) by ||psi(x)|| in every edge
quadratic form and discard the nonnegative contact penalty. This remains
true when one ring has no particles or no holes.

## 6. A uniform separation from every unwanted global sector

Let N be even. Among central equal-count sectors let E_* be the least scalar
ground energy. Such sectors exist, and the h=j=N/2 trial gives

    E_* <=mu_*:=2lambda F_N(N/2).                            (28)

For every h,j, F_N(h)+F_N(j)>=2F_N(N/2). Thus (22) gives

    e_(h,j)>=E_*-1/(4096N^4).                                (29)

For central unequal-count or nonsinglet sectors, combine (27),(29). For
N>=2^28 their energies are at least E_*+2^(-39)N^(-3).
If either h or j lies outside [N/4,3N/4], (21) gives

    mu_(h,j)-mu_* >=lambda N/16 >=1/(1024N^3).                (30)

The strict band boundary only improves this conservative bound. Equations
(22),(28), diamagnetism and (30) give an even larger separation, for large N.

Define the reducing good subspace to consist of *all* charge-clock vectors
in central equal-count sectors, tensored with their ordered singlet vector
G_(N-h). This includes clock excitations and more than one charge number;
it is not an assertion of a unique ground state. The complementary bad
subspace therefore satisfies, for every even N>=2^30,

    H_bad >=E_*+kappa/N^3,       kappa=2^(-40).                (31)

The good subspace contains a state of energy E_*, by construction. No
unexamined particle-number sector or residual spin degeneracy remains.

## 7. Full Gibbs state and middle-cut mutual information

The full Hilbert dimension is 3^(2N). Since the good and bad subspaces reduce
H, the Gibbs bad weight delta obeys directly

    delta <=3^(2N) exp[-beta kappa/N^3].                      (32)

Set beta=2^44 N^4. Then delta<=exp[-(16-2log3)N]<exp(-13N).
This is a bound for the actual unconstrained Gibbs ensemble of (2)--(5).
It does not identify a projected sector with a physical Gibbs state.

There are local CPTP maps on the two rings that extract r=N/4 ordered spins
(for N divisible by four) and discard all other registers, with a fixed
padding rule on sectors containing fewer than r particles. Charge sectors
can first be measured locally. On every good state both counts agree and
there are at least r singlet pairs, so the output is exactly |s><s|^tensor r.
This remains true for arbitrary clock mixtures/correlations and mixtures of
charge sectors: ordered-spin extraction is the local identification (6).

Consequently the output of the full Gibbs state is

    (1-delta)|s><s|^tensor r+delta omega,

for some state omega. Entropy continuity on r qubits per party gives

    I(output) >=2r log2-4delta r log2-3h_2(delta).             (33)

Local data processing and delta<exp(-13N) imply (1), with ample margin.
Taking the sequence N=4s>=2^30 removes integer rounding. It has n=N folded
sites and beta_n=2^44 n^4, so I>=c beta^(1/4) with the universal positive
constant c=(log2)/(8*2^11). This covers the exact original lower-bound card.

## Attribution and limits

Inherited: GH's two-ring idea, interior hopping, singlet contact and folding;
the path-exclusion gap (CLR); standard moving-particle comparisons, Temple,
Feynman–Kac, ground-state transforms, entropy continuity and data processing.
The candidate contribution is the strict finite-density boundary interaction,
its endpoint-event/all-color coercivity, the weak *local* charge selection,
and their combination giving the full Gibbs lower bound. R263's one-hole
thermal obstruction is not contradicted or recounted as progress.

The proof above has not yet received independent review. Its most sensitive
steps are the endpoint transport estimate (11), the precise edge twist (7),
the arbitrary unequal-count inequality (17), and the uniform comparison in
(26)--(31). Finite checks cannot replace these all-size arguments. Bounded
source searches have not established priority. No release is authorized.

## Version and finite controls

Version 2 fixes the displayed twist orientation and states the sequence as
N divisible by four. Neither change weakens the original target. The preceding
v1 is retained. q048_checks.py compares physical qutrit operators with the
charge/spin model for every basis vector at N=2,3,4: 22,113 exact operator-column
equalities and 50 exact charge means. It exactly checks the overlapping-singlet
identity and constants; four intentionally incorrect operators are detected.
126 floating-point endpoint dual-norm controls and 16 spin-gap controls are
additional diagnostics, not all-size certificates. The all-size proof rests
on Sections 3--7. The reviewer is the same agent throughout.
