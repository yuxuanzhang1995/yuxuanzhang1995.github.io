"""Independent finite Fock-space channel diagnostic; not a proof."""
import json
import numpy as np


def kron(xs):
    out = np.ones((1, 1), dtype=complex)
    for x in xs:
        out = np.kron(out, x)
    return out


def majoranas(m):
    I = np.eye(2)
    Z = np.diag([1, -1])
    X = np.array([[0, 1], [1, 0]])
    Y = np.array([[0, -1j], [1j, 0]])
    return [kron([Z] * j + [a] + [I] * (m - j - 1))
            for j in range(m) for a in (X, Y)]


def unitary(H):
    e, u = np.linalg.eigh(H)
    return (u * np.exp(-1j * e)) @ u.conj().T


def trace_norm(H):
    return float(np.abs(np.linalg.eigvalsh((H + H.conj().T) / 2)).sum())


rng = np.random.default_rng(1240001)
rows = []
for m in (1, 2, 3):
    g = majoranas(m)
    h = majoranas(2 * m)
    mats = [1j * g[a] @ g[b] for a in range(2 * m)
            for b in range(a + 1, 2 * m)]
    for rep in range(8):
        p = rng.uniform(size=m)
        if rep == 0:
            p[:] = 0
        if rep == 1:
            p[:] = 1
        if rep == 2:
            p = np.array([1e-8 if j % 2 == 0 else 1 - 1e-8 for j in range(m)])
        U = unitary(sum(x * M for x, M in zip(rng.normal(size=len(mats)), mats)))
        rho = U @ kron([np.diag([1 - x, x]) for x in p]) @ U.conj().T
        tau = (0.2 if rep % 2 else 0.03) / (8 * m)
        transmission = 1 / (1 + 2 * tau)
        theta = np.arccos(np.sqrt(transmission))
        V = unitary(sum(0.5j * theta * h[a] @ h[2 * m + a] for a in range(2 * m)))
        total = V @ np.kron(rho, np.eye(2 ** m) / 2 ** m) @ V.conj().T
        reduced = np.einsum('iaja->ij', total.reshape([2 ** m] * 4))
        q = (p + tau) / (1 + 2 * tau)
        expected = U @ kron([np.diag([1 - x, x]) for x in q]) @ U.conj().T
        channel_error = trace_norm(reduced - expected)
        state_error = trace_norm(reduced - rho)
        coupling_bound = 2 * m * tau / (1 + 2 * tau)
        assert channel_error < 2e-12, (m, rep, channel_error)
        assert state_error <= coupling_bound + 2e-12, (m, rep, state_error, coupling_bound)
        rows.append(dict(m=m, rep=rep, channel_error=channel_error,
                         state_error=state_error, coupling_bound=coupling_bound))
print(json.dumps(dict(status='finite_channel_checks_passed', instances=len(rows),
                     maximum_channel_error=max(x['channel_error'] for x in rows),
                     rows=rows), indent=2))
