# Q114: fixed-tester dual attainment

13 November 2026. This is a same-root proof correction, not an independent
review or a counterexample to the main theorem. The frozen R305 v2 is preserved.
The repaired argument is in [v3](../proof-reviewed.md), Section 4.

For a positive, possibly singular tester T and Hermitian X, the correct formula is

    max_{0 <= Q <= T} Tr(QX) = inf_{Y >= 0, Y >= X} Tr(TY).

The left maximum is attained. Strict feasibility on the right proves equality
of values, but does not ensure the right infimum is attained. The word `min`
in v2's fixed-T sentence was therefore unjustified. The subsequent uniform
minimum in equation (10) has a separate compactness argument and survives.

## A physical example above the relevant discrimination rate

Use the input-output ordering for two qubit-channel Choi operators. Write X2,Z2
for the Pauli matrices, t=1/128, and set

    R0 = I4/2,
    R1 = I4/2 + diag(1/4,-1/4,0,0) + t X2 tensor Z2.

Both have output partial trace I2. Rational diagonal-dominance bounds give

    a R0 <= R1 <= c R0,  a=31/64, c=97/64.

Thus both represent channels. Put P=(R1-a R0)/(1-a); this is another channel
and P <= 2 R0. For every n and common input/tester, expand the first channel's
tensor power as the mixture of words in the channels R0 and P. A word with
j occurrences of P is CP dominated by 2^j R0^tensor n. Its output relative
entropy against the all-R0 output is at most j. Convexity in the first state
and the binomial mean imply

    D_ch^infinity(R1 || R0) <= 1-a = 33/64 bits.

The exact integer inequality 2^97 < 3^64 proves
33/64 < log_2(3/2). Hence lambda=3/2 is strictly above the regularized
relative-entropy rate. Ordinary channels are a special case of two-combs
with the intermediate slots trivial.

Let X=R1-lambda R0 and T=|0><0| tensor I2. Then

    T X T = diag(0,-1/2,0,0),
    X[0,2] = t != 0.

Every effect 0<=Q<=T has Tr(QX)<=0, and Q=0 gives the primal value zero.
For epsilon>0, in input-block notation define

    Y_epsilon = [ epsilon I2,           (t/2) Z2             ]
                [ (t/2) Z2,       t^2/(4 epsilon) I2         ].

This is the positive Gram matrix of the block column
(sqrt(epsilon) I2, t Z2/(2 sqrt(epsilon))). The matrix Y_epsilon-X is the
Gram matrix with the second block negated, plus
diag(0,1/2,1/4,1/4), so it too is positive. Its objective is 2 epsilon.
The dual infimum is therefore zero.

There is no attaining Y. If Y>=0 and Tr(TY)=0, then TY=0. The (0,0) entry
of Y-X is then zero, whereas its (0,2) entry is -t. A positive matrix with
a zero diagonal entry has a zero corresponding row, a contradiction.
Tensor powers also retain a zero compressed eigenvector with a nonzero
off-support coupling at lambda^n. The issue is not confined to lambda=1.

## Why the main proof is repaired locally

Keep `inf` before applying minimax. The tester set is compact and convex;
the slack set is convex and nonempty; the pairing is continuous and bilinear.
The minimax equality therefore gives

    h_n = inf_{Y >= 0, Y >= X} max_T Tr(TY) = inf_Y g_n(Y).

There is a full-rank tester T0. For Y>=0,

    g_n(Y) >= Tr(T0 Y) >= lambda_min(T0) Tr(Y).

Any minimizing sequence of slacks is bounded. The feasible set is closed,
so it has an attaining subsequence limit. Thus the global `min` in (10) is
correct, and the common amplitude selected from its minimizer still exists.
No new assumption on the unknown combs or the general testers is introduced.

The rational channel constraints, CP bounds, objective sequence and Gram
identities are checked in [bottleneck_checks.py](../checks/controls.py).
The nonattainment and uniform-attainment conclusions above are analytic;
a solver's optimum was not used as their proof.
