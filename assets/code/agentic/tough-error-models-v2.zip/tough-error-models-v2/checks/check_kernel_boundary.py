"""Exact regression for the auxiliary strict left-kernel dimension condition."""
import json
import sympy as s

k, m, n = 2, 1, 4
X = s.eye(n)[:, :k]
Y = s.eye(n)[:, k:]
G, C = s.diag(1, -1), s.eye(k)
H = G.row_join(C.T).col_join(C.row_join(s.zeros(k)))
assert H == H.conjugate().T
assert Y.T * H * X == C
assert n == (m + 1) * k
assert C.T.nullspace() == []
assert C.col_join(s.zeros(1, k)).T.nullspace() != []
print(json.dumps({
    "exact_controls": 1,
    "square_cross_block_has_no_left_kernel": True,
    "strictly_more_rows_gives_left_kernel": True,
    "main_quantitative_dimension_condition_unchanged": True,
}))
