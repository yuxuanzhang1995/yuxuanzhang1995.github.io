---
title: "The high-dimensional crossover of optimized port-based teleportation"
author: "Yuxuan Zhang"
date: "24 September 2026"
geometry: margin=1in
fontsize: 11pt
header-includes:
  - \usepackage{amsmath,amssymb}
  - \usepackage{microtype}
---

\begin{center}\small
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland\\
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA
\end{center}

**Working manuscript.** This complete proof candidate passed two independent internal AI reviews. External expert confirmation and literature priority remain unverified. The supplementary computations check finite identities and formula evaluation, not the asymptotic theorem.

## Abstract

Let $F_d^*(N)$ denote the optimal entanglement fidelity of deterministic port-based teleportation with $N$ ports and local dimension $d$, optimizing the resource and Alice's measurement. We give a proof candidate for the existence and value of $\varphi(c)=\lim_{d\to\infty}F_d^*(\max\{1,\lfloor cd^2\rfloor\})$ for every fixed $c>0$. The answer is $c$ for $0<c\le1/4$. Above this threshold it is specified by one real parameter and elementary trigonometric integrals. The proof starts with the published teleportation-matrix characterization, identifies Young-diagram branching with fermionic hopping, and obtains matching bounds. A bounded commutator controls the passage from fixed diagram size to mean size; explicitly discretized Slater states and a variance estimate give the reverse passage. No fixed-dimensional expansion is substituted into the joint limit.

## Statement

Use the entanglement-fidelity convention

$$
F_e(\mathcal T)=\operatorname{Tr}[\Phi_d(\mathrm{id}\otimes\mathcal T)(\Phi_d)],
\qquad \Phi_d=\frac1d\sum_{a,b=1}^d|aa\rangle\langle bb|.
$$

Bob selects a port and performs no correcting unitary. Both the resource state and Alice's measurement are optimized. This is the model in QIQCOP problem `op_25342dbb8d64e728` [1].

**Theorem.** For each fixed $c>0$, the limit

$$
\varphi(c)=\lim_{d\to\infty}F_d^*(N_d),\qquad
N_d=\max\{1,\lfloor cd^2\rfloor\},
$$

exists. For $0<c\le1/4$, it equals $c$. For $c>1/4$, set

$$
I_j(\mu)=\frac1\pi\int_0^\pi(\cos p-\mu)_+^j\,dp\quad(j=1,2).
$$

There is a unique $\mu\in(-1,1)$ with

$$
c+\frac12=\frac{I_2(\mu)}{2I_1(\mu)^2}.
$$

The answer is

$$
\varphi(c)=\left[\mu+\frac{I_2(\mu)}{I_1(\mu)}\right]^2.
$$

Here $x_+=\max\{x,0\}$. For numerical evaluation, put $\theta=\arccos\mu$:

$$
I_1=\frac{\sin\theta-\mu\theta}{\pi},\qquad
I_2=\frac{(1/2+\mu^2)\theta-(3/2)\mu\sin\theta}{\pi}.
$$

For example, the certified evaluation at $c=1/2$ lies in $(0.472865,0.472867)$. This interval checks the formula at one point; the following proof addresses every $c>0$.

## Branching as fermionic hopping

The finite-resource characterization of Mozrzymas et al. [2] gives

$$
F_d^*(n)=\frac{\|D_{d,n}\|^2}{d^2},
$$

where $D_{d,n}$ maps a partition of $n$ with at most $d$ rows to the sum of its immediate predecessors. Indeed, $D_{d,n}^*D_{d,n}$ has diagonal entry equal to the number of removable boxes and off-diagonal entry one precisely for a permissible one-box move. This is the teleportation matrix with the stated normalization. We use this published characterization as an input, not as a new result.

On $\ell^2(\mathbb N_0)$, let $S|x\rangle=|x-1\rangle$ for $x\ge1$, $S|0\rangle=0$, and $X|x\rangle=x|x\rangle$. On the $d$-fold exterior power, define

$$
T=d\Gamma(S),\qquad V=d\Gamma(X),\qquad Q=V-\frac{d(d-1)}2.
$$

Increasing particle coordinates $x_1<\cdots<x_d$ correspond to a partition through $\lambda_i=x_{d+1-i}-(d-i)$. Thus $Q$ is the diagram size. A permitted one-step lowering never crosses another particle, so its coefficient is positive. Consequently $T$ on grade $Q=n$ is $D_{d,n}$ and annihilates grade zero. Moreover,

$$
\|T\|\le d,\qquad
[T,T^*]=d\Gamma(|0\rangle\langle0|)=K,\qquad 0\le K\le I.
$$

The last inequality is the exclusion principle at one site. All vectors used first in the argument have finite support; the unbounded operators $Q$ and $V$ then cause no domain ambiguity.

## Upper bound

### From fixed grade to mean grade

Write $A=T^*T$ and choose a unit top eigenvector $\psi$ of $A$ in grade $n$, with eigenvalue $a^2=\|D_{d,n}\|^2$. This grade is finite dimensional. Fix an integer $m$ independently of $d$, and set $v_j=(T^*)^j\psi$ for $0\le j\le m$. Since $[A,T^*]=T^*K$, telescoping gives

$$
\|(A-a^2)v_j\|\le j d^j.
$$

Consider a subsequence on which $a/d\ge\eta>0$. The identity

$$
\|v_{j+1}\|^2=a^2\|v_j\|^2+
\langle v_j,(A-a^2)v_j\rangle+\langle v_j,Kv_j\rangle
$$

implies inductively

$$
\|v_j\|=a^j(1+O_{m,\eta}(d^{-2})).
$$

To verify the error, once $\|v_j\|$ is of order $d^j$, the last two terms are $O_{m,\eta}(d^{2j})$, whereas the first is of order $d^{2j+2}$. The induction starts with $v_0=\psi$ and also proves nonvanishing.

The normalized $w_j=v_j/\|v_j\|$ occupy distinct grades, and

$$
\langle w_j,Tw_{j+1}\rangle=
\frac{\|v_{j+1}\|}{\|v_j\|}=a(1+O_{m,\eta}(d^{-2})).
$$

Let $\alpha_j=\sqrt{2/(m+2)}\sin(\pi(j+1)/(m+2))$ and $z=\sum_{j=0}^m\alpha_jw_j$. The path-matrix sine identity gives

$$
\frac{\langle z,\operatorname{Re}(T)z\rangle}{d}
=\frac ad\cos\frac\pi{m+2}+O_{m,\eta}(d^{-2}),
\qquad \langle z,Qz\rangle\le n+m.
$$

An asymptotic upper bound at bounded mean grade therefore bounds the fixed-grade singular value, after first $d\to\infty$ and then $m\to\infty$. Subsequences with $a/d\to0$ already satisfy the positive bounds below.

### A one-particle trace limit

For fixed $b>0$ and real $\mu$, define $h_{b,d}=\operatorname{Re}(S)-bX/d$. It is self-adjoint on the domain of $X$, bounded above, and has compact resolvent. We claim

$$
\lim_{d\to\infty}\frac1d\operatorname{Tr}(h_{b,d}-\mu)_+
=\frac{I_2(\mu)}{2b}.
$$

Choose $C>\max\{0,(1-\mu)/b\}+1$. Remove the hopping edge between sites below $\lfloor Cd\rfloor$ and the remaining half-line. The removed operator has trace norm one. On the tail, $\operatorname{Re}(S)\le I$ and $X/d\ge\lfloor Cd\rfloor/d$, so the tail contributes no positive trace for large $d$.

For an operator bounded above with finite positive trace,
$\operatorname{Tr}(B)_+=\sup_{0\le P\le I,\ P\text{ finite rank}}\operatorname{Tr}(PB)$.
This variational identity shows that a trace-class perturbation changes the positive trace by at most its trace norm. Partition the retained interval into a fixed number $M$ of blocks approximating a partition of $[0,C]$, and remove the $M-1$ internal edges. Their total error is at most $M-1$.

On each block, replacing $X/d$ by the lower or upper endpoint orders the original operator. The gap in potential is at most $b$ times the mesh plus $O(1/d)$. The two normalized positive traces differ by at most $Cb$ times the mesh plus $o(1)$: in dimension $L$, a scalar shift $\epsilon$ changes the positive trace by at most $L|\epsilon|$. A length-$L$ constant-potential block has eigenvalues $\cos(k\pi/(L+1))-by$, $k=1,\ldots,L$. With the partition fixed, let $d$ grow and use Riemann sums; then refine the partition. The result is

$$
\frac1\pi\int_0^C\int_0^\pi(\cos p-by-\mu)_+\,dp\,dy
=\frac{I_2(\mu)}{2b}.
$$

The integrand vanishes beyond $C$. Every cutting error was $O(M)/d$ before refinement, which fixes the required order of limits.

### Evaluation of the bound

The one-particle density matrix of a normalized $d$-fermion state satisfies $0\le\gamma\le I$ and $\operatorname{Tr}\gamma=d$. Filling the $d$ largest one-particle levels bounds its expectation of $d\Gamma(h_{b,d})$. For any real $\mu$, their sum is at most $d\mu+\operatorname{Tr}(h_{b,d}-\mu)_+$. Hence

$$
\frac{\langle\operatorname{Re}(T)\rangle}{d}
\le\mu+\frac1d\operatorname{Tr}(h_{b,d}-\mu)_+
+b\frac{\langle V\rangle}{d^2}.
$$

For the ladder states at $n=N_d$, $\langle V\rangle/d^2\le c+1/2+o(1)$. The preceding two steps give

$$
\limsup \frac ad\le\mu+b(c+1/2)+\frac{I_2(\mu)}{2b}.
$$

Set $b=I_1(\mu)$ and choose $\mu$ to satisfy $c+1/2=I_2/(2I_1^2)$. If $0<c\le1/4$, take $\mu=-1/(2\sqrt c)\le-1$. Then $I_1=-\mu$, $I_2=\mu^2+1/2$, and the bound is $q(c)=\sqrt c$. If $c>1/4$, it is $q(c)=\mu+I_2/I_1$ with $-1<\mu<1$.

For completeness, let $\theta=\arccos\mu$ and $J=\theta/\pi$. Differentiation gives $I_1'=-J$ and $I_2'=-2I_1$, so

$$
\frac{d}{d\mu}\frac{I_2}{2I_1^2}
=\frac{I_2J-I_1^2}{I_1^3}>0
$$

by strict Cauchy--Schwarz on $[0,\theta]$. The ratio tends to $3/4$ at $\mu=-1$ and diverges at $\mu=1$: as $\theta\downarrow0$, uniform Taylor expansion gives $I_1\sim\theta^3/(3\pi)$ and $I_2\sim2\theta^5/(15\pi)$, hence the ratio is asymptotic to $3\pi/(5\theta)$. This proves uniqueness and continuity of the parameter. The formulas agree at $c=1/4$, where $q=1/2$. Also $q>0$: the numerator $I_2+\mu I_1$ is the integral of $\cos p(\cos p-\mu)_+$; positivity follows by pairing $p$ with $\pi-p$ when $\mu<0$, and directly when $\mu\ge0$. We conclude that $\limsup F_d^*(N_d)\le q(c)^2$.

## Matching lower bound

Fix $0<c'<c$ and use its parameters $\mu,b$ above. Define a continuous profile on $y\ge0$ by

$$
f(y)=\begin{cases}
1,&\mu+by\le-1,\\
\pi^{-1}\arccos(\mu+by),&-1<\mu+by<1,\\
0,&\mu+by\ge1.
\end{cases}
$$

It is supported in $[0,Y]$, where $Y=(1-\mu)/b$. Fubini gives

$$
\int f=1,\qquad \int yf(y)\,dy=c'+\frac12,
\qquad \int\frac{\sin(\pi f(y))}{\pi}\,dy=q(c').
$$

The first two integrals are $I_1/b$ and $I_2/(2b^2)$. The third is $(I_2+\mu I_1)/b$, obtained by integrating $\cos p$ over $0\le p\le\pi f(y)$.

Choose a finite partition $0=y_0<\cdots<y_M=Y$ and replace $f$ by its cell averages $f_j$. Its mass remains exactly one. As the mesh tends to zero, the cell-midpoint first moment tends to $c'+1/2$, and the sum of cell widths times $\sin(\pi f_j)/\pi$ tends to $q(c')$. Choose the mesh small enough that the first moment minus $1/2$ is strictly below $c$.

For large $d$, make disjoint site blocks with endpoints $\lfloor dy_j\rfloor$ and lengths $L_j$. In block $j$, occupy its first $k_j$ normalized sine orbitals, with $0\le k_j\le L_j$, $\sum k_j=d$, and
$k_j/d\to(y_j-y_{j-1})f_j$.
Such integers follow by rounding and $O(M)$ corrections. At least one positive-width cell has $0<f_j<1$, providing enough occupied and vacant slots for those corrections for large $d$.

Form the Slater determinant of these $d$ orbitals. Cross-block one-body density vanishes, so hopping between blocks has zero expectation. The sine formulas yield

$$
\frac{\langle T\rangle}{d}\longrightarrow
\sum_j\frac{(y_j-y_{j-1})\sin(\pi f_j)}{\pi},
$$


$$
\frac{\langle Q\rangle}{d^2}\longrightarrow
\sum_j\frac{(y_j-y_{j-1})(y_{j-1}+y_j)f_j}{2}-\frac12<c.
$$

All occupied sites lie below $Yd+O(1)$. If $P$ is the orbital projection, the Slater occupation identities give

$$
\operatorname{Var}(Q)=\operatorname{Tr}(PX(I-P)X)
\le\operatorname{Tr}(PX^2)\le d(Yd+O(1))^2=O(d^3).
$$

The strictly positive mean margin and Chebyshev's inequality therefore imply $\Pr(Q>N_d)=O(1/d)$.

Decompose the Slater state $\psi=\sum_n\psi_n$ by grade. The vectors $T\psi_n$ occupy distinct grades. Operational fidelity is nondecreasing in the number of ports: an additional port can be ignored using a zero measurement effect and a product extension of the resource. Together with $\|T\|\le d$ and the branching characterization, this gives

$$
\begin{aligned}
\frac{|\langle\psi,T\psi\rangle|^2}{d^2}
&\le\frac{\|T\psi\|^2}{d^2}\\
&\le F_d^*(N_d)\sum_{n\le N_d}\|\psi_n\|^2
+\sum_{n>N_d}\|\psi_n\|^2\\
&\le F_d^*(N_d)+\Pr(Q>N_d).
\end{aligned}
$$

The grade-zero contribution vanishes. First take $d\to\infty$ with the partition fixed; then refine it, preserving the positive mean margin. This proves $\liminf F_d^*(N_d)\ge q(c')^2$. Finally let $c'\uparrow c$ and use continuity. The matching upper bound proves the theorem for every $c>0$.

## Relation to prior work and verification

The finite teleportation matrix is due to Mozrzymas et al. [2]. Christandl et al. [3, Section 8] explicitly discuss the limit at fixed $N/d^2$; their fixed-dimensional asymptotics do not determine it. Yoshida et al. [4] relate port-based teleportation to unitary estimation and give order estimates; an order estimate does not specify the entire crossover function. The proposed contribution here is the matching joint-limit proof and the resulting function. A targeted source comparison did not locate the same formula, but it was not an exhaustive priority search.

The full proof originated in round 36, following exploratory sine-orbital lower bounds. It passed two frozen internal reviews, including the grade-transfer argument, tail truncation, integer particle counts, and limit order. The supplementary checker verifies the branching commutator on 60 small partition layers exactly. Separate finite spectral calculations and a rational interval evaluation provide further controls. None is a machine proof of the limiting theorem. The original frozen text is included alongside this typeset exposition.

The result addresses the entire stated crossover question, but does not provide a finite-$d$ error rate or an efficient implementation of the optimal resources. External expert review is requested. K-Dense's scientific-writing guidance [5] was used for evidence tracking and exposition.

## References

1. QIQCOP Zoo, *High-dimensional crossover of optimized port-based teleportation*, problem `op_25342dbb8d64e728`. <https://qiqc-op.com/problem/op_25342dbb8d64e728/>. Statement checked 24 September 2026.
2. M. Mozrzymas, M. Studziński, S. Strelchuk, and M. Horodecki, *Optimal Port-based Teleportation*, New Journal of Physics **20**, 053006 (2018). <https://arxiv.org/abs/1707.08456>.
3. M. Christandl, F. Leditzky, C. Majenz, G. Smith, F. Speelman, and M. Walter, *Asymptotic performance of port-based teleportation*, Communications in Mathematical Physics **381**, 379--451 (2021). <https://doi.org/10.1007/s00220-020-03884-0>.
4. S. Yoshida, Y. Koizumi, M. Studziński, M. T. Quintino, and M. Murao, *One-to-One Correspondence between Deterministic Port-Based Teleportation and Unitary Estimation*, IEEE Transactions on Information Theory **72**, 2358--2377 (2026). <https://arxiv.org/abs/2408.11902>.
5. T. Kassis, V. Agarwal, Y. He, D. Patel, and A. M. Brueckner, *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents* (2026). <https://doi.org/10.48550/arXiv.2609.00065>. Local scientific-writing skill at commit `330c8e764435`.
