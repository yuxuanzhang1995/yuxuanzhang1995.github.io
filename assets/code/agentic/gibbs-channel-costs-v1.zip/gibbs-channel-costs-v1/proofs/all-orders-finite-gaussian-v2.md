# A direct finite clock for the all-orders GP family

24 November 2026. Same-root constructive refinement of Section 4 of
`all-orders-gp-family-v1.md`. This supplies the matching upper exponent
without the predecessor's translated-fibre lemma or a continuous resource.
For each fixed m, the coherent clock dimension is

  O(epsilon^(-1/m) sqrt(log(1/epsilon))),

and its QFI is O(epsilon^(-2/m)). Additional finite sharp blanks have zero
QFI and are charged resources; no work bound or useful constant is claimed.

Use the integer system energies and coefficients a_l,b_l from v1, and
write a_l/l!,b_l/l! as ordinary Taylor coefficients when implementing them.
For W sufficiently large put

 p(n)=(sqrt(2 pi)W)^(-1) exp[-n^2/(2W^2)],
 N=ceil(W sqrt(4(m+2) log W)),
 p_R(n)=p(n)/Z_R for -N<=n<=N,   Z_R=sum_(-N)^N p(n).

The actual resource is the FINITE pure state sum_n sqrt(p_R(n))|n>,
with energy n (or a common shifted nonnegative energy origin). Its QFI
is at most C W^2. It has 2N+1 levels.

## 1. Positive coefficient matrices on a finite environment

Let J={-N-m,...,N+L}, with L=m+3. On J set

 q_A(z)=sum_(l<m) (-1)^l a_l p^(l)(z)/(l! Z_R),
 q_B(z)=sum_(l<m) (-1)^l b_l p^(l)(z)/(l! Z_R),
 C_z=[[q_A(z),c p(z)/Z_R],[c p(z)/Z_R,q_A(z)]]
                                        direct_sum q_B(z)sigma^T,

and set C_z=0 outside J. Gaussian derivatives satisfy
p^(l)(z)/p(z)=(-1)^l W^(-l) He_l(z/W). Since |z|/W=O(sqrt(log W))
on J and m is fixed, q_A/p and q_B/p converge uniformly to 1/Z_R.
Thus C_z is positive definite on J, with
c_m p(z)I<=C_z<=C_m p(z)I for sufficiently large W.

The full lattice Gaussian identities are

 sum_(n in Z) p(n)=sum_(k in Z) exp(-2 pi^2 W^2 k^2),
 sum_(n in Z) p^(l)(n)=sum_(k in Z) (-2 pi i k)^l
                                      exp(-2 pi^2 W^2 k^2).

They follow by Fourier expansion of the periodized Gaussian. For l>0
the k=0 term vanishes. Gaussian tails beyond N, including any fixed
number of derivative factors and shifts, are O(W^(-2m-3)) after enlarging
the W cutoff if necessary: exp(-N^2/(2W^2))=W^(-2m-4), and all remaining
factors are fixed powers of log W and inverse W. Consequently

  C_tot=sum_z C_z=T+O(W^(-2m-3)).                         (1)

The same estimates give Z_R=1+O(W^(-2m-3)) and variance O(W^2).

## 2. Exact energy-sector isometries

Work in an output energy eigenbasis with energies f_j=j. Let S_z=C_z^(1/2).
For total energy t form the rectangular matrix A_t with rows (j,alpha)
and columns i=0,1,2, whose entries are

  (A_t)_(j,alpha;i)=sum_a (S_(t-f_j))_(alpha,a) (K_a)_(j,i).

Its Gram L_t=A_t* A_t is the sector expression L(C). The clock's desired
input Gram is G_t=diag(p_R(t-L),p_R(t-L),p_R(t)). For every t with G_t!=0,
all output shifts t-f_j lie inside J. The positive lower bound on C_z,
the TP identity Omega(T)=I and bounded Gaussian shift ratios show
L_t>=c_m p(t)I. Define

  B_t=A_t L_t^(-1/2) G_t^(1/2).

Then B_t*B_t=G_t EXACTLY. For G_t=0 put B_t=0. Dividing occupied input
columns by their clock amplitudes yields an isometry separately in every
finite total-energy sector. It therefore intertwines the Hamiltonians.
Finite sharp blank registers allow its unitary completion sector by sector.
Discarding the final environment gives an actual finite thermal-resource
implementation. No probabilistic failure branch is used.

## 3. The purified channel error has order W^(-m)

On the interior where all shifted clock entries are occupied, Taylor's
formula, the reciprocal coefficients from v1 and the mth difference
identity give

 ||L_t-G_t|| <= C_m W^(-m) p(t)
                        (1+|t/W|^m) exp(C_m |t|/W^2).

Here and below the constants are fixed for m,c. Gaussian shift ratios
are bounded on the chosen window. The standard square-root perturbation
bound for positive matrices bounded below by c_m p(t) gives

 ||B_t-A_t||_HS^2 <= C'_m ||L_t-G_t||_HS^2/p(t).

Summing over interior t is O(W^(-2m)), since every fixed Gaussian moment
is bounded uniformly after scaling by W. This integrated estimate is why
the final error does NOT acquire a power of log W from the cutoff.

At the fixed-width boundary strips some columns of G_t vanish. Bound
||B_t-A_t||_HS^2 by 2 Tr G_t+2 Tr L_t instead. The sum of these strips,
and of sectors outside the clock range, is bounded by the same Gaussian
tails, O(W^(-2m-3)).

Finally replace S_z in the reference dilation by

  S'_z=S_z C_tot^(-1/2) T^(1/2).

Their Gram sum is exactly T, so these reference Kraus operators implement
Phi exactly. Equation (1), T>0 and finite-dimensional square-root
continuity show that this changes the reference isometry by
O(W^(-2m-3)). The actual and reference isometries thus differ in operator
norm by O(W^(-m)). Stinespring comparison, including an arbitrary reference
input, gives D_ch<=C_m W^(-m). Choose W proportional to epsilon^(-1/m).

Together with the direct lower bound in v1, this proves the matching
coherence exponent for every m using finite resources explicitly.
The finite Gaussian computation checks this construction for m=3;
floating matrix identities and fitted slopes are diagnostics, not the
proof of the all-m claim.
