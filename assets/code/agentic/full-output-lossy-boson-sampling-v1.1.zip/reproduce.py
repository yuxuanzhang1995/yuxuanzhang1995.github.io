"""Reproduce the supplement's finite exact controls using Python's stdlib.

These tests do not certify the universal theorem or benchmark its sampler.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    if sys.version_info < (3, 10):
        raise SystemExit('Python 3.10 or later is required; no third-party packages are needed.')
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    for row in manifest['files']:
        path = (root / row['path']).resolve()
        if not path.is_relative_to(root):
            raise RuntimeError('Manifest path leaves the package')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != row['sha256']:
            raise RuntimeError('Hash mismatch: ' + row['path'])
    results = root / 'results'
    results.mkdir(exist_ok=True)
    child = subprocess.run(
        [sys.executable, str(root / 'checks' / 'exact_checks.py')],
        cwd=root, text=True, capture_output=True,
    )
    (results / 'execution.log').write_text(child.stdout + child.stderr)
    if child.returncode:
        print(child.stdout + child.stderr)
        raise SystemExit(child.returncode)
    actual = json.loads((results / 'exact-results.json').read_text())
    expected = json.loads((root / 'checks' / 'reference-results.json').read_text())
    for key, value in expected.items():
        if actual.get(key) != value:
            raise RuntimeError('Scientific result differs: ' + key)
    receipt = {
        'status': 'passed',
        'package_files_checked': len(manifest['files']),
        'frame_factorial_controls': actual['exact_frame_and_factorial_identities'],
        'coefficient_cases': len(actual['coefficient_cases']),
        'mutation_controls_detected': actual['mutation_controls_detected'],
        'python': sys.version.split()[0],
        'claim_limit': 'Finite exact algebraic controls; no independent expert certification or production sampler benchmark',
    }
    (results / 'reproduction-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
