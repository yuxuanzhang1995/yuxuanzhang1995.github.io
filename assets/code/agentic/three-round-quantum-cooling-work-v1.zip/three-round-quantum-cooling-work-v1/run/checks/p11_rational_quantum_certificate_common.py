"""Directed arithmetic for real rational controls; exact identities by construction."""
from pathlib import Path
from fractions import Fraction as F
import json
ns={};exec(Path('run/checks/r30_p11_finite_certificate.py').read_text().split('q=exp_minus_fraction')[0],ns)
I,D,rat=ns['I'],ns['D'],ns['rat'];q=ns['exp_minus_fraction'](F(1),120)
E=[0,1,1,2,2,3];Zs=1+q+q*q;Zsm=Zs*(1+q);p=[q**e/Zsm for e in E];bath=[q**r/Zs for r in range(3)]
def controls(record):
 cs=record.get('population_base_controls',record.get('controls'));assert cs is not None
 out=[]
 for r in cs:
  for key,n in [('V',6),('U',18)]:
   perm=r[key];assert sorted(perm)==list(range(n))
   if n==18:assert all(E[s//3]+s%3==E[perm[s]//3]+perm[s]%3 for s in range(n))
   A=[[F(0) for _ in range(n)] for _ in range(n)]
   for j,i in enumerate(perm):A[i][j]=F(1)
   out.append(A)
 for r in record.get('rotations',[]):
  assert not r['imaginary'];k,i,j=r['stage'],r['i'],r['j'];t=F(r['value']);c=(1-t*t)/(1+t*t) if r['kind']=='tan' else (t*t-1)/(1+t*t);s=2*t/(1+t*t);assert c*c+s*s==1
  if k%2:assert E[i//3]+i%3==E[j//3]+j%3
  A=out[k];a,b=A[i][:],A[j][:];A[i]=[c*x-s*y for x,y in zip(a,b)];A[j]=[s*x+c*y for x,y in zip(a,b)]
 return out
def transform(rho,A):
 rows=[[(j,rat(x)) for j,x in enumerate(row) if x] for row in A];n=len(A)
 return [[sum((a*b*rho[k][l] for k,a in rows[i] for l,b in rows[j]),I(0)) for j in range(n)] for i in range(n)]
def evaluate(record):
 cs=controls(record);rho=[[p[i] if i==j else I(0) for j in range(6)] for i in range(6)];works=[]
 for k in range(3):
  a=transform(rho,cs[2*k]);works.append(sum(E[i]*(a[i][i]-rho[i][i]) for i in range(6)))
  full=[[a[i//3][j//3]*bath[i%3] if i%3==j%3 else I(0) for j in range(18)] for i in range(18)];full=transform(full,cs[2*k+1]);rho=[[sum(full[3*i+r][3*j+r] for r in range(3)) for j in range(6)] for i in range(6)]
 gross=sum((I(max(D(0),w.a),max(D(0),w.b)) for w in works),I(0))
 return [rho[i][i] for i in range(6)],works,gross
def certificate(data,upper,gamma_delta=F(1,100000)):
 selected=[data['protocols'][i] for i in data['selected']];assert len(selected)==5
 cols=[];costs=[];wr=[]
 for r in selected:
  out,w,c=evaluate(r);cols.append([out[i]-p[i] for i in range(6)]);costs.append(c);wr.append([x.pair() for x in w])
 def solve(v):
  A=[[cols[j][i] for j in range(5)]+[v[i]] for i in range(5)];piv=[]
  for k in range(5):
   t=max(range(k,5),key=lambda i:abs(A[i][k].a));A[k],A[t]=A[t],A[k];z=A[k][k];assert z.a*z.b>0;piv.append(z.pair());A[k]=[x/z for x in A[k]]
   for i in range(5):
    if i!=k:
     z=A[i][k];A[i]=[x-z*y for x,y in zip(A[i],A[k])]
  w=[r[-1] for r in A];assert all(x.a>0 for x in w);res=sum(w[j]*cols[j][5] for j in range(5))-v[5];assert res.a<=0<=res.b
  return w,piv
 mean=sum(p[i]*(i//2) for i in range(6));v=[p[i]*(mean-i//2) for i in range(6)];w,piv=solve(v);slope=sum(a*b for a,b in zip(w,costs));assert slope.b<D(upper)
 qg=q*ns['exp_minus_fraction'](gamma_delta,40);Zg=1+qg+qg*qg;t=[qg**(i//2)*q**(i%2)/(Zg*(1+q)) for i in range(6)];wf,pf=solve([t[i]-p[i] for i in range(6)]);assert sum(wf).b<1
 return dict(precision=80,selected_indices=data['selected'],tangent_upper=slope.pair(),tangent_weights=[a.pair() for a in w],pivots=piv,branch_works=wr,finite_gamma_delta=str(gamma_delta),finite_weights=[a.pair() for a in wf],finite_weight_sum=sum(wf).pair(),finite_work=sum(a*b for a,b in zip(wf,costs)).pair(),scope='feasible exact product return after final sign twirl folded into U3; no global optimum or separation')
