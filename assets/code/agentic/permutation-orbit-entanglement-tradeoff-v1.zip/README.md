# Reproduction package, version 1.0

Yuxuan Zhang, 27 November 2026.

The full proof is in manuscript/paper.tex. The review record describes the scope of the finite controls.
Requirements: Python 3.10+ and NumPy for the noncommuting matrix control.
Run python3 reproduce.py from a freshly extracted directory. To typeset the source, run latexmk -pdf manuscript/paper.tex with a standard TeX Live installation.

Original statement: https://qiqc-op.com/problem/op_ad12295d8fdfb02a/
Website and public PDF: https://yuxuanzhang1995.github.io/agentic-research/permutation-orbit-entanglement-tradeoff/
PDF SHA-256: 72a06ad40b38938636908b48fbdd30cc017cfef7a2f86ede02622ee273da8be4

The work received sequential internal review. External specialist review and priority remain open.
