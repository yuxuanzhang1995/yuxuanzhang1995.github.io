# Evidence-mapped outline — delayed onset (drafting stage 1; prose in delayed-onset-additivity.tex)

Evidence classes: E# = external source (EVIDENCE.json); K = checker line(s); R38 = the round-38 adversarial review;
I = internal research rounds 34, 36, 37 (orchestrator-checked, not separately reviewed); P = proved in the manuscript.

| ID | Claim | Type | Evidence |
|---|---|---|---|
| C01 | Definitions of S_p, S_p,min and Eq. (2) with m >= 3 exactly as in the record | declaration | E1 |
| C02 | The question is Ruskai's (Problem 19) | factual | E2 (metadata), E1 source note |
| C03 | Known violations: Hastings (p = 1), CHLMW (p near 0, pair of 4->3 channels, minimum output rank), Derksen-Lovitz (explicit, p > 1), Shou-Gorshkov (explicit) — exhibited for two uses | factual | E3, E4, E5, E6 |
| C04 | Flagged-sum formula S_p,min(Phi^n) = min_k [s_k + (n-k) b] for 0 < p < 1 | result | P (Lemma 2); R38 re-derived; I (round 34) |
| C05 | With b = s_2/2: equality at n = 1, 2 and violation at n = 3 iff s_3 < (3/2) s_2 | result | P (Lemma 3); R38 |
| C06 | Psi is CPTP | result | P; K (design/TP line); R38 |
| C07 | x^dag W x >= 2^-14 |x|^2 on product vectors; lambda_min((Psi(x)Psi)(rho)) >= 2^-14/9; ranks 9 and 3 | result (computer-assisted certificate) | P (Proposition 5); K (two independent exact routes); R38 (own exact Gram certificate) |
| C08 | Relaxation optimum ~2.1e-4; product-vector minimum ~9.1e-4; theta = 1 negative control | numerical / control | R38 numerics; K (control) |
| C09 | Three-copy output of rank <= 26 | result | P (Proposition 7, by hand); K (216 identities); R38 |
| C10 | s_3 <= log 26; s_2 >= B(p); (3/2) B(1/1000) > log 26; small-p limit | result | P (Lemma 8); K (X^500 > 26^333); R38 (60-digit interval) |
| C11 | Theorem 1 | result | C04-C10, C14 |
| C14 | Explicit block tau* = diag(1-2^-20, 2^-21, 2^-21) lies in the window (log2(26)/3, B(1/1000)/2] | result (computer-certified) | P (Lemma 8); K (T^1000 > 26^333 and T^2 <= X); final audit (M1) |
| C12 | No prior delayed first violation on arXiv through 27 Sep 2026 | factual (search-limited) | R38 listing searches; E6, E7 abstracts |
| C13 | Review status: one full AI review of the final proof; reductions developed over internal rounds; no human review | declaration | R38; INTERNAL_REVIEW.json |
