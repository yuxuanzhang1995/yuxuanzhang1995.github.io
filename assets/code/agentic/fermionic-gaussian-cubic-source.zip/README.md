# Uniform single-copy tomography of fermionic Gaussian states

Yuxuan Zhang. Version 1.0, 12 October 2026.

The manuscript gives a complete proof candidate for the uniform cubic-copy bound in Rubin, arXiv:2609.23189v1, Conjecture 10.1. Its exact assumptions and guarantees are in Theorem 1. It is a source-defined follow-up and must not be counted again as the earlier quadratic-copy QIQCOP catalog question.

Compile `fermionic-gaussian-cubic.tex` with pdfLaTeX (two passes) or latexmk. All mathematical prerequisites are included in the manuscript. The author affiliations are EPFL first, Princeton second.

`verification/` preserves the earlier core and warm-start arguments, the final frozen manuscript review, a bounded source comparison and three numerical diagnostics. The main manuscript includes the prerequisite and is the release statement. Earlier frozen files keep their historical scopes and provenance; project-local provenance paths refer to the author's research records and are not needed to read the proof.

Run each `*_check.py` with Python 3 and NumPy. The accompanying `*.expected.json` is the output from the recorded Docker environment; floating-point differences may occur with a different numerical runtime. Every check passed twice in separate network-disabled containers. These are finite convention and implementation checks, not proofs of universal claims. The variance diagnostic checks a looser inequality than the sharp constant proved analytically.

The final frozen AI review found no mathematical error. This is internal verification, not peer review or formal certification; exhaustive priority and external expert confirmation remain unestablished. Finite-bit running time is not proved. The theorem counts input copies.

The website release is authorized separately from the completed research rounds. This package does not announce a Zenodo record, QIQC issue update or catalog acceptance. Author and AI contributions appear in the manuscript.
