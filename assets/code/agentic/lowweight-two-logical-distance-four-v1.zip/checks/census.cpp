// Exact self-dual-parent census. Reads graph6 extracted from the raw archive.
// Enumerates only coefficient words with support <= cap (a proved complete
// restriction for graph-code words of physical weight <= cap).
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
int parity(unsigned a){return __builtin_parity(a);}
int rankrows(const vector<unsigned>& a){
  array<unsigned,12> piv{};int rank=0;
  for(unsigned x:a)while(x){int p=__builtin_ctz(x);if(piv[p])x^=piv[p];else{piv[p]=x;rank++;break;}}
  return rank;
}
int main(int argc,char**argv){
 if(argc!=6)return 2;
 int n=stoi(argv[1]),cap=stoi(argv[2]),expected=stoi(argv[3]),need=n-2;
 if(n<3||n>12||cap<3||cap>n)throw runtime_error("input range");
 ifstream in(argv[4]);if(!in)throw runtime_error("missing graph source");
 unsigned N=1u<<n;long rows=0,rankpruned=0,planes=0,countsurvivors=0;int maxrank=0,maxrank_countsurvivors=0,maxcount=0;bool found=false;string graph;
 auto start=chrono::steady_clock::now();
 while(getline(in,graph)){
  rows++;if(graph.size()!=size_t(1+(n*(n-1)/2+5)/6)||int(graph[0])-63!=n)throw runtime_error("graph6 size");
  vector<int>bits;for(size_t j=1;j<graph.size();j++){int c=int(graph[j])-63;if(c<0||c>=64)throw runtime_error("graph6 char");for(int b=5;b>=0;b--)bits.push_back((c>>b)&1);}
  vector<unsigned>g(n);int at=0;for(int j=1;j<n;j++)for(int i=0;i<j;i++)if(bits[at++]){g[i]|=1u<<j;g[j]|=1u<<i;}
  vector<unsigned>low,shorts;
  for(unsigned t=1;t<N;t++){
   if(__builtin_popcount(t)>cap)continue;
   unsigned z=0,walk=t;while(walk){unsigned bit=walk&-walk;int j=__builtin_ctz(bit);z^=g[j];walk-=bit;}
   int w=__builtin_popcount(t|z);if(w<=cap)low.push_back(t);if(w<=3)shorts.push_back(t);
  }
  if(rankrows(low)<need){rankpruned++;continue;}
  // All products of <=3 one-site errors, allowing repeated sites. Repeats
  // reduce to errors of no greater weight, so this is the exact same ball.
  vector<unsigned>unit{0};for(int i=0;i<n;i++){unit.push_back(1u<<i);unit.push_back(g[i]);unit.push_back((1u<<i)^g[i]);}
  sort(unit.begin(),unit.end());unit.erase(unique(unit.begin(),unit.end()),unit.end());
  vector<unsigned char>bad(N),eligible(N);
  for(size_t a=0;a<unit.size();a++)for(size_t b=a;b<unit.size();b++)for(size_t c=b;c<unit.size();c++)bad[unit[a]^unit[b]^unit[c]]=1;
  vector<unsigned>h;
  for(unsigned u=1;u<N;u++)if(!bad[u]){bool good=true;for(auto t:shorts)if(parity(t&u)){good=false;break;}if(good){eligible[u]=1;h.push_back(u);}}
  for(size_t i=0;i<h.size();i++)for(size_t j=i+1;j<h.size();j++){
   unsigned u=h[i],v=h[j],w=u^v;if(w<=v||!eligible[w])continue;planes++;
   vector<unsigned>inside;for(unsigned t:low)if(!parity(t&u)&&!parity(t&v))inside.push_back(t);
   int r=rankrows(inside);if(r>need)throw runtime_error("kernel rank exceeded");maxrank=max(r,maxrank);maxcount=max(maxcount,int(inside.size()));
   if(int(inside.size())>=need){countsurvivors++;maxrank_countsurvivors=max(maxrank_countsurvivors,r);}
   if(r==need){found=true;goto done;}
  }
 }
 done:
 if(!found&&(!in.eof()||rows!=expected))throw runtime_error("incomplete source census");
 ofstream out(argv[5]);if(!out)throw runtime_error("output failure");
 out<<"{\"n\":"<<n<<",\"cap\":"<<cap<<",\"rows\":"<<rows<<",\"low_rank_pruned\":"<<rankpruned<<",\"planes\":"<<planes<<",\"max_low_rank\":"<<maxrank<<",\"count_survivors\":"<<countsurvivors<<",\"max_rank_count_survivors\":"<<maxrank_countsurvivors<<",\"max_low_count\":"<<maxcount<<",\"found\":"<<(found?"true":"false")<<",\"source_exhausted\":"<<(!found&&in.eof()?"true":"false")<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cout<<"rows="<<rows<<" planes="<<planes<<" found="<<found<<" max_rank="<<maxrank<<"\n";
}
