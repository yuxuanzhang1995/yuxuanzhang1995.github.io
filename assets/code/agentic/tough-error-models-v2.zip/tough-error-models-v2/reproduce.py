"""Replay finite checks in a temporary copy; this does not certify the proofs."""
from pathlib import Path
from hashlib import sha256
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
manifest_path = ROOT / "MANIFEST.json"
verified = 0
if manifest_path.exists():
    for item in json.loads(manifest_path.read_text())["files"]:
        assert sha256((ROOT / item["path"]).read_bytes()).hexdigest() == item["sha256"], item["path"]
        verified += 1

scripts = [
    "inherited/check_variational_identity.py",
    "inherited/check_block_models.py",
    "S01-q119-core-and-boundary-audit/check_full_hessian.py",
    "S02-q119-quantitative-landscape/verify_quantitative.py",
    "S03-q119-constructive-recovery/verify_recovery.py",
    "check_kernel_boundary.py",
]
reports = []
with tempfile.TemporaryDirectory(prefix="q119-v2-replay-") as tmp:
    target = Path(tmp) / "checks"
    shutil.copytree(ROOT / "checks", target)
    for script in scripts:
        result = subprocess.run(
            [sys.executable, "-B", str(target / script)],
            cwd=tmp, text=True, capture_output=True, check=True,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        summary = json.loads(result.stdout)
        for diagnostic in summary.get("diagnostics", []):
            assert diagnostic["target_reached"], diagnostic
        if "pipeline" in summary:
            assert summary["pipeline"]["target_reached"], summary["pipeline"]
        reports.append({"checker": script, "summary": summary})
    details = {}
    for path in sorted(target.rglob("*.json")):
        # Path fields in inherited reports identify temporary copies only.
        text = path.read_text().replace(str(target), "checks")
        details[str(path.relative_to(target))] = json.loads(text)

print(json.dumps({
    "version": "2.0", "hashes_verified": verified,
    "checks": reports, "details": details,
    "scope": "Finite exact controls and floating diagnostics; analytic proof review is separate.",
}, indent=2))
