import numpy as np
import sympy as sp
from scipy.integrate import quad
from itertools import combinations
# Exact Bell convention and transpose on the SECOND qubit.
B=sp.Matrix([[1,1,0,0],[0,0,1,1],[0,0,1,-1],[1,-1,0,0]])/sp.sqrt(2)
def ptc(M):
    return sp.Matrix(4,4,lambda r,c:M[2*(r//2)+c%2,2*(c//2)+r%2])
def pt(M): return sp.simplify(B.T*ptc(B*M*B.T)*B)
def unit(i,j):
    M=sp.zeros(4); M[i,j]=1; return M
pairs=list(combinations(range(4),2))
S={(i,j):unit(i,j)+unit(j,i) for i,j in pairs}
A={(i,j):sp.I*(unit(i,j)-unit(j,i)) for i,j in pairs}
for ij in pairs: assert pt(S[ij])==S[ij]
for ij,kl,sign in [((0,1),(2,3),1),((0,2),(1,3),-1),((0,3),(1,2),-1)]:
    assert pt(A[ij])==sign*A[kl]
    assert pt(A[kl])==sign*A[ij]
print('Exact Bell PT: six real identities and six imaginary identities PASS')
P=unit(3,3); W=pt(P)
assert W==sp.diag(-sp.Rational(1,2),sp.Rational(1,2),sp.Rational(1,2),sp.Rational(1,2))
print('Exact supporting witness diag(-1,1,1,1)/2 PASS')
b=np.array(B,dtype=complex)
def gamma(M):
    Z=b@M@b.T
    Z=Z.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
    return b.T@Z@b
pn=np.diag([0.,0.,0.,1.]); wn=np.array(W,dtype=complex)
def ell(a,b):
    if a==b: return 1/a
    return np.log1p((a-b)/b)/(a-b)
def hfun(pi,pj,a,b):
    if a==b: return (pi+pj)/(2*a*a)
    z=a-b
    return (pi*(np.log(a/b)-z/a)+pj*(z/b-np.log(a/b)))/(z*z)
basis=[]
for k in range(3):
    H=np.zeros((4,4),complex); H[k,k]=1; H[3,3]=-1; basis.append(H)
for ij in pairs:
    basis += [np.array(S[ij],complex),np.array(A[ij],complex)]
assert len(basis)==15
worst=0.; hworst=0.
for nums in [(31,9,6,4),(30,8,8,4),(30,10,5,5),(30,7,7,6),(30,5,5,5)]:
    den=sum(nums); pr=[sp.Rational(x,den) for x in nums]
    # Last sample also tests repeated tail eigenvalues, all states are strictly entangled.
    q=1-pr[0]; sr=[sp.Rational(1,2)]+[x/(2*q) for x in pr[1:]]
    lam=4*pr[0]-2; dr=[sp.Rational(1,2)-sr[3],sp.Rational(1,2)-sr[2],sp.Rational(1,2)-sr[1]]
    assert min(pr)>0 and lam>0 and min(dr)>0
    print('Exact sample '+str(nums)+': min(p)='+str(min(pr))+' > 0; lambda='+str(lam)+' > 0; min(d)='+str(min(dr))+' > 0: PASS')
    p=np.array(pr,float); s=np.array(sr,float); la=float(lam); d=np.array(dr,float)
    G=np.diag(list(1/d)+[0.]); E=np.array([[ell(x,y) for y in s] for x in s])
    hs=np.zeros((4,4))
    for i in range(4):
        hs[i,i]=p[i]/s[i]**2
    for i,j in pairs:
        val=hfun(p[i],p[j],s[i],s[j])
        integ=quad(lambda t:p[i]/((s[i]+t)**2*(s[j]+t))+p[j]/((s[i]+t)*(s[j]+t)**2),0,np.inf,epsabs=1e-12,epsrel=1e-12)[0]
        hworst=max(hworst,abs(val-integ)); hs[i,j]=hs[j,i]=integ
    for H in basis:
        X=np.zeros((4,4),complex)
        for i in range(1,4): X[i,i]=(H[i,i]+p[i]*H[0,0]/float(q))/(2*float(q))
        for i,j in pairs:
            kr=la/d[i] if j==3 else 0.
            ki=la/d[({0,1,2}-{i,j}).pop()] if j<3 else 0.
            X[i,j]=E[i,j]*(H[i,j].real/(hfun(p[i],p[j],s[i],s[j])+kr)+1j*H[i,j].imag/(hfun(p[i],p[j],s[i],s[j])+ki))
            X[j,i]=X[i,j].conjugate()
        Y=gamma(X)
        TX=hs*X+la*gamma(G@Y@pn+pn@Y@G)
        R=TX-E*H
        # Normal space is span(I,W), so all off-diagonals and tail differences vanish.
        residual=max(np.max(np.abs(R-np.diag(np.diag(R)))),abs(R[1,1]-R[2,2]),abs(R[1,1]-R[3,3]),abs(np.trace(X)),abs(X[0,0]))
        worst=max(worst,float(residual))
assert hworst<1e-10
assert worst<1e-10
print('Scalar quadrature disagreement < 1e-10: PASS (floating-point check, not interval certification)')
print('All 15 directions x 5 samples: tangent KKT residual < 1e-10: PASS (floating-point check)')
