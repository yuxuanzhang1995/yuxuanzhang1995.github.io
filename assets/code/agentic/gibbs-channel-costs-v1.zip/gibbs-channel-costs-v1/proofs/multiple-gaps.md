# One finite clock for several independently selectable measurements

Let the input be the orthogonal direct sum of \(k\) qubit sectors. In sector \(i\) the energies are \(e_i,e_i+\Delta_i\), \(\Delta_i>0\). The output is one degenerate classical bit. The two effects on the input are \(\bigoplus_i (I\pm v_i X_i)/2\), \(0\le v_i\le1\). Thus coherences between different input sectors are discarded. This channel is Gibbs preserving for every inverse temperature. The sector offsets and Gibbs weights do not need to agree. The set of gaps can have any finite rational rank, including two incommensurate gaps. The caller may put an arbitrary reference on the input.

**Result.** For this family one can decide zero-error finite implementability and compute both costs at every error to any specified additive precision. A finite search size for the QFI optimum comes directly from the target, energy data and requested precision. It applies even when the additive energy group is dense. At common visibility \(1-t\), the exact zero-error coherence cost has sharp leading coefficient
\[
  \lim_{t\downarrow0} tF_c^0=\tfrac12\max_i \Delta_i^2.
\]
The simultaneous finite-size estimate is the central result here. R217 and R218 treated one physical gap. R219 treated simultaneous commensurate modes in a different, qutrit Fourier detector.

## Joint overlaps give the exact optimization

Supply lattice generators \(\omega\in\mathbb R^d\) for the group of the \(\Delta_i\), with integer labels \(k_i\) satisfying \(\omega\cdot k_i=\Delta_i\). For each finite nonnegative unit amplitude vector \(u\) on \(\mathbb Z^d\) define
\[
 b_i(u)=\sum_z u_z u_{z+k_i},\qquad V(u)=\operatorname{Var}_{u_z^2}(\omega\cdot z).
\]
Put \(w_i=\cos(\min\{\pi/2,\arccos v_i+2\arcsin\varepsilon\})\) for \(0\le\varepsilon\le1\). The QFI cost is four times the infimum of \(\sum_j p_j V(u_j)\) over finite mixtures satisfying \(\sum_jp_j b_i(u_j)\ge w_i\) for every \(i\). Denote this variance infimum by \(V_*(w)\). All \(w_i<1\) suffice for a finite implementation to the desired error. If any \(w_i=1\) the cost is infinite, since a nonzero finite sequence cannot have overlap one with a nonzero shift. At \(\varepsilon=0\) this gives the finite-realization decision exactly. For the sharp battery the answer is infinity if any \(w_i>0\), zero otherwise.

To prove necessity, first reduce an arbitrary finite mixed resource to a finite pure purification of the same QFI divided by four as variance, using its optimized purifier Hamiltonian. Pull back the classical bit effect. On **the same program** the block-\(i\) off-diagonal element is at most \(\tfrac12\sum_E a_Ea_{E+\Delta_i}\), by invariance and the operator-norm bound on the cross block of an effect (see costs.md). Here \(a_E\) is the norm of the program's component of energy \(E\). Testing the two \(X_i\)-eigenstates gives the lower requirement \(w_i\). Split the finite program into energy cosets of the group and take the normalized nonnegative amplitude norms on each coset. The weighted \(b_i\)'s are precisely the simultaneous overlap bounds. Their average physical variance is at most the program variance by conditional variance decomposition, regardless of coset offsets or degeneracies. This gives the required finite mixture lower bound.

For sufficiency use a mixed program with orthogonal classical flags, distribution \(p_j\), and the indicated pure finite ladders. Each flag may shift its energy origin. Its QFI is four times the weighted within-flag variance. Read the energy-commuting input sector and, conditional on sector \(i\), apply the paired-sector invariant effect of costs.md with step \(k_i\). This can be done for every \(i\) in one processor since the inputs are mutually orthogonal. A single attenuation for each \(i\) yields exactly \(w_i\) from the averaged overlap (use zero if both vanish). Finite covariant dilation with included sharp blanks implements it thermally. For the reference-assisted distance, retain the true sector and the ideal \(X_i\) sign before the two classical reporting rules. Root fidelity is bounded below by the smallest conditional Bernoulli root fidelity. A single sector and eigenstate attain the corresponding distance. This gives precisely the maximum of the individual distances and proves sufficiency. Sharp-battery impossibility follows on any offending sector by covariance. If all \(w_i=0\), Gibbs replacement achieves the tolerance for every reference. The Gibbs input prohibits a deterministic battery gain as in costs.md.

## A finite cutoff for near-optimal cost

Let \(K=\max_i\|k_i\|_1\), \(\gamma=(1-\max_i w_i)/2>0\), and \(D_L=\pi^2 K^2/[2(L+1)^2]\). A normalized product of length-\(L\) sine windows on the box \([1,L]^d\) has autocorrelation \(\kappa_i\ge1-D_L\) for each step, by the shift norm estimate in costs.md. Choose \(L_0\) with \(D_{L_0}\le\gamma\). This reference packet has all overlaps at least \(w_i+\gamma\). Its variance is at most \(A=(L_0-1)^2\sum_a\omega_a^2/4\) by independence. Let \(V_L(w)\) be the same finite-mixture infimum using packets supported in \([1,L]^d\).

For every \(L\ge L_0\),
\[
  V_L(w)-A\,\frac{D_L}{\gamma+D_L}\ \le\ V_*(w)\ \le\ V_L(w).
\]
In particular, for additive QFI precision \(\tau>0\), it suffices to choose \(L\ge L_0\) with \(4 A D_L/\gamma\le\tau\), allowing any extra numerical optimization error separately. This is an explicit, target-dependent bound on the support of a near-optimal finite program. Feasibility with the specified channel accuracy is exact. For \(\varepsilon=0\) the programs implement the target exactly even though its optimal QFI is an infimum.

Here is why the bound holds for *all* programs in this family. Take a finite packet \(u\) from any feasible near-optimal mixture. Let \(g\) be the sine window on the box and decompose \(u\) into the normalized packets proportional to \(u_zg(z-a)\), weighted by their squared norms over integer translates \(a\). These weights sum to one. Before normalization the averaged position distribution is exactly the original one, since \(\sum_a g(z-a)^2=1\). The average within-packet variance cannot exceed \(V(u)\). The averaged \(i\)-th overlap is exactly \(\kappa_i b_i(u)\), since \(\sum_a g(z-a)g(z+k_i-a)=\kappa_i\) for every \(z\). Translate the normalized packets into the same box. Their variances and overlaps are translation invariant. Carry this out for the entire finite mixture. All overlaps are now at least \(w_i-D_L\). Mix in the \(L_0\)-reference packet with common probability \(D_L/(\gamma+D_L)\). This restores every required overlap and increases average variance by at most the subtracted term in the bound. Pass to the infimum. Localizing the mean of the *energy* rather than bounding each lattice coordinate by the energy is what allows incommensurate gaps.

On a fixed box the moment vectors \((b_1,\ldots,b_k,V)\) of individual packets form a compact set in \(\mathbb R^{k+1}\). Its convex hull requires at most \(k+2\) packets per point. Thus the finite optimum is attained in at most \((k+2)L^d\) flagged program dimensions plus the finite implementing blanks. All finite constraints and the objective are polynomial in the nonnegative amplitudes and mixture probabilities. Algebraic input admits finite real quantifier elimination. For general computable energy values with supplied integer labels, compact amplitude grids give arbitrarily close moment approximations, with explicit continuity bounds on the box; the strict reference slack repairs small overlap errors. These statements do not require recognizing arbitrary real rational-independence relations from numerical samples.

## Sharp common-noise asymptotics

Restriction to the largest-gap sector and the one-mode Robertson bound give \(F_c^0\ge \max_i\Delta_i^2 (1-t)^2/[1-(1-t)^2]\). To prove an upper bound with the same constant use one anisotropic packet for all gaps. Let \(P_\perp\) be the orthogonal projection onto \(\omega^\perp\) in the coordinate lattice space, \(\sigma^2=(1+\sqrt{t})\max_i\Delta_i^2/(8t)\), and
\[
 \Sigma^{-1}=\omega\omega^\mathsf{T}/\sigma^2+t^2 P_\perp .
\]
Use lattice amplitudes proportional to \(\exp[-z^\mathsf{T}\Sigma^{-1}z/4]\). The physical variance is \(\sigma^2(1+o(1))\), and overlap at step \(k_i\) equals
\[
 \exp[-k_i^\mathsf{T}\Sigma^{-1}k_i/8]\,(1+O(e^{-c/t})).
\]
For detail, Poisson summation of the shifted squared-amplitude normalization at offset \(k_i/2\) gives the dual Gaussian sum with terms \(\exp[-2\pi^2 l^\mathsf T\Sigma l]e^{i\pi l\cdot k_i}\). Its nonzero terms are exponentially small because the least eigenvalue of \(\Sigma\) grows at least as \(c'/t\). Differentiating the centered sum with respect to a linear source in direction \(\omega\) gives the continuous variance \(\omega^\mathsf T\Sigma\omega=\sigma^2\) plus exponentially small terms times polynomial factors in \(\|\Sigma\|\). The largest eigenvalue is \(O(t^{-2})\). Since the shifts are fixed and \(k_i^\mathsf T\Sigma^{-1}k_i=\Delta_i^2/\sigma^2+O(t^2)\), every overlap exceeds \(1-t\) for sufficiently small \(t\), with a margin of order at least \(t^{3/2}\). For each such \(t\), a finite symmetric box retains all margins and approximates the variance to additive one. The sector-dependent attenuation is then exact. This proves the leading coefficient using a single finite clock for any finite list of fixed gaps.

The result uses a common bit effect on orthogonal input sectors, allowing separate implementations conditional on that sector. For overlapping effects on a shared input space this sufficiency step can fail, as R219's compatibility analysis illustrates. The general nonpolyhedral finite-existence problem and optimal work for arbitrary channels remain open.
