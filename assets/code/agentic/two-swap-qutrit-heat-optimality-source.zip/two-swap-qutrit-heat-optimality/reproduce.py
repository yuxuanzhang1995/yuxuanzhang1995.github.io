"""Check release hashes and execute the selected finite controls in a clean copy."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys, tempfile, os
root = Path(__file__).resolve().parent
manifest = json.loads((root/"release-manifest.json").read_text())
for entry in manifest["files"]:
    actual = hashlib.sha256((root/entry["path"]).read_bytes()).hexdigest()
    if actual != entry["sha256"]:
        raise RuntimeError("Hash mismatch: "+entry["path"])
specs = json.loads((root/"checks.json").read_text())
out = root/"reproduction-results"
out.mkdir(exist_ok=True)
results = []
with tempfile.TemporaryDirectory(prefix="research-replay-") as tmp:
    work = Path(tmp)
    shutil.copytree(root/"evidence", work/"evidence")
    for i, spec in enumerate(specs):
        script, *args = spec
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        proc = subprocess.run([sys.executable, str(work/script), *args],
                              cwd=work, capture_output=True, text=True, env=env)
        (out/f"{i+1:02d}-{Path(script).stem}.log").write_text(proc.stdout+"\n"+proc.stderr)
        results.append({"script":script,"arguments":args,"exit_code":proc.returncode})
        if proc.returncode:
            (out/"summary.json").write_text(json.dumps(results,indent=2)+"\n")
            print(proc.stdout[-3000:]+proc.stderr[-3000:], file=sys.stderr)
            raise SystemExit(proc.returncode)
(out/"summary.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps({"status":"pass","hashes_checked":len(manifest["files"]),
                  "checks":len(results),"scope":"Finite evidence replay; not a replacement for analytic proofs."},indent=2))
