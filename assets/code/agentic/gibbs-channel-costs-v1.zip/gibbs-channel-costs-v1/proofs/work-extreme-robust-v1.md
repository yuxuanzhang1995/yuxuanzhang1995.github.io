# Stability of the extreme-channel deterministic work formula

24 November 2026. Extension of `work-extreme-v1.md`; same normal infinite
Gibbs bath, same finite input/output system and Hamiltonian, exactly sharp
initial/final battery, no other resource. Same-root analytic proof candidate.

Let Phi be CPTP-extreme and covariant, and let its minimal Kraus operators
K_alpha be Hilbert--Schmidt orthogonal and of definite frequencies omega_alpha.
Put Z_K=sum_alpha exp(beta omega_alpha), W*=beta^(-1)log Z_K.
There is a finite constant C_Phi,beta such that, for sufficiently small
epsilon, every sharp-battery implementation of Psi with
D_ch(Phi,Psi)<=epsilon has

    W >= beta^(-1) log[Z_K-C_Phi,beta epsilon].             (1)

Combined with the exact construction for every W>W*, this proves

    W* - O(epsilon) <= inf W_epsilon(Phi) <= W*,
    lim_{epsilon downarrow 0} inf W_epsilon(Phi) = W*.

This is a continuity bound, not an assertion of an optimal linear correction.

## Small leakage from the target Kraus support

Let J_Phi be the unnormalized Choi matrix and P its support projection.
The maximally entangled test input is allowed in D_ch. Since J_Phi/d is
supported on P and purified distance is at most epsilon,

    Tr[(I-P)J_Psi] <= d epsilon^2.                        (2)

Indeed fidelity squared with a state supported on P cannot exceed the
other state's weight on P. Choose Hilbert--Schmidt orthonormal operators
L_mu spanning the orthogonal complement of the Kraus support. They can
be chosen with definite frequencies nu_mu because the target is covariant.

As before, purity of the final battery makes the restricted processor an
isometry V on system plus bath, raising their total energy by W. Expand
its system factor uniquely as

    V=V0+V1,
    V0=sum_alpha K_alpha tensor S_alpha,
    V1=sum_mu L_mu tensor T_mu.

Every S_alpha and T_mu is bounded by a constant depending only on the
fixed operator basis (take the corresponding finite system matrix-entry
functional of the contraction V). The bath Gibbs state gamma satisfies

    sum_mu ||T_mu||_(2,gamma)^2 = Tr[(I-P)J_Psi]
                               <=d epsilon^2,             (3)

where ||X||_(2,gamma)^2=Tr(gamma X^*X). Energy conservation gives
[B,S_alpha]=(W-omega_alpha)S_alpha and
[B,T_mu]=(W-nu_mu)T_mu.

## Stable Gram orthogonality from extremality

V^*V=I implies

 sum_{alpha,beta} K_alpha^*K_beta tensor
   (S_alpha^*S_beta-delta_alpha_beta I)
   = -(V0^*V1+V1^*V0+V1^*V1).                            (4)

The system matrices K_alpha^*K_beta are linearly independent. Fixed dual
linear functionals therefore extract each coefficient on the left. The
weighted L2 norm of every term on the right is O(epsilon), uniformly over
the bath and W. For example,

 ||S_alpha^*T_mu||_(2,gamma)
       <= ||S_alpha|| ||T_mu||_(2,gamma).

For the adjoint term use the exact Gibbs identity: if [B,X]=kappa X,

    ||X^*||_(2,gamma)^2=exp(-beta kappa)||X||_(2,gamma)^2.

Here kappa=omega_alpha-nu_mu, so no bath spectrum or W enters the constant.
Terms T_mu^*T_nu have the same bound using the uniform operator norm of
T_mu. There are finitely many fixed system coefficients. Consequently

 sum_{alpha,beta} ||S_alpha^*S_beta-delta_alpha_beta I||_(2,gamma)^2
       <= C1^2 epsilon^2.                               (5)

## Gibbs-weighted rank obstruction

Regard M=[S_1 ... S_r] as an operator from bath tensor C^r to bath, and
give its domain the Hamiltonian

    B_D = B tensor I - I tensor diag(omega_alpha).

Then B M-M B_D=W M. Its Gram G=M^*M commutes with B_D. The unnormalized
finite trace weight on this domain is

    tau_D(X)=Tr[(gamma tensor diag(exp(beta omega_alpha))) X],
    tau_D(I)=Z_K.

Equation (5) implies ||G-I||_(2,tau_D)<=C2 epsilon. Let P_G be its support
projection. In the polar decomposition M=U sqrt(G), U raises energy by W
between its initial support P_G and final range Q_G. Spectral counting gives

    tau_D(P_G)=exp(beta W) Tr(gamma Q_G)<=exp(beta W).     (6)

All projections and functional-calculus operators used here commute with
their respective Gibbs weights. On the kernel of G, |G-I| equals I. Thus

 Z_K-exp(beta W)
    <=tau_D(I-P_G)
    <=tau_D(|G-I|)
    <=sqrt(Z_K) ||G-I||_(2,tau_D)
    <=C_Phi,beta epsilon.

This proves (1). The argument does not infer a small operator norm from a
small weighted norm; the rank bound is precisely what avoids that error.

## Finiteness, without extremality

The word-bath construction in `work-extreme-v1.md` applies to every finite
covariant channel. Hence exact deterministic work is finite for all such
channels in this bath model. Every sharp-battery thermal implementation is
covariant. The set of covariant channels is compact, so for a noncovariant
target Phi its distance delta_cov from that set is strictly positive.
For every epsilon<delta_cov the work cost is infinite. More generally, for
any target and error epsilon, finite work is possible iff some covariant
channel lies within that channel-distance tolerance. The minimum distance
is attained by compactness, and the chosen covariant approximant has a
finite exact word-bath realization.

Thus this model has a complete structural finiteness test for work. It
does not yet give the tight value for arbitrary nonextreme covariant
channels. Noncovariant targets do not have a finite power-law divergence
in work as epsilon tends to zero: there is already an infinite-cost
interval. Giving a free coherent reference would change this conclusion
and is outside the stated battery-only model.
