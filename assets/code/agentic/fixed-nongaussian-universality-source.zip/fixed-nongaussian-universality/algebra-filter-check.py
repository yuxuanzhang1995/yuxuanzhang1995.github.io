"""Symbolic finite identities and bounded filter diagnostics, not operator proof."""
import sympy as s
import numpy as np,json,math
q=s.symbols('q',real=True)
for d in range(3,13):
    f=q**d
    for _ in range(d-3):f=s.expand(f.subs(q,q+1)-f)
    assert s.degree(f,q)==3 and s.expand(f).coeff(q,3)==s.factorial(d)/s.factorial(3)
p=lambda f:-s.I*s.diff(f,q)
for d in range(10):
    f=q**d
    bplus=lambda f:p(f)-3*q*q*f
    bminus=lambda f:p(f)+3*q*q*f
    assert s.expand(bplus(bplus(f))+bminus(bminus(f))-2*p(p(f))-18*q**4*f)==0
alpha=np.array([math.sqrt(2),math.sqrt(3)])
vertices=[(i,j)for i in range(3)for j in range(3)]
freq=np.array([2*alpha[0]*(alpha@np.array(k))+alpha[0]**2 for k in vertices])
assert np.all(freq>0)and len(np.unique(freq))==len(freq)
w=freq[4];L=32;r=np.arange(L**3);times=r/L**2
cos=2/L**3*np.cos(w*times);sin=2/L**3*np.sin(w*times)
a=np.array([np.sum(cos*np.exp(1j*v*times))for v in freq]);b=np.array([np.sum(sin*np.exp(1j*v*times))for v in freq])
for i,v in enumerate(freq):
    # Deterministic finite-L upper bound from the oscillatory integral plus mesh error.
    off=0 if i==4 else 2/(L*abs(v-w))
    bound=off+2/(L*(v+w))+2*(w+v)/L**2
    assert abs(a[i]-(1 if i==4 else 0))<=bound
    assert abs(b[i]-(1j if i==4 else 0))<=bound
print(json.dumps(dict(status='passed',finite_difference_degrees=list(range(3,13)),quartic_identity_test_polynomials=10,filter=dict(L=L,frequencies=9,max_cosine_residual=float(max(abs(a-np.eye(1,9,4)[0]))),max_sine_residual=float(max(abs(b-1j*np.eye(1,9,4)[0])))),scope='Symbolic finite polynomial identities and finite frequency estimates only. No numerical truncation certifies essential self-adjointness, strong closure or energy-constrained convergence.'),indent=2))
