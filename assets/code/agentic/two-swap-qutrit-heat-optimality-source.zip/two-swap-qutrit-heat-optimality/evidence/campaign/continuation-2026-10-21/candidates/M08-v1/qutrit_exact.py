"""Independent integer support evaluation, with Arb input enclosures.

No discovery oracle imported. Uses 60-bit floor approximations and a proved
uniform 1000/2^60 support error allowance, including thermal and lambda error.
"""
import sys,itertools,json,time,math
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
from flint import arb,ctx
ctx.prec=200
S=2**60
def floorlo(x):
    f=x.lower().fmpq();return int(f.numerator//f.denominator)
def ceilhi(x):
    f=x.upper().fmpq();return -int((-f.numerator)//f.denominator)
def thermal(x):
    a=[(-x*j).exp() for j in range(3)];z=sum(a);return [t/z for t in a]
def moments(x):
    p=thermal(x);e=p[1]+2*p[2];v=p[1]+4*p[2]-e*e
    dp=[p[j]*(e-j) for j in range(3)]
    dd=[p[j]*((e-j)**2-v) for j in range(3)]
    return p,e,-v,dp,dd
p0,e0,_,_,_=moments(arb(1));p2,e2,ep2,dp2,_=moments(arb(2))
lo=Fraction(144,100);hi=Fraction(146,100)
def root_derivative(a):
    a=arb(a.numerator)/a.denominator
    _,e,ep,_,_=moments(a)
    return e0-e+(2-a)*ep
assert root_derivative(lo)<0 and root_derivative(hi)>0
for _ in range(170):
    mid=(lo+hi)/2;a=arb(mid.numerator)/mid.denominator
    _,e,ep,_,_=moments(a);d=e0-e+(2-a)*ep
    if d>0:hi=mid
    elif d<0:lo=mid
    else:break
A=arb(str(float((lo+hi)/2)),str(float((hi-lo)/2)+2e-16))
# Reconstruct the interval exactly, avoiding the display approximation above.
mid=(lo+hi)/2;rad=(hi-lo)/2
A=arb(mid.numerator)/mid.denominator+arb(0,str(float(rad)*1.000001))
pa,ea,epa,_,_=moments(A)
LAM0=(ea-e2-2*ep2-3*dp2[1])/dp2[0]
Q=A*(e0-ea)+2*(ea-e2);Z=Q-LAM0*p2[0]-3*p2[1]
L0=floorlo(LAM0*S)
assert ceilhi(LAM0*S)-L0<=1
def parts(s):
    if not s:yield [];return
    a=min(s)
    for pair in itertools.combinations(sorted(s-{a}),2):
        t=(a,)+pair
        for rest in parts(s-set(t)):yield [t]+rest
PART=list(parts(set(range(9))))
@lru_cache(None)
def probs(g):
    x=arb(g.numerator)/g.denominator
    p=thermal(x);lo=tuple(floorlo(t*S) for t in p)
    assert all(ceilhi(t*S)-l<=1 for t,l in zip(p,lo))
    return lo
P0=probs(Fraction(1))
def value(a,b,exclude=None):
    # All arithmetic after thermal enclosure is exact Python integer arithmetic.
    a,b=Fraction(a),Fraction(b);D=math.lcm(a.denominator,b.denominator)
    assert D%a.denominator==D%b.denominator==0
    ga=a.numerator*(D//a.denominator);gb=b.numerator*(D//b.denominator)
    p=probs(a);t=probs(b);x=[r*s for r in P0 for s in p]
    costs=sorted([gb*j*S-D*l for l in (L0,3*S,0) for j in range(3)])
    best=None
    for index,part in enumerate(PART):
        if index==exclude:continue
        rows=[sorted((x[j] for j in block),reverse=True) for block in part]
        mid=[sum(row) for row in rows]
        q1=ga*(sum(row[1]+2*row[2] for row in rows)-S*(p[1]+2*p[2]))
        xx=sorted([r*s for r in mid for s in t],reverse=True)
        numerator=q1*S*S+sum(u*c for u,c in zip(xx,costs))-gb*(t[1]+2*t[2])*S**3
        if best is None or numerator<best:best=numerator
    exact=arb(best)/(D*S**4)
    return exact-Z-arb(1000)/S
def replay():
    start=time.time();data=json.loads((ROOT/'cover.json').read_text())
    vals={}
    def point(a,b):
        key=(a,b)
        if key not in vals:vals[key]=value(a,b)
        return vals[key]
    lower=[]
    for a,A,b,B,_ in data['passed']:
        v=min(point(x,y).lower() for x in (a,A) for y in (b,B))
        v=arb(v)-(arb(28)*(A-a)**2+arb(22)*(B-b)**2)/8
        assert v>0, (a,A,b,B,str(v))
        lower.append(float(v.lower()))
    out={'status':'pass','certified_remote_leaves':len(lower),'vertices':len(vals),'minimum_remote_lower':min(lower),'seconds':time.time()-start,'root_interval':str(globals()['A']),'lambda0':str(LAM0),'Qswap':str(Q),'Z':str(Z),'input_error_allowance':str(arb(1000)/S),'local_region_still_required':True}
    return out

