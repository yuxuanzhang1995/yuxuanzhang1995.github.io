from fractions import Fraction as Q
from itertools import product
from math import comb
import json

t=Q(1,2);a=(1-t)/2;b=(1+t)/2
# Independent route: the probability x of a zero outcome is uniform on[a,b].
def ix(k):return (b**(k+1)-a**(k+1))/(t*(k+1))
s=ix(4);N=((t-1)*ix(4)+2*ix(5))/(2*t);F=N/s;baseline=(1+t)/2
# Separate Bloch-moment expansion and all n=2,3 controls.
def moments(n,t):
 coeff=[Q(comb(n,k))*t**k/Q(2**n) for k in range(n+1)]
 den=sum(c/Q(k+1)for k,c in enumerate(coeff)if k%2==0)
 num=den/2+sum(c/Q(2*(k+2))for k,c in enumerate(coeff)if k%2==1)
 return den,num
assert moments(4,t)==(s,N)
assert (s,N,F)==(Q(121,1280),Q(547,7680),Q(547,726))
assert F-baseline==Q(5,1452)>0
assert N-baseline*s==Q(1,3072)>0
# K=|0><0000| has one nonzero element K[0,0]=1; K*K is a diagonal projector.
assert all(Q(int(j==0))<=1 for j in range(16))
# Source(S25): J/16 = x0 |00000><00000|, x0=1/16, all other coefficients0.
# Verify all4^5 Pauli coefficient equations exactly, including zeros.
pauli_rows=0
for word in product(range(4),repeat=5): # I,X,Y,Z
 expectation=Q(int(all(p in(0,3)for p in word)))
 b_i=expectation/16;G_i0=expectation;x0=Q(1,16)
 assert G_i0*x0==b_i
 pauli_rows+=1
# Control: same construction does not refute n=2 or3 no-go at t=1/2.
controls={}
for n in (2,3):
 p,q=moments(n,t);assert q/p<=baseline;controls[str(n)]=str(q/p-baseline)
# Check polynomial gain on an exact rational grid for the analytic formula.
for j in range(1,50):
 u=Q(j,50);p,q=moments(4,u);D=1+2*u*u+u**4/5
 assert q/p-(1+u)/2==u*(5-18*u*u-3*u**4)/(30*D)
# Pointwise failure control: south-pole target has positive acceptance and zero fidelity.
assert a**4>0 and Q(0)<baseline
print(json.dumps({'status':'passed','delta':'1/2','copies':4,'success_probability':str(s),'numerator':str(N),'conditional_fidelity':str(F),'baseline':str(baseline),'critical_inequality':f'{F} > {baseline}','fidelity_gain':str(F-baseline),'unnormalized_gain':str(N-baseline*s),'source_S25_Pauli_equations_checked':pauli_rows,'n2_n3_gain_controls':controls,'scope':'success-weighted Haar mean, not pointwise purification'},sort_keys=True))

from fractions import Fraction as Q
from math import comb
import json
# Exact independent expansion of the paired polynomial (x-t)(1+tx)^4+(-x-t)(1-tx)^4.
def poly(t):
 out=[Q(0)]*6
 for sign in(1,-1):
  for k in range(5):
   c=Q(comb(4,k))*(sign*t)**k
   out[k]-=t*c;out[k+1]+=sign*c
 return out
for t in [Q(1,2),Q(1,3),Q(1,10)]:
 assert poly(t)==[-2*t,0,8*t-12*t**3,0,8*t**3-2*t**5,0]
t=Q(1,3);a=(t-6*t**3)/96;b=(4*t**3-t**5)/96
assert b>0
lower=a+b/3;haar=a+b*Q(3,5)
assert lower==Q(29,17496)>0 and haar==Q(1,486)>0
assert Q(2,3)+lower==Q(11693,17496)>Q(2,3)
assert Q(2,3)+haar==Q(325,486)>Q(2,3)
# Alternate spherical-moment computation for the nonsymmetrized Haar gain at t=1/2.
t=Q(1,2);coeff=[Q(comb(4,k))*t**k/32 for k in range(5)]
gain=sum(c/Q(k+2)for k,c in enumerate(coeff)if k%2==1)-t*sum(c/Q(k+1)for k,c in enumerate(coeff)if k%2==0)
assert gain==Q(1,3072)>0
assert Q(3,4)+gain==Q(2305,3072)>Q(3,4)
# Instrument completeness: first-four Pauli outcome projectors sumI; success+failure exhaust16 outcomes.
assert sum(1 for outcome in range(16) if outcome==0)+sum(1 for outcome in range(16) if outcome!=0)==16
print(json.dumps({'status':'passed','copies':5,'success_probability_on_every_input':'1','delta_pointwise':'2/3','pointwise_gain_lower_bound':str(lower),'pointwise_fidelity_lower_bound':'11693/17496','pointwise_comparator':'11693/17496 > 2/3','haar_gain_at_delta_2_over_3':str(haar),'haar_fidelity_at_delta_2_over_3':'325/486','haar_comparator_at_delta_2_over_3':'325/486 > 2/3','fixed_Z_delta_half_fidelity':'2305/3072','fixed_Z_delta_half_comparator':'2305/3072 > 3/4','proof_scope':'Universal r inequality separately follows from S4>=1/3; no numerical grid substitutes for that proof'},sort_keys=True))
