# Primary-source comparison for the frozen v1 manuscript

Cutoff: 2026-11-19. This audit checks mathematical coverage and attribution, not journal acceptance or global first-discovery priority. Public primary sources were read at the relevant theorem/section level; the candidate TeX was read in full. Source excerpts are preserved under `sources/`; existing workspace source files are pinned by `FROZEN-INPUTS.json`.

## Finding

The manuscript's common-marginal extension interface is already known. **Pironio 2014, Lemma 5** is an exact finite-output antecedent, and the three-binary interface is explicit in **Budroni–Cabello 2012, §3.3**. Applying classical finite Helly to that interface gives the present bound directly. Thus the result should be positioned as a short convex-geometric strengthening and its classification consequence, not a new locality framework.

Among the explicit results checked below, no theorem already stating the five-setting bound or the arbitrary-$N$ six-class classification was found. That limited statement is evidence of a difference from the checked sources; it is **not** proof of priority. The standard ingredients imply the result once combined as in the manuscript.

## Closest exact sources

| Primary source and exact location | Result actually used or compared | Coverage judgment |
| --- | --- | --- |
| [Budroni–Cabello, arXiv:1112.5876v2](https://arxiv.org/pdf/1112.5876v2), §§3.3–3.5 | Common Alice-triple extensions; four unobservable Alice joint coordinates. §3.4 obtains a sixteen-setting bound by Fourier–Motzkin elimination; §3.5 gives the general elimination-based finiteness principle. | The compatibility construction and fixed-marginal dimension are inherited. Their stated numerical reduction is 16, not 5. **Reviewer inference:** finite Helly on those four coordinates immediately improves it to 5. No new gluing mechanism should be claimed. |
| [Pironio, “All CHSH polytopes,” arXiv:1402.6914v2](https://arxiv.org/abs/1402.6914v2), Lemma 5 and Theorem 1; [full text](https://arxiv.org/html/1402.6914) | Lemma 5 gives equivalence between a global local joint distribution and one extension per Bob setting with the same full Alice marginal, for finite measurements/outcomes. Theorem 1 classifies all facets when Alice has two binary measurements and Bob arbitrary finite measurements/outcomes. | Exact antecedent for the general-output interface, absent from v1's references. Theorem 1 already covers the $t=2$ binary special case. It does not state the present general formula or the three-binary five-setting conclusion. Its displayed Eq. (9) has an apparent exponent typo ($m-1$ for $n$ Bob factors); the correctly normalized conditional-product proof is independently supplied here. |
| [Jesus–Zambrini Cruzeiro, arXiv:2212.03212v3](https://arxiv.org/html/2212.03212v3), §§II.B–D, IV.B/HTML IV.2, Appendix B.2 | Full conditional probabilities with normalization and no-signalling removed by an injective coordinate chart; no restriction to correlators. §IV.B reports the complete $(6,3,2,2)$ result with the same six nontrivial classes as at $(5,3,2,2)$, and explicitly poses the all-$N\ge5$ conjecture. | Exact target source. The finite complete enumeration is an external input; the conjecture is not a theorem in that paper. Slice sampling alone is distinguished from the completion procedure using PANDA. The candidate's Helly plus facet argument supplies the missing all-$N$ step. |
| [Pironio, “Lifting Bell inequalities,” arXiv:quant-ph/0503179v3](https://arxiv.org/html/quant-ph/0503179v3), §IV.C, Theorem 6 | A genuinely multipartite facet remains a facet under adding a measurement, using the outcome-lifting construction. | Existing source for the forward setting-lifting direction. It does not say that every larger-scenario facet is a lift from five settings. The manuscript's direct binary appendix proves the needed lifting statement independently and also handles the facet-support argument's use. |
| [José Diogo da Costa Jesus, MSc thesis (2022)](https://fenix.tecnico.ulisboa.pt/downloadFile/1970719973970056/Thesis_JJ.pdf), §5.4, Table 5.4, Table A.4 | *Semi-device Independent Protocols for Quantum Key Distribution*, Master of Science in Engineering Physics, December 2022. The five-by-three finite classes, orbit counts, and exact representative coefficient arrays are explicit. Table A.4 is on printed page 74, PDF page 90. | A directly readable source for the six coefficient vectors and $I_{5322}$ identity. It is by one of the enumeration-paper authors, so it is not an independent second enumeration. The separate reviewer orbit check validates these representatives, not their completeness. |

## Equivalent formulations

For binary outcomes the candidate's coordinates are
\[
(A_i,B_j,C_{ij})\in\operatorname{conv}\{(a_i,b_j,a_i b_j):a_i,b_j\in\{0,1\}\}.
\]
This is exactly the bipartite Boolean quadric polytope $\operatorname{BQP}^{3,N}$. With an additional anchor vertex 0, the covariance map
\[
x_{0i}=A_i,\quad x_{0j}=B_j,\quad x_{ij}=A_i+B_j-2C_{ij}
\]
identifies it with $\operatorname{CUT}(K_{1,3,N})$. A correlator-only polytope obtained by dropping $A,B$ is a different projection; results about that projection cannot establish the present full-probability claim.

| Primary source checked | Exact comparison and limitation |
| --- | --- |
| [Avis–Imai–Ito–Sasaki, “Two-party Bell inequalities derived from combinatorics via triangular elimination”](https://cgm.cs.mcgill.ca/~avis/doc/avis/AIIS05a.pdf), §2.1.1, Theorem 2.1, §3.5 | Gives the covariance equivalence and facet-preserving triangular elimination, with its stated exceptions. §3.5 explicitly notes missing three-by-four facet classes. It is a facet-generation theorem, not a complete $\operatorname{CUT}(K_{1,3,N})$ classification or a five-setting converse. |
| [Sripratak–Punnen–Stephen, “The Bipartite Boolean Quadric Polytope”](https://www.sfu.ca/~tstephen/Papers/bbqp.pdf), Theorem 3.4, Proposition 3.7/Corollary 3.8, Proposition 3.10 | The coordinate object is the same BQP. The full dimension and trivial-facet relaxation are distinguished from the integer hull. Cycle facets reduce to four-cycles in the complete bipartite graph; Proposition 3.10 supplies the complete $2\times2$ nontrivial list. The checked claims do not classify $\operatorname{BQP}^{3,N}$. |
| [Bärmann–Martin–Schneider, 2020 public manuscript](https://optimization-online.org/wp-content/uploads/2020/09/8033.pdf), Proposition 2.4, Theorem 3.5 and Corollary 3.6 | Proposition 2.4 supplies zero-lifting with a fixed left shore. The complete convex-hull theorem applies to subset-uniform graphs with cycle-free dependency graph; the corollary covers one multiple-choice block. Ordinary BQP corresponds to singleton blocks, whose dependency graph is $K_{3,N}$, containing cycles for $N\ge2$. Combining all three Alice bits into one at-most-one block would change the feasible set. These results therefore do not cover the target. Numbering here is the linked 2020 version. |
| [Kaparis–Letchford–Mourtos, “On Cut Polytopes and Graph Minors”](https://www.lancaster.ac.uk/staff/letchfoa/articles/max-cut-minors.pdf), Definition 1, Lemmas 4–5, Theorem 2, §4.3 | Studies projections of complete-graph relaxations generated by inequalities on at most five **graph vertices**. This is different from support on five Bob measurements. Lemma 4 handles four-vertex-coverable graphs only up to eight vertices; Theorem 2 handles $G_{12}$-minor-free graphs. §4.3 retains a broader conjecture. None of these statements is the required all-$N$ Bell facet classification. No unproved vertex-cover extension was imported. |
| [Staufenbiel, arXiv:2604.22859v1](https://arxiv.org/html/2604.22859v1), §5.1/Table 1 and methodological scope | Uses $(5,3,2,2)$'s seven total classes as a finite known benchmark. The angle-based search trades completeness for speed. This is not an additional completeness proof and supplies no all-$N$ support theorem. |

## Search scope and unresolved priority

Search families included Bell/Helly/locality; three binary measurements and arbitrary settings; $2^s-s$ setting bounds; $I_{5322}$ coefficient sources; the exact Jesus–Zambrini Cruzeiro conjecture; cut polytopes $K_{1,3,N}$; bipartite Boolean quadric facets; fixed-marginal extensions; and Helly-type marginal compatibility. Primary papers, their linked original versions, and source statements were checked rather than relying on search-result claims.

Search results mixing Bell locality with the unrelated integer Helly theorem of Doignon–Bell–Scarf were excluded. Other-workspace research conclusions, AI review labels on public aggregate pages, and unreviewed solution scores were not used as evidence. The publisher's supplementary-file endpoint for the finite enumeration was not successfully retrieved. The article's full-probability complete-enumeration statements and the thesis's coefficient tables were available. No local reconstruction of a complete PANDA enumeration is claimed.

The strongest supported novelty description is: **a Helly application to an existing marginal-compatibility formulation gives the stated bound; paired with an existing finite classification, it proves the precise all-$N$ conjecture from the checked 2023 source.** An assertion that this is the first ever such observation would require further evidence. The mathematical conclusion does not depend on establishing priority.

## Source-to-claim separation

- **Known results:** deterministic local-polytope representation; compatibility/gluing interface; standard finite Helly; binary setting lifting; finite five-setting facets and their names.
- **Manuscript deduction independently checked here:** the formula $t=\prod_xa_x-\sum_x(a_x-1)$; facet support at most $t$; the all-$N$ consequence; the explicit rational sharpness table and its local deletion models.
- **Reviewer controls:** exact probability reconstruction, mixed-output zero-mass gluing, source-facet ranks/orbits, and the exact $I_{5322}$ relabeling.
- **Still unconfirmed:** global priority, external expert acceptance, and an independent complete re-enumeration of the finite base polytope.

No source discovered in this audit refutes the mathematics. The missing Pironio 2014 attribution is a necessary correction before release; it does not turn the new bound into a false statement.

