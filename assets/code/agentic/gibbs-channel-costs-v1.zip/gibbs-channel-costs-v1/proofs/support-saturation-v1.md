# Saturating a Kraus-support face with finite exact coherence resources

24 November 2026. Same-root proof candidate. This is a new analytic route
beyond the retired finite-box rank-three SDP search. No independent review
or priority claim. It supplies a sufficient structural criterion and, with
the separate rank-two analysis, a full qubit finiteness classification.
It does not determine the optimal QFI value in every finite case.

Let K_1,...,K_r be linearly independent operators A->B spanning a Kraus
support S. In a fixed energy-group coordinate system write

    L_x(C)=sum_(alpha,lambda) C_(alpha,lambda)
            K_alpha* B(x) K_lambda,
    B(x)=sum_j x^(b_j) Q_j,  A(x)=sum_i x^(a_i) P_i.

The finite exact-sector criterion asks for scalar p with nonnegative
coefficients and Hermitian matrix C with PSD coefficients satisfying
L_x(C)=p A(x), p(1)=1, and C(1) equal to the desired positive Choi
coefficient matrix. Transposes in the Choi representation do not affect
positivity or support. Common monomial shifts can make all polynomials
ordinary. Arbitrary energy-gap rational rank is allowed.

## The support-saturation theorem

Assume:

1. L_1:Herm(r)->Herm(d_A) is onto.
2. At least one channel with Kraus support exactly S has a finite exact
   coherence-resource implementation. In this basis its sector witness
   (p0,C0) has p0(1)=1, C0(1)>0 and L_1(C0(1))=I_A.

Then EVERY channel with Kraus support exactly S has a finite exact
coherence-resource implementation, for these same input/output Hamiltonians.
Equivalently, for every T>0 with L_1(T)=I_A, there is a finite positive
polynomial sector witness normalized by C(1)=T.

This does not say that all channels on the boundary of this face are
implementable: positivity of T is strict. It also does not assert any
uniform bound on the resource size as T approaches a smaller support.

### A. Compactification and a polynomial kernel extension

Put t_i=x_i/(1+x_i), so x=1 corresponds to t0=(1/2,...,1/2).
Let D_i bound the degree of C0 in variable x_i and set

    Cbar(t)=product_i (1-t_i)^(D_i) C0(t/(1-t)).

Cbar has PSD Bernstein coefficients on the cube: its monomial coefficients
in x become positive multiples of Bernstein basis coefficients. Its value
C*=Cbar(t0) is positive definite. Clear denominators similarly in L_x to
obtain a polynomial linear map Lbar_t. It is onto at t0, since only a
nonzero scalar factor has been introduced.

Let T*=2^(-sum D_i)T and Delta=T*-C*. Then Lbar_(t0)(Delta)=0.
There is a Hermitian polynomial matrix H0(t) with

    Lbar_t(H0(t))=0 identically, H0(t0)=Delta.           (1)

For an explicit algebraic construction, select an invertible full-row-rank
minor of Lbar at t0. It gives a rational right inverse R(t), regular there.
Then Delta-R(t)Lbar_t(Delta) lies identically in the kernel and equals Delta
at t0. Multiply by the minor determinant to clear denominators, and divide
by its nonzero value at t0. Use real coordinates on Hermitian matrices, so
H0 remains Hermitian on the real cube. No global rank assumption is needed.

### B. Extract almost all of the central positive matrix in a Bernstein bump

Choose 0<delta<1 so that T*-2 delta C*>0, and put Q=(1-delta)C*>0.
By continuity there is a small product neighborhood U of t0, inside the
cube, where Cbar(t)-Q is uniformly positive definite.

Degree-elevate Cbar to degree N in every variable. Its coefficients remain
PSD, and, uniformly in grid index k, converge to Cbar(k/N). For sufficiently
large N, every coefficient whose k/N lies in U remains PSD after subtracting
Q. Let g_N be the sum of the corresponding scalar Bernstein basis functions.
It has nonnegative Bernstein coefficients, takes values in [0,1], and

    Cbar=A_N+g_N Q,

where A_N has PSD Bernstein coefficients. Also g_N(t0)->1: it is the
probability that independent Binomial(N,1/2) coordinates lie in the fixed
central product window. Choose N large enough that

    Q+H0(t0)/g_N(t0)>0.                               (2)

This is possible because its limit is T*-delta C*>0.

### C. Localize the kernel correction and recover coefficient positivity

Set H=H0/g_N(t0). By (2), Q+H is positive definite in a neighborhood V of t0.
Use the scalar polynomial bump

    b_M(t)=product_i [4t_i(1-t_i)]^M.

It satisfies 0<=b_M<=1, b_M(t0)=1, and tends uniformly to zero on the
complement of V as M grows. On V, Q+b_M H is a convex combination of
Q and Q+H and is positive definite. Outside V, boundedness of H and small
b_M make it positive definite too. Thus

    P(t)=Q+b_M(t)H(t)>0

uniformly on the closed cube for sufficiently large M. Degree elevation
of this fixed strictly-positive matrix polynomial yields positive definite
Bernstein coefficients. This is the elementary matrix Bernstein argument:
coefficient matrices converge uniformly in norm to their sampled values,
whose smallest eigenvalue has a fixed positive lower bound.

Now define

    Cbar_new=A_N+g_N P=Cbar+g_N b_M H.

Both summands have PSD Bernstein coefficients after putting them at a
common degree, because products of a nonnegative scalar Bernstein
polynomial and a PSD matrix Bernstein polynomial have PSD coefficients.
Equation (1) implies Lbar(Cbar_new)=Lbar(Cbar) identically. At t0,
Cbar_new(t0)=C*+Delta=T*.

Finally choose coordinate degrees E_i>=D_i for Cbar_new and decompactify:

    C_new(x)=product_i (1+x_i)^(E_i) Cbar_new(x/(1+x)),
    p_new(x)=p0(x) product_i (1+x_i)^(E_i-D_i).

C_new has PSD ordinary coefficients and p_new has nonnegative coefficients.
Their sector equation is unchanged, and C_new(1)=p_new(1)T. Normalize by
p_new(1). This proves the theorem with finite polynomials, hence a finite
resource and an exactly conserving finite completion.

## Every Choi-corank-one channel has finite exact coherence cost

Suppose d_A,d_B>=2 and S is a hyperplane in the operator space:
S={K:Tr(M* K)=0}, for a fixed nonzero d_B-by-d_A matrix M.
Both assumptions of the support-saturation theorem hold.

### Surjectivity of L_1

If a Hermitian X annihilates its range, then

    Tr(X K* L)=0 for all K,L in S.

Thus right multiplication by X maps S into the one-dimensional space
S-perp. If rank(X)=k>=2, the restriction of this multiplication to S has
rank at least d_B k-1>=3, a contradiction. If rank(X)=1, X is semidefinite,
and Tr(X K*K)=0 forces K to annihilate its nonzero eigenvector for every K
in S. That subspace has dimension d_B(d_A-1)<d_A d_B-1. Again impossible.
Hence X=0 and L_1 is onto.

### A finite exact entanglement-breaking channel with full support S

For each pure input vector psi, a nonzero output vector v exists with
< M psi,v>=0, since d_B>=2. Thus the rank-one operator |v><psi| belongs
to S. Moreover these rank-one operators span S. One algebraic proof is to
show that any N orthogonal to all of them satisfies N psi parallel to
M psi for every psi (and N psi=0 when M psi=0). Linearity then forces
N to be a scalar multiple of M, including the rank-one M case. Hence the
orthogonal complement of their span is exactly span(M).

Select finitely many rank-one |v_l><psi_l| spanning S. There is a finite,
exact, covariantly implementable rank-one POVM containing each desired
input ray psi_l with some positive coefficient. For each desired ray,
append a finite resource in the conjugate state on a system with Hamiltonian
-H_A, and measure the invariant maximally entangled projector on A tensor
that system. This has a nonzero rank-one POVM effect proportional to
|psi_l><psi_l|. Complete that projector to a rank-one projective measurement
inside each total-energy eigenspace. For a pure initial resource every
outcome induces a rank-one effect or zero on the input. Mix these finitely
many measurements using a finite classical zero-energy flag. Such flags
and all measurement blanks belong to the resource, not to the free bath.

For every nonzero POVM effect c_j|psi_j><psi_j|, choose a normalized output
v_j perpendicular to M psi_j, assigning the selected v_l to the designated
outcomes. Store these finitely many output states in resource registers
with Hamiltonian H_B; following the energy-invariant measurement, route
the designated output register by controlled swaps. The resulting
measure-and-prepare channel has Kraus operators sqrt(c_j)|v_j><psi_j|,
all in S, and their span is S. Every step has a finite thermal realization
with the explicitly supplied resource; its QFI is finite. Therefore its
sector witness has C0(1)>0.

The support-saturation theorem now proves finite exact coherence for every
channel whose Choi matrix has corank one, for arbitrary finite Hamiltonians.
This assertion is about finiteness, not an optimal QFI formula or efficiency.

## Consequence for the qubit classification

Every qubit channel has Choi rank 1,2,3 or 4. Rank 3 is the hyperplane case
above. Rank 4 is already covered by the known interior-channel finite
coherence argument; alternatively the same saturation theorem applies to
the full operator space, using an energy-measure-and-prepare full-support
channel as the base. Ranks 1 and 2 are treated in
`qubit-rank-two-classification-v1.md` under Gibbs preservation.
Thus these results together give a complete finite-versus-infinite exact
coherence classification for qubit GP channels. They still do not close
Q117's arbitrary-dimensional classification or its tight values at all errors.

## Review points

The proof uses a real polynomial kernel extension and two different
Bernstein bumps. A single coefficient extraction would provide only a small
local perturbation and would not prove saturation; the central-window sum
g_N, whose value tends to one at t0, is essential. The positivity argument
must be on the entire compact cube, not just the physical temperature ray.
All ancillas used in the base channel are charged as coherence resources;
this construction is not a zero-work implementation.
