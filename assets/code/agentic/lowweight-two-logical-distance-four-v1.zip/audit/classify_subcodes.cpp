// Exact finite enumeration relative to the published self-dual classification.
// No floating arithmetic and no purity assumption. A prefix is not a converse.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
static int pc(unsigned x){return __builtin_popcount(x);}
static bool addbasis(unsigned x,array<unsigned,16>&b){while(x){int i=31-__builtin_clz(x);if(b[i])x^=b[i];else{b[i]=x;return true;}}return false;}
static vector<string> split(const string&s,char c){vector<string>o;stringstream t(s);string a;while(getline(t,a,c))o.push_back(a);return o;}
static string pauli(unsigned x,unsigned z,int n){string s;for(int i=0;i<n;i++)s+="IXZY"[((x>>i)&1)+2*((z>>i)&1)];return s;}
int main(int argc,char**argv){
 if(argc<5){cerr<<"n cap infile outfile [type_filter=0] [start=0] [limit=0]\n";return 2;}
 int n=stoi(argv[1]),cap=stoi(argv[2]),filter=argc>5?stoi(argv[5]):0;long start=argc>6?stol(argv[6]):0,limit=argc>7?stol(argv[7]):0;
 if(n>12||n<2)throw runtime_error("unsupported length");unsigned M=1u<<n;int target=n-2;
 ifstream in(argv[3]);if(!in)throw runtime_error("input missing");ofstream out(argv[4]);if(!out)throw runtime_error("output inaccessible");
 long inputrows=0,processed=0,lowrank_pruned=0,short_rank_pruned=0,zero_holes=0,planes=0,maxholes=0,candidates=0;bool found=false;string witness;auto begin=chrono::steady_clock::now();string line;
 while(getline(in,line)){
  long ordinal=inputrows++;if(ordinal<start)continue;if(limit&&ordinal>=start+limit)break;
  auto a=split(line,'\t');if(a.size()!=5)throw runtime_error("bad row");int type=stoi(a[4]);if(filter&&type!=filter)continue;string g=a[1];if((unsigned char)g[0]-63!=n||g.size()!=1+(n*(n-1)/2+5)/6)throw runtime_error("graph6 header");
  array<unsigned,12> adj{};int bit=0;for(int j=1;j<n;j++)for(int i=0;i<j;i++,bit++)if(((unsigned char)g[1+bit/6]-63)>>(5-bit%6)&1){adj[i]|=1u<<j;adj[j]|=1u<<i;}
  vector<unsigned> z(M),lo;lo.reserve(400);array<int,13>enumerator{};array<unsigned,16>b3{},bw{};int r3=0,rw=0;
  for(unsigned t=0;t<M;t++){
   if(t){int j=__builtin_ctz(t);z[t]=z[t^(1u<<j)]^adj[j];}
   int w=pc(t|z[t]);enumerator[w]++;
   if(t&&w<=3)r3+=addbasis(t,b3);
   if(t&&w<=cap){lo.push_back(t);rw+=addbasis(t,bw);}
  }
  auto counts=split(a[2],',');if((int)counts.size()!=n+1)throw runtime_error("enumerator length");for(int i=0;i<=n;i++)if(stoi(counts[i])!=enumerator[i])throw runtime_error("source enumerator mismatch row "+a[0]);
  processed++;
  if(r3>target){short_rank_pruned++;continue;}
  if(rw<target){lowrank_pruned++;continue;}
  array<array<unsigned,3>,12>single{};array<bool,4096>bad{},ok{};
  for(int i=0;i<n;i++){single[i]={1u<<i,adj[i],(1u<<i)^adj[i]};for(auto x:single[i])bad[x]=true;}
  for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)for(auto x:single[i])for(auto y:single[j]){
   bad[x^y]=true;for(int k=j+1;k<n;k++)for(auto zz:single[k])bad[x^y^zz]=true;
  }
  vector<unsigned>holes;for(unsigned u=1;u<M;u++)if(!bad[u]){
   bool good=true;for(auto t:b3)if(pc(t&u)&1){good=false;break;}if(good){holes.push_back(u);ok[u]=true;}
  }
  maxholes=max(maxholes,(long)holes.size());if(holes.size()<3){zero_holes++;continue;}
  for(size_t i=0;i<holes.size()&&!found;i++)for(size_t j=i+1;j<holes.size()&&!found;j++){
   unsigned u=holes[i],v=holes[j],w=u^v;if(w<=v||!ok[w])continue;planes++;
   array<unsigned,16>bs{};vector<unsigned>basis;for(auto t:lo)if(!(pc(t&u)&1)&&!(pc(t&v)&1)&&addbasis(t,bs)){basis.push_back(t);if((int)basis.size()==target)break;}
   if((int)basis.size()==target){
    found=true;candidates++;ostringstream ws;ws<<"{\"source_row\":"<<a[0]<<",\"ordinal\":"<<ordinal<<",\"u\":"<<u<<",\"v\":"<<v<<",\"generators\":[";
    for(size_t k=0;k<basis.size();k++){if(k)ws<<",";ws<<"\""<<pauli(basis[k],z[basis[k]],n)<<"\"";}ws<<"]}";witness=ws.str();
   }
  }
  if(processed%1000==0)cerr<<"rows "<<processed<<" ordinal "<<ordinal<<" planes "<<planes<<" holes_max "<<maxholes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<"\n";
  if(found)break;
 }
 bool exhausted=!found&&in.eof();out<<"{\n\"n\":"<<n<<",\"cap\":"<<cap<<",\"type_filter\":"<<filter<<",\"start\":"<<start<<",\"limit\":"<<limit<<",\"input_rows_visited\":"<<inputrows<<",\"processed\":"<<processed<<",\"enumerator_checks_passed\":"<<processed<<",\"short_rank_pruned\":"<<short_rank_pruned<<",\"low_rank_pruned\":"<<lowrank_pruned<<",\"too_few_holes\":"<<zero_holes<<",\"planes_examined\":"<<planes<<",\"max_holes\":"<<maxholes<<",\"found\":"<<(found?"true":"false")<<",\"source_exhausted\":"<<(exhausted?"true":"false")<<",\"witness\":"<<(found?witness:"null")<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<"\n}\n";out.close();cout<<"found="<<found<<" source_exhausted="<<exhausted<<" processed="<<processed<<" planes="<<planes<<"\n";
}
