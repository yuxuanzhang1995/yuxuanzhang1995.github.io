import sympy as s
# A common phase rotation makes x=r>0; y=u+iv retains every relative phase.
P,Q,r,u,v,B=s.symbols('P Q r u v B', real=True)
a=r*r; Y=u*u+v*v; b=B+Y; p=P*P; q=Q*Q
x=r; y=u+s.I*v; R=r*u
conj=s.conjugate
h=P*x+Q*y
j=-P*x*(a/2+2*q*b)-2*p*Q*a*y
f=s.sqrt(2)*P*Q*x*y
ell=s.sqrt(2)*P*Q*(P*a*y+Q*b*x)
k=p*a+q*b+2*P*Q*R
k2=-4*p*q*a*b-P*Q*a*R
m=2*p*q*a*b
d=q*B
H=p*q*(2*B*Y+(a+Y)**2-4*R**2)
w=k2+m-k*k-2*s.re(conj(h)*j)-f*conj(f)
def reduce(expr):
    return s.factor(s.rem(s.expand(expr),P*P+Q*Q-1,P))
def check(label,expr):
    val=reduce(expr)
    print(label+': '+str(val)+' == 0')
    assert val == 0
check('leading spectral coefficient',k-h*conj(h)-d)
check('second spectral coefficient',w+d*d-H-q*(B*B-b*b))
D3=k*m-ell*conj(ell)-m*h*conj(h)-k*f*conj(f)+2*s.re(h*ell*conj(f))
check('determinant cubic coefficient',D3)
check('Schur off-diagonal identity',ell-conj(h)*f-s.sqrt(2)*P*Q*Q*B*x)
check('strictness decomposition',H-p*q*(2*B*Y+(a-Y)**2+4*r*r*v*v))
# Exact positive sample with a non-real relative phase, not a numerical proof of generality.
Hsample=s.factor(H.subs({P:s.Rational(3,5),Q:s.Rational(4,5),r:1,u:s.Rational(1,3),v:s.Rational(1,2),B:s.Rational(2,3)}))
print('complex-phase H sample: '+str(Hsample)+' > 0')
assert Hsample > 0
# Rational-log bracket has a positive numerator for D>0 and 0<q<1.
D,qq,ellq=s.symbols('D qq ellq', real=True)
identity=qq/D-qq**2/(D-ellq)-qq*((1-qq)*D-ellq)/(D*(D-ellq))
val=s.factor(identity)
print('rational-log bracket identity: '+str(val)+' == 0')
assert val == 0
print('exact symbolic checks passed')
