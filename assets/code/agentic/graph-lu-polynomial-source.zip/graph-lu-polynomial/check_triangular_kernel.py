"""Targeted exact check of the explicit integer recurrence in Lemma 4.3.

Uses the preceding recheck's HNF and incidence construction. This is a focused
regression check, not an independent end-to-end graph-equivalence verifier.
Run with Python 3 + SymPy, without -O, beside check_recheck.py.
"""
import hashlib
import itertools as it
import json
from pathlib import Path
import time

import sympy
from sympy import Matrix
from check_recheck import closure, hnf, modular_span


def triangular_kernel(H, q):
    m = H.rows
    assert H.cols == m
    for i in range(m):
        assert H[i, i] > 0 and q % H[i, i] == 0
        for j in range(m):
            assert 0 <= H[i, j] <= q
            if j > i:
                assert H[i, j] == 0
            if j < i:
                assert H[i, j] < H[j, j]
    K = sympy.zeros(m)
    for j in range(m):
        for i in range(m):
            numerator = q * (i == j) - sum(H[i, k] * K[k, j] for k in range(i))
            value, remainder = divmod(int(numerator), int(H[i, i]))
            assert remainder == 0
            K[i, j] = value
    assert H * K == K * H == q * sympy.eye(m)
    if m:
        assert K == q * H.inv()
        assert max(abs(x) for x in K) <= q * (1 + q) ** (m - 1)
    return K


def run():
    started = time.time()
    general_count = 0
    nonfree_count = 0
    for entries in it.product(range(4), repeat=4):
        B = Matrix(2, 2, entries)
        H = hnf(B.tolist(), 2, 4)
        K = triangular_kernel(H, 4)
        generators = [tuple(int(K[i, j]) % 4 for i in range(2)) for j in range(2)]
        expected = {s for s in it.product(range(4), repeat=2)
                    if all(sum(int(B[i, j]) * s[j] for j in range(2)) % 4 == 0
                           for i in range(2))}
        assert modular_span(generators, 2, 4) == expected
        nonfree_count += len(expected) in (2, 8)
        general_count += 1
    cases = []
    for t in (4, 5):
        columns = list(it.product((0, 1), repeat=t))
        a = [tuple(v[j] for v in columns) for j in range(t)]
        for r in (1, 2, 3, 4, 8, 32, 128, 256):
            H, steps = closure(a, 1 << t, r)
            K = triangular_kernel(H, 1 << r)
            cases.append(dict(t=t, m=1 << t, r=r, strict_enlargements=steps,
                              largest_kernel_entry_bits=max(abs(int(x)).bit_length() for x in K)))
    for m in (0, 1, 3):
        assert triangular_kernel(8 * sympy.eye(m), 8) == sympy.eye(m)
    return dict(status='pass', arithmetic='exact integers', sympy_version=sympy.__version__,
                general_mod4_matrices=general_count, certified_nonfree_kernels=nonfree_count,
                boolean_pattern_cases=cases, unconstrained_boundaries=3,
                comparison='Integral forward substitution versus rational inverse; exhaustive general mod-4 kernels',
                shared_dependencies=['check_recheck.py: hnf, closure, modular_span'],
                end_to_end_verification=False, human_verified=False,
                seconds=round(time.time() - started, 3),
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())


if __name__ == '__main__':
    result = run()
    Path(__file__).with_name('triangular-kernel-results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
