"""Verify file integrity, then regenerate all ten exact exclusion systems.

This checks the finite certificates. It does not prove that every quantum
code satisfies the relaxation; that analytic step is in the manuscript.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

BOOTSTRAP = r'''
import importlib.abc, pickle, runpy, sys
def no_cache(*args, **kwargs):
    raise RuntimeError("cached or pickled coefficients are forbidden")
pickle.load = pickle.loads = no_cache
def audit(event, args):
    if event in {"socket.connect", "socket.connect_ex", "socket.bind", "socket.getaddrinfo"}:
        raise RuntimeError("network disabled during reproduction")
sys.addaudithook(audit)
class NoOptimizer(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"cvxpy", "clarabel", "mosek", "scs"}:
            raise RuntimeError("optimizer import forbidden during exact checking")
sys.meta_path.insert(0, NoOptimizer())
sys.path.insert(0, ".")
sys.argv = ["certify_dual.py", sys.argv[1], "--verify", "--clean"]
runpy.run_path("certify_dual.py", run_name="__main__")
'''


def main():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for item in manifest["files"]:
        source = (ROOT / item["path"]).resolve()
        if not source.is_relative_to(ROOT):
            raise ValueError("manifest path leaves package")
        actual = hashlib.sha256(source.read_bytes()).hexdigest()
        if actual != item["sha256"]:
            raise ValueError("changed package input: " + item["path"])
    expected = json.loads((ROOT / "expected/certificates.json").read_text())
    files = ["moment3.py", "ppt3.py", "certify_dual.py"] + [
        f"certificate-ppt-n{n}.json" for n in range(9, 19)
    ]
    results = []
    with tempfile.TemporaryDirectory(prefix="symmetric-code-check-") as name:
        clean = Path(name)
        if list(clean.iterdir()):
            raise RuntimeError("reproduction directory was not empty")
        for filename in files:
            shutil.copyfile(ROOT / "checks" / filename, clean / filename)
        for n, target in zip(range(9, 19), expected):
            if target["n"] != n:
                raise ValueError("expected cases are not exactly 9 through 18")
            result = subprocess.run(
                [sys.executable, "-c", BOOTSTRAP, str(n)],
                cwd=clean, text=True, capture_output=True, check=True,
            )
            actual = json.loads((clean / f"check-ppt-n{n}-clean.json").read_text())
            exact = {key: actual[key] for key in target}
            if exact != target:
                raise ValueError(f"exact output differs for n={n}")
            results.append(exact)
            print(f"n={n}: exact certificate passed", flush=True)
    summary = {
        "status": "pass",
        "file_hashes_checked": len(manifest["files"]),
        "lengths_checked": list(range(9, 19)),
        "exact_results": results,
        "coefficient_cache_used": False,
        "optimizer_used": False,
        "scope": "finite certificate reproduction; analytic necessity is a separate proof",
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
