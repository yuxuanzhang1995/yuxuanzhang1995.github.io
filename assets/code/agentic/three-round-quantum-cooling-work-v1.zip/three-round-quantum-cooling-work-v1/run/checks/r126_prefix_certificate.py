from pathlib import Path
from decimal import ROUND_FLOOR,ROUND_CEILING
import collections,json,time,numpy as np
from p11_rational_quantum_certificate_common import I,D,q,p,bath,E
S=2**40
def lo(x,scale=S):return int((x*scale).a.to_integral_value(rounding=ROUND_FLOOR))
def hi(x,scale=S):return int((x*scale).b.to_integral_value(rounding=ROUND_CEILING))
if __name__=='__main__':
 start=time.time();data=json.loads(Path('run/checks/r125_first_stage.result.json').read_text());store=np.load('run/checks/r125_first_stage_states.npz');N=store['coefficients'];pid=store['profile_ids'];lam=store['suffix_lambdas'];y=[I(str(x)) for x in data['price']];Zs=1+q+q*q;Zsm=Zs*(1+q);basis=[q**k/(Zsm*Zs) for k in range(6)];bl=[lo(a) for a in basis];bh=[hi(a) for a in basis];bb=[a*b for a in bath for b in bath];bbl=[lo(a) for a in bb];bbh=[hi(a) for a in bb];eb=sum(r*bath[r] for r in range(3));yp=sum(a*b for a,b in zip(y,p));costcoef=[];costs=[]
 for rec in data['profiles']:
  w=[0]*4
  for i,e in enumerate(E):w[rec['profile'][i]]+=e;w[e]-=e
  c=np.convolve(w,[1,1,1]).astype(int).tolist();costcoef.append(c);costs.append(sum(int(v)*a for v,a in zip(c,basis)))
 cached={};bounds=[];survivors=[]
 for ix,arr in enumerate(N):
  a=int(pid[ix]);l=str(lam[ix]);key=(a,l)
  if key not in cached:
   z=I(l);assert 0<=z.a<=z.b<=1;h=sorted(hi(y[s]-z*(E[s]+r+t)) for s in range(6) for r in range(3) for t in range(3));constant=hi(2*z*eb-costs[a]-yp,S*S);cached[key]=(h,hi(z),constant)
  obs,lh,const=cached[key];rl=[sum(int(v)*x for v,x in zip(row,bl)) for row in arr];rh=[sum(int(v)*x for v,x in zip(row,bh)) for row in arr];sl=sorted(a*b//S for a in rl for b in bbl);sh=sorted((a*b+S-1)//S for a in rh for b in bbh);v=sum((b if h>=0 else a)*h for a,b,h in zip(sl,sh,obs))+lh*sum(e*r for e,r in zip(E,rh))+const;bounds.append(str(v))
  if v>=0:survivors.append(ix)
 groups=collections.defaultdict(list)
 for i in survivors:groups[tuple(sorted(tuple(int(v) for v in row) for row in N[i]))].append(i)
 def cphi(i):
  c=np.array(costcoef[int(pid[i])],dtype=int);return c,c-np.array(E)@N[i].astype(int)
 polys={i:cphi(i) for i in survivors}
 def nonpositive(v):return not np.any(v) or sum(int(x)*b for x,b in zip(v,basis)).b<0
 def dominates(a,b):return all(nonpositive(x-y) for x,y in zip(polys[a],polys[b]))
 kept=[];mapping=[]
 for ids in groups.values():
  alive=[]
  for i in ids:
   if any(dominates(j,i) for j in alive):continue
   alive=[j for j in alive if not dominates(i,j)];alive.append(i)
  kept+=alive
  for i in ids:
   j=next(j for j in alive if dominates(j,i));sources=collections.defaultdict(list)
   for k,row in enumerate(N[j]):sources[tuple(row)].append(k)
   P=[-1]*6
   for dest,row in enumerate(N[i]):P[sources[tuple(row)].pop()]=dest
   mapping.append(dict(state=i,representative=j,input_permutation=P))
 np.savez_compressed('run/checks/r126_suffix_bound_numerators.npz',upper_numerators=np.array(bounds),survivors=np.array(survivors),representatives=np.array(kept))
 neg=[int(v) for v in bounds if int(v)<0];out=dict(scale=S,states=len(N),certified_negative=len(N)-len(survivors),largest_negative_upper_numerator=max(neg),survivors=len(survivors),spectrum_classes=len(groups),representatives=kept,dominance_mapping=mapping,seconds=time.time()-start,scope='all excluded states have strictly negative quantum-suffix pricing upper at the fixed price; retained spectra reduced by exact cost/energy dominance, not solved');Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='dominance_mapping'},indent=2))
