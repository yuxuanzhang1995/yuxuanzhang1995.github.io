"""Replay finite diagnostics without modifying the source package or using the network."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "MANIFEST.json").read_text())
for item in manifest["files"]:
    data = (ROOT / item["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item["sha256"], item["path"]

with tempfile.TemporaryDirectory(prefix="nonhermitian-checks-") as folder:
    target = Path(folder) / "checks.py"
    shutil.copyfile(ROOT / "checks.py", target)
    subprocess.run([sys.executable, str(target)], check=True, cwd=folder)
    actual = json.loads((Path(folder) / "checks.json").read_text())
    expected = json.loads((ROOT / "expected/checks.json").read_text())
    assert actual["summary"] == expected["summary"]
    assert all(item["caught"] for item in actual["mutations"])
    assert len(actual["derivative_cases"]) == 12
    assert sum(len(row["derivative_errors"]) for row in actual["derivative_cases"]) == 24
    assert len(actual["stationary_diagnostics"]) == 2
    assert all(row["global_optimum_certified"] is False for row in actual["stationary_diagnostics"])
    maximum = max(err["absolute_error"] for row in actual["derivative_cases"]
                  for err in row["derivative_errors"])
    print(json.dumps({"manifest_files_verified": len(manifest["files"]),
                      "max_gradient_discrepancy": maximum,
                      "summary": actual["summary"],
                      "scope": "finite diagnostics only; not an all-dimension proof certificate"}, indent=2))
