# Scalar compressions and asymptotically optimal tough error models

Review version 1.0, 13 November 2026.

The manuscript gives a complete proof candidate for the asymptotically
matching-bounds option of the tough-error-model problem, together with
explicit nearly worst-case error spaces. The review is internal and
sequential. Independent proof review and comprehensive priority assessment
remain outstanding. This package is a website release, not a journal or
catalog acceptance.

## Contents

- main.tex: full manuscript, with an inline bibliography.
- manuscript.pdf: the approved seven-page review draft, unchanged.
- check_variational_identity.py: exact local rotation-derivative checks.
- check_block_models.py: exact finite block-model and hypothesis controls.
- reproduce.py: verifies package hashes and runs the two checkers in fresh
  temporary directories. Needs Python 3 and SymPy; no network is used.
- review.json: exact scope, author-side review and source comparison.
- MANIFEST.json: SHA-256 values of the fixed package files.

Run the finite checks with:

    python3 reproduce.py

To compile the manuscript with a standard LaTeX installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The theorem is an analytic existence statement. The scripts verify local
identities and finite construction cases, not every matrix dimension.
The block checker also includes explicitly marked normalized-channel
controls; these do not change the manuscript's arbitrary-error-space model.
No floating-point optimization is used as a proof.

For all 1 <= e <= n^2, the result is

    max(1, floor((n+1)/(e^2+1))) <= c(e,n) <= ceil(n/(e^2+1)).

The endpoints differ by at most one, and the upper bound has an explicit
construction. The relative asymptotic statement requires n/(e^2+1) to
diverge. Some exact finite values, including c(2,6), remain undetermined.

Original problem:
https://qiqc-op.com/problem/op_b1b41f737f9b4aeb/

Background and closest comparison are cited in the manuscript: Krueger--
Werner; Knill--Laflamme--Viola; Weaver; Allen--Kornell; Li--Tam; Reimpell;
Choi--Kribs--Zyczkowski; and recent Pauli-compression geometry papers.
The frame and block obstruction are inherited. The proposed contribution
is the general variational scalar-compression lower bound.

No author or affiliation has been added to the approved manuscript during
this release. AI-assisted derivation, literature work, computation and
drafting were carried out under human direction. The same agent conducted
the current internal proof review.
