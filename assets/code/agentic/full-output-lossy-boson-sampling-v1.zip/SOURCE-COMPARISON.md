# P60 version 1.0: original scope and source comparison

Checked 31 October 2026. This record supports a specific comparison, not an exhaustive global-priority claim.

| Item | Checked source and location | Relationship to the manuscript |
| --- | --- | --- |
| Original statement | Supplied immutable `questions/P60.json`; [public statement](https://qiqc-op.com/problem/op_d436ff9fb9cb0ce5/), equations (1)–(2) and following runtime question | The target law, fixed rational transmission, every m≥n, complete Fock outcomes, Haar-average TV criterion, polynomial accuracy dependence and input-precision allowance agree. P60 is the package ID; the public stable ID is `op_d436ff9fb9cb0ce5`. |
| Representation decomposition | Arienzo–Grinko–Kliesch–Heinrich, [arXiv:2408.11111v2](https://arxiv.org/html/2408.11111v2), Lemma T1 / Proposition B2 | Imported multiplicity-free operator sectors and dimensions; not a new result of this manuscript. |
| Number-measurement frame | Same source, Lemma T3 / Theorem T4, equation (11) | Imported eigenvalue, reconciled to 1/(D_l+D_{l−1}) in the manuscript. |
| Algorithmic framework | Go–Jeong, [arXiv:2610.27065v1](https://arxiv.org/html/2610.27065v1), Section VII, Lemma 8 and Appendix B | Color coding, inverse determinants and signed marginal sampling have prior sources. The manuscript supplies a self-contained signed-prefix proof and attributes the framework. |
| Closest full-output guarantee | Go–Jeong, Section IX, Corollary 4; Section X uniform-transmission extension | Their full-output comparison uses the dilute-mode restriction and an additional birthday-bound condition. In fixed-loss notation these include M≥C₀ n_surv² N and M≥C_B n_surv²/(εδ). These conditions do not cover all m≥n in the supplied question. |
| Explicit remaining direction | Go–Jeong, Section XI | Saturated-mode full Fock-output simulation is identified as a further direction. This supports the exact scope distinction used in the introduction and website summary. |

The candidate combines the exact Haar harmonic tail, collision-support enumeration and a two-projection prefix identity. The paper does not claim that general constant-loss simulation, harmonic representation theory, or color coding was invented here. Different average and high-probability guarantees are not silently identified.

The public catalog is used for the statement and identifier, not as evidence that the result is new or accepted. No progress report has been submitted and no catalog status has been changed.

The source versions and needed interfaces are unchanged from the targeted proof review. The preparation checked bibliographic metadata and the precise nearest-source restrictions; it did not repeat a broad, unchanged literature search merely to generate more activity. Independent expert review and worldwide priority remain unresolved.
