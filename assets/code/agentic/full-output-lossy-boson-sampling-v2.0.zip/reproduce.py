"""Offline finite checks for the v2.0 supplement; optional full Haar replay."""
from pathlib import Path
import argparse,csv,hashlib,json,os,subprocess,sys,time

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--haar',action='store_true',help='also rerun both full recorded Haar grids (substantially slower)');a=ap.parse_args()
    root=Path(__file__).resolve().parent;out=root/'results';out.mkdir(exist_ok=True)
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for row in manifest['files']:
        p=(root/row['path']).resolve()
        assert p.is_relative_to(root),row['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env.setdefault('MPLCONFIGDIR',str(out/'matplotlib-cache'));env.setdefault('OPENBLAS_NUM_THREADS','1')
    logs=[]
    def run(script,*args):
        start=time.monotonic();r=subprocess.run([sys.executable,str(root/script),*args],cwd=root,env=env,text=True,capture_output=True)
        (out/(Path(script).stem+'.log')).write_text(r.stdout+r.stderr)
        if r.returncode:raise RuntimeError(f'{script} failed: '+r.stdout[-2000:]+r.stderr[-2000:])
        logs.append({'script':script,'seconds':time.monotonic()-start,'status':'pass'})
        print(script+': pass',flush=True)
    for script in ['checks/exact_checks.py','code/pair_spectrum.py','code/verify_identities.py','code/gaussian_prefix.py','code/check_bottlenecks.py','code/check_precision.py','code/check_parameters.py','code/check_extensions.py']:run(script)
    def read(name):return json.loads((out/name).read_text())
    fock=read('exact-results.json');ref=json.loads((root/'checks/reference-results.json').read_text())
    for k,v in ref.items():assert fock[k]==v,k
    pair=read('E01-checks.json');ratio=read('E02-checks.json');prefix=read('E03-prefix-checks.json');bottle=read('bottleneck-checks.json');precision=read('precision-checks.json')
    assert pair['exact_reduction_checks']==990 and len(pair['finite_controls'])==28
    assert ratio==json.loads((root/'reference/gaussian/E02-checks.json').read_text())
    assert len(prefix['cases'])==7 and prefix['mutations_detected']==json.loads((root/'reference/gaussian/E03-prefix-checks.json').read_text())['mutations_detected']
    assert bottle['symbolic_identities']==3 and len(bottle['prefix_controls'])==3 and precision['exact_cases']==9
    assert read('parameter-checks.json')['exact_parameter_cases']==72
    # Data integrity and independently recomputed summary statistics; no new Haar draws.
    with (root/'reference/gaussian/E04-haar.csv').open() as f:rows=list(csv.DictReader(f))
    import numpy as np
    groups={};unique=set()
    for row in rows:
        key=tuple(float(row[x]) for x in ['m','N','eta','r']);groups.setdefault(key,[]).append(row);unique.add((row['m'],row['N'],row['draw']))
    assert len(rows)==6528 and len(unique)==512
    reference=json.loads((root/'reference/gaussian/E04-haar.json').read_text());maxz=0.
    for stat in reference['statistics']:
        key=tuple(float(stat[x]) for x in ['m','N','eta','r']);rr=groups[key];v=np.array([float(x['squared_error']) for x in rr]);target=float(rr[0]['predicted']);se=v.std(ddof=1)/len(v)**.5
        assert abs(v.mean()-stat['mean_squared_error'])<1e-12
        assert abs(np.mean([float(x['TV']) for x in rr])-stat['mean_TV'])<1e-12
        if target>1e-20:maxz=max(maxz,abs((v.mean()-target)/se))
    assert abs(maxz-reference['max_absolute_z'])<1e-9
    if a.haar:
        run('code/pair_haar.py');run('code/haar_tv.py','--draws','256');run('code/analyze_haar.py')
        # BLAS versions may change roundoff. Compare scientific statistics with tolerance.
        fresh=read('E04-haar.json');assert fresh['rows']==6528 and fresh['independent_Haar_matrices']==512
        for x,y in zip(fresh['statistics'],reference['statistics']):
            assert abs(x['mean_TV']-y['mean_TV'])<1e-10
            assert abs(x['mean_squared_error']-y['mean_squared_error'])<1e-10
    receipt={'status':'pass','hashed_files':len(manifest['files']),'checks':logs,'fock_identities':329,'fock_coefficient_cases':8,'pair_reduction_checks':990,'weight_ratio_checks':7735,'geometric_envelope_checks':6307,'Gaussian_prefix_cases':7,'review_symbolic_identities':3,'review_prefix_cases':3,'exact_precision_cases':9,'Haar_raw_rows_reaggregated':6528,'Haar_new_draws':2048 if a.haar else 0,'python':sys.version.split()[0],'numpy':np.__version__,'limits':'Internal finite checks and data replay; not independent expert verification, an all-size proof certificate or a practical sampler benchmark.'}
    (out/'REPRODUCTION.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
