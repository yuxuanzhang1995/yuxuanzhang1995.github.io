# Full-output classical simulation of lossy boson sampling

Yuxuan Zhang. Version 1.1, 31 October 2026. Complete solution candidate, internally checked.

Start with `full-output-lossy-boson-sampling-v1.1.pdf`. The proof includes the
exact Haar error estimate, the collision-resolving evaluator and finite-bit
implementation. `SOURCE-COMPARISON.md` separates inherited ingredients from
the proposed scope extension. `REVIEW-STATUS.json` records review limits.

Version 1.1 expands the literature comparison and attribution, adds an explicit
conservative accuracy-cost table, and improves the exposition. The main theorem
and exact-check cases are unchanged from version 1.0.

## Reproduce the finite exact checks

With Python 3.10 or later, from the extracted package run:

```text
python3 reproduce.py
```

No third-party Python package or network connection is needed. The runner checks
all payload hashes, reruns the exact arithmetic comparisons and mutation
controls, and matches the results against `checks/reference-results.json`.
Generated outputs are written to `results/`; they are not part of the immutable
payload. A failed hash, assertion or reference comparison returns a nonzero exit.

Expected scientific results: 329 frame/factorial checks, eight coefficient cases,
and detected mutation counts 4 / 7 / 5 for omitted spectators / the second
binomial denominator / heavy-mode binomial weights.

These are small-case algebraic controls. They are not the all-size sampler
specified in the theorem and do not replace its analytic proof.

## Rebuild the manuscript

The `manuscript/` directory is a complete LaTeX project with `main.tex` as its
entry point. A standard LaTeX installation with the listed packages suffices:

```text
cd manuscript
pdflatex main.tex
pdflatex main.tex
pdflatex main.tex
```

The first pages contain the statement and review status; the later sections
give the complete proof. The website article is a shorter reader-facing
companion. Its Jekyll download links are intended for the research website;
the PDF and source are included directly in this archive.

## Status and provenance

Independent expert review and worldwide novelty confirmation remain pending.
The construction and internal review used AI assistance under human direction.
The public checker preserves the reviewed mathematical functions and test cases;
only package-integrity and output paths were adapted. `PROVENANCE.json` records
the original and adapted code hashes and function-identity comparison.

The package contains no conversation, global ledger, unrelated question bank,
account information or access credentials. It makes no archival-deposit,
external-acceptance or catalog-resolution claim.
