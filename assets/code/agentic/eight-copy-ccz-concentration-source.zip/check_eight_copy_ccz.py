#!/usr/bin/env python3
# Exact standalone checker for the eight-copy CCZ concentration protocol of eight-copy-ccz-concentration.tex.
# Python standard library only.  No arguments, no files, no network; deterministic; exit status 1 on any failure.
# Conventions (as in the manuscript).  Qubits 0..7; qubit q <-> bit q of the basis index s in 0..255.  A Pauli is a
# triple (x, z, sign) of two 8-bit masks and a sign: P = sign * i^{|x&z|} X^x Z^z, so P|s> = sign i^{|x&z|} (-1)^{|z&s|}|s^x>.
# Every Pauli used has |x&z| even, hence is a real matrix.  Vectors are lists of 256 integers, or pairs (re, im) of such
# lists (Gaussian integers).  Gates act on unnormalised vectors: H' = [[1,1],[1,-1]] = sqrt2 H, and I -+ iX = sqrt2 R^{+-1}
# with R = exp(-i pi X/4).  A measurement path with outcomes s_k is represented by prod_k (I + s_k P_k), which is
# 2^(path length) times the Kraus operator of the path.  Every PASS/FAIL decision is an exact integer, Fraction or
# polynomial comparison; no floating point is used anywhere.
import sys
from fractions import Fraction

N, ALL8 = 256, 0xFF
POP = [bin(i).count("1") for i in range(N)]
OK = True
def check(cond, msg):
    global OK
    print(("PASS " if cond else "FAIL ") + msg)
    OK = OK and bool(cond)
def bits(*qs): return sum(1 << q for q in qs)
def dot(u, v): return sum(p * q for p, q in zip(u, v))
ZERO = [0] * N

# ---------------- Pauli action, projectors, gates ----------------
def pauli(v, x, z, s):
    """(s i^{|x&z|} X^x Z^z) v for an integer vector v; only real Paulis (|x&z| even) are admitted."""
    if POP[x & z] % 2:
        raise ValueError("Pauli with odd |x&z| is not a real matrix")
    ph = s * (1 - 2 * ((POP[x & z] // 2) & 1))
    return [ph * (1 - 2 * (POP[(i ^ x) & z] & 1)) * v[i ^ x] for i in range(N)]
def proj(v, path):
    """prod_k (I + s_k P_k) v, factors applied in measurement order."""
    for (x, z, s) in path:
        v = [p + q for p, q in zip(v, pauli(v, x, z, s))]
    return v
def cx(v, c, t): return [v[i ^ (((i >> c) & 1) << t)] for i in range(N)]
def xg(v, q): return [v[i ^ (1 << q)] for i in range(N)]
def hg(v, q):
    b = 1 << q
    return [v[i] + v[i | b] if not i & b else v[i & ~b] - v[i] for i in range(N)]
def run(v, gates):
    for g in gates:
        v = cx(v, g[1], g[2]) if g[0] == "cx" else xg(v, g[1]) if g[0] == "x" else hg(v, g[1])
    return v
def run_c(u, gates): return (run(u[0], gates), run(u[1], gates))
def h_all(v):
    for q in range(8): v = hg(v, q)
    return v
def r_all(u, sgn):
    """(I - sgn iX)^{(x)8} u for a Gaussian vector u: sgn = +1 gives 16 R^{(x)8} u, sgn = -1 gives 16 R^{dag(x)8} u."""
    re, im = u
    for q in range(8):
        xr, xi = xg(re, q), xg(im, q)
        re, im = [p + sgn * t for p, t in zip(re, xi)], [p - sgn * t for p, t in zip(im, xr)]
    return re, im
def pivot(t): return next((j for j in range(N) if t[j]), None)
def prop(u, t):
    """u = lam t for a nonzero rational lam (t a nonzero integer vector)."""
    k = pivot(t)
    return k is not None and u[k] != 0 and all(u[j] * t[k] == t[j] * u[k] for j in range(N))
def gprop(u, t):
    """u = lam t for a nonzero Gaussian rational lam (u Gaussian, t a nonzero real integer vector)."""
    k = pivot(t)
    return (k is not None and (u[0][k] != 0 or u[1][k] != 0)
            and all(u[0][j] * t[k] == t[j] * u[0][k] and u[1][j] * t[k] == t[j] * u[1][k] for j in range(N)))
def grank(rows):
    """Exact rank of a list of vectors over Z[i] (entries (re, im)), by fraction-free Gauss-Jordan elimination."""
    rows = [list(r) for r in rows if any(c != (0, 0) for c in r)]
    r = 0
    for col in range(len(rows[0]) if rows else 0):
        piv = next((i for i in range(r, len(rows)) if rows[i][col] != (0, 0)), None)
        if piv is None: continue
        rows[r], rows[piv] = rows[piv], rows[r]
        g = rows[r][col]
        for i in range(len(rows)):
            f = rows[i][col]
            if i != r and f != (0, 0):
                rows[i] = [(g[0] * p[0] - g[1] * p[1] - f[0] * q[0] + f[1] * q[1],
                            g[0] * p[1] + g[1] * p[0] - f[0] * q[1] - f[1] * q[0]) for p, q in zip(rows[i], rows[r])]
        r += 1
    return r
def real_rank(vecs): return grank([[(c, 0) for c in v] for v in vecs])
def wht(g):
    g = list(g); h = 1
    while h < N:
        for i in range(0, N, 2 * h):
            for j in range(i, i + h):
                p, q = g[j], g[j + h]; g[j], g[j + h] = p + q, p - q
        h *= 2
    return g
def spectrum(c):
    """(#P with |<c|P|c>| = <c|c>, #P with 2|<c|P|c>| = <c|c>, #P with any other nonzero value), c real."""
    n2 = dot(c, c); n1 = nh = other = 0
    for x in range(N):
        g = [c[i] * c[i ^ x] for i in range(N)]
        if not any(g): continue
        for w in wht(g):
            w = abs(w)
            if w == n2: n1 += 1
            elif 2 * w == n2: nh += 1
            elif w: other += 1
    return n1, nh, other

# ---------------- [G] conventions ----------------
M2 = {"I": {(0, 0): (1, 0), (1, 1): (1, 0)}, "X": {(0, 1): (1, 0), (1, 0): (1, 0)},
      "Y": {(0, 1): (0, -1), (1, 0): (0, 1)}, "Z": {(0, 0): (1, 0), (1, 1): (-1, 0)}}
def kron_apply(labels, v):
    """(P_7 (x) ... (x) P_0) v from 2x2 matrices: <r|P|c> = prod_q <r_q|P_q|c_q>, labels[q] acting on qubit q."""
    out = []
    for r in range(N):
        sr = si = 0
        for c in range(N):
            pr, pi = 1, 0
            for q in range(8):
                e = M2[labels[q]].get(((r >> q) & 1, (c >> q) & 1))
                if e is None: pr = pi = 0; break
                pr, pi = pr * e[0] - pi * e[1], pr * e[1] + pi * e[0]
            sr += pr * v[c]; si += pi * v[c]
        out.append((sr, si))
    return out
def xz(labels):
    return (sum(1 << q for q, c in enumerate(labels) if c in "XY"), sum(1 << q for q, c in enumerate(labels) if c in "ZY"))
TV = [(7 * s * s + 3 * s + 1) % 23 - 11 for s in range(N)]
okP = all(kron_apply(lab, TV) == [(p, 0) for p in pauli(TV, *xz(lab), 1)] for lab in ("YYYYIIII", "XZYYIIII", "YIIYYYII"))
def e_(i): return [1 if j == i else 0 for j in range(N)]
okG = (cx(e_(bits(2)), 2, 5) == e_(bits(2, 5)) and cx(e_(bits(5)), 2, 5) == e_(bits(5)) and xg(e_(0), 3) == e_(bits(3))
       and hg(e_(0), 3) == [p + q for p, q in zip(e_(0), e_(bits(3)))] and hg(e_(bits(3)), 3) == [p - q for p, q in zip(e_(0), e_(bits(3)))])
check(okP and okG, "[G] conventions: the Pauli routine equals the Kronecker product of 2x2 matrices (qubit q = bit q; Y = [[0,-i],[i,0]]) "
      "for Y0Y1Y2Y3, X0Z1Y2Y3, Y0Y3Y4Y5; CX(c,t) flips t iff c = 1; H' = [[1,1],[1,-1]]")

# ---------------- the protocol: measurement tree ----------------
E1, E2, P01, T3 = bits(0, 1, 2, 3), bits(0, 3, 4, 5), bits(0, 1), bits(0, 1, 4, 6)
SECTOR = {"Z": (-1, +1), "X": (+1, -1), "Y": (-1, -1)}          # outcomes of (X^(x)8, Z^(x)8); (+1, +1) is rejected
def pt(P, m, s): return {"X": (m, 0, s), "Y": (m, m, s), "Z": (0, m, s)}[P]
def root(P): return [(ALL8, 0, SECTOR[P][0]), (0, ALL8, SECTOR[P][1])]
def leaves(P):
    r = root(P)
    return {"A1": r + [pt(P, E1, -1), pt(P, P01, +1)], "A2": r + [pt(P, E1, -1), pt(P, P01, -1)],
            "B": r + [pt(P, E1, +1), pt(P, E2, -1)], "R": r + [pt(P, E1, +1), pt(P, E2, +1)]}
LV = {P: leaves(P) for P in "ZXY"}
ACC = [(P, k) for P in "ZXY" for k in ("A1", "A2", "B")]
RLK = [(P, k) for P in "ZXY" for k in ("A1", "A2")]
TREE = [LV[P][k] for P in "ZXY" for k in ("A1", "A2", "B", "R")] + [[(ALL8, 0, +1), (0, ALL8, +1)]]

# ---------------- [C1] instrument ----------------
def commute(p, q): return (POP[p[0] & q[1]] + POP[p[1] & q[0]]) % 2 == 0
check(len(TREE) == 13 and len(ACC) == 9 and all(POP[p[0] & p[1]] % 2 == 0 for L in TREE for p in L)
      and all(commute(p, q) for L in TREE for p in L for q in L),
      "[C1] instrument: 13 leaves (9 accepted); on every path the measured Paulis are Hermitian and commute pairwise")
def complete():
    for i in range(N):
        tot = ZERO
        for L in TREE:
            tot = [t + 2 ** (4 - len(L)) * p for t, p in zip(tot, proj(e_(i), L))]
        if any(tot[j] != (16 if j == i else 0) for j in range(N)): return False
    return True
check(complete(), "[C1] completeness: the 13 leaf projectors sum to the identity on (C^2)^(x)8 (all 256 columns, exact)")

# ---------------- [C2] rank one on Sym^8 ----------------
U = [[1 if POP[s] == w else 0 for s in range(N)] for w in range(9)]        # unnormalised Dicke vectors u_0..u_8
IMG = {key: [proj(U[w], LV[key[0]][key[1]]) for w in range(9)] for key in ACC}
def line(vecs):
    nz = [v for v in vecs if any(v)]
    return nz[0] if nz and all(prop(v, nz[0]) or not any(v) for v in vecs) else None
CHI = {key: line(IMG[key]) for key in ACC}
check(all(CHI[key] is not None for key in ACC),
      "[C2] rank one: each of the 9 accepted leaf operators maps u_0..u_8 (Dicke basis of Sym^8) into one fixed nonzero line")
def chi_pairs(pairs):
    v = [0] * N
    for (i, j) in pairs:
        v[bits(i, j)] += 1; v[bits(i, j) ^ ALL8] -= 1
    return v
PAIRS = {"A1": [(i, j) for i in (2, 3) for j in (4, 5, 6, 7)], "A2": [(i, j) for i in (0, 1) for j in (4, 5, 6, 7)],
         "B": [(i, j) for i in (0, 3) for j in (1, 2)] + [(i, j) for i in (4, 5) for j in (6, 7)]}
okZ = all(len(PAIRS[k]) == 8 and IMG[("Z", k)][2] == [8 * c for c in chi_pairs(PAIRS[k])]
          and IMG[("Z", k)][6] == [-8 * c for c in chi_pairs(PAIRS[k])]
          and not any(any(IMG[("Z", k)][w]) for w in (0, 1, 3, 4, 5, 7, 8)) for k in PAIRS)
check(okZ, "[C2] sector Z: Pi_L u_w = 0 for w not in {2,6}, Pi_L u_2 = -Pi_L u_6 = chi_L/2 with chi_L = sum over 8 strings e_i+e_j "
      "of |e_i+e_j> - |complement>: A1 {2,3}x{4,5,6,7}, A2 {0,1}x{4,5,6,7}, B {0,3}x{1,2} + {4,5}x{6,7}")

# ---------------- [C3] capture of the sector direction E_P ----------------
EZ = [p - q for p, q in zip(U[2], U[6])]                                      # sqrt56 E_Z, E_Z = (D2 - D6)/sqrt2
EP = {"Z": (EZ, ZERO), "X": (h_all(EZ), ZERO), "Y": r_all((EZ, ZERO), +1)}    # E_X = H^(x)8 E_Z, E_Y = R^(x)8 E_Z (scaled)
def capture(P, L):
    u = EP[P]
    return Fraction(dot(u[0], proj(u[0], L)) + dot(u[1], proj(u[1], L)), 2 ** len(L) * (dot(u[0], u[0]) + dot(u[1], u[1])))
caps = [capture(P, LV[P][k]) for (P, k) in ACC]
check(caps == [Fraction(2, 7)] * 9, "[C3] capture: <E_P|Pi_L|E_P> = 2/7 for all 9 accepted leaves, so per sector A1+A2 keep 4/7 "
      "and A1+A2+B keep 6/7 of E_P (E_Z = (D2-D6)/sqrt2, E_X = H^(x)8 E_Z, E_Y = R^(x)8 E_Z)")

# ---------------- [C4] decoders ----------------
DEC = {"A1": [("cx", 0, 1), ("cx", 0, 4), ("cx", 0, 5), ("cx", 0, 6), ("cx", 0, 7), ("h", 0), ("x", 0),
              ("cx", 2, 3), ("h", 2), ("x", 3),
              ("cx", 4, 7), ("cx", 5, 7), ("cx", 6, 7), ("x", 7), ("cx", 6, 4), ("cx", 6, 5), ("h", 6)],
       "A2": [("cx", 2, 3), ("cx", 2, 4), ("cx", 2, 5), ("cx", 2, 6), ("cx", 2, 7), ("h", 2), ("x", 2),
              ("cx", 0, 1), ("h", 0), ("x", 1),
              ("cx", 4, 7), ("cx", 5, 7), ("cx", 6, 7), ("x", 7), ("cx", 6, 4), ("cx", 6, 5), ("h", 6)],
       "B": [("cx", 0, 3), ("cx", 1, 2), ("cx", 4, 5), ("cx", 6, 7), ("cx", 3, 2), ("cx", 5, 7), ("cx", 3, 5), ("x", 5),
             ("h", 0), ("h", 1), ("h", 4), ("h", 6), ("cx", 4, 3), ("cx", 6, 3),
             ("cx", 0, 6), ("cx", 1, 6), ("cx", 4, 6), ("x", 6), ("cx", 4, 0), ("cx", 4, 1), ("h", 4)]}
OUTQ = {"A1": (4, 5, 6), "A2": (4, 5, 6), "B": (0, 1, 4)}
def ccz(q):
    a, b, c = q; m = bits(a, b, c)
    return [0 if i & ~m else 1 - 2 * ((i >> a) & (i >> b) & (i >> c) & 1) for i in range(N)]
K3 = ("A1", "A2", "B")
okDZ = [len(DEC[k]) for k in K3] == [17, 17, 21] and all(prop(run(CHI[("Z", k)], DEC[k]), ccz(OUTQ[k])) for k in K3)
okDZc = not prop(run(CHI[("Z", "A1")], DEC["B"]), ccz(OUTQ["B"]))
check(okDZ and okDZc, "[C4] decoders, sector Z: the explicit circuits D_A1, D_A2, D_B (17, 17, 21 gates of CX, X, H) map chi_A1, chi_A2, "
      "chi_B exactly to multiples of |CCZ> on qubits (4,5,6), (4,5,6), (0,1,4) times |0> on the other five; control: D_B chi_A1 is not")
okX = all(prop(h_all(CHI[("Z", k)]), CHI[("X", k)]) and prop(run(h_all(CHI[("X", k)]), DEC[k]), ccz(OUTQ[k])) for k in K3)
check(okX, "[C4] sector X: chi^X_L = H^(x)8 chi^Z_L (up to a factor; X-type leaf projectors) and D_L H^(x)8 maps chi^X_L exactly to |CCZ>(x)|0>^5")
okY = all(gprop(r_all((CHI[("Z", k)], ZERO), +1), CHI[("Y", k)])
          and gprop(run_c(r_all((CHI[("Y", k)], ZERO), -1), DEC[k]), ccz(OUTQ[k])) for k in K3)
okYr = all(gprop(run_c(r_all((CHI[("Y", k)], ZERO), +1), DEC[k]), ccz(OUTQ[k])) for k in K3)
okYc = not any(prop(run(h_all(CHI[("Y", k)]), DEC[k]), ccz(OUTQ[k])) for k in K3)
check(okY and okYr and okYc, "[C4] sector Y: chi^Y_L = R^(x)8 chi^Z_L (Y-type projectors, Gaussian integers) and D_L R^dag(x)8 maps chi^Y_L "
      "exactly to |CCZ>(x)|0>^5; R^(x)8 in place of R^dag(x)8 also works (R^(x)8 R^(x)8 = X^(x)8 = -1 there); control: D_L H^(x)8 fails")
SPEC = spectrum(ccz((4, 5, 6)))
check(SPEC == (32, 896, 0) and all(spectrum(CHI[key]) == SPEC for key in ACC),
      "[C4] independent invariant: the Pauli spectrum of all 9 leaf states equals that of |CCZ>(x)|0>^5 (32 x |<P>| = 1, 896 x 1/2, rest 0)")

# ---------------- [C5] Hermitian forms on Sym^8 (psi^8 = sum_w a^(8-w) b^w u_w) ----------------
def herm(keys):
    M = [[Fraction(0)] * 9 for _ in range(9)]
    for key in keys:
        L = LV[key[0]][key[1]]
        for w in range(9):
            for w2 in range(9):
                M[w][w2] += Fraction(dot(U[w], IMG[key][w2]), 2 ** len(L))
    return M
def vec(k): return [(j == k) - (j == k + 4) for j in range(9)]
V1, V2, V3 = vec(1), vec(2), vec(3)
Vm, Vp = [p - q for p, q in zip(V1, V3)], [p + q for p, q in zip(V1, V3)]
def outer(c, u, v): return [[c * p * q for q in v] for p in u]
def madd(*Ms): return [[sum(M[i][j] for M in Ms) for j in range(9)] for i in range(9)]
BASE = madd(outer(1, V1, V1), outer(2, V2, V2), outer(1, V3, V3))       # v1v1^T + 2 v2v2^T + v3v3^T
PER = {"Z": outer(4, V2, V2), "X": outer(1, Vm, Vm), "Y": outer(1, Vp, Vp)}
check(all(herm([key]) == PER[key[0]] for key in ACC),
      "[C5] per-leaf forms <u_w|Pi_L|u_w'>: sector Z 4 v2v2^T, sector X (v1-v3)(v1-v3)^T, sector Y (v1+v3)(v1+v3)^T (v_k = e_k - e_{k+4})")
NTOT = herm(ACC)
check(NTOT == [[6 * c for c in r] for r in BASE],
      "[C5] total: N = sum over the 9 accepted leaves = 6 (v1v1^T + 2 v2v2^T + v3v3^T) exactly (9x9 over Q)")
def dcoef(u): return [(dot(U[w], u[0]), dot(U[w], u[1])) for w in range(9)]
def binom(n, k):
    r = 1
    for i in range(k): r = r * (n - i) // (i + 1)
    return r
TAU = [((1, 0), (0, 0)), ((0, 0), (1, 0)), ((1, 0), (1, 0)), ((1, 0), (-1, 0)), ((1, 0), (0, 1)), ((1, 0), (0, -1))]
def gm(u, v): return (u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0])
def gpow(u, k):
    r = (1, 0)
    for _ in range(k): r = gm(r, u)
    return r
TROWS = [[gm(gpow(al, 8 - w), gpow(be, w)) for w in range(9)] for (al, be) in TAU]    # tau^(x)8 = sum_w row[w] u_w
D = {P: dcoef(EP[P]) for P in "XYZ"}
okSym = all(EP[P][t][s] * binom(8, POP[s]) == D[P][POP[s]][t] for P in "XYZ" for t in (0, 1) for s in range(N))
okOrth = all(dot(EP[P][0], EP[Q][0]) + dot(EP[P][1], EP[Q][1]) == 0 and dot(EP[P][0], EP[Q][1]) - dot(EP[P][1], EP[Q][0]) == 0
             for P, Q in (("X", "Y"), ("X", "Z"), ("Y", "Z")))
okTau = all(sum(gm((r[w][0], -r[w][1]), D[P][w])[t] for w in range(9)) == 0 for r in TROWS for P in "XYZ" for t in (0, 1))
NM8, NM8i = [[Fraction(0)] * 9 for _ in range(9)], [[Fraction(0)] * 9 for _ in range(9)]
for P in "XYZ":                                   # <u_w|Pi_M8|u_w'> = sum_P <u_w|E_P><E_P|u_w'> / <E_P|E_P>
    nP = dot(EP[P][0], EP[P][0]) + dot(EP[P][1], EP[P][1])
    for w in range(9):
        for w2 in range(9):
            pr = gm(D[P][w], (D[P][w2][0], -D[P][w2][1]))
            NM8[w][w2] += Fraction(pr[0], nP); NM8i[w][w2] += Fraction(pr[1], nP)
check(okSym and okOrth and okTau and grank(TROWS) == 6 and not any(any(r) for r in NM8i)
      and NM8 == [[7 * c for c in r] for r in BASE] and NTOT == [[Fraction(6, 7) * c for c in r] for r in NM8],
      "[C5] M_8: E_X, E_Y, E_Z lie in Sym^8, are pairwise orthogonal and orthogonal to the six tau^(x)8 (rank 6, so dim M_8 = 3); "
      "Pi_M8 has form 7(v1v1^T + 2v2v2^T + v3v3^T) and N = (6/7) Pi_M8 on Sym^8")

# ---------------- [C6] polynomial identities in a, b, A = conj(a), B = conj(b) (independent symbols) ----------------
class Poly:
    """Exact polynomial in (a, b, A, B) with coefficients in Q(i), stored as {exponents: (re, im)}."""
    def __init__(self, t=None): self.t = {k: v for k, v in (t or {}).items() if v[0] != 0 or v[1] != 0}
    def __add__(self, o):
        o = o if isinstance(o, Poly) else const(o); t = dict(self.t)
        for k, v in o.t.items():
            u = t.get(k, (0, 0)); t[k] = (u[0] + v[0], u[1] + v[1])
        return Poly(t)
    def __neg__(self): return Poly({k: (-v[0], -v[1]) for k, v in self.t.items()})
    def __sub__(self, o): return self + (-(o if isinstance(o, Poly) else const(o)))
    def __mul__(self, o):
        o = o if isinstance(o, Poly) else const(o); t = {}
        for k1, v1 in self.t.items():
            for k2, v2 in o.t.items():
                k = (k1[0] + k2[0], k1[1] + k2[1], k1[2] + k2[2], k1[3] + k2[3]); u = t.get(k, (0, 0))
                t[k] = (u[0] + v1[0] * v2[0] - v1[1] * v2[1], u[1] + v1[0] * v2[1] + v1[1] * v2[0])
        return Poly(t)
    __rmul__ = __mul__
    def __pow__(self, n):
        r = const(1)
        for _ in range(n): r = r * self
        return r
    def __eq__(self, o): return not (self - o).t
def const(c, ci=0): return Poly({(0, 0, 0, 0): (c, ci)})
def mono(e, c=1): return Poly({e: (c, 0)})
a, b, A, B = mono((1, 0, 0, 0)), mono((0, 1, 0, 0)), mono((0, 0, 1, 0)), mono((0, 0, 0, 1))
bx, by, bz, nn = A * b + a * B, const(0, -1) * (A * b - a * B), a * A - b * B, a * A + b * B   # 2Re(conj(a)b), 2Im, |a|^2-|b|^2, |psi|^2
f6, F6 = a ** 5 * b - a * b ** 5, A ** 5 * B - A * B ** 5                                     # f_6 and conj(f_6)
S6 = nn ** 6 - bx ** 6 - by ** 6 - bz ** 6
check(bx + const(0, 1) * by == 2 * A * b and bx * bx + by * by + bz * bz == nn * nn and S6 == 12 * f6 * F6
      and S6 == 3 * (nn * nn - bx * bx) * (nn * nn - by * by) * (nn * nn - bz * bz),
      "[C6] Bloch conversion (polynomial identities over Q(i)): x + iy = 2 conj(a) b, x^2+y^2+z^2 = |psi|^4 and (|psi|^12 - x^6-y^6-z^6)/2 "
      "= 6|f6|^2 = (3/2)(|psi|^4-x^2)(|psi|^4-y^2)(|psi|^4-z^2), f6 = ab(a^4-b^4); so m_3 = 6|f6|^2 for normalised psi")
def form_poly(M):
    p = Poly()
    for w in range(9):
        for w2 in range(9):
            if M[w][w2]: p = p + mono((8 - w2, w2, 8 - w, w), M[w][w2])
    return p
check(form_poly(NTOT) == 6 * f6 * F6 * nn * nn,
      "[C6] success probability: <psi^8| sum_L Pi_L |psi^8> = sum_ww' conj(a^(8-w)b^w) N_ww' a^(8-w')b^w' = 6|f6|^2 |psi|^4 identically, "
      "so p(psi) = m_3(psi) for every pure psi")

# ---------------- [C7] independent route: exact evaluation at Gaussian-rational inputs ----------------
def prob(al, be, keys):
    amp = [gm(gpow(al, 8 - POP[s]), gpow(be, POP[s])) for s in range(N)]
    re, im = [t[0] for t in amp], [t[1] for t in amp]
    n2 = al[0] ** 2 + al[1] ** 2 + be[0] ** 2 + be[1] ** 2
    tot = Fraction(0)
    for (P, k) in keys:
        L = LV[P][k]; pr, pi = proj(re, L), proj(im, L)
        tot += Fraction(dot(pr, pr) + dot(pi, pi), 4 ** len(L))
    return tot / n2 ** 8
def m3_bloch(al, be):
    n2 = al[0] ** 2 + al[1] ** 2 + be[0] ** 2 + be[1] ** 2
    x1 = Fraction(2 * (al[0] * be[0] + al[1] * be[1]), n2); y1 = Fraction(2 * (al[0] * be[1] - al[1] * be[0]), n2)
    z1 = Fraction(al[0] ** 2 + al[1] ** 2 - be[0] ** 2 - be[1] ** 2, n2)
    return (1 - x1 ** 6 - y1 ** 6 - z1 ** 6) / 2
PTS = [((1, 0), (2, 1)), ((2, -1), (3, 0)), ((1, 2), (1, -1))]
check(all(m3_bloch(al, be) > 0 and prob(al, be, ACC) == m3_bloch(al, be) and prob(al, be, RLK) == Fraction(2, 3) * m3_bloch(al, be)
          for (al, be) in PTS),
      "[C7] direct exact evaluation of sum_L ||Pi_L psi^8||^2 at psi = (1, 2+i), (2-i, 3), (1+2i, 1-i): p = m_3 from the Bloch vector, "
      "and the A-leaves alone give (2/3) m_3")

# ---------------- [C8] controls ----------------
NRL = herm(RLK)
check(NRL == [[4 * c for c in r] for r in BASE] and form_poly(NRL) == 4 * f6 * F6 * nn * nn,
      "[C8] positive control: the six A-leaves alone give N_RL = 4(v1v1^T + 2v2v2^T + v3v3^T), i.e. 4|f6|^2|psi|^4 = (2/3) m_3, "
      "the value of Rizzo-Leone's eight-copy protocol")
LC = root("Z") + [pt("Z", E1, +1), pt("Z", E2, +1), pt("Z", T3, -1)]
chiC = line([proj(U[w], LC) for w in range(9)])
check(chiC is not None and capture("Z", LC) == Fraction(1, 7) and prop(chiC, chi_pairs([(0, 3), (1, 2), (4, 5), (6, 7)]))
      and spectrum(chiC)[0] == 256,
      "[C8] negative control: the leaf (+Z^E1, +Z^E2, -Z^{0,1,4,6}) is rank one with capture 1/7, but its state chi_C (pairs 03,12,45,67) "
      "is a stabilizer state (256 Paulis with |<P>| = 1), so no Clifford decoder yields CCZ")
GHZ = [1 if s == 0 else -1 if s == ALL8 else 0 for s in range(N)]
IMR = [proj(U[w], LV["Z"]["R"]) for w in range(9)]
okR = (all(real_rank([proj(U[w], LV[P]["R"]) for w in range(9)]) == 2 for P in "ZXY")
       and prop(IMR[0], GHZ) and prop(IMR[2], chi_pairs([(0, 3), (1, 2), (4, 5), (6, 7)]))
       and all(prop(IMR[w], IMR[0]) or prop(IMR[w], IMR[2]) or not any(IMR[w]) for w in range(9))
       and spectrum(GHZ)[0] == 256)
check(okR, "[C8] negative control: B with the opposite P^E2 outcome (the rejected leaf) has rank 2 on Sym^8 in every sector, not rank one; "
      "in sector Z its image is spanned by GHZ- = |0^8>-|1^8> and chi_C, both stabilizer states")

# ---------------- [C9] values ----------------
def m3_sq(x2, y2, z2): return (1 - x2 ** 3 - y2 ** 3 - z2 ** 3) / 2
T, H0 = Fraction(1, 3), Fraction(1, 2)
mT, mH = m3_sq(T, T, T), m3_sq(H0, Fraction(0), H0)
okV = (mT == Fraction(4, 9) and Fraction(2, 3) * mT == Fraction(8, 27) and Fraction(7, 6) * mT == Fraction(14, 27)
       and mH == Fraction(3, 8) and Fraction(2, 3) * mH == Fraction(1, 4) and Fraction(7, 6) * mH == Fraction(7, 16)
       and mT == Fraction(3, 2) * (1 - T) ** 3 and all(m3_sq(*map(Fraction, v)) == 0 for v in ((1, 0, 0), (0, 1, 0), (0, 0, 1))))
check(okV, "[C9] values: T-type (x^2=y^2=z^2=1/3) p = m_3 = 4/9 vs (2/3) m_3 = 8/27 and (7/6) m_3 = 14/27; "
      "H-type (x^2=z^2=1/2, y=0) 3/8 vs 1/4 and 7/16; m_3 = 0 at the six stabilizer states")
print("VERDICT " + ("PASS: an explicit U_8 protocol outputs exactly |CCZ> with probability m_3(psi) > (2/3) m_3(psi) at every "
                    "non-stabilizer psi, so Eq. (2) fails" if OK else "FAIL"))
sys.exit(0 if OK else 1)
