# Evidence outline: low-energy Hamiltonian simulation

Document: English mathematical research draft, no target venue specified.
Author: Yuxuan Zhang; EPFL first, Princeton second (user-approved project metadata).
Status: local draft; external expert confirmation and final author approval pending.

1. Abstract and introduction: exact factor access, clean-output vector error, tight precision formula. E01/E02/E03.
2. Model and theorem: all three asymptotic conditions, universal query circuit, no classical description of A, absolute constants; fixed-s and shrinking-s consequences. E01/E02.
3. Contractive polynomial: coefficient majorant, binomial tail cutoff, uniform approximation bound. E01/E04.
4. Exact synthesis and quantum walk: self-contained Laurent completion, degree stripping credited to existing QSP; arbitrary factor encoding and no free energy projection. E01/E04/E05.
5. Upper bound: finite-parameter guarantee first; clean-vector leakage and asymptotic rounding explicitly retained. E01/E04.
6. Lower bound: four-sign averaging, complex-polynomial derivative bound, finite differences, k=1 edge. E01/E04.
7. Scope and practical limits: query versus gate complexity, exact oracle, phase convention; adjacent term-access lower bounds. E02/E06.
8. Reproducibility and AI disclosure: numerical diagnostics are corroboration; outer coordinator and model reviewers are AI; no external human verification claimed. E07/E08/E09.

No empirical efficiency benchmark, gate-complexity claim, exhaustive novelty claim, funding declaration, or conflict statement will be invented. Research mathematics is written as a self-contained proof in a visibly marked draft.
