# A support minimax formula for exact deterministic work

24 November 2026. Same-root candidate. Normal countable baths, beta>0,
sharp battery. This removes the optimization over an all-temperature
profile from the support barrier, but retains finite-dimensional quantum
factorization at each single temperature. It is not a fully evaluated
answer for arbitrary channels.

Fix finite A,B and shift both system ground energies to zero. Let S be a
covariance-invariant Kraus subspace supporting at least one TP channel.
For a finite Gibbs isometric dilation V whose channel is supported in S,
write c_u(V) for its partition index at inverse temperature u. Define

 a_u(S)=inf_V c_u(V),
 g(S)=min_{covariant TP Psi supported in S} max{omega: Kraus frequency
                                                   omega occurs in Psi}.

The second minimum is finite and attained. It is found by checking the
finitely many frequency cutoffs: whether the intersection of S with
frequencies <=w supports a PSD TP Choi matrix is a finite SDP. In general
energy origins, add min(H_A)-min(H_B) to the frequency maximum.

Let s(S)=inf_V sup_(u>=beta)c_u(V), as in the face-separation theorem.
Then

    s(S)=max{g(S), sup_(u>=beta) a_u(S)}.                 (1)

For a target Phi with minimal support S, consequently,

 W_0(Phi)=max{ beta^(-1)log b(Phi),
              g(S), sup_(u>=beta) a_u(S) }.             (2)

Here b(Phi) is the exact-target single-temperature finite-dilation
optimization from `general-work-face-separation-v1.md`. Formula (2)
separates the target-dependent cost, the ground-energy obstruction, and
single-temperature support costs. The a_u optimization can still contain
noncommutative factorization with unbounded ancillary sizes.

## 1. Ground obstruction and the easy minimax inequality

Normalize a finite dilation to logical shift zero and initial environment
ground energy zero. Its all-temperature profile has limiting value
-g_F as u->infinity. Restrict V to one ground input environment vector.
The induced system channel is TP, covariant, and supported in S. Every
frequency in that channel is -f for an output energy f>=g_F. Thus its
maximum frequency is <=-g_F. It follows that g(S)<=lim c_u(V).
The lower bounds g(S)<=s(S) and sup_u a_u(S)<=s(S) follow.

Conversely choose a supported TP channel realizing g(S), and take its
ordinary pure-environment covariant Stinespring dilation V_infinity.
Its profile tends to g(S). The pure initial environment is only a logical
one-dimensional Gibbs input; the inherited convolution construction is
still needed to implement that dilation using an actual work bath.

## 2. Finite thermal selection lemma

Given finitely many finite shift-zero dilations V_i, suppose their profiles
satisfy: at every u>=beta at least one c_u(V_i)<W, and a distinguished
V_0 has c_u(V_0)<W for all sufficiently large u with a strictly smaller
limiting slope. Then a finite Gibbs direct-sum dilation, all of whose
component channels are supported in S, has c_all<W.

Proof. Give each input environment ground zero. Write its partition
functions A_i(u),B_i(u), and R_i(u)=Z_B B_i/(Z_A A_i). On a compact
interval covering all finite-temperature switches, a continuous partition
of unity subordinate to {R_i<exp(uW)} produces a convex selector with
strict slack. Make its V_0 weight strictly positive by an arbitrarily
small perturbation on that compact interval, and choose V_0 alone past
its high-temperature endpoint (that is, at large inverse temperature).
This retains strict slack. Write the desired weights as w_i(u).

For t=exp(-h u), h>0 fixed, the desired multiplicity factors are
q_i(t)=w_i(u)/A_i(u). They are continuous on the compact t interval after
extension to t=0; q_0(0)>0, and q_i for i!=0 can be chosen identically zero
near zero. Normalize V_0's input to be its one-dimensional ground input
when applying the lemma below; more generally its finite ground multiplicity
only changes a positive constant.

Choose integer K so hK exceeds all finitely many adverse exponential
slopes from B_i/B_0, with margin. Approximate q_0(t) and q_i(t)/t^K for
 i!=0 by nonnegative-coefficient polynomial numerators over a common
(1+t)^N denominator. This is the Bernstein approximation after the change
s=t/(1+t), extending the continuous nonnegative functions to [0,1].
The q_0 approximant has a strictly positive constant coefficient; the
other factors retain t^K. Degree elevation puts all denominators at a
common N while preserving coefficient nonnegativity.

On the compact switching interval, the approximation error can be made
arbitrarily small. Near t=0 the unwanted factors are bounded by delta t^K,
because their approximated target functions vanish there; q_0 stays
bounded below. The choice of K suppresses their output partition tails.
Thus the ratio

    (Z_B/Z_A) sum_i Q_i(t) B_i(u) / sum_i Q_i(t) A_i(u)

remains below exp(uW) for every u>=beta. The common denominator cancels.
Scale the finitely many nonnegative numerator coefficients by a common
large number and round them to nonnegative integers, keeping zeros zero.
Relative coefficient errors can be made uniformly small. They preserve
both compact-interval slack and the vanishing order at zero.

The resulting Q_i are actual finite multiplicity polynomials: append
energy levels 0,h,2h,... with those integer degeneracies to each input and
output environment, and direct-sum the logical dilations. The displayed
ratio is exactly its partition ratio. This proves the lemma. No target
channel equality is being approximated here: the resulting exact channel
is simply a convex mixture of supported channels, as required for s(S).

## 3. Proof of the upper bound in (1)

Take W strictly above the right side. Choose V_infinity as in Section 1;
its profile is below W for u>=U. For each u in [beta,U+1], the definition
of a_u supplies a finite V_u with c_u(V_u)<W. Continuity gives an open
neighborhood of u on which the same inequality holds. Compactness selects
finitely many such dilations. Together with V_infinity they satisfy the
thermal selection lemma, so s(S)<W. Let W decrease to the stated maximum.

## 4. Consistency checks and limits

- For CPTP-extreme S, every supported TP channel is the same target;
  orthogonal environment copies give a_u=log[Z_B Z_K/Z_A]/u. Formula (2)
  recovers the inherited all-temperature extreme formula.
- For a one-relation face, Section 1 of `one-relation-work-v1.md` gives
  a_u=min_j log R_j(u)/u. Its limiting minimum already includes g(S),
  recovering the evaluated two-profile formula.
- At equal-dimensional H=0, g(S)=0, and the temperature dependence of
  a_u is the fixed finite tracial rank infimum divided by u. Its support
  minimum is bounded by the target beta cost, recovering the H=0 theorem.
- Finite thermal baths and exact zero-work attainment remain distinct.
- No swap of infimum and supremum is asserted without the ground term and
  finite thermal-selector proof. No recursive ancillary dimension bound
  or complete solution of the noncommutative factorization problem follows.
