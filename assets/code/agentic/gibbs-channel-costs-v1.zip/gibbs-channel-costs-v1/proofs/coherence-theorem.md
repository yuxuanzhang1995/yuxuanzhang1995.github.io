# A finite-order classification of small-error coherence cost

24 November 2026. Complete proof candidate, with a new finite-resource
construction. Derived and checked by the same root agent. This is not an
independent review, a priority claim, or a complete solution of Q117.

## Statement

Let \(\Phi:A\to B\) be any channel between finite systems with Hamiltonians
\(H_A,H_B\). Take a minimal Kraus representation \(K_1,\ldots,K_r\), put
\(V=\sum_\alpha K_\alpha\otimes|\alpha\rangle\), and define
\[
 \Omega_h(X)=V^*(H_B^h\otimes X)V.
\]
The resource cost \(F_c^\epsilon\) uses the SLD QFI, arbitrary finite resource
Hamiltonians and states, thermal operations, and worst-case reference-assisted
purified channel distance, exactly as in Q117. Work is unrestricted in this
cost. In particular, pure sharp-energy ancillary registers cost zero QFI.

For each \(m\ge0\), consider the finite real linear system in Hermitian
\(C_1,\ldots,C_m\), with \(C_0=I_r\):
\[
 \sum_{h=0}^{\ell}{\ell\choose h}\Omega_h(C_{\ell-h})
       =H_A^\ell,\qquad 0\le\ell\le m.                    \tag{J_m}
\]
All coefficients up to order \(m\) are solved jointly. The question is not
whether an arbitrarily chosen solution at one order extends.

Let \(k\) be the first infeasible positive order, and \(k=\infty\) if every
system is feasible. Then:

1. For finite \(k\), there are positive constants \(c,C,\epsilon_0\), depending
   only on the fixed channel and Hamiltonians, such that
   \[
   c\epsilon^{-2/k}-1\le F_c^\epsilon(\Phi)
          \le C\epsilon^{-2/k}\quad(0<\epsilon<\epsilon_0).
                                                              \tag{1}
   \]
2. For \(k=\infty\), \(F_c^\epsilon(\Phi)\) is bounded uniformly for small
   positive \(\epsilon\). This does not imply a finite exact implementation.

The alternative is determined by finitely many exact linear systems. If
\(a,b\) count distinct input and output energies, and \(p\) is the generic
rank of the analytic linear map
\[
 \mathcal L(u)X=V^*(e^{uH_B}\otimes X)V,
\]
then it suffices to test through
\[
 K=a{b+p-1\choose p}-1.                                  \tag{2}
\]
The generic rank and feasibility tests here are exact mathematical tests;
floating-point rank thresholds do not establish the theorem's alternative.
One can avoid computing the generic rank altogether: replace \(p\) in
(2) by \(p_* =\min(r^2,d_A^2)\). The binomial coefficient is nondecreasing
in \(p\), so this larger bound uses only the dimensions and numbers of
distinct energies, followed by a finite list of ordinary linear systems.

Gibbs preservation is not required in the proof. Consequently the theorem
applies to all Gibbs-preserving channels in Q117, with the same charged
coherence resource model.

## 1. Resource reduction

For a finite state \(\rho=\sum_i\lambda_i|i\rangle\langle i|\), purify it as
\(|\psi\rangle=\sum_i\sqrt{\lambda_i}|i,i\rangle\). Assign the purifier the
Hamiltonian
\[
 h_{ij}=-\frac{2\sqrt{\lambda_i\lambda_j}}{\lambda_i+\lambda_j}H_{ji}
\]
when the denominator is nonzero, and zero otherwise. Direct expansion gives
\[
 4\operatorname{Var}_\psi(H\otimes I+I\otimes h)=F_Q(\rho,H).
\]
This is the optimized-purification identity of Marvian, Theorem 3,
[arXiv:2112.04694](https://arxiv.org/abs/2112.04694).
Discarding the purifier after the old thermal protocol implements the same
channel. Thus a lower bound for every pure resource also bounds arbitrary
mixed resources. Setting the purifier Hamiltonian to zero would not give
this reduction. A scalar energy shift centers the pure resource without
changing its QFI or the implemented channel.

Every thermal operation on the finite input and resource is covariant and
has a finite covariant Stinespring isometry, regardless of the bath used in
its original representation. One can see finiteness directly: decompose the
finite Choi matrix into its eigenspaces under the input-output energy-gap
action and choose Kraus operators with definite gaps. Assign the opposite
gaps as environment energies. This avoids assuming a finite variance for
an actual heat bath.

## 2. Analytic feasibility and a robust obstruction

Use fixed real bases of Hermitian matrices. The equation
\[
 \mathcal L(u)C(u)=e^{uH_A},\qquad C(0)=I_r                 \tag{3}
\]
is a finite real analytic linear system near zero. Its Taylor equations,
with \(C(u)=\sum C_\ell u^\ell/\ell!\), are exactly \((J_m)\).

Here is the local algebra needed. Every nonzero convergent power series
is \(u^s\) times an invertible analytic series. In a nonzero analytic
matrix choose an entry of minimal vanishing order, move it to the first
position, and divide out its invertible factor. It divides every entry
of the matrix. Analytic row and column elimination remove its row and
column. Repeating yields invertible analytic matrices \(P,Q\) such that
\(P\mathcal LQ\) has nonzero diagonal entries \(u^{s_1},\ldots,u^{s_p}\)
and otherwise zero. The exponents are nonnegative and their sum is the
minimal vanishing order of a nonzero maximal minor. This is the
one-variable analytic Smith reduction; the elimination also proves the
facts about it used here.

Put \(b(u)=P(u)e^{uH_A}\) in coordinates and \(y=Q^{-1}C\). Its constant
term is prescribed by \(C(0)=I\). A nonzero row has the equation
\(u^s y_j=b_j(u)\). It requires zero coefficients below degree \(s\), and
the prescribed coefficient at degree \(s\). If these conditions hold, the
quotient is analytic. A zero row requires \(b_j\equiv0\). Free coordinates
can be chosen analytic with their prescribed constants. Therefore all
finite joint systems are feasible if and only if (3) has an analytic
Hermitian solution for real \(u\).

If the first infeasible order is \(k\), this same reduction proves the
following uniform obstruction: for some \(c_0,\delta_0,t_0>0\),
\[
 \|\mathcal L(it)X-e^{itH_A}\|\ge c_0|t|^k
 \quad(0<|t|<t_0,\ \|X-I\|\le\delta_0),                 \tag{4}
\]
including complex \(X\). Indeed, a failed row has a first nonzero right
coefficient below its diagonal exponent, a mismatch of the prescribed
constant at that exponent, or a first nonzero coefficient in a zero row.
In the first and third cases bounded \(X\) cannot cancel the leading term.
In the second, choose \(\delta_0\) smaller than the fixed mismatch after
the invertible change of coordinates. All remaining terms are higher
order, and the row operations and their inverses stay bounded. Substituting
\(u=it\) cannot remove the leading nonzero coefficient.

## 3. Lower bound for all finite resources

Let a pure, centered clock \(\psi\) implement \(\Psi\) with error at most
\(\epsilon\), and write its QFI as \(F=4\operatorname{Var}(H_R)\). Its
energy distribution is \(\mu\). Choose a covariant isometry
\(T:A\otimes R\to B\otimes E\), and write
\(W=T(I_A\otimes|\psi\rangle)\). Intertwining gives exactly
\[
 W^*(e^{itH_B}\otimes e^{itH_E})W
       =\widehat\mu(t)e^{itH_A}.                           \tag{5}
\]

Project each environment-energy Kraus operator of \(W\), in Hilbert--Schmidt
inner product, onto the target Kraus span. Call the projected dilation
\(W_c\). Its positive coefficient measure \(C(dz)\) is defined with the
convention \(C_z=S_z^*S_z\) when
\(A_{s,z}=\sum_\alpha(S_z)_{s\alpha}K_\alpha\). The coefficient in the Choi
matrix is then \(C_z^T\), while the energy Gram uses \(C_z\).

A maximally entangled input tests the normalized Choi states. Fidelity
with the target, which is supported on its Kraus span, implies that the
actual state has mass at most \(\epsilon^2\) outside that support. Hence
\[
 \|W-W_c\|_{\rm HS}\le\sqrt{d_A}\epsilon.                 \tag{6}
\]
The minimal Kraus Gram is invertible. The trace-distance bound on the
Choi states therefore also gives \(C(\mathbb R)=I+O(\epsilon)\).
Equation (5), (6), and boundedness of the unitaries imply uniformly in \(t\)
\[
 \|\widehat\mu(t)e^{itH_A}-\mathcal L(it)\widehat C(t)\|
        \le c_1\epsilon.                                 \tag{7}
\]

For the required moment bound, differentiate the intertwining relation
before inserting the clock:
\[
 (I\otimes H_E)W
 =WH_A+T(I\otimes H_R|\psi\rangle)-(H_B\otimes I)W.
\]
Its Hilbert--Schmidt norm is at most
\(\sqrt{d_A}(\|H_A\|+\|H_B\|+\sqrt F/2)\). Projection is a contraction
separately at each energy. Inverting the fixed target Kraus Gram gives
\[
 \int z^2\operatorname{Tr}C(dz)\le c_2(1+F),\qquad
 \|\widehat C(t)-I\|\le c_3(\epsilon+|t|\sqrt{1+F}).       \tag{8}
\]
These estimates do not involve the bath's energy moments.

The centered clock satisfies
\(\operatorname{Re}\widehat\mu(t)\ge1-Ft^2/8\) and
\(|\widehat\mu(t)-1|\le|t|\sqrt F/2\). Choose
\(t=\alpha/\sqrt{1+F}\), with fixed sufficiently small \(\alpha>0\).
For small \(\epsilon\), the matrix
\(X=\widehat C(t)/\widehat\mu(t)\) lies in the neighborhood in (4), while
the denominator is bounded away from zero. Combining (4) and (7) yields
\[
 \epsilon\ge c_4(1+F)^{-k/2}.
\]
Infimizing proves the lower bound in (1), and excludes a finite exact
resource whenever \(k<\infty\).

## 4. Continuous positive profiles for the upper bound

Use the even positive probability density
\[
 f(x)=\frac{\operatorname{sinc}^4x+
       \operatorname{sinc}^4(x+\pi/2)+
       \operatorname{sinc}^4(x-\pi/2)}{2\pi},
 \qquad\operatorname{sinc}x=\sin(x)/x.
\]
Each summand integrates to \(2\pi/3\). The sine and cosine zeros do not
coincide. Compactness on bounded intervals and the explicit tails give
\(c/(1+x^4)\le f(x)\le C/(1+x^4)\). Every fixed derivative is bounded by
a constant times \(f\); differentiating its explicit tails proves this
outside a compact interval. Its Fourier transform is supported on
\([-4,4]\), and it has finite second moment.

Set \(p_W(x)=W^{-1}f(x/W)\), whose second moment is \(M_fW^2\).
In fact \(M_f=3/4+\pi^2/6\), by integrating \(x^2\operatorname{sinc}^4x\)
and translating the other two terms.
For finite \(k\), choose a feasible joint solution through order \(k-1\)
and define
\[
 C_W(x)=\sum_{\ell=0}^{k-1}\frac{(-1)^\ell C_\ell}{\ell!}
                                  p_W^{(\ell)}(x).        \tag{9}
\]
For sufficiently large \(W\),
\(\tfrac12p_WI\le C_W\le\tfrac32p_WI\), and \(\int C_W=I\).
Taylor-expand \(p_W^{(\ell)}(x-f_j)\) through order \(k-1-\ell\).
The coefficient of \((-1)^m p_W^{(m)}(x)/m!\) in the sector Gram is
\(\sum_{h=0}^m{m\choose h}\Omega_h(C_{m-h})=H_A^m\).
It therefore matches the expansion of \(\sum_i p_W(x-e_i)|i\rangle\langle i|\).
Derivative and shift-ratio bounds control the remainder uniformly in \(x\):
\[
 \|L_W(x)-G_W(x)\|\le c_5W^{-k}p_W(x).                  \tag{10}
\]

For \(k=\infty\), take the analytic solution \(C(u)\) of (3). Choose a real
even smooth cutoff \(\chi\), supported inside its analytic neighborhood
and equal to one near zero. Let \(R\) be the inverse Fourier transform of
\(\chi(t)C(it)\), with transform convention \(\widehat f(t)=\int e^{itx}f(x)dx\).
Then \(R(x)\) is Hermitian and Schwartz, and \(\int R=I\).
Define \(C_W=p_W*R\). The bound on \((\log p_W)'\) implies, for each fixed
\(y\), \(p_W(x-y)/p_W(x)\to1\) uniformly in \(x\). The tail comparison
also gives the uniform dominating bound \(c(1+|y|)^4\) for \(W\ge1\).
Consequently \(C_W(x)/p_W(x)\to I\) uniformly in \(x\). Fix one sufficiently
large \(W\) so that \(C_W\) is positive and the Fourier support of \(p_W\)
lies where \(\chi=1\). Fourier-transforming (3) then gives
\[
 L_W(x)=G_W(x)\quad\hbox{for every }x.                    \tag{11}
\]
Only this one finite second moment is needed for the bounded branch.

## 5. Finite physical implementation

Apply the fully proved translated-fibre lemma in
[finite-resource-lemma.md](finite-resource-lemma.md) to (9)--(11).
Its hypotheses hold with ratio and domination constants uniform for
\(W\) above the fixed lower cutoff. Thus any positive additional error
\(t\) is attainable by a finite resource with
\[
 D_{\rm ch}(\Psi,\Phi)\le c_6W^{-k}+t,\qquad
 F_Q\le4M_fW^2+t                                      \tag{12}
\]
in the finite-order case. Choose \(W\) a sufficiently large multiple of
\(\epsilon^{-1/k}\) and \(t<\epsilon/2\). This proves the matching upper
bound. In the infinite-order case the first term in (12) is absent; keep
\(W\) fixed and let \(t\) tend to zero. The QFI stays bounded.

For clarity, the finite-resource lemma first averages translated lattice
fibres using their scalar masses, normalizes each energy-sector Gram,
truncates every clock, and finally takes a finite ensemble. It uses neither
Poisson summation nor an approximate replacement of the system energies.
Sharp blank registers are charged at zero QFI, and finite unitary completion
is explicit. No infinite clock or continuous classical flag remains in the
operational protocol.

## 6. Why finitely many joint systems suffice

Let \(N={b+p-1\choose p}\). A \(p\)-minor of \(\mathcal L(u)\) is an
exponential polynomial with at most \(N\) distinct frequencies, since each
term sums \(p\) output energies. A nonzero exponential polynomial with
\(n\) distinct real frequencies has vanishing order at most \(n-1\):
vanishing of its first \(n\) derivatives would give an invertible
Vandermonde system with all coefficients zero. Thus the sum of the
nonzero Smith exponents is at most \(N-1\). Every divisibility or
prescribed-constant obstruction in a nonzero row appears by that order.

An augmented \((p+1)\)-minor of
\([\mathcal L(u)\mid e^{uH_A}]\) has at most \(aN\) frequencies. If the
augmented rank exceeds \(p\), at least one such minor is nonzero, with
order at most \(aN-1\). In Smith coordinates its determinantal ideal is
generated by the product of the nonzero diagonal entries times the
right-hand-side zero-row coordinates. Consequently the first nonzero
zero-row residual appears by order \(aN-1\) as well. If the augmented rank
is \(p\), these zero rows vanish identically. This proves (2).

Scalar energy origins change \(C(u)\) by a nonzero scalar exponential
with constant one; they preserve first infeasible order. Changing a minimal
Kraus basis changes all coefficient matrices by a fixed unitary conjugation
(with the consistent transpose convention), and also preserves feasibility.

## 7. Zero cost and the bounded nonzero branch

The standard QFI speed bound also specifies when the bounded branch can
have zero limit. Write
\(\Phi_t=\mathcal U_B(-t)\circ\Phi\circ\mathcal U_A(t)\), with
\(\mathcal U_X(t)(\rho)=e^{-itH_X}\rho e^{itH_X}\), and let
\(\Delta_t=D_{\rm ch}(\Phi_t,\Phi)\). A covariant processor with resource
\(\eta\) realizes \(\Psi_t\) by replacing its resource with the oppositely
translated state. The Bures-angle length of this orbit is at most
\(|t|\sqrt{F_Q(\eta,H_R)}/2\). Purified distance is at most that angle.
Contractivity and the channel-distance triangle inequality therefore give
\[
 \Delta_t\le2\epsilon+\frac{|t|\sqrt F}{2},\qquad
 F_c^\epsilon\ge
 \frac{4(\Delta_t-2\epsilon)_+^2}{t^2}\quad(t\ne0).         \tag{13}
\]
This is an inherited speed-limit argument, not a new QFI inequality.

A covariant channel has a finite covariant Stinespring dilation and can
be implemented with sharp blank registers by the finite unitary completion
in the resource lemma. Its exact QFI cost is zero. For a noncovariant
channel, some \(\Delta_t>0\); (13) gives a strictly positive lower constant
at small error. Thus the small-error alternatives sharpen to:

- covariant target: exact cost zero;
- noncovariant target with \(k=\infty\): \(F_c^\epsilon=\Theta(1)\);
- finite \(k\): \(F_c^\epsilon=\Theta(\epsilon^{-2/k})\).

More generally let \(d_{\rm cov}\) be the minimum purified channel distance
from \(\Phi\) to the compact set of covariant channels. At every error,
\[
 F_c^\epsilon(\Phi)=0\quad\Longleftrightarrow\quad
                        \epsilon\ge d_{\rm cov}.         \tag{14}
\]
The reverse implication uses a minimizing covariant channel and its
zero-QFI implementation. For the forward implication take implementations
with QFI tending to zero, extract a convergent subsequence of their Choi
matrices, and apply the orbit bound to their channels for each fixed \(t\).
The limit is covariant and remains in the closed error ball. No convergence
or dimension bound for the resource states is needed.

## Original coverage and inherited material

This proves the proposed sharp small-positive-error alternatives. It does
not classify all finite exact implementations when \(k=\infty\), and it
does not determine the separate deterministic-work cost. A bounded
positive-error limit can coexist with infinite exact cost; the existing
R268/R337 examples already establish that distinction and are not new
results of this task.

The \(k=1\) condition is
\(H_A-\Phi^*(H_B)\notin\operatorname{span}_{\mathbb R}\{K_\alpha^*K_\beta\}_{\rm Herm}\).
It is the inherited Hamiltonian-not-in-Kraus-span condition. Its inverse-square
branch is not claimed as a new result: compare Zhou--Jiang,
[arXiv:2003.10559](https://arxiv.org/abs/2003.10559), and Tajima--Takagi,
[arXiv:2404.03479](https://arxiv.org/abs/2404.03479). Their Proposition S.11
also already covers finite exact cost in the relative interior of the
Gibbs-preserving set. The candidate contribution is the joint higher-order
classification and its arbitrary-spectrum finite-resource achievability.
The previous measurement subclass and R337 theorem statement retain their
predecessor credit. This task strengthens and completes the proof interface;
it does not count the statement again as a separate discovery.
