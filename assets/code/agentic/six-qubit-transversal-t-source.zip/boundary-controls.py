"""Exact controls for the small-support lemma and a known seven-qubit code.

The published positive control is from Zhang et al., arXiv:2504.20847v1,
Section 6.3.1, at its two free phases equal to zero. It is prior work.
"""
from itertools import combinations, product
import sympy as s

# Local X maps the first vertex to zero. Every distinct second vertex and
# every cube vertex are checked, using only integers.
for b in range(1, 64):
    weight=b.bit_count()
    for x in range(64):
        value=weight*x.bit_count()-(x&b).bit_count()**2
        assert value>=0
        assert (value==0) == (x==0 or x==b)
print('All 63 normalized two-point supports and all 64 vertices: quadratic zero set exact.')

n=7
a={int(word,2):amp/4 for word,amp in [
    ('0000000',s.Integer(1)), ('0111100',s.sqrt(3)),
    ('1001110',s.sqrt(3)), ('1010101',s.sqrt(2)),
    ('1011001',s.sqrt(2)), ('1110010',s.Integer(1)),
    ('0100011',2*s.I)]}
b={127^word:amp for word,amp in a.items()}
code=(a,b)

def element(left,right,ops):
    ans=s.Integer(0)
    for word,amp in right.items():
        phase=s.Integer(1); target=word
        for bit,op in ops:
            z=(word>>bit)&1
            if op=='X': target ^= 1<<bit
            elif op=='Y': target ^= 1<<bit; phase *= s.I*(-1)**z
            else: phase *= (-1)**z
        ans += s.conjugate(left.get(target,0))*phase*amp
    return s.simplify(ans)

checked=0
for weight in (0,1,2):
    for sites in combinations(range(n),weight):
        for paulis in product('XYZ',repeat=weight):
            ops=tuple(zip(sites,paulis))
            c=element(a,a,ops)
            assert element(b,b,ops)==c
            assert element(a,b,ops)==0 and element(b,a,ops)==0
            if weight==0: assert c==1
            checked+=1
assert checked==211
# Source exponents are in most-significant-bit order. Residue 7 implements
# T dagger; seventh power implements T without changing the code.
k=(1,2,2,2,2,3,3)
def residue(word): return sum(k[j]*((word>>(6-j))&1) for j in range(7))%8
assert {residue(x) for x in a}=={0}
assert {residue(x) for x in b}=={7}
assert {7*residue(x)%8 for x in b}=={1}
print('Published seven-qubit positive control: all 211 weight<=2 Pauli compressions exact; logical T exact after seventh power.')
print('This control is attributed prior work; it is not a new result or part of a six-qubit exclusion.')

signature=0
for weight in (1,2):
 for sites in combinations(range(7),weight):
  for paulis in product('XYZ',repeat=weight):
   c=element(a,a,tuple(zip(sites,paulis)));signature+=s.conjugate(c)*c
signature=s.simplify(signature);assert signature==s.Rational(21,8)
print('Published seven-qubit control signature squared = 21/8, exactly noninteger; local-unitary stabilizer equivalence excluded.')
