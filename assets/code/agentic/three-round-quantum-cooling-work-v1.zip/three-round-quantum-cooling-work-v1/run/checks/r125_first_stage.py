from pathlib import Path
import itertools,json,time,numpy as np
from p11_free_pulses_common import E,p,b
from p11_first_stage_common import q,Zsm,profile_controls,enumerate_profile,suffix_bounds
if __name__=='__main__':
 start=time.time();old=json.loads(Path('run/checks/r123_focused.result.json').read_text());y=(np.array(old['population']['dual'])+np.array(old['quantum']['dual']))/2;globalp=np.kron(np.kron(np.kron(p,b),b),b);cap=float(np.sort(globalp)@np.sort(np.repeat(y,27))-y@p);profiles=[];arrays=[];controls=[];profile_ids=[];bounds=[];lams=[];offset=0
 for profile in sorted(set(itertools.permutations(E.tolist()))):
  rho=q**np.array(profile)/Zsm;w=float(E@(rho-p))
  if w<1e-10 or w>cap+1e-10:continue
  N,U,info=enumerate_profile(profile);states=N@(q**np.arange(6))/(Zsm*(1+q+q*q));ub,knots,idx=suffix_bounds(states,w,y);assert np.max(abs(states.sum(axis=1)-1))<1e-12
  rec=dict(profile=list(profile),V=profile_controls(profile).tolist(),first_work=w,offset=offset,**info,negative_suffix_bound=int(np.sum(ub<-1e-10)),maximum_suffix_bound=float(max(ub)),minimum_suffix_bound=float(min(ub)));print(json.dumps(rec),flush=True);profiles.append(rec);arrays.append(N);controls.append(U);profile_ids.extend([len(profiles)-1]*len(N));bounds.extend(ub.tolist());lams.extend(knots[idx].tolist());offset+=len(N)
 N=np.concatenate(arrays);U=np.concatenate(controls);np.savez_compressed('run/checks/r125_first_stage_states.npz',coefficients=N,collisions=U,profile_ids=np.array(profile_ids,dtype=np.int16),suffix_bounds=np.array(bounds),suffix_lambdas=np.array(lams))
 result=dict(price=y.tolist(),global_reward_cap=cap,profiles=profiles,distinct_profile_states=len(N),negative_suffix_bound=sum(x['negative_suffix_bound'] for x in profiles),candidate_states=int(np.sum(np.array(bounds)>=-1e-10)),maximum_suffix_bound=max(bounds),seconds=time.time()-start,scope='exact integer first-stage enumeration for14 active profiles under a floating profile filter; suffix bounds are numerical quantum relaxations, not certified exclusions');Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='profiles'},indent=2))
