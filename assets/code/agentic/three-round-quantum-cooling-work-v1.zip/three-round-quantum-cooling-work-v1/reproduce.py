"""Reproduce the P11 certificate in a new, isolated temporary directory.

Requires Python 3 and NumPy. No network access and no paid services are used.
Do not run Python with -O: the numerical certificate uses assertions.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
STEPS = [
    ["r125_first_stage.py"],
    ["r125_first_stage_certificate.py"],
    ["r126_prefix_certificate.py"],
    ["r128_scaled_price_certificate.py"],
    ["r130_p11_frontier.py"],
    ["r131_p11_complete_suffix.py", "--all"],
    ["r131_p11_tail_certificate.py"],
    ["r131_p11_audit.py"],
    ["r131_p11_gap_certificate.py"],
    ["p11_r131_independent_arithmetic.py"],
]


def main():
    if not __debug__:
        raise SystemExit("Assertions must be enabled; do not use Python -O.")
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for name, expected in manifest["files"].items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Input hash mismatch: {name}")
    scratch = Path(tempfile.mkdtemp(prefix="p11-work-v1-"))
    shutil.copytree(ROOT / "run", scratch / "run")
    print(f"Verified {len(manifest['files'])} packaged files.", flush=True)
    print(f"Output directory: {scratch}", flush=True)
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1")
    env.pop("PYTHONOPTIMIZE", None)
    started = time.time()
    records = []
    for index, args in enumerate(STEPS, 1):
        log = scratch / f"step-{index:02d}.log"
        then = time.time()
        with log.open("w") as stream:
            result = subprocess.run(
                [sys.executable, "run/checks/" + args[0], *args[1:]],
                cwd=scratch, env=env, stdout=stream, stderr=subprocess.STDOUT,
            )
        records.append({"step": args[0], "returncode": result.returncode,
                        "seconds": time.time() - then})
        print(f"{index:02d}/{len(STEPS)} {args[0]}: "
              f"{'PASS' if result.returncode == 0 else 'FAIL'}", flush=True)
        if result.returncode:
            print(log.read_text()[-6000:], flush=True)
            raise SystemExit(result.returncode)
    checks = scratch / "run/checks"
    gap = json.loads((checks / "r131_p11_gap_certificate.result.json").read_text())
    tail = json.loads((checks / "r131_p11_tail_certificate.result.json").read_text())
    dyadic = json.loads((checks / "p11_r131_independent_arithmetic.result.json").read_text())
    summary = {
        "success": True, "steps": records, "seconds": time.time() - started,
        "gamma": gap["gamma"], "delta": gap["delta"],
        "quantum_upper": gap["quantum_upper"],
        "population_lower": gap["population_lower"],
        "population_feasible_upper": gap["population_feasible_upper"],
        "strict_gap": gap["strict_gap"],
        "frontier_count": tail["frontier_count"],
        "post_U2_states": tail["post_U2_states"],
        "remaining_unclosed_states": tail["remaining_unclosed_states"],
        "dyadic_gap": dyadic["strict_gap"],
        "identity_control_passed": dyadic["identity_control_passed"],
        "invalid_collision_rejected": dyadic["invalid_collision_rejected"],
        "review": "Same-agent reproduction and different arithmetic implementation; not independent expert review.",
    }
    (scratch / "reproduction-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
