"""Exact adversarial controls for the uniform tail proof.
The test does not assert any global theorem by numerical extrapolation.
"""
from pathlib import Path
import json
import sympy as s
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);Z=s.diag(1,-1);J=s.Matrix([[0,1],[-1,0]]);D=Z
Es=[(I+x*X+y*Y+z*Z)*J/(2*s.sqrt(2)) for x,y,z in [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]]
checks=[]
def simp(A):return A.applyfunc(s.simplify) if isinstance(A,s.MatrixBase) else s.simplify(A)
def eq(a,b,name):
 z=simp(a-b);ok=all(t==0 for t in z) if isinstance(z,s.MatrixBase) else z==0
 assert ok,(name,z);checks.append(name)
def norm2(A):return simp(s.trace(A.H*A))
# General polynomial identity, without invertibility or scalar nonzero assumptions.
v=s.symbols('x0:4');w=s.symbols('y0:4');c=s.symbols('c')
XX=s.Matrix(2,2,v);YY=s.Matrix(2,2,w);ZZ=c*I-XX*YY
K=YY*XX; left=c*(K-s.trace(K)*I/2);right=YY*ZZ.adjugate()*XX;right-=s.trace(right)*I/2
eq(s.expand(left),s.expand(right),'generic adjugate polynomial')
# Non-Hermitian complex, rectangular and zero-contraction branches.
for j,E in enumerate(Es):
 for c0 in [s.Rational(2,3),s.I,0]:
  for tail in [1,3]:
   L0=s.diag(s.Rational(3,5),s.Rational(2,5));Lt=s.diag(*[s.Rational(1,7+i) for i in range(tail)])
   A0=s.Matrix([[1,s.I],[1,2]]);At=s.Matrix(2,tail,lambda i,k:s.Rational(i+k+1,3)+s.I*(i-k));Bt=s.Matrix(2,tail,lambda i,k:s.Rational(2*i-k,5)+s.I*(i+k+1))
   T=At*Lt*Bt.T;B0t=(A0*L0).inv()*(c0*E-T);B0=B0t.T
   f=s.trace(D*B0.T*E.inv()*A0*L0);Q=A0*L0*D*B0.T
   eq(c0*f,s.trace(T.adjugate()*Q)/E.det(),f'scalar identity j{j} c{c0} tail{tail}')
# A physical higher-rank LOCC positive control: deterministic conversion
# (1/2,1/3,1/6) -> a Bell pair on pairs 01 and 02, followed by teleportation.
lam=[s.Rational(1,2),s.Rational(1,3),s.Rational(1,6)];L=s.diag(*[s.sqrt(v) for v in lam]);L0=L[:2,:2];Lt=L[2:,2:]
pairs=[((0,1),s.Rational(2,3)),((0,2),s.Rational(1,3))]
Sjs=[s.zeros(36) for _ in range(4)];f_sum=[0]*4;c_norm=[0]*4;Tnorm=0;Qnorm=0;zero=0;zero_mass=0;zero_trace=0
Ps=[I,X,Y,Z]
for pair,weight in pairs:
 for a,P in enumerate(Ps):
  A=s.zeros(2,3)
  for bit,idx in enumerate(pair):
   for i in range(2):A[i,idx]=P[i,bit]/s.sqrt(2)*s.sqrt(weight/(2*lam[idx]))
  bs=[]
  for j,E in enumerate(Es):
   B=s.zeros(2,3);Bsmall=(P.H*E).T
   for bit,idx in enumerate(pair):B[:,idx]=Bsmall[:,bit]
   bs.append((j,B,s.sqrt(weight)/2))
  omitted=next(i for i in range(3) if i not in pair)
  for bit in range(2):
   B=s.zeros(2,3);B[bit,omitted]=1;bs.append((0,B,0))
  for j,B,c0 in bs:
   eq(A*L*B.T,c0*Es[j],f'physical contraction {pair} a{a} j{j} null{c0==0} b{len(checks)}')
   av=s.Matrix(list(A));bv=s.Matrix(list(B));prod=s.kronecker_product(av,bv)
   Sjs[j]+=prod*prod.H
   T=A[:,2:]*Lt*B[:,2:].T;Q=A[:,:2]*L0*D*B[:,:2].T
   f=s.trace(D*B[:,:2].T*Es[j].inv()*A[:,:2]*L0)
   f_sum[j]+=s.conjugate(c0)*f;c_norm[j]+=s.conjugate(c0)*c0
   Tnorm+=norm2(T);Qnorm+=norm2(Q)
   if c0==0:
    zero+=1;zero_mass+=norm2(T)+norm2(Q);zero_trace+=norm2(A)*norm2(B)
Sjs=[simp(M) for M in Sjs]
eq(sum(Sjs,s.zeros(36)),s.eye(36),'complete physical POVM including zero branches')
eq(Tnorm,4*lam[2],'complete tail energy')
eq(Qnorm,4*(lam[0]+lam[1]),'complete signed top-two energy')
for j,E in enumerate(Es):
 vv=s.Matrix([E[i,k]*L[alpha,beta] for i in range(2) for alpha in range(3) for k in range(2) for beta in range(3)])
 eq(Sjs[j]*vv,vv,f'exact effect eigenvector {j}')
 eq(f_sum[j],2*(lam[0]-lam[1]),f'linear functional on eigenvector {j}')
 eq(c_norm[j],1,f'effect normalization {j}')
# Old PPT witness gives a strict rational violation, so no SEP inference is valid.
p,q,tail=s.Rational(144,226),s.Rational(81,226),s.Rational(1,226)
margin=(p-q)**2-4*(1-tail)*tail
eq(margin,s.Rational(3069,51076),'PPT witness strictly violates necessary SEP bound')
assert margin>0
# Rank-two nonmaximal resources fail; a Bell pair saturates.
assert (s.Rational(3,5)-s.Rational(2,5))**2>0
eq((s.Rational(1,2)-s.Rational(1,2))**2,0,'Bell boundary')
# Entropy proof's positive logarithmic margin: exact rational lower bound.
assert s.Rational(7,3)>s.Rational(9,4)
mutations={'replace_E_inverse_by_transpose_detected':False,'omit_zero_product_branches_breaks_POVM_trace':simp(zero_trace)>0,'PPT_is_not_SEP_detected':margin>0}
E=Es[0];A=s.Matrix([[1,0],[0,1]]);B=(s.I*E).T;Lmut=s.eye(2)
correct=s.trace(D*B.T*E.inv()*A*Lmut)
bad=s.trace(D*B.T*E.T*A*Lmut)
mutations['replace_E_inverse_by_transpose_detected']=simp(correct-bad)!=0
assert all(mutations.values()),mutations
out={'status':'PASS','exact_checks':len(checks),'checks':checks,'physical_resource':[str(t) for t in lam],'zero_contraction_terms':zero,'zero_terms_T_plus_Q_norm2':str(simp(zero_mass)),'zero_terms_POVM_trace':str(simp(zero_trace)), 'rejected_mutation':'In this particular positive control the zero branches have zero T and Q as well. Dropping them does not change those two norm sums; the invalid expectation was removed. They are required for full POVM completeness.','ppt_rejection_margin':str(margin),'mutations':{k:bool(v) for k,v in mutations.items()},'scope':'Exact algebra, a real higher-rank LOCC protocol, zero-branch completeness and rational negative controls. Uniform proof remains required.'}
Path(__file__).with_name('ejm-tail-exact-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
