# Audit of the finite thermal selector and exact target correction

25 November 2026 UTC. Same-root analytical review; no independent audit.
This clarifies the noncompact step of `general-work-support-minimax-v1.md`
and its use in `general-work-face-separation-v1.md`. It is verification of
those claims, not another research result or another round.

## The compact interval and the tail must be treated together

Write A_i(u),B_i(u)>0 for the finite input/output partition sums, with
input ground energy zero, and R_i=Z_B B_i/(Z_A A_i). There are finitely
many profiles. Assume at each u>=beta one R_i(u)<exp(uW), and that
lim_(u->infinity)log R_0(u)/u<W. Enlarge U until

  R_0(u)/exp(uW)<=1/2 for all u>=U.

On [beta,U+1], a continuous partition of unity subordinate to the strict
good-profile neighborhoods gives weights with positive slack. Blend to
weight one on profile zero before the endpoint; profile zero is good in
that overlap. Make its weight positive everywhere by adding a sufficiently
small amount of it on the compact part. The compact slack survives. Thus
w_0>0, w_i=0 for i!=0 and u>=U+1, and the resulting weighted ratio has
strict slack everywhere.

Set t=exp(-h u), h>0. The desired factors q_i=w_i/A_i are continuous on
[0,exp(-h beta)], because A_i has a finite nonzero limit at t=0. Also
q_0 is bounded below by a positive constant. For i!=0 choose one integer
K large enough that

  t^K B_i(u)/B_0(u) is bounded for all u>=beta

and tends to zero at infinity. Such a K exists because these are finite
exponential sums. The functions q_i/t^K are continuous and zero near t=0.

Use s=t/(1+t). Extend all these nonnegative continuous functions to [0,1]
in the s variable, keeping q_0 strictly positive. Ordinary Bernstein
polynomials approximate them uniformly with nonnegative Bernstein
coefficients. In t coordinates they are P_i(t)/(1+t)^N with P_i having
nonnegative MONOMIAL coefficients. For i!=0 multiply the numerator by
t^K, then degree-elevate to a common denominator. Choose the approximation
error small enough that the approximant for q_0 stays bounded below.

On the finite u interval, uniform approximation and strict slack directly
control the partition ratio. In the tail, unwanted factors are at most
delta t^K, while the profile-zero factor stays bounded below. Therefore

  R_mix(u)/R_0(u) <= 1+C delta

there, for a constant determined by the finite profiles and the chosen K.
Combining with R_0/exp(uW)<=1/2, then choosing delta small, preserves the
inequality throughout the tail. This closes the noncompact estimate.

The common denominator cancels in the ratio. Scale each nonzero numerator
coefficient by the same sufficiently large number and round to an integer,
keeping zero coefficients zero. Relative errors of the finitely many
positive coefficients can be made arbitrarily small, so all positive
partition sums change by the same controlled relative factor at EVERY t.
This preserves compact slack, tail slack and the powers t^K. The final
polynomials are literal finite ancillary degeneracy functions, not signed
weights, continuous degeneracies, or an approximate logical channel.

This argument also works when the profile-zero input has ground multiplicity
greater than one. It need not be replaced by a one-dimensional input.
The phrase "high-temperature endpoint" in v1 is a wording error: the
u->infinity endpoint is LOW temperature.

## Why the target equation remains exact

Thermal selection alone produces some channel Psi whose Kraus support is
contained in S. It does not enforce the desired Gibbs mixture at beta.
The separate face-separation argument handles that issue: for a strictly
positive target coefficient T on S and sufficiently small t>0,

  Phi_t=(Phi-t Psi)/(1-t)

is exactly CPTP and covariant. This follows from Choi positivity, not from
approximate numerical correction. The single-temperature index b is a
finite convex function on this finite-dimensional face and is continuous
at its relative interior point Phi. Hence b(Phi_t)->b(Phi).

The energy-separation construction replicates the Phi_t block N times and
uses a real energy offset L_N chosen from an exact logarithmic equation to
keep its beta weight precisely 1-t. Integer degeneracies are exact; real
energy offsets are permitted. For u>beta, that block's weight decays as
N exp(-u L_N), letting the supported selector control the tail. Thus the
channel is EXACTLY Phi for every N, while the work bound approaches the
claimed infimum. No convergence of the channel is substituted for equality.

## Reviewed scope

No flaw was found in these two arguments after this audit. They give
equalities of INFIMA and preserve the normal-countable-bath convention.
They do not provide a finite auxiliary dimension bound, turn arbitrary
tracial factorizations into matrix factorizations, or imply attainment at
the sharp boundary. The general cost is still not evaluated for arbitrary
finite channels. The simplicial work theorem depends on this review.
