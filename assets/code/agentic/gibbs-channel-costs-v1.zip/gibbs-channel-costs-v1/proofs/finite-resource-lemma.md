# Finite resources from translated lattice fibres

24 November 2026. Root derivation and self-review. This replaces the
Poisson-summation interface in the R337 coherence-cost proof. It is a proof
completion for that candidate, not a newly counted original solution.

All systems and the final resource are finite dimensional. Intermediate
integrals and countable isometries below are mathematical constructions;
the last two steps remove both. No restriction on work is imposed. Every
sharp ancillary register used below belongs to the charged resource and
has zero QFI. It is not a free Gibbs state.

## Lemma

Fix a channel with linearly independent Kraus operators
\(K_1,\ldots,K_r:A\to B\), and put
\(V=\sum_\alpha K_\alpha\otimes|\alpha\rangle\).
Use energy eigenbases, with input energies \(e_i\) and output energies
\(f_j\), repeated according to multiplicity. Let \(p(x)>0\) be a scalar
probability density with finite second moment \(M_2\), and let \(C(x)\ge0\)
be an integrable Hermitian matrix density such that
\[
 \int C(x)\,dx=I_r,\qquad \|C(x)\|\le M p(x).
\]
Assume that the ratios \(p(x-s)/p(x)\) are bounded above and below by
positive constants for all the finitely many shifts \(s=e_i,f_j\). Define
\[
 G(x)=\sum_i p(x-e_i)|i\rangle\langle i|,
 \quad L(x)=\sum_j V^*(|j\rangle\langle j|\otimes C(x-f_j))V.
\]
Suppose \(\|L(x)-G(x)\|\le\delta p(x)\) for every \(x\).
The constants below depend on the systems and these ratio bounds, not on
the dimension or support of a constructed clock.

For sufficiently small \(\delta\), every \(t>0\) admits a finite thermal
implementation with
\[
 D_{\rm ch}(\Psi,\Phi)\le c\delta+t,
 \qquad F_Q(\eta,H_R)\le 4M_2+t.
 \tag{1}
\]
If a family of densities has uniform ratio and domination bounds, the
constant \(c\) is uniform for that family. The cost inequality is an
infimum statement in the construction: the finite ensemble and cutoff
can be enlarged until the additive tolerances in (1) are attained.

## 1. Lift the density, and average the origin

After harmless scalar energy shifts, choose rationally independent real
numbers \(\omega_1,\ldots,\omega_q\) and integer vectors \(a_i,b_j\) such
that \(e_i=\omega\cdot a_i\), \(f_j=\omega\cdot b_j\). Such a basis exists
for every finite list of energies. For the zero Hamiltonians take \(q=1\),
\(\omega_1=1\), with all labels zero. Write \(P\) for orthogonal projection
onto \(\omega^\perp\). Fix a strictly positive smooth probability density
\(g\) on that space whose logarithmic gradient is bounded; a normalized
\(\exp(-\sqrt{1+\|y\|^2})\) suffices. For \(q=1\) omit \(g\).

For a transverse width \(T\), put
\[
 \kappa_T=\|\omega\|T^{-(q-1)},\quad
 h_T(x)=\kappa_T p(\omega\cdot x)g(Px/T),\quad
 D_T(x)=\kappa_T C(\omega\cdot x)g(Px/T).
\]
Fubini and the orthogonal change of variables give exactly
\[
 \int_{\mathbb R^q}h_T=1,\quad \int_{\mathbb R^q}D_T=I_r,
 \quad \int(\omega\cdot x)^2h_T(x)\,dx=M_2.                 \tag{2}
\]
These identities use integration, not a claim about point sampling.

For \(s\in[0,1)^q\), set
\[
 Z_s=\sum_{z\in\mathbb Z^q}h_T(z+s),\quad
 p_{s,z}=h_T(z+s)/Z_s,\quad C_{s,z}=D_T(z+s)/Z_s.
\]
Tonelli implies that \(Z_s\) is finite and positive almost everywhere and
\(\int Z_s\,ds=1\). We discard the null exceptional set. The clock energy
of label \(z\) is \(E_{s,z}=\omega\cdot(z+s)\). Rational independence makes
the labels injective. The matrix masses need not sum to \(I_r\) for an
individual fibre. Their correctly weighted average does:
\[
 \int Z_s\sum_z C_{s,z}\,ds=I_r.                         \tag{3}
\]
Likewise the average clock second moment is exactly \(M_2\).

## 2. Normalize the energy sectors

For total energy \(E_{s,z}\), define
\[
 G_{s,z}=\sum_i p_{s,z-a_i}|i\rangle\langle i|,
 \quad L_{s,z}=\sum_jV^*(|j\rangle\langle j|\otimes C_{s,z-b_j})V.
\]
The bound on \(\nabla\log g\) gives, uniformly in \(s,z\),
\[
 g(P(z+s-v)/T)/g(P(z+s)/T)=1+O(T^{-1})
\]
for each fixed label \(v\). Combine this with the continuous residual and
the fixed-shift bounds on \(p\). With
\(u_{s,z}=h_T(z+s)/Z_s\) and \(d_T=\delta+T^{-1}\),
\[
 \|L_{s,z}-G_{s,z}\|\le c_1d_Tu_{s,z},\qquad
 c_2u_{s,z}I\le G_{s,z},L_{s,z}\le c_3u_{s,z}I.            \tag{4}
\]
For \(q=1\) the transverse error is absent. The lower bound for \(L\)
uses sufficiently small \(d_T\); it does not require \(C(x)\) invertible.

Factor \(C_{s,z}=S_{s,z}^*S_{s,z}\) measurably, using the positive square
root, and form Kraus rows
\(A_{a,z}=\sum_\alpha(S_{s,z})_{a\alpha}K_\alpha\).
At total energy \(E_{s,z}\), collect the rows of these operators with output
energy \(f_j\) and environment label \(z-b_j\) in a matrix \(A_{s,z}\).
Its Gram matrix is \(L_{s,z}\). Thus
\[
 T_{s,z}=A_{s,z}L_{s,z}^{-1/2}
\]
is an isometry. Inserting the pure clock with amplitudes
\(\sqrt{p_{s,z}}\) produces dilation rows
\[
 A_{s,z}B_{s,z},\qquad B_{s,z}=L_{s,z}^{-1/2}G_{s,z}^{1/2}.
\]
On the fixed positive spectral interval in (4), the inverse-square-root
and square-root maps are Lipschitz. Rescaling by \(u_{s,z}\) gives
\(\|B_{s,z}-I\|\le c_4d_T\). No commutation of the Gram matrices is used.

## 3. Average first; compare two genuine isometries

The raw rows \(A_{s,z}\) in a single fibre need not define a trace-preserving
channel. This is why normalizing their total coefficient matrix separately
is unnecessary and would complicate the argument. Equation (3) implies
that their direct integral with weights \(Z_sds\) is an isometry whose
channel is exactly \(\Phi\): expand the Kraus coefficients and integrate.

Each normalized fibre does define a trace-preserving channel. Its direct
integral is another isometry, say \(W_T\). The squared Hilbert--Schmidt
distance between these two isometries is at most
\[
 \begin{split}
 &\int Z_s\sum_z
   \operatorname{Tr}[(B_{s,z}-I)^*L_{s,z}(B_{s,z}-I)]\,ds\\
 &\hspace{1cm}\le c_4^2d_T^2\int Z_s\sum_z\operatorname{Tr}L_{s,z}\,ds
   =c_4^2d_A d_T^2.                                      \tag{5}
 \end{split}
\]
Here \(\operatorname{Tr}(LXX^*)\le\|X\|^2\operatorname{Tr}L\) is sufficient;
no operator inequality with \(L\) on the right is asserted. Common
isometries give a purified-distance bound on every reference-assisted
input, so the averaged channel is within \(c_5d_T\) of \(\Phi\).

Its mean pure-clock QFI is at most
\[
 \int Z_s,4\sum_z E_{s,z}^2p_{s,z}\,ds=4M_2.             \tag{6}
\]
The fibre means need not vanish; variance only decreases this bound.

## 4. Make every branch finite

Fix \(0<\tau<1\). In each fibre retain a finite cube of clock labels with
probability at least \(1-\tau^2\). Choose the first such integer cube, making
the choice measurable. The sector isometry still has orthonormal columns
after restricting its input columns. Only finitely many environment labels
are reachable: they have the form \(z+a_i-b_j\) for retained \(z\).
The finite clock differs from the original pure clock by purified distance
at most \(\tau\). Contractivity gives the same channel bound, uniformly in
the input and reference. Its second moment is at most the original second
moment divided by \(1-\tau^2\).

For completeness, these finite sector isometries have an actual thermal
implementation. Include blank output and environment registers among the
resource, initially in sharp states of energies \(b_0,e_0\). Reset the old
input and clock to fixed sharp states of energies \(a_0,r_0\). Give an
occupied output environment label \(z\) energy
\(z+b_0+e_0-a_0-r_0\), and append a separate blank environment level of
energy \(e_0\). Input and output total energies then agree. Extend the
prescribed orthonormal columns to a unitary independently in every finite
energy sector. The bath can be trivial. The blank level is additional, so
there is no circular equation for its energy. Constant Hamiltonian shifts
can make all spectra nonnegative without changing QFI or conservation.

## 5. Remove the continuum of branch labels

The preceding family consists now of finite physical channels. Its Choi
matrix is a bounded measurable function of \(s\), and its nonnegative
QFI cost is integrable with mean at most \(4M_2/(1-\tau^2)\).
Take independent samples from the probability measure \(Z_sds\).
The strong law, applied to the finitely many real Choi entries and this
one cost variable, provides finite empirical ensembles whose average
channel and cost approach those means. This is an existence argument for
a finite ensemble; it does not introduce an operational continuous flag.

Choi convergence implies diamond-norm convergence in fixed dimension and
hence uniform purified channel-distance convergence. Store the finitely
many branch labels in an invariant classical register and use the direct
sum resource Hamiltonian. The QFI of a flagged direct sum is exactly the
average branch QFI, as follows directly from its spectral formula. The
controlled finite energy-conserving implementations are again a finite
thermal operation. No bound on ancillary dimension or runtime is claimed.

Finally send \(T\) large, then \(\tau\) small, and take a sufficiently large
finite ensemble. The error is \(c\delta+o(1)\) and the cost at most
\(4M_2+o(1)\), proving (1).

## Audit notes

- Normalizing each raw fibre as if its coefficients summed to identity
  would be wrong. The proof only uses identity after weighted integration.
- The origin measure is \(Z_sds\), not uniform \(ds\).
- The finite ensemble approximation must control both Choi entries and
  cost; channel convergence alone would not bound the mean energy variance.
- This avoids all Diophantine estimates and Poisson summation. It does not
  replace the band-limited-profile argument used to obtain an exactly
  balanced continuous density in the bounded-cost branch of the theorem.
- It proves finite approximations at positive error. Taking its limits is
  not a finite implementation at zero error.
