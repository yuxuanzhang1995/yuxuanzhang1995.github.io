# Third-level Clifford-hierarchy gates on at most six qubits are semi-Clifford

Yuxuan Zhang. Research preprint, 26 September 2026.
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

The complete mathematical argument is in `semi-clifford-six-qubits.tex`. The paper is a proof candidate reviewed only by AI (three
isolated adversarial reviews and a final audit, `INTERNAL_REVIEW.json`). **No independent human expert has examined
the argument, and neither external peer review nor human novelty certification is recorded.** AI assistance is
disclosed in the paper.

**Result.** Every gate in the third level of the Clifford hierarchy on n ≤ 6 qubits is semi-Clifford — explicitly,
C₁D₁·π·D_h·D₂C₂ with π a single layer of Toffoli gates with disjoint controls and targets and D_h a product of T,
controlled-S and CCZ gates on the non-target qubits. With a certified seven-qubit gate in C₃(7) ∖ SC(7), the least
number of qubits carrying a non-semi-Clifford third-level gate is **n_min = 7**, settling the open cases n = 5 and
n = 6. The only published results the proof uses are Beigi–Shor, Theorem 1.1 (QIC 2010) and Zeng–Chen–Chuang,
Proposition 2 (PRA 2008).

## Reproduce the computation

`check_c3_n5_n6.py` uses **only the Python standard library** and runs on CPython 3.10 or later:

```sh
python3 check_c3_n5_n6.py | diff - expected_stdout.txt && echo BYTE-EXACT
```

Or with no network at all:

```sh
docker run --rm --network=none -v "$PWD":/workspace:ro python:3.12-slim \
  python /workspace/check_c3_n5_n6.py | diff - expected_stdout.txt
```

It prints 54 lines in about seven seconds. The lines cover the class census, two independent derivations of each of
the ten admissible-phase groups with kernel certificates, the generated-subgroup comparison of Theorem 12, the
Lagrangian checks, the third-level diagonal classification for n = 1…6, and three controls. `mutate.py` applies 20
single-point mutations, each of which makes the program exit nonzero (`MUTATION_REPORT.txt`). Reproduction confirms only that the program computes what the paper describes; the reductions it
relies on are established by the written argument. `reproduction.json` records the isolated runs and
`INTERNAL_REVIEW.json` the three independent AI adversarial reviews.

## Build the manuscript

Compile `semi-clifford-six-qubits.tex` twice with pdfLaTeX (amsmath, amsthm, amssymb, mathtools, geometry, lmodern, microtype, xcolor,
hyperref). `EVIDENCE.json` gives primary-source locators for every external claim; source inspection was performed by
AI, and independent human verification remains unrecorded.

The scientific-writing guidance from K-Dense's Scientific Agent Skills was consulted at commit
330c8e764435a731eff571e3efdda70b363d0792 and is cited in the manuscript. Its evidence workflow was followed
selectively: a source register (`EVIDENCE.json`) and an evidence-mapped claims outline (`OUTLINE.md`) were written
before the prose. The skill's bundled audit scripts were not executed; their checks were carried out by hand and by
the final internal audit.

## Caution for readers

Two steps are computer-assisted: the inclusion A_π ⊆ Cliff + Cliff∘π + H_π for the ten layer classes (Theorem 12) and
the transitivity of GL(4,2) on each nondegenerate line type of the Klein quadric (Proposition 10). Everything else,
including the seven-qubit upper bound (Proposition 17), is proved by hand and confirmed by the program. Scrutiny should
start with the program's two independent derivations of each A_π and with the kernel certificate described in §9.

The program's output uses a few internal labels: "Lemma A" is Lemma 5, the "Lemma-C certificate" is the kernel
certificate of §9, "Step 3" is Lemma 11, "Theorem 1" is Theorem 12, "Step 6" is Remark 15, and the "M9 control" is the
control "Toffoli times T on an idle qubit". Mutant identifiers follow the earlier development checker; M4 is unused.
