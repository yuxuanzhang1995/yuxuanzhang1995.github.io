"""Checks the six source representatives, their orbits, and the control's identity.

Source: Jose Diogo da Costa Jesus, 2022 master's thesis, Table A.4 (printed
page 74, PDF page 90), and Table 5.4. Numerical coefficient data are
transcribed from the public institutional PDF. This checks their validity,
facet rank, orbit sizes, and distinctness. It does NOT prove that the union
of these orbits is the whole facet set.
"""
from itertools import product, permutations
from pathlib import Path
import json
from independent_control import H, rank_mod

HERE = Path(__file__).resolve().parent
SOURCE_URL = 'https://fenix.tecnico.ulisboa.pt/downloadFile/1970719973970056/Thesis_JJ.pdf'
# joint coefficients (5 rows, 3 columns), five Alice marginals,
# three Bob marginals, and upper bound, exactly as in Table A.4.
REPRESENTATIVES = {
    'CHSH': [1,1,0,1,-1,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,-1,0,0,0],
    'I3322': [1,1,1,1,1,-1,1,-1,0,0,0,0,0,0,0,-1,0,0,0,0,-2,-1,0,0],
    'I4322_1': [1,1,1,1,1,-1,1,-1,1,1,-1,-1,0,0,0,-1,0,0,1,0,-3,0,0,1],
    'I4322_2': [1,1,1,1,0,-1,1,-1,0,0,1,-1,0,0,0,-1,0,0,0,0,-2,-1,0,0],
    'I4322_3': [2,1,1,1,-1,-1,1,-1,-1,0,1,-1,0,0,0,-2,1,0,0,0,-2,0,1,1],
    'I5322': [1,1,1,1,1,1,1,0,-1,1,-1,0,0,1,-1,-1,-2,0,0,0,-2,-1,0,0],
}
EXPECTED_ORBITS = {'CHSH':240, 'I3322':5760, 'I4322_1':11520,
                   'I4322_2':15360, 'I4322_3':23040, 'I5322':15360}


def normal(vector):
    assert len(vector) == 24
    # Exchange the source's parties and reverse <= into >=.
    return (vector[-1], *(-x for x in vector[20:23]),
            *(-x for x in vector[15:20]),
            *(-vector[3*y+x] for x in range(3) for y in range(5)))


def flipped(h, u, v):
    # Source bit a_i = u_i+(1-2u_i)*new_a_i; likewise for b_j.
    k, a, b = h[0], h[1:4], h[4:9]
    c = [h[9+5*i:14+5*i] for i in range(3)]
    constant = k + sum(a[i]*u[i] for i in range(3)) + sum(b[j]*v[j] for j in range(5))
    constant += sum(c[i][j]*u[i]*v[j] for i in range(3) for j in range(5))
    new_a = [(1-2*u[i])*(a[i]+sum(c[i][j]*v[j] for j in range(5))) for i in range(3)]
    new_b = [(1-2*v[j])*(b[j]+sum(c[i][j]*u[i] for i in range(3))) for j in range(5)]
    new_c = [[c[i][j]*(1-2*u[i])*(1-2*v[j]) for j in range(5)] for i in range(3)]
    return constant, new_a, new_b, new_c


def orbit(h, target):
    output = set()
    found = None
    for flips in product((0, 1), repeat=8):
        u, v = flips[:3], flips[3:]
        k, a, b, c = flipped(h, u, v)
        for pa in permutations(range(3)):
            for pb in permutations(range(5)):
                candidate = (k, *(a[i] for i in pa), *(b[j] for j in pb),
                             *(c[i][j] for i in pa for j in pb))
                output.add(candidate)
                if candidate == target and found is None:
                    found = {'flipped_old_alice_indices_zero_based': [i for i,z in enumerate(u) if z],
                             'flipped_old_bob_indices_zero_based': [i for i,z in enumerate(v) if z],
                             'new_alice_to_old_after_party_swap': pa,
                             'new_bob_to_old_after_party_swap': pb}
    return output, found


def main():
    vertices = [(1, *a, *b, *(x*y for x in a for y in b))
                for a in product((0,1), repeat=3) for b in product((0,1), repeat=5)]
    target = (3,0,-1,-2,0,0,0,-1,-2,*(z for row in H for z in row))
    seen = set()
    results = {}
    identity = None
    for name, data in REPRESENTATIVES.items():
        h = normal(data)
        slacks = [sum(x*y for x,y in zip(h,p)) for p in vertices]
        assert min(slacks) == 0
        saturated = [p for p,z in zip(vertices,slacks) if z==0]
        assert rank_mod(saturated) == 23
        relabelings, match = orbit(h, target)
        assert len(relabelings) == EXPECTED_ORBITS[name], (name,len(relabelings))
        assert seen.isdisjoint(relabelings)
        seen.update(relabelings)
        results[name] = {'vertices_tested':len(vertices), 'minimum_slack':min(slacks),
                         'saturating_vertices':len(saturated),
                         'augmented_facet_rank_lower_bound_mod_1000003':rank_mod(saturated),
                         'orbit_size':len(relabelings),
                         'source_vector':data}
        if match:
            assert name=='I5322'
            identity = match
    assert identity is not None
    report = {'status':'pass','source':SOURCE_URL,'source_locations':['Table A.4','Table 5.4'],
              'input_data':'6 exact source coefficient vectors, independently transcribed',
              'facet_orbit_results':results,
              'total_nontrivial_inequalities_generated':len(seen),
              'with_60_positivity_facets':len(seen)+60,
              'paper_witness_is_source_I5322':True,'witness_relabeling':identity,
              'completeness':'not re-enumerated; no claim that no other facets exist is certified here'}
    (HERE/'source-facet-control-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
