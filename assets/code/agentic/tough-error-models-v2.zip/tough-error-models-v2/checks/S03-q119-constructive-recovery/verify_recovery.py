"""Exact singular recovery controls and one fixed normalized-channel pipeline."""
from pathlib import Path
import importlib.util, json, time, hashlib
import sympy as s
import numpy as np

OUT=Path(__file__).resolve().parent
START=time.monotonic()
I=s.I

def exact_checks():
    k,e,n=2,2,5
    U=s.eye(n)[:,:4]
    R=[s.eye(4)[i*k:(i+1)*k,:]*U.conjugate().T for i in range(e)]
    replacement=s.zeros(k,n);replacement[0,4]=1
    R.append(replacement)
    assert sum((r.conjugate().T*r for r in R),s.zeros(n))==s.eye(n)
    A=[s.diag(1,1,0,0,1),s.diag(0,0,1,1,0)]
    rows=[]
    for name,c0,s0,c1,s1 in [
        ('singular-gram',s.Integer(1),s.Integer(0),s.Integer(1),s.Integer(0)),
        ('full-rank-exact-gram',s.Rational(3,5),s.Rational(4,5),s.Rational(3,5),s.Rational(4,5)),
        ('approximate-rational-code',s.Rational(3,5),s.Rational(4,5),s.Rational(5,13),s.Rational(12,13))]:
        X=s.Matrix([[c0,0],[0,c1],[s0,0],[0,s1],[0,0]])
        assert X.conjugate().T*X==s.eye(k)
        W=(A[0]*X).row_join(A[1]*X);K=W.conjugate().T*W
        Lam=s.Matrix(e,e,lambda i,j:s.trace(K[i*k:(i+1)*k,j*k:(j+1)*k])/k)
        L=s.kronecker_product(Lam,s.eye(k));F=s.trace((K-L).conjugate().T*(K-L))
        rootK=s.diag(c0,c1,s0,s1)
        assert rootK*rootK==K and U*rootK==W
        assert s.trace(Lam)==1
        gamma=c0*c1+s0*s1
        for a in range(k):
            for b in range(k):
                E=s.zeros(k);E[a,b]=1
                noise=sum((z*X*E*X.conjugate().T*z.conjugate().T for z in A),s.zeros(n))
                recovered=sum((r*noise*r.conjugate().T for r in R),s.zeros(k))
                assert recovered==(1 if a==b else gamma)*E
        # The resulting channel is (1-p)id+p Z(.)Z, p=(1-gamma)/2.
        # Its exact diamond error is 1-gamma: triangle upper bound and |+> saturation.
        error=1-gamma
        assert error**4 <= 16*e**2*F
        rows.append({'name':name,'F':str(F),'lambda_rank':Lam.rank(),
                     'gamma':str(gamma),'exact_diamond_error':str(error),
                     'full_channel_matrix_units_checked':True,'complete_decoder_TP':True})
    # Singular, genuinely complex error Gram; transposing it is an invalid convention.
    a=s.Rational(3,5);b=4*I/5;X=s.eye(4)[:,:2]
    A=[a*s.eye(4),b*s.eye(4)]
    W=(A[0]*X).row_join(A[1]*X)
    Lam=s.Matrix([[a*a,a*b],[s.conjugate(b)*a,s.conjugate(b)*b]])
    K=W.conjugate().T*W;L=s.kronecker_product(Lam,s.eye(2))
    B=s.Matrix([[a,b],[-s.conjugate(b),a]])
    U=s.kronecker_product(B,s.eye(2))
    assert U.conjugate().T*U==s.eye(4)
    assert Lam*Lam==Lam and K==L and U*L==W
    assert s.kronecker_product(Lam.T,s.eye(2))!=K
    rows.append({'name':'complex-singular-Gram','F':'0','lambda_rank':1,'transpose_negative_control':True})
    P=s.diag(1,0);v=s.Matrix([s.Rational(3,5),s.Rational(4,5)]);Q=v*v.T
    assert P*P==P and Q*Q==Q and P*Q!=Q*P
    assert (P-Q)**2==s.Rational(16,25)*s.eye(2)
    assert s.Rational(16,25)<=s.Rational(4,5)
    rows.append({'name':'noncommuting-singular-square-roots','delta':'4/5','square_root_difference_squared':'16/25'})
    assert 3<2*2
    assert sum(((2*z).conjugate().T*(2*z) for z in A),s.zeros(4))==4*s.eye(4)
    rows.append({'name':'invalid-dimension-and-nonnormalized-controls','completion_impossible_at_n3_e2_k2':True,'nonTP_rejected':True})
    return rows

def normalized_pipeline():
    prior=OUT.parent/'S02-q119-quantitative-landscape/verify_quantitative.py'
    sp=importlib.util.spec_from_file_location('inherited_search',prior)
    v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
    rng=np.random.default_rng(371193);n,k,e=7,2,2;m=3
    raw=rng.normal(size=(e*n,n))+1j*rng.normal(size=(e*n,n))
    V=np.linalg.qr(raw)[0];A=[V[i*n:(i+1)*n] for i in range(e)]
    cross=A[0].conj().T@A[1]
    H=[(A[0].conj().T@A[0]-A[1].conj().T@A[1])/np.sqrt(2),
       (cross+cross.conj().T)/np.sqrt(2),(cross-cross.conj().T)/(1j*np.sqrt(2))]
    assert max(np.linalg.norm(h,2) for h in H)<=1+1e-12
    X=np.eye(n,dtype=complex)[:,:k];P=k*m;tau=1e-4;a=(k-1)*np.sqrt(k+1)
    F0=v.quantities(H,X)[0];branches={'gradient':0,'curvature':0};margin=float('inf')
    for step in range(4096):
        if time.monotonic()-START>90:break
        F,G,T,R=v.quantities(H,X)
        if F<=tau:break
        g=4*np.linalg.norm(R)
        if g>=F/a:
            Y=v.geodesic(X,-4*R/g,g/(16*P));branch='gradient'
        else:
            perp=np.linalg.qr(X,mode='complete')[0][:,k:]
            C=np.concatenate([perp.conj().T@h@X for h in H],axis=1)
            left=np.linalg.svd(C,full_matrices=True)[0][:,-1];y=perp@left
            options=[]
            for b in range(k):
                for phase in [1,1j]:
                    Z=np.zeros_like(X);Z[:,b]=phase*y;options.append((v.curvature(H,X,G,T,Z),Z))
            q,Z=min(options,key=lambda z:z[0]);assert q<=-2*F/k+1e-10
            t=np.sqrt(F/(32*P*k));Y=min([v.geodesic(X,Z,t),v.geodesic(X,Z,-t)],key=lambda Q:v.quantities(H,Q)[0]);branch='curvature'
        Fnew=v.quantities(H,Y)[0];d=F-Fnew-F*F/(48*P*k**3)
        assert d>=-1e-10; margin=min(margin,d);branches[branch]+=1;X=Y
    W=np.column_stack([a@X for a in A]);K=W.conj().T@W
    Lam=np.array([[np.trace(K[i*k:(i+1)*k,j*k:(j+1)*k])/k for j in range(e)] for i in range(e)])
    L=np.kron(Lam,np.eye(k));F=float(np.vdot(K-L,K-L).real)
    assert abs(F-v.quantities(H,X)[0])<1e-11
    U0,sv,Vh=np.linalg.svd(W,full_matrices=False);U=U0@Vh
    vals,vec=np.linalg.eigh(L);rootL=(vec*np.sqrt(np.maximum(vals,0)))@vec.conj().T
    W0=U@rootL;ideal=[W0[:,i*k:(i+1)*k] for i in range(e)]
    actual=[a@X for a in A]
    D=[U[:,i*k:(i+1)*k].conj().T for i in range(e)]
    Q=np.eye(n)-U@U.conj().T
    def decode(sigma):
        out=sum((d@sigma@d.conj().T for d in D),np.zeros((k,k),complex))
        out[0,0]+=np.trace(Q@sigma)
        return out
    # Check the entire ideal channel on a basis, not only a set of states.
    ideal_error=0.
    choi=np.zeros((k*k,k*k),complex)
    for i in range(k):
        for j in range(k):
            E=np.zeros((k,k),complex);E[i,j]=1
            out0=decode(sum((b@E@b.conj().T for b in ideal),np.zeros((n,n),complex)))
            ideal_error=max(ideal_error,np.linalg.norm(out0-E))
            out=decode(sum((b@E@b.conj().T for b in actual),np.zeros((n,n),complex)))
            choi[i*k:(i+1)*k,j*k:(j+1)*k]=out
    dil=np.vstack(actual)-np.vstack(ideal)
    dilnorm=float(np.linalg.norm(dil,2));resbound=np.sqrt(e)*F**.25
    assert dilnorm<=resbound+1e-10
    assert ideal_error<1e-10
    assert np.linalg.norm(sum((a.conj().T@a for a in A),np.zeros((n,n),complex))-np.eye(n))<1e-10
    assert np.linalg.norm(sum((d.conj().T@d for d in D),np.zeros((n,n),complex))+Q-np.eye(n))<1e-10
    assert np.linalg.eigvalsh((choi+choi.conj().T)/2).min()>-1e-10
    np.savez(OUT/'normalized-pipeline-v1.npz',A=np.array(A),X=X,U=U,ideal=np.array(ideal),logical_choi=choi)
    return {'seed':371193,'n':n,'e':e,'k':k,'m':m,'P':P,'initial_F':F0,'final_F':F,'target_F':tau,
            'target_reached':F<=tau,'steps':sum(branches.values()),'branches':branches,'minimum_decrease_margin':margin,
            'isometry_error':float(np.linalg.norm(X.conj().T@X-np.eye(k))),
            'ideal_channel_basis_error':float(ideal_error),'stinespring_difference_norm':dilnorm,
            'uniform_residual_diamond_bound':min(2.,2*resbound),
            'uniform_dilation_diamond_bound':min(2.,2*dilnorm),
            'scope':'Floating pipeline regression; displayed norm bounds have not been enclosed with rigorous arithmetic.'}

def main():
    exact=exact_checks();pipeline=normalized_pipeline()
    report={'exact_controls':exact,'normalized_pipeline':pipeline,'scientific_seconds':time.monotonic()-START,
            'proof_sha256':hashlib.sha256((OUT/'proof-candidate-v1.md').read_bytes()).hexdigest()}
    (OUT/'checks-v1.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'exact_controls':len(exact),'pipeline':pipeline,'scientific_seconds':report['scientific_seconds']}))

if __name__=='__main__':main()
