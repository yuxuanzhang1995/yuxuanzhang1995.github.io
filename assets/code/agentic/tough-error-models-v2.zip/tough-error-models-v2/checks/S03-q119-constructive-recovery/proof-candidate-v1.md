# Physical recovery from the quantitative compression search

Q119 transfer candidate, 16 November 2026. This uses established polar/transpose
recovery ideas; it does not claim a new general theory of approximate QEC.
The proposed addition is an explicit link to S02's search guarantee at the
inherited scalar-compression dimension threshold.

## A decoder with a uniform residual bound

Let A_1,...,A_e be n by n Kraus matrices with sum A_i^*A_i=I_n. Let
X:C^k -> C^n be an isometry and assume n>=ek. Set

    W=[A_1X ... A_eX], K=W^*W,
    Lambda_ij=tr(X^*A_i^*A_jX)/k, L=Lambda tensor I_k,
    F=||K-L||_F^2.

Then Lambda is positive semidefinite and tr Lambda=1. Positivity follows
by testing coefficient vectors against the Gram matrix; the trace identity
uses the channel normalization. There is an isometry U:C^(ek)->C^n such
that W=U sqrt(K), even if K is singular: extend the partial polar isometry
from the support of K into the unused output dimensions. The inequality
n>=ek ensures that this completion exists.

Fix any state rho_* on C^k. Define

    D(sigma)=Tr_error(U^* sigma U)
               + tr[(I-UU^*)sigma] rho_*.             (10)

Both summands are CP; the second is measurement followed by preparation.
Their trace contributions sum to tr sigma, so D is a channel on the entire
physical output space. No inverse of Lambda or K appears in this formula.

**Claim.** With E_X(rho)=X rho X^* and N(rho)=sum_i A_i rho A_i^*,

    ||D N E_X-id_k||_diamond <= min{2, 2 sqrt(e) F^(1/4)}.       (11)

Here the diamond norm has its full trace-norm convention, without a factor 1/2.

### Square-root estimate, including zero eigenvalues

For any PSD K,L, put delta=||K-L||_op. Then

    ||sqrt(K)-sqrt(L)||_op <= sqrt(delta).             (12)

Indeed K<=L+delta I and L<=K+delta I. The square-root function is operator
monotone; this follows directly by integrating the order-monotone function
A(A+tI)^(-1)=I-t(A+tI)^(-1):

    sqrt(A)=(1/pi) integral_0^infinity t^(-1/2) A(A+tI)^(-1) dt.

Also sqrt(L+delta I)<=sqrt(L)+sqrt(delta)I by scalar functional calculus
of L. Interchanging K,L bounds both signs of sqrt(K)-sqrt(L), proving (12).
Thus singular eigenvalues cause no division or conditioning assumption.

### A nearby exactly correctable channel

Put W_0=U sqrt(L) and split its e blocks into n by k matrices B_i. Then

    B_i=U(sqrt(Lambda)e_i tensor I_k),
    N_0(rho)=sum_i B_i rho B_i^*=U(Lambda tensor rho)U^*.

This is a channel because tr Lambda=1, and D N_0=id_k exactly. Set
Delta_i=A_iX-B_i. Equation (12) and delta<=sqrt(F) imply

    ||W-W_0||_op <= F^(1/4).

The two Stinespring isometries V=sum_i A_iX tensor |i> and
V_0=sum_i B_i tensor |i> obey

    ||V-V_0||_op^2=||sum_i Delta_i^*Delta_i||_op
                    <= e ||W-W_0||_op^2 <= e sqrt(F).

For an arbitrary reference space and trace-class input Z, expand
V Z V^*-V_0 Z V_0^* as (V-V_0)Z V^*+V_0 Z(V^*-V_0^*).
The trace-norm ideal property and contraction under partial trace give
||N E_X-N_0||_diamond<=2||V-V_0||_op. Postcomposing with the channel D
proves (11). This proof controls every reference input; testing a maximally
entangled state alone is neither used nor sufficient.

The factor sqrt(e) is a conservative block estimate; no optimality is claimed.
There is a transpose in the complementary-channel density matrix under some
index conventions. This proof uses the explicitly ordered Gram K_ij and
the physical syndrome state Lambda, avoiding that convention ambiguity.

## Relation to established recovery maps

On the range of W, the polar factor is (WW^*)^(-1/2)W, where the inverse
is on the support. Therefore the logical recovery Kraus blocks are

    X^* A_i^* [N(XX^*)]^(-1/2).

This is the standard transpose/Petz recovery for the maximally mixed code
state, expressed in logical coordinates. The arbitrary isometric completion
and replacement term extend it outside the actually noisy code support.
The recovery construction itself is inherited from that theory, not credited
as a new discovery. The present elementary proof gives a convenient bound
in precisely the variance quantity controlled by S02.

## Normalized-channel search theorem

Assume e>=2 and n>=e^2 k-1, with k>=2. Take a Hilbert--Schmidt orthonormal
Hermitian basis B_0,...,B_(e^2-1) of M_e, with B_0=I_e/sqrt(e). Set

    H_alpha=sum_ij (B_alpha)_ij A_i^*A_j.

The map B -> sum B_ij A_i^*A_j is unital CP. Hence the H_alpha are
Hermitian, ||H_alpha||_op<=||B_alpha||_op<=1, and H_0=I_n/sqrt(e).
The H_0 traceless-compression term vanishes. Changing the coefficient basis
preserves the squared Frobenius residual sum, so the remaining m=e^2-1
observables have objective exactly F above.

S02 now applies at n>=(m+1)k-1=e^2k-1. We may choose P=k(e^2-1).
For 0<epsilon<=2, target variance tau=epsilon^4/(16e^2). Its ideal-
arithmetic search uses at most

    ceil[768 e^2(e^2-1) k^4 / epsilon^4]             (13)

iterations to obtain F<=tau. The decoder (10), formed by a polar completion,
then has logical diamond error at most epsilon. The dimension condition also
ensures n>=ek, as required for that completion. For e=1 the normalized
channel is unitary and has the obvious exact inverse; no search is needed.

The complexity statement counts ideal matrix and geodesic operations for
dense matrix input. It is not polynomial in the number of qubits, a
finite-precision bit-complexity theorem, or an exact finite-step decoder
construction for epsilon=0. Those claims require additional work.

## Scope relative to Q119

The arbitrary-error problem does not impose sum A_i^*A_i=I. Its search
threshold remains n>=(e^2+1)k-1 as in S02. This normalized-channel corollary
does not remove the metric condition recorded in sibling R275, and does not
determine c(2,6). The old asymptotic exact existence theorem is not new here.

Primary comparisons: Ng--Mandayam, arXiv:0909.0931v2, equation (4), gives
the transpose recovery; Beny--Oreshkov, arXiv:0907.5391, Corollary 2, gives
general approximate KL conditions in worst-case entanglement fidelity.
Kretschmann--Schlingemann--Werner, arXiv:0710.2495, supplies the broader
Stinespring continuity framework. No claim of priority for recovery continuity
is made. The remaining candidate contribution is the quantitative search
and its stated dimension-dependent constructive corollary.
