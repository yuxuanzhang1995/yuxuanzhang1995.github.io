"""Check package integrity and run the two offline supplementary controls."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import shutil
import subprocess
import sys
import tempfile


def main():
    base = Path(__file__).resolve().parent
    manifest = json.loads((base / 'MANIFEST.json').read_text())
    for item in manifest['files']:
        path = base / item['path']
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != item['sha256']:
            raise RuntimeError('Hash mismatch: ' + item['path'])
    versions = {x: importlib.metadata.version(x) for x in ['numpy', 'scipy', 'sympy']}
    print(json.dumps({'integrity': 'passed', 'files': len(manifest['files']),
                      'python': sys.version.split()[0], 'dependencies': versions}), flush=True)

    with tempfile.TemporaryDirectory(prefix='se-schmidt-check-') as scratch:
        work = Path(scratch)
        for name in ['check_local_bands.py', 'check_direct_transfer.py']:
            shutil.copyfile(base / 'checks' / name, work / name)
            done = subprocess.run([sys.executable, str(work / name)], cwd=work,
                                  capture_output=True, text=True)
            if done.returncode:
                sys.stderr.write(done.stdout + done.stderr)
                raise RuntimeError('Checker failed: ' + name)
            print(done.stdout.strip(), flush=True)
        local = json.loads((work / 'local-band-checks.json').read_text())
        direct = json.loads((work / 'direct-transfer-checks.json').read_text())
        expected_local = json.loads((base / 'expected/local-band-checks.json').read_text())
        expected_direct = json.loads((base / 'expected/direct-transfer-checks.json').read_text())
        assert local['status'] == 'passed'
        assert local['check_count'] == len(local['checks']) == 374
        assert all(x['passed'] for x in local['checks'])
        assert len(local['mutations']) == 3 and all(x['detected'] for x in local['mutations'])
        assert [(x['name'], x['passed']) for x in local['checks']] == [
            (x['name'], x['passed']) for x in expected_local['checks']]
        assert direct['status'] == 'all_asserted_finite_controls_pass'
        assert direct['assertions'] == len(direct['checks']) == 71
        assert len(direct['cases']) == 3 and len(direct['parameter_cases']) == 8
        assert len(direct['mutation_controls']) == 4
        assert direct == expected_direct

    print(json.dumps({'result': 'passed', 'local_band_assertions': 374,
                      'direct_transfer_exact_assertions': 71,
                      'mutation_classes': [3, 4],
                      'scope': 'Supplementary finite checks, not a universal proof certificate.'}))


if __name__ == '__main__':
    main()
