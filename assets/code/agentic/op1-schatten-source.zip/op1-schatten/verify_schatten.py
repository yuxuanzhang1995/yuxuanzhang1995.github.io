"""Exact arithmetic diagnostics for two commuting Alhejji--Knill witnesses.

Run with Python 3, without -O. No third-party packages are needed.
The analytic proof in the note, not finite enumeration, covers every word.
"""
from fractions import Fraction
from itertools import product
from math import isqrt, prod
import json
from pathlib import Path

WITNESSES = {
    "small": ((2, 0, 1), (2, 1, 0), (1, 2, 0), (2, 1, 0)),
    "integer_power_sum": ((176, 0, 64), (80, 49, 0), (64, 176, 0), (80, 49, 0)),
}

def trace_word(pair, word):
    return sum(prod(pair[bit][coordinate] for bit in word) for coordinate in range(3))

checks = {}
for name, (a0, a1, b0, b1) in WITNESSES.items():
    assert all(x >= 0 for diagonal in (a0, a1, b0, b1) for x in diagonal)
    assert sorted(a0) == sorted(b0) and sorted(a1) == sorted(b1)
    alpha, beta = Fraction(b0[0], a0[0]), Fraction(b1[1], a1[0])
    assert 0 < alpha < 1 and 0 < beta < 1 and alpha + beta <= 1
    # For a mixed word with k,m>=1, tr(B)/tr(A)=alpha**k+beta**m.
    # The proof uses monotonicity of powers on (0,1) to bound this by alpha+beta.
    count = 0
    for length in range(13):
        for word in product((0, 1), repeat=length):
            a = trace_word((a0, a1), word)
            b = trace_word((b0, b1), word)
            assert a >= abs(b)
            k, m = word.count(0), word.count(1)
            if k and m:
                assert Fraction(b, a) == alpha**k + beta**m
            else:
                assert a == b
            count += 1
    checks[name] = {"nonnegative_diagonals": True, "matched_spectra": True,
        "uniform_mixed_word_ratio_bound": str(alpha + beta),
        "finite_word_checks_including_empty": count,
        "sum_A_diagonal": [x+y for x,y in zip(a0,a1)],
        "sum_B_diagonal": [x+y for x,y in zip(b0,b1)]}

# Small witness: sum_A^(3/2)=4^(3/2)+1+1=10; sum_B^(3/2)=6*sqrt(3).
# Both are nonnegative, so squaring preserves the strict comparison.
assert checks["small"]["sum_A_diagonal"] == [4, 1, 1]
assert checks["small"]["sum_B_diagonal"] == [3, 3, 0]
assert 10**2 == 100 < 108 == 6**2 * 3
checks["small"]["decisive_p_3_over_2_comparison"] = "10 < 6*sqrt(3), certified by 100 < 108"

def integer_three_halves(n):
    root = isqrt(n)
    assert root*root == n
    return n*root

a = sum(integer_three_halves(x) for x in checks["integer_power_sum"]["sum_A_diagonal"])
b = sum(integer_three_halves(x) for x in checks["integer_power_sum"]["sum_B_diagonal"])
assert a == 4951 < 5103 == b
assert b-a == 152
checks["integer_power_sum"].update(power_sum_A=a, power_sum_B=b, strict_gap_B_minus_A=b-a)
assert Fraction(64,176)+Fraction(49,80) == Fraction(859,880) < 1

result = {"status": "PASS", "arithmetic": "integers and exact rational numbers",
    "checks": checks,
    "analytic_claims": {"all_words": "proved by commutativity, pure-word isospectrality, and the uniform ratio bound",
        "failure_for_all_1_lt_p_lt_2": "proved by strict convexity of (4/3)^p+2*(1/3)^p-2",
        "minimal_dimension_3": "proved using equal trace and the degree-two word in dimension two"},
    "scope": "Finite diagnostics and constants for a separate analytic proof; no external expert verification or novelty claim."}
print(json.dumps(result, indent=2))
Path(__file__).with_name("verification-results.json").write_text(json.dumps(result, indent=2)+"\n")
