# Three-round quantum cooling work: version 1.0

Date: 2026-10-29. Complete original-model solution candidate, internally checked.
See NOTE.md for the full mathematical model, theorem, proof and primary sources.

With Python 3 and NumPy installed, run from this extracted folder:

    OPENBLAS_NUM_THREADS=1 python3 reproduce.py

Do not use Python -O. The runner verifies all packaged hashes and executes ten
steps in a fresh temporary directory. It requires no network or paid service.
It leaves outputs and logs in the printed temporary directory. Several minutes,
roughly 0.2 GB of output, and working memory for one frontier at a time are needed;
actual requirements depend on the machine and NumPy build.

The run/checks layout is retained to keep mathematical programs byte-identical.
Historical round labels identify dependency files, not extra discovery claims.
Intermediate result messages may say that a suffix is unresolved: later steps
close it. Only the final complete certificate and reproduction summary report
the result. Floating tilts are proposals; all exclusions use directed arithmetic.

The ten histories in r131_p11_witness.json are exact controls. Array permutations
map source to destination. A quantum rotation acts on the two indexed rows after
the base permutation. Stage indices 0,...,5 alternate recharge and collision.
The parameter is an exact rational string; kind tan uses (1-t^2)/(1+t^2), while
kind cot uses (t^2-1)/(1+t^2), with sine 2t/(1+t^2). The exact mixture weights
are defined by the five linear equations in NOTE.md, with an identity remainder.
The final random sign twirl is folded into the last collision as proved there.

PROVENANCE.json records source and packaged hashes. Two proposal records are
reduced to the price entries actually consumed by the checker. The raw problem
bank, research ledger, conversation, internal logs and precomputed exhaustive
state archive are not part of this public supplement. The certificate regenerates
its full state enumeration; no exclusion relies on an omitted floating result.

The separate 192-bit dyadic implementation checks feasible controls and the gap,
not the universal population converse by itself. All verification so far is by
the same agent. Independent expert review and broader novelty clearance remain
outstanding. Website publication is not an archival deposit or catalog acceptance.
