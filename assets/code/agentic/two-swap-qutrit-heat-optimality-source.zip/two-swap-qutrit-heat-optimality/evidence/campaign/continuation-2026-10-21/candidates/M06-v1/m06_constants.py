"""Exact arithmetic controls for the analytic M06 proof; no cutoff inference."""
from fractions import Fraction as F
from math import factorial
import json

def check():
 # Independently multiply sparse exact Jacobi walks for powers2,4. Each
 # traversed edge contributes a square root; every closed path traverses
 # each edge an even number of times, so its weight is an integer.
 import itertools
 controls=[]
 for r in range(1,25):
  values={}
  for length in [2,4]:
   total=0
   for steps in itertools.product([-1,1],repeat=length):
    pos=0;counts={};ok=True
    for step in steps:
     nxt=pos+step
     if nxt<0 or nxt>r:ok=False;break
     edge=min(pos,nxt);counts[edge]=counts.get(edge,0)+1;pos=nxt
    if not ok or pos:continue
    weight=1
    for j,num in counts.items():
     assert num%2==0
     weight*=((r-j)*(2*j+1)*(2*j+2))**(num//2)
    total+=weight
   values[length]=total
  assert values[2]==2*r and values[4]==28*r*r-24*r
  controls.append({'r':r,'m2':values[2],'m4':values[4]})
 # Symbolic all-r difference fourth moment =2m4+6m2^2.
 # The fourth-moment ratio <=5 is immediate for every r>=1.
 assert 2*28+6*2**2==80 and 2*(-24)==-48
 # All scalar constants checked as rational inequalities; transcendental
 # inequalities are proved analytically in proof.txt, not inferred here.
 assert F(7,45000)>F(1,10000)
 assert F(1841,1920)<F(24,25)
 assert F(30401,30720)<F(99,100)
 assert sum(F(1,factorial(k)) for k in range(4))>F(5,2) # e>5/2
 assert F(2,5)<F(16,25)**2
 d0=F(3,5)*F(1,200000);Phi=d0*F(4,5)
 lam=F(1,10**12);c=lam/2;C=500001
 assert Phi>F(2,10**6) and Phi*Phi/2>lam
 assert 1-lam>F(99,100)
 assert F(25,9)**2<8 # L^(3/2) norm<2
 assert 720/F(4,5)**6<15**3 # second moment<30
 assert 2/F(4,5)**2<4
 assert 68*C<6000**2
 assert 4*6000/(c/2)<10**17
 # Invalid moment should be rejected by the closed-walk control.
 bad_rejected=any(x['m4']!=28*x['r']**2-23*x['r'] for x in controls)
 assert bad_rejected
 return {'pass':True,'analytic_scope':'all r>=1 and all N>=0; finite walk controls only verify the moment algebra','scalar_escape_floor':'1/10000','vacuum_leave_floor':'1/200000','conductance_lower_rational':str(Phi),'positive_gap_used':str(lam),'negative_spectrum_floor':'-99/100','C':C,'c':str(c),'uniform_second_moment_upper':30,'averaged_gross_work_upper':10**17,'conditional_history_expected_gross_work_upper':'6N','invalid_moment_control_rejected':bad_rejected,'walk_controls':controls}
if __name__=='__main__':print(json.dumps(check(),indent=2))
