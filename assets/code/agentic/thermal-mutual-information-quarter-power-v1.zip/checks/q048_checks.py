"""Decisive finite controls for Q048; not a proof of the uniform estimates.

No sampling/optimizer is used. Physical qutrit operators and charge/spin
operators are constructed by different rules and compared in exact integers.
Floating-point spectral controls are explicitly reported separately.
"""
import itertools as it
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import numpy as np
import sympy as sp

OUT = Path(__file__).with_name('q048-checks.json')


def add(d, w, c):
    d[tuple(w)] += c


def clean(d):
    return {k: v for k, v in d.items() if v}


def physical(w, n, kind, mutant=False):
    d = defaultdict(int)
    if kind == 'interior':
        for off in (0, n):
            for i in range(n - 1):
                a, b = off + i, off + i + 1
                if (w[a] == 2) != (w[b] == 2):
                    z = list(w); z[a], z[b] = z[b], z[a]
                    add(d, w, 2); add(d, z, -2)
    elif kind == 'boundary':
        e = [(w[o+n-1], w[o]) for o in (0, n)]
        plus = [a == 2 and b != 2 for a, b in e]
        minus = [a != 2 and b == 2 for a, b in e]
        xx = [a == b == 2 for a, b in e]
        active = all(plus) or all(minus)
        if mutant:
            active |= any(plus) and all(plus[i] or xx[i] for i in (0, 1))
            active |= any(minus) and all(minus[i] or xx[i] for i in (0, 1))
        if active:
            z = list(w)
            for o in (0, n):
                z[o], z[o+n-1] = z[o+n-1], z[o]
            add(d, w, 2); add(d, z, -2)
    elif kind == 'contact':
        if w[0] != 2 and w[n] != 2:
            if w[0] == w[n]:
                add(d, w, 2)
            else:
                z = list(w); z[0], z[n] = z[n], z[0]
                add(d, w, 1); add(d, z, -1 if mutant else 1)
    return clean(d)


def decode(w, n):
    return tuple((tuple(i for i, a in enumerate(w[o:o+n]) if a == 2),
                  tuple(a for a in w[o:o+n] if a != 2)) for o in (0, n))


def encode(sector, n):
    w = []
    for holes, spins in sector:
        q = iter(spins)
        w.extend(2 if i in holes else next(q) for i in range(n))
    return tuple(w)


def model(w, n, kind, wrong_twist=False):
    sector = decode(w, n)
    holes = [set(x[0]) for x in sector]; spins = [x[1] for x in sector]
    d = defaultdict(int)
    if kind == 'interior':
        for r in (0, 1):
            for i in range(n-1):
                if (i in holes[r]) != (i+1 in holes[r]):
                    changed = [set(x) for x in holes]
                    changed[r] ^= {i, i+1}
                    z = encode([(changed[t], spins[t]) for t in (0, 1)], n)
                    add(d, w, 2); add(d, z, -2)
    elif kind == 'boundary':
        forward = all(n-1 in h and 0 not in h for h in holes)
        backward = all(0 in h and n-1 not in h for h in holes)
        if forward or backward:
            changed = [h ^ {0, n-1} for h in holes]
            rotated = spins if wrong_twist else [
                s[1:] + s[:1] if forward else s[-1:] + s[:-1] for s in spins]
            z = encode(list(zip(changed, rotated)), n)
            add(d, w, 2); add(d, z, -2)
    elif kind == 'contact' and all(0 not in h for h in holes):
        if spins[0][0] == spins[1][0]:
            add(d, w, 2)
        else:
            flipped = [(1-s[0],) + s[1:] for s in spins]
            z = encode(list(zip(holes, flipped)), n)
            add(d, w, 1); add(d, z, 1)
    return clean(d)


def potential(w, n, omit_cyclic=False):
    return sum(sum(int(w[o+i] == w[o+(i+1) % n] == 2)
                   for i in range(n - int(omit_cyclic)))
               - sum(a == 2 for a in w[o:o+n]) for o in (0, n))


def exact_physics():
    counts = {}; mutations = dict(one_sided_boundary=0, missing_twist=0,
                                  wrong_singlet_sign=0, missing_cyclic_pair=0)
    for n in (2, 3, 4):
        cols = 0; entries = 0; means = defaultdict(lambda: [0, 0])
        for w in it.product(range(3), repeat=2*n):
            assert encode(decode(w, n), n) == w
            for kind in ('interior', 'boundary', 'contact'):
                a, b = physical(w, n, kind), model(w, n, kind)
                assert a == b, (n, w, kind, a, b)
                cols += 1; entries += len(a)
            mutations['one_sided_boundary'] += physical(w,n,'boundary',True) != model(w,n,'boundary')
            mutations['missing_twist'] += physical(w,n,'boundary') != model(w,n,'boundary',True)
            mutations['wrong_singlet_sign'] += physical(w,n,'contact',True) != model(w,n,'contact')
            mutations['missing_cyclic_pair'] += potential(w,n,True) != potential(w,n)
            h,j = (len(x[0]) for x in decode(w,n))
            means[h,j][0] += potential(w,n); means[h,j][1] += 1
        for (h,j),(total,num) in means.items():
            assert Fraction(total,num) == Fraction(h*(h-n)+j*(j-n),n-1)
        counts[str(n)] = dict(physical_basis_states=3**(2*n),
                             operator_column_equalities=cols,
                             nonzero_entries_compared=entries,
                             charge_mean_equalities=len(means))
    assert all(mutations.values())
    return counts, mutations


def exact_monogamy():
    # Three qubits; Q1 acts on (0,1), Q2 on (0,2), built directly.
    qs=[]
    for pair in ((0,1),(0,2)):
        q=sp.zeros(8)
        for w in it.product((0,1),repeat=3):
            if w[pair[0]] != w[pair[1]]:
                col=int(''.join(map(str,w)),2)
                z=list(w); z[pair[0]],z[pair[1]]=z[pair[1]],z[pair[0]]
                row=int(''.join(map(str,z)),2)
                q[col,col]+=sp.Rational(1,2);q[row,col]-=sp.Rational(1,2)
        qs.append(q)
    q1,q2=qs
    assert q1*q2*q1 == q1/4
    assert q1*q1 == q1 and q2*q2 == q2
    spectrum=(q1+q2).eigenvals()
    assert max(spectrum)==sp.Rational(3,2)
    return {str(k):int(v) for k,v in spectrum.items()}


def exclusion(n,h):
    states=list(it.combinations(range(n),h)); index={x:i for i,x in enumerate(states)}
    l=np.zeros((len(states),len(states)))
    for s,col in index.items():
        z=set(s)
        for j in range(n-1):
            if (j in z)!=(j+1 in z):
                row=index[tuple(sorted(z^{j,j+1}))]
                l[col,col]+=1;l[row,col]-=1
    val,vec=np.linalg.eigh(l)
    return states,val,vec


def endpoint_controls():
    cases=[]
    for n in range(3,8):
        for h in range(1,n):
            if not n/4<=h<=3*n/4:continue
            x,vx,ux=exclusion(n,h)
            for j in range(1,n):
                if not n/4<=j<=3*n/4:continue
                y,vy,uy=exclusion(n,j)
                lam=vx[:,None]+vy[None,:]
                pred=[lambda s:0 not in s,
                      lambda s:n-1 in s and 0 not in s,
                      lambda s:0 in s and n-1 not in s]
                for name,p in zip(('contact','plus','minus'),pred):
                    a=np.array([p(s) for s in x],float)
                    b=np.array([p(s) for s in y],float)
                    coeff=np.outer(ux.T@a,uy.T@b)
                    mask=lam>1e-8
                    sharp=float(np.sum(coeff[mask]**2/lam[mask])/(len(x)*len(y)))
                    assert sharp<=128*n+1e-9
                    cases.append(dict(n=n,h=h,j=j,event=name,sharp_covariance_constant=sharp))
    return dict(cases=len(cases),max_ratio_to_claim=max(z['sharp_covariance_constant']/(128*z['n']) for z in cases),largest=sorted(cases,key=lambda z:z['sharp_covariance_constant'])[-3:])


def spin_controls():
    cases=[]
    for m in range(1,5):
        for k in range(1,5):
            words=list(it.product((0,1),repeat=m+k)); ix={w:i for i,w in enumerate(words)}
            d=len(words);r=np.zeros((d,d));p=np.eye(d)
            for w,c in ix.items():
                a,b=w[:m],w[m:]
                r[ix[a[1:]+a[:1]+b[1:]+b[:1]],c]=1
                if w[0]!=w[m]:
                    z=list(w);z[0],z[m]=z[m],z[0]
                    p[c,c]-=.5;p[ix[tuple(z)],c]+=.5
            b=(np.eye(d)-r).T@(np.eye(d)-r)+p
            val=np.linalg.eigvalsh(b)
            zero=int(np.sum(abs(val)<1e-9));assert zero==int(m==k)
            gap=float(val[zero]);required=1/(2*m*m) if m==k else 1/(6*max(m,k)**2)
            assert gap>=required-1e-9
            cases.append(dict(m=m,k=k,kernel_dimension=zero,gap=gap,claimed_bound=required))
    return cases


def constants():
    n=2**30
    assert 6*128*256**2 < 2**26
    assert 2*128*16**2 < 2**17
    assert Fraction(1,2**38*n**3)-Fraction(1,4096*n**4) >= Fraction(1,2**39*n**3)
    assert Fraction(1,1024*n**3)-Fraction(1,4096*n**4) >= Fraction(1,2**40*n**3)
    assert Fraction(1,64**2*3*n**4)<=Fraction(1,4096*n**4)
    return 'five exact rational/integer constant checks passed'


if __name__=='__main__':
    physical_counts,mutations=exact_physics()
    result=dict(status='PASS',scope='finite controls only; all-size proof is separate',
                exact_physical_intertwining=physical_counts,mutation_mismatches=mutations,
                exact_monogamy_spectrum=exact_monogamy(),exact_constants=constants(),
                numerical_endpoint_controls=endpoint_controls(),numerical_spin_controls=spin_controls())
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='numerical_spin_controls'},indent=2))
