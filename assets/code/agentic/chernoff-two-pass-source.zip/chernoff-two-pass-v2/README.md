# Feedback-enhanced quantum Chernoff discrimination

Yuxuan Zhang and Mao-Sheng Li. Manuscript version 2.0, 29 October 2026.

The manuscript refutes the universal measured-Chernoff equality for copywise LOCC discrimination. Version 2 adds a faithful qubit construction with an unbounded additive gap, existence of the optimal finite-round LOCC exponent, and explicit rate formulas with a sharp 3/2 comparison for orthogonally flagged pure conditional states. General SEP convergence, LOCC–SEP exponent separation, and exact optimal faithful-qubit exponents remain open.

## Contents and reproduction

- `source/chernoff-two-pass.tex`: complete manuscript source, including references and author-contribution disclosure.
- `checks/verify_v2.py`: standalone standard-library checker for the original rational four-dimensional estimates and the added qubit/faithful-family calculations.
- `checks/expected-stdout.txt`: exact expected summary output.
- `checks/li-integration-checks.json`: the detailed 100-digit Decimal calculations, including five qubit parameters, 30 finite-transcript cases and the faithful-noise scaling check.
- `checks/manuscript-review.json`: frozen internal review and two clean checker runs, with actual usage and source/checker hashes.
- `SOURCE-COMPARISON.md`: model distinctions, inherited results and unresolved scope.
- `MANIFEST.json`: file hashes and release identity.

Use Python 3.11 or later. From the package directory run:

```sh
python3 checks/verify_v2.py
latexmk -pdf -interaction=nonstopmode -halt-on-error source/chernoff-two-pass.tex
```

The checker writes its detailed Decimal calculations next to the script. Its final output should match `checks/expected-stdout.txt` after removing trailing whitespace. These finite checks supplement the analytic proofs; they do not establish the asymptotic statements by themselves. Internal AI review is fallible and does not amount to external peer review, formal verification or priority certification.

The source is version 2.0. The earlier version 1.0 remains separately archived at https://zenodo.org/records/23417491/files/chernoff-two-pass.pdf. This website update does not change that archive or QIQC issue #139.
