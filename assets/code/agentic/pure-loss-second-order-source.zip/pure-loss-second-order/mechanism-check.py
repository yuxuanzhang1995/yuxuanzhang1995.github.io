"""Finite checks of the shell-code mechanism; the all-n proof is analytical."""
import math,itertools
from fractions import Fraction
import numpy as np
from scipy.stats import binom,norm

def compositions(total,n):
    if n==1:return [(total,)]
    return [(a,)+t for a in range(total+1) for t in compositions(total-a,n-1)]

def vector(u,k,basis):
    out=np.zeros(len(basis),complex)
    for i,r in enumerate(basis):
        if sum(r)==k:
            out[i]=math.sqrt(math.factorial(k)/math.prod(math.factorial(a) for a in r))*np.prod([u[j]**r[j] for j in range(len(u))])
    return out

# Exact rational Dirichlet moments give the shell isotropy identity.
for n in range(2,7):
    for l in range(7):
        dim=math.comb(n+l-1,l);basis=compositions(l,n);assert len(basis)==dim
        for r in basis:
            moment=Fraction(math.factorial(n-1)*math.prod(math.factorial(a) for a in r),math.factorial(n+l-1))
            amplitude=Fraction(math.factorial(l),math.prod(math.factorial(a) for a in r))
            assert moment*amplitude==Fraction(1,dim)
print('PASS: exact shell moment and dimension identities')

rng=np.random.default_rng(15092026)
for n,k in [(2,2),(3,3)]:
    basis=sum((compositions(l,n) for l in range(k+1)),[]);index={r:i for i,r in enumerate(basis)}
    for eta in [.2,.5,.8]:
        u=rng.normal(size=n)+1j*rng.normal(size=n);u/=np.linalg.norm(u);psi=vector(u,k,basis)
        rho=np.zeros((len(basis),len(basis)),complex)
        for loss in basis:
            v=np.zeros(len(basis),complex)
            for j,r in enumerate(basis):
                if sum(r)==k and all(a>=b for a,b in zip(r,loss)):
                    s=tuple(a-b for a,b in zip(r,loss))
                    v[index[s]]+=psi[j]*math.sqrt(math.prod(math.comb(a,b) for a,b in zip(r,loss)))*eta**((k-sum(loss))/2)*(1-eta)**(sum(loss)/2)
            rho+=np.outer(v,v.conj())
        pred=sum((math.comb(k,l)*eta**l*(1-eta)**(k-l)*np.outer(v,v.conj()) for l in range(k+1) for v in [vector(u,l,basis)]),start=np.zeros_like(rho))
        assert np.linalg.norm(rho-pred)<1e-12
        assert abs(np.trace(rho)-1)<1e-12
        assert sum(abs(psi[i])**2 for i,r in enumerate(basis) if sum(r)!=k)==0
print('PASS: direct pure-loss Kraus outputs and zero input leakage')

# Direct verification of the Gram-Schmidt decoding identity on finite codebooks.
for n in [2,3,4]:
    us=rng.normal(size=(5,n))+1j*rng.normal(size=(5,n));us/=np.linalg.norm(us,axis=1)[:,None]
    for l in [0,1,2,3]:
        basis=compositions(l,n);dim=len(basis);P=np.zeros((dim,dim),complex)
        for u in us:
            psi=vector(u,l,basis);w=(np.eye(dim)-P)@psi;normw=np.linalg.norm(w)
            if normw>1e-10:q=w/normw;Q=np.outer(q,q.conj())
            else:Q=np.zeros_like(P)
            assert abs((psi.conj()@Q@psi).real-(1-(psi.conj()@P@psi).real))<1e-10
            assert np.linalg.norm(P@Q)<1e-10
            P+=Q
        assert np.linalg.norm(P@P-P)<1e-9
print('PASS: shellwise Gram-Schmidt decoder identity and POVM positivity')

# Exact integers for code sizes, binomial probabilities only as diagnostics.
eps=float(norm.cdf(-1))
for n in [100,1000,10000]:
    k=2*n; t=int(binom.ppf(eps-1/n,k,.5));d=math.comb(n+t-1,t);M=d//n
    assert M>=1
    error_bound=float(binom.cdf(t-1,k,.5)) + float(Fraction(M-1,2*d))
    assert error_bound<eps
    logM=math.log2(M)
    predicted=2*n-math.sqrt(n/2)-1.5*math.log2(n)
    assert abs(logM-predicted)<8
    print('n=%d: error_bound=%.8f < epsilon=%.8f; asymptotic_remainder=%.6f' % (n,error_bound,eps,logM-predicted))
assert math.sqrt(.5)<math.sqrt(2)
print('PASS: finite code-size bounds; strict asymptotic coefficient comparison')
