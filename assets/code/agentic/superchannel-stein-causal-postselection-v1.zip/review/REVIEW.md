# Q074 and Q114: superchannel discrimination review

13 November 2026. Same-root analytical review, with new exact computational
controls for selected identities. No independent agent or external expert
was used. This review is separate from discovery rounds.

Reviewed inputs:

- [Q074 v1](../nested-alternative.md),
  SHA-256 `6135eb8a630288e3ad7079b32638c7d2942cfdc8946b44c3e61498473325f6af`.
- [Q114 v2](../proof-pre-correction.md),
  SHA-256 `b3f853b03158fc58a23ef93ba1b22981121427070d1cfa8d33c9bbafe5c0892e`.
- [Q114 v3](../proof-reviewed.md), the local correction produced by this review.
  The frozen v2 remains unchanged; [the diff](../version-diff.patch) identifies the repair.

**Verdict:** Q074 is supported internally as a full-original candidate. Q114
v2 contains a false fixed-tester dual-attainment assertion; v3 corrects it
without changing the theorem. No fatal gap was identified in the remaining
Q114 argument. Mathematical certainty, independent review and priority are
not established by these verdicts.

## Original scope and overlap

The pinned Q074 original asks whether nested-adaptive and fully parallel
vanishing-type-I Stein exponents coincide for every finite-dimensional
superchannel pair. Q114 asks whether any causally valid interleaving of the
two components can do better than nesting, keeping each internal memory
inaccessible and each first component before its matched second component.
Their complete statements are preserved in the two `*-original.txt` files.

Q074 v1 addresses exactly the first weak-exponent equality. Q114 addresses
the larger interleaving class and proposes an exponential strong converse,
which implies the requested weak converse. No access to hidden memories,
postselected testers or indefinite causal orders is assumed. Q114 implies
Q074, so the records represent one overlapping discrimination direction,
not two independent discoveries.

## Q074: the imported theorem and the missing interface

The crucial external input is Gao--Ji--Liu's CP trace-nonincreasing channel
approximation theorem, Corollaries 5.2--5.3. It is not a result of this
campaign. The proof does not assume that the approximating map is trace
preserving, or that its trace-preserving completion remains CP dominated
by the alternative channel. Both distinctions matter.

The Choi readout in Section 1 is legal: the tester stores A and sends a fresh
maximally entangled half into B, retaining references and the final output.
It obtains R_i/(d_C d_B) without touching internal memory. Failure of Choi
support inclusion therefore gives infinite parallel rate directly. Otherwise
R1<=c R2 supplies uniform complete-order domination for every common tester,
independent of side-wire dimension. The nested intermediate divergences used
in subtraction are then finite.

A CP-TNI inserted map is completed with an accessible flag. The success
branch remains outside the hidden memory. Projecting onto all success flags
is trace nonincreasing and is not followed by renormalization. The separate
state normalization contributes the explicit -log r term, with r>=1-eta^2.
Diamond-to-purified-distance conversion and tensor telescoping yield the
stated smoothing radius xi, including the subnormalized failure mass.

The finite-state AEP must be uniform before optimizing over testers. From
u<=c^n v, inverse-square-root antitonicity on the support bounds
Tr u^(3/2) v^(-1/2) by c^(n/2); Cauchy--Schwarz bounds the affinity by one.
This controls the AEP constant without an ancillary-dimension bound. Fixing
m first, then sending n to infinity, then m to infinity, then the chosen
approximation rate to the channel rate, gives the chain rule. No pointwise
AEP is interchanged with a varying optimizer.

The final nesting telescopes the ordinary amortized channel divergence,
and the binary relative-entropy bound gives the original weak converse.
Fixed-block repetition gives parallel achievability. The Q074 proof alone
does not establish a fixed-error strong converse; that stronger statement
comes from the distinct Q114 argument.

## Q114: physical causal postselection

The pure-isometry domination is inherited fixed-marginal postselection.
In the supplied calculation, a Schur block has an eigenvalue f_lambda/p_lambda
and a target squared norm q_lambda f_lambda. The Specht factors cancel,
leaving sum p_lambda q_lambda, exactly the claimed polynomial. They cannot
be replaced by a crude minimum representation weight.

For a symmetric deterministic joint two-comb, its first marginal is a channel.
The square-root Choi purification gives a canonical Stinespring isometry with
memory (C A)^tensor n. Permutation matrices are real, so this dilation is
covariant under the natural factor permutations. A minimal-memory
realization transfers into the canonical memory by an isometry; the second
channel can be extended on the unused memory complement. Twirling that
channel preserves the original joint comb and makes it covariant. Its own
canonical dilation has a fixed-per-copy environment as well.

Applying pure-isometry domination at both stages and contracting their memory
legs is a fixed CP operation. Each iid atom is a deterministic physical
two-comb, with the required no-backwards-signalling constraint. The product
of the two dimension polynomials is the stated P(n). Applying an ordinary
channel de Finetti bound without preserving that causal constraint would not
justify the next step.

## Q114: common slack, amplification and general testers

Positive-strategy domination gives g_n(Y)=max_T Tr(TY) and the equivalent
minimum deterministic-comb domination cost. Therefore sqrt(g_n(ZZ*)) is a
genuine norm on amplitudes, is tensor submultiplicative, and contracts under
right multiplication up to its operator norm. A full-rank tester makes the
norm nondegenerate.

The fixed-T SDP sentence in v2 incorrectly said that its dual optimum is
always attained. [The correction record](q114-dual-attainment-correction.md)
gives exact physical qubit channels exhibiting nonattainment even above
their regularized discrimination rate. Keeping `inf` in the fixed-T step
is enough: minimax holds, and the full-rank tester bounds the trace of a
global minimizing slack sequence. The global minimum in equation (10) is
therefore attained. The supported Douglas factorization still supplies one
common amplitude, valid for every parallel tester.

The two-rate tensor expansion uses only the checked norm properties, the
common weak approximation and a finite-cost exact residual. The first
iteration lowers cost at stretched-exponential error; the second uses one
fixed sufficiently accurate block and its exact residual to obtain
exponential error. Integer block padding has vanishing rate cost in the
first stage and bounded cost in the second. The strict final rate margin
absorbs it. The large-degree P(n) remains a fixed polynomial, so exponential
error dominates it for every fixed finite set of slot dimensions.

Finally, a general interleaving tester need not normalize every correlated
joint comb. The proof correctly uses only its normalization on every iid
physical one-copy comb. Replacing each use with such a comb gives an acyclic
deterministic circuit, so that normalization holds, including classical
branches choosing later causal orders. Positivity of its total tester and
binary effect follows from the circuit link contractions. Causal
postselection now bounds the residual for these testers, yielding (18).
This is the essential bridge beyond the parallel setting.

Support failure again gives infinite parallel rate via a legal Choi readout;
it is not treated by subtracting infinite divergences. In the finite case,
the converse and the inherited parallel coding theorem cover the entire
pinned original strategy class.

## Exact controls and source comparison

New exact code builds Haar moments from the permutation-commutant Gram
pseudoinverse, rather than from the proposed Schur formula. For qubits at
n=2 and n=3, including a singular Gram matrix, a correlated covariant unitary
gives domination constants 10 and 20. Halving those constants produces exact
negative witnesses. The two fixed-tester counterexamples, their channel
constraints and feasible dual sequences also pass exact checks. These are
finite controls of the vulnerable steps, not certification of all dimensions.

Hirche supplies the strategy model and parallel rate; GJL supplies the
subchannel theorem and amplification algebra; Nahar et al. supply pure
fixed-marginal domination; Gutoski--Watrous supply realization and positive
strategy duality. Zhu--Wang already use closely related positive-slack and
postselection methods for ordinary memoryless channels. Those methods must
be attributed, rather than presented as new here.

The newly checked Ye--Bergh--Datta paper concerns ordinary-channel marginal
and almost-iid representations. Its statements do not directly provide the
all-n physical two-comb domination used here. This distinction and the
infinite-exchangeability limitation of Costa--Barrett--Shrapnel are recorded
in [PRIMARY-COMPARISON.md](PRIMARY-COMPARISON.md). A finite primary-source
search has not established that the causal two-stage extension is new.

Retain both candidate records, point Q114 to v3, and keep priority and fresh
mathematical review pending. No publication, catalogue submission, additional
research round or independent-review count is justified by this review.
