# Thermal mutual information of order beta^(1/4) in one dimension

Yuxuan Zhang. Version 1.0, 13 November 2026. No affiliation listed.

This package accompanies a complete analytical proof candidate. It has sequential internal review, not independent expert or formal verification. The specific primary-source differences are recorded; comprehensive priority remains unresolved.

- `main.tex`: the complete paper; compile with pdflatex twice.
- `proof-reviewed.md`: the proof notes used in the analytical audit.
- `review/REVIEW.md`: bottleneck review and its limits.
- `review/PRIMARY-COMPARISON.md`: inspected sources and precise scope comparisons.
- `checks/`: finite controls, including deliberately incorrect variants.
- `expected/`: recorded reference outputs.
- `PROVENANCE.json`: original problem identifiers and reviewed input hashes.

Run `python reproduce.py` after installing the versions in `requirements.txt` into an environment of your choice. The runner verifies every manifest hash, copies the checking programs into an empty temporary directory, and executes them without an optimizer or a network requirement. Exact outputs must match. Floating diagnostics are checked against their stated tolerances, not by requiring identical last bits.

The finite calculations do not prove the all-size claims; those require the analytical argument in the paper. Internal filenames in the frozen source notes identify the development history. Review links in this portable package have been adjusted for navigation without changing the mathematics.
