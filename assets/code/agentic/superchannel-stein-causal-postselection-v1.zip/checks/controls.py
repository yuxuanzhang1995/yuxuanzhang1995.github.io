"""Exact finite controls; not a proof certificate for the all-size theorem."""
from pathlib import Path
from itertools import permutations, combinations, product
from math import comb, factorial
import json
import sympy as S

def permutation_matrix(n, perm):
    states = list(product(range(2), repeat=n))
    where = {b: i for i, b in enumerate(states)}
    P = S.zeros(2**n)
    for j, bits in enumerate(states):
        P[where[tuple(bits[k] for k in perm)], j] = 1
    return P

def haar_control(n):
    # Haar conjugation is the Hilbert-Schmidt projection onto the permutation
    # commutant. Its Choi matrix uses the Moore-Penrose inverse of that Gram
    # matrix, including the singular n>d case. This avoids fitting eigenvalues
    # to the candidate's claimed Schur formula.
    perms = [permutation_matrix(n, p) for p in permutations(range(n))]
    gram = S.Matrix([[(p.T*q).trace() for q in perms] for p in perms])
    dual = gram.pinv()
    dim = 2**n
    omega = S.zeros(dim*dim)
    for i, p in enumerate(perms):
        for j, q in enumerate(perms):
            omega += dual[i, j]*S.kronecker_product(q, p)
    assert omega == omega.H and omega.trace() == dim
    sym = sum(perms, S.zeros(dim))/factorial(n)
    V = sym + S.I*(S.eye(dim)-sym)  # Correlated, permutation-covariant unitary.
    assert (V.H*V-S.eye(dim)).applyfunc(S.simplify) == S.zeros(dim)
    assert all((V*p-p*V).applyfunc(S.simplify) == S.zeros(dim) for p in perms)
    v = V.T.reshape(dim*dim, 1)
    sol, params = omega.gauss_jordan_solve(v)
    sol = sol.subs({a: 0 for a in params})
    assert (omega*sol-v).applyfunc(S.simplify) == S.zeros(dim*dim, 1)
    exact_cost = S.simplify((v.H*sol)[0])
    assert exact_cost == comb(n+3, 3)
    # Positivity of omega follows from its Haar-twirl construction. Range and
    # the exact inverse quadratic form imply the asserted rank-one domination.
    bad = S.simplify((sol.H*(exact_cost*omega/2-v*v.H)*sol)[0])
    assert bad < 0
    return {'n': n, 'ambient_dimension': dim*dim, 'gram_rank': gram.rank(),
            'rank_one_domination_constant': str(exact_cost),
            'wrong_half_constant_witness': str(bad)}

def singular_tester_dual_control():
    eps = S.symbols('epsilon', positive=True)
    I2 = S.eye(2)
    z = S.diag(1,-1)
    x = S.Matrix([[0,1],[1,0]])
    X = S.kronecker_product(x,z)/4
    R0 = S.eye(4)/2
    R1 = R0+X
    T = S.diag(1,1,0,0)
    assert min(R0.eigenvals()) > 0 and min(R1.eigenvals()) > 0
    def ptrout(M):
        return S.Matrix([[sum(M[2*i+a,2*j+a] for a in range(2))
                          for j in range(2)] for i in range(2)])
    assert ptrout(R0) == I2 and ptrout(R1) == I2
    assert T*X*T == S.zeros(4) and T*X != S.zeros(4)
    F = S.sqrt(eps)*I2.col_join(z/(8*eps))
    Fminus = S.sqrt(eps)*I2.col_join(-z/(8*eps))
    Y = F*F.H
    assert (Y-X-Fminus*Fminus.H).applyfunc(S.simplify) == S.zeros(4)
    assert S.simplify((T*Y).trace()) == 2*eps
    # Any PSD Y with Tr(TY)=0 has TY=0. If also Y-X>=0, its zero
    # T-diagonal would force T(Y-X)=0, contradicting TX!=0. Thus the
    # fixed-T infimum 0 is not attained, although Y_eps approaches it.
    return {'physical_qubit_channels':True,'common_tester':'|0><0| tensor I',
            'fixed_tester_primal':0,'dual_infimum':0,'dual_attained':False,
            'approaching_feasible_objective':'2*epsilon',
            'effect':'Replace min by inf before minimax; global g-minimum remains attained.'}

def singular_tester_above_rate_control():
    # The same failure can occur at a rate strictly ABOVE the regularized
    # channel relative entropy, not just at lambda=1 in the simpler example.
    eps = S.symbols('epsilon', positive=True)
    I2 = S.eye(2)
    z = S.diag(1,-1)
    x = S.Matrix([[0,1],[1,0]])
    t = S.Rational(1,128)
    R0 = S.eye(4)/2
    R1 = R0+S.diag(S.Rational(1,4),-S.Rational(1,4),0,0)+t*S.kronecker_product(x,z)
    def ptrout(M):
        return S.Matrix([[sum(M[2*i+a,2*j+a] for a in range(2))
                          for j in range(2)] for i in range(2)])
    assert ptrout(R0) == I2 and ptrout(R1) == I2
    # Rational diagonal-dominance witnesses prove a R0 <= R1 <= c R0.
    a, c = S.Rational(31,64), S.Rational(97,64)
    for M in [R1-a*R0, c*R0-R1]:
        assert M == M.H
        assert all(M[i,i] >= sum(abs(M[i,j]) for j in range(4) if i != j)
                   for i in range(4))
    P = (R1-a*R0)/(1-a)
    assert ptrout(P) == I2 and (c-a)/(1-a) == 2
    # Convexity and the expansion N^n=(a M+(1-a) P)^n give
    # D_ch^infinity(N||M) <= (1-a) log_2(2)=33/64.
    # Exact integer comparison: 33/64 < log_2(3/2).
    assert 2**97 < 3**64
    lam = S.Rational(3,2)
    X = R1-lam*R0
    T = S.diag(1,1,0,0)
    assert T*X*T == S.diag(0,-S.Rational(1,2),0,0)
    F = S.sqrt(eps)*I2.col_join(t*z/(2*eps))
    Fminus = S.sqrt(eps)*I2.col_join(-t*z/(2*eps))
    Y = F*F.H
    remainder = (Y-X-Fminus*Fminus.H).applyfunc(S.simplify)
    assert remainder == S.diag(0,S.Rational(1,2),S.Rational(1,4),S.Rational(1,4))
    assert S.simplify((T*Y).trace()) == 2*eps
    # At objective zero TY=0. Then (Y-X)[0,0]=0 while its [0,2]
    # entry is -t, contradicting positive semidefiniteness.
    assert X[0,0] == 0 and X[0,2] != 0
    return {'physical_qubit_channels': True, 'lambda': '3/2',
            'regularized_rate_upper_bound_bits': '33/64',
            'rate_strictly_above_upper_bound': True,
            'fixed_tester_primal': 0, 'dual_infimum': 0,
            'dual_attained': False, 'approaching_feasible_objective': '2*epsilon'}

if __name__ == "__main__":
    result={'status':'PASS','q114_haar_normalization':[haar_control(2),haar_control(3)],'q114_fixed_tester_dual':singular_tester_dual_control(),'q114_fixed_tester_dual_above_rate':singular_tester_above_rate_control()}
    Path("controls-result.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
