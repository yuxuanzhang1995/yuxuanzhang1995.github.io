# Primary-source comparison

Inspected through 9 November 2026. The claim of difference below concerns
the stated theorems and open questions in these sources, not an exhaustive
certification of worldwide priority.

| Primary source | What it establishes or supplies | Relationship to this manuscript |
| --- | --- | --- |
| [Akibue, Miyazaki and Osaka, arXiv:2501.17394v4](https://arxiv.org/html/2501.17394v4), Theorem 3 and Corollary 1 | A pure resource of the same Schmidt rank as the target entangled state must be maximally entangled to implement its exact verification measurement by separable operations. | Applied to an EJM outcome, this settles resource Schmidt rank two. Section 5.3 explicitly leaves the higher-rank EJM question open. The manuscript adds a quantitative tail constraint and the arbitrary-finite-rank entropy lower bound. |
| [S. Bandyopadhyay, arXiv:2611.05317v1](https://arxiv.org/html/2611.05317v1), Theorem 1 and equations (7)–(12) | A linear-algebra proof of matched-rank rigidity, including the contraction and effect-eigenvector reductions. | Those reductions are inherited and cited. Section 5.2 still leaves higher-rank EJM resources open. The adjugate/completeness estimate in Section 3 of this manuscript controls that tail. |
| [Bandyopadhyay, Brassard, Kimmel and Wootters, arXiv:0809.2264](https://arxiv.org/abs/0809.2264), Physical Review A 80, 012313 (2009), Section III | Coherent detector methods for lower bounds on measurement entanglement cost. | The detector method is inherited. The explicit EJM detector yields lambda_1 <= 2/3 here. That bound alone does not prove the one-ebit result. |
| [Nielsen, arXiv:quant-ph/9811053](https://arxiv.org/abs/quant-ph/9811053), Physical Review Letters 83, 436 (1999) | Majorization criterion for deterministic pure-state LOCC conversion. | Used to turn the detector conversion into its largest-Schmidt-probability bound. |
| [Gisin, Entropy 21, 325 (2019)](https://doi.org/10.3390/e21030325) | Definition of the elegant joint measurement. | The tetrahedral measurement is the same one; the input model is not changed. |
| [Pauwels, Pozas-Kerstjens, Del Santo and Gisin, arXiv:2408.00831](https://arxiv.org/abs/2408.00831), Physical Review X 15, 021013 (2025) | Entanglement-assisted localization without communication during the local measurement stage. | A different communication model. Its EJM construction does not establish the adaptive-LOCC cost considered here. |

Bandyopadhyay's Section 5.1 discusses higher-rank sub-ebit resources for
other, weakly entangled two-qubit bases. The manuscript makes no universal
one-ebit claim for two-qubit bases. Its tail argument uses the specific EJM
identity sum_j |det E_j|=1; retaining the actual determinant sum for another
basis changes the inequality.

Targeted searches for EJM entanglement cost, higher Schmidt rank, one-ebit
optimality and Schmidt-tail bounds did not locate the same result. The
[catalogue problem](https://qiqc-op.com/problem/op_d40d1f65b5aaaefd/)
retained the unrestricted finite-rank question when inspected. Its status
badge alone is not evidence of novelty. The supplied pinned record preserves
its historical wording, rather than changing the catalogue's claim.

The proposed new result is therefore the full finite-rank lower bound for
this EJM, obtained by combining a coherent detector with the quantitative
adjugate/completeness tail inequality and the entropy argument. The matched-
rank theorem, detector framework and teleportation upper bound are credited
to their prior sources.
