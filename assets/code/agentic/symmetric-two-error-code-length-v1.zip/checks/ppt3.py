"""Partial-time-reversal strengthening of the same three-copy moment unit."""
from pathlib import Path
from fractions import Fraction as F
import sys,time,pickle,json
import numpy as np
import sympy as sp
from moment3 import delta2,h_rational,basis_transform,recoupling,coupled_matrix


def transfer(blocks,a,b):
    n=blocks[0]['n'];j=F(n,2)
    support=[bi for bi,bl in enumerate(blocks) if a in bl['aa'] and b in bl['aa']]
    out=np.zeros((len(support),len(support)),dtype=object);out[:]=F(0)
    for l in range(abs(a-b),min(n,a+b)+1):
        common2=F((2*a+1)*(2*b+1))*delta2(j,j,F(a))*delta2(j,j,F(b))*delta2(F(a),F(b),F(l))*delta2(j,j,F(l))
        fac=F((-1)**l*(2*l+1))*common2
        c=[h_rational(blocks[bi],a,b,l) for bi in support]
        for i,ci in enumerate(c):
            for k,ck in enumerate(c):out[i,k]+=fac*ci*ck
    for i,bi in enumerate(support):
        bl=blocks[bi];ia=bl['aa'].index(a);ib=bl['aa'].index(b)
        out[i,:]/=(2*bl['J']+1)*bl['d'][ia]*bl['d'][ib]
    assert np.array_equal(out@out,np.eye(len(support),dtype=object))
    return support,out


def direct_pt_control(n):
    blocks=recoupling(n);N=n+1;rng=np.random.default_rng(356+n)
    Zs=[];Cs=[];Omega=np.zeros((N**3,N**3))
    for bl in blocks:
        sz=len(bl['aa']);zz=rng.normal(size=(sz,sz));zz=(zz+zz.T)/2
        tt=np.sqrt(np.array(bl['d'],float));xx=tt[:,None]*zz*tt[None,:]
        Zs.append(zz);cl=[]
        for m2 in range(int(-2*bl['J']),int(2*bl['J'])+1,2):
            _,C=coupled_matrix(n,sp.Rational(bl['J'].numerator,bl['J'].denominator),sp.Rational(m2,2))
            C=np.array(C,float);cl.append(C);Omega+=C@xx@C.T
        Cs.append(cl)
    pt=Omega.reshape(N,N,N,N,N,N).transpose(0,1,5,3,4,2).reshape(N**3,N**3)
    flip=np.zeros((N,N))
    for i in range(N):flip[n-i,i]=(-1)**i
    big=np.kron(np.eye(N*N),flip);pt=big@pt@big.T
    pred=[np.zeros_like(z) for z in Zs]
    for a in range(n+1):
        for b in range(n+1):
            ss,T=transfer(blocks,a,b)
            v=np.array([Zs[bi][blocks[bi]['aa'].index(a),blocks[bi]['aa'].index(b)] for bi in ss])
            out=np.array(T,float)@v
            for bi,value in zip(ss,out):pred[bi][blocks[bi]['aa'].index(a),blocks[bi]['aa'].index(b)]=value
    err=0.
    for bl,cl,z in zip(blocks,Cs,pred):
        x=sum(C.T@pt@C for C in cl)/float(2*bl['J']+1)
        tt=np.sqrt(np.array(bl['d'],float));err=max(err,float(np.max(np.abs(x-tt[:,None]*z*tt[None,:]))))
    assert err<1e-11,(n,err)
    return err


def build_maps(blocks,variables):
    n=blocks[0]['n'];nv=len(variables)
    zm=[np.zeros((len(bl['aa']),len(bl['aa']),nv)) for bl in blocks]
    for ci,(bi,u,v) in enumerate(variables):zm[bi][:,:,ci]=np.array(basis_transform(blocks[bi],u,v),float)
    yp=[np.zeros_like(z) for z in zm]
    for a in range(n+1):
        for b in range(a,n+1):
            # S3 invariance already makes opposite swap12 parity entries zero.
            if (a-b)%2:continue
            ss,T=transfer(blocks,a,b)
            vec=np.array([zm[bi][blocks[bi]['aa'].index(a),blocks[bi]['aa'].index(b)] for bi in ss])
            res=np.array(T,float)@vec
            for bi,row in zip(ss,res):
                ia=blocks[bi]['aa'].index(a);ib=blocks[bi]['aa'].index(b)
                yp[bi][ia,ib]=row;yp[bi][ib,ia]=row
    return yp


if __name__=='__main__':
    import scipy.linalg as la
    import cvxpy as cp
    base=Path(__file__).resolve().parent;t=time.time()
    print('PT controls',{n:direct_pt_control(n) for n in [1,2,3]},flush=True)
    n=int(sys.argv[1]) if len(sys.argv)>1 else 18;depth=4
    blocks,labels,variables,A,b,G,EA=pickle.loads((base/f'data-n{n}-d4.pkl').read_bytes())
    cache=base/f'ppt-maps-n{n}.pkl'
    if cache.exists():yp=pickle.loads(cache.read_bytes())
    else:yp=build_maps(blocks,variables);cache.write_bytes(pickle.dumps(yp))
    print('maps ready',time.time()-t,flush=True)
    af=np.array(A,float);rs=np.maximum(np.abs(af).max(axis=1),1e-300);bf=np.array(b,float)/rs;af/=rs[:,None]
    gf=np.array(G,float);gs=np.maximum(np.abs(gf).max(axis=1),1e-300);gf/=gs[:,None]
    _,r,piv=la.qr(af.T,mode='economic',pivoting=True);keep=piv[:np.sum(np.abs(np.diag(r))>1e-10)]
    hs=[cp.Variable((len(bl['keep']),len(bl['keep'])),symmetric=True) if bl['keep'] else None for bl in blocks]
    x=cp.hstack([hs[bi][u,v] for bi,u,v in variables]);mu=cp.Variable()
    constraints=[af[keep]@x==bf[keep],gf@x>=0]+[h>>0 for h in hs if h is not None]
    for bi,bl in enumerate(blocks):
        for parity in [0,1]:
            ii=[i for i,a in enumerate(bl['aa']) if a%2==parity]
            if not ii:continue
            ym=yp[bi][np.ix_(ii,ii)].reshape(len(ii)**2,len(variables))
            Y=cp.reshape(ym@x,(len(ii),len(ii)),order='C')
            constraints.append(Y-mu*np.eye(len(ii))>>0)
    pr=cp.Problem(cp.Maximize(mu),constraints)
    val=pr.solve(solver='CLARABEL',max_iter=200,tol_feas=1e-9,tol_gap_abs=1e-9,tol_gap_rel=1e-9)
    out=dict(n=n,depth=depth,status=pr.status,partial_transpose_margin=mu.value,exact_certificate=False,elapsed_seconds=time.time()-t)
    if x.value is not None:
        xx=np.array(x.value);out.update(x=xx.tolist(),max_equality_residual=float(np.max(np.abs(af@xx-bf))),min_inequality=float(np.min(gf@xx)),minimum_seed_eigenvalue=min(float(np.linalg.eigvalsh(h.value).min()) for h in hs if h is not None),minimum_PT_eigenvalue=min(float(np.linalg.eigvalsh(np.einsum('abk,k->ab',y,xx)).min()) for y in yp),enumerator=(np.array(EA,float)@xx).tolist())
    (base/f'numerical-ppt-n{n}.json').write_text(json.dumps(out,indent=2,default=lambda v:float(v))+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['x','enumerator']},default=lambda v:float(v)),flush=True)
