"""Finite quantum-output control with complex Kraus cross terms.

Uses the previously known GP amplitude-damping example only as a control.
This file independently constructs a finite clock and sector isometries.
No new claim about that example or its exact-cost discontinuity is made.
"""
import json
from pathlib import Path
import numpy as np
from scipy.linalg import expm

HERE=Path(__file__).resolve().parent
I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1,-1]).astype(complex)
paulis=[I,X,Y,Z]
K=[np.diag([1,1/np.sqrt(2)]).astype(complex),np.array([[0,1/np.sqrt(2)],[0,0]],complex)]
z=1-16*np.sqrt(2)/15
x=4*np.sqrt(30*np.sqrt(2)-41)/15
angle=np.pi/3
rA=np.array([x*np.cos(angle),x*np.sin(angle),z])
rB=np.array([rA[0]/np.sqrt(2),rA[1]/np.sqrt(2),(1+z)/2])
h=np.log(2)/2
HA=-2*h*sum(a*s for a,s in zip(rA/(3/5),[X,Y,Z]))
HB=-h*sum(a*s for a,s in zip(rB/(1/3),[X,Y,Z]))
gA=expm(-HA);gA/=np.trace(gA)
gB=expm(-HB);gB/=np.trace(gB)
assert np.linalg.norm(sum(k@gA@k.conj().T for k in K)-gB) < 1e-13

def omega(C,O=I):
    return sum(C[a,b]*K[a].conj().T@O@K[b] for a in range(2) for b in range(2))

def coords(A):
    return np.array([np.trace(P@A).real/2 for P in paulis])

M=np.stack([coords(omega(P)) for P in paulis],axis=1)
rhs=HA-sum(k.conj().T@HB@k for k in K)
C1=sum(c*P for c,P in zip(np.linalg.solve(M,coords(rhs)),paulis))
assert np.linalg.norm(omega(C1)-rhs) < 1e-13
assert np.max(np.abs(C1.imag)) > .01
_,UA=np.linalg.eigh(HA); _,UB=np.linalg.eigh(HB)
Ke=[UB.conj().T@k@UA for k in K]
alabel=np.array([-2,2]);blabel=np.array([-1,1])
assert np.linalg.norm(UA.conj().T@HA@UA-np.diag(h*alabel)) < 1e-13
assert np.linalg.norm(UB.conj().T@HB@UB-np.diag(h*blabel)) < 1e-13

W=8.;N=400
clock=np.arange(-N,N+1)
def pc(E):
    p=2*W**3/(np.pi*(W*W+E*E)**2)
    dp=-4*E/(W*W+E*E)*p
    return p,p*I-C1*dp

mass=np.array([pc(h*n)[0] for n in clock]); mass/=mass.sum()
P={int(n):float(p) for n,p in zip(clock,mass)}
sectors=sorted(set(int(n+a) for n in clock for a in alabel))
rows={}
gram_residual=0.;transpose_mutation=0.;min_eigenvalue=1.
for E in sectors:
    A=np.zeros((4,2),complex)
    expected=np.zeros((2,2),complex)
    transposed=np.zeros((2,2),complex)
    for j,b in enumerate(blabel):
        _,C=pc(h*(E-b))
        v,u=np.linalg.eigh(C)
        min_eigenvalue=min(min_eigenvalue,float(v[0]))
        assert v[0]>0
        S=(u*np.sqrt(v))@u.conj().T
        for s in range(2):
            A[2*j+s]=sum(S[s,a]*Ke[a][j] for a in range(2))
        for a in range(2):
            for d in range(2):
                outer=np.outer(Ke[a][j].conj(),Ke[d][j])
                expected+=C[a,d]*outer
                transposed+=C[d,a]*outer
    L=A.conj().T@A
    gram_residual=max(gram_residual,float(np.linalg.norm(L-expected)))
    transpose_mutation=max(transpose_mutation,float(np.linalg.norm(L-transposed)))
    v,u=np.linalg.eigh(L)
    inv=(u/np.sqrt(v))@u.conj().T
    G=np.array([P.get(int(E-a),0.) for a in alabel])
    actual=(A@inv)*np.sqrt(G)[None,:]
    for j,b in enumerate(blabel):
        for s in range(2):
            key=(int(E-b),s)
            if key not in rows: rows[key]=np.zeros((2,2),complex)
            rows[key][j]=actual[2*j+s]

tp=np.linalg.norm(sum(k.conj().T@k for k in rows.values())-I)
assert tp < 1e-11
assert gram_residual < 1e-13
assert transpose_mutation > 1e-5
def choi(kraus):
    vectors=[k.T.reshape(-1) for k in kraus]
    return sum(np.outer(v,v.conj()) for v in vectors)

J=choi(rows.values());target=choi(Ke)
trace_norm=float(np.sum(np.abs(np.linalg.eigvalsh(J-target))))
mean=np.dot(mass,h*clock)
qfi=4*(np.dot(mass,(h*clock)**2)-mean**2)
result={"role":"intrinsic quantum-output control, not independent review",
        "predecessor_example_credit":"R337 zero-boundary quantum-output example; qualitative gap predates it in R268",
        "gibbs_residual":float(np.linalg.norm(sum(k@gA@k.conj().T for k in K)-gB)),
        "Omega0_real_basis_determinant":float(np.linalg.det(M)),
        "first_joint_equation_residual":float(np.linalg.norm(omega(C1)-rhs)),
        "complex_cross_terms":True,"clock_dimension":len(clock),"environment_kraus_count":len(rows),
        "sector_gram_residual":gram_residual,"transpose_mutation_residual":transpose_mutation,
        "tp_residual":float(tp),"resource_qfi":float(qfi),
        "choi_trace_norm_error":trace_norm,
        "purified_channel_error_upper_from_choi_numeric":min(1.,float(np.sqrt(trace_norm))),
        "rigorous_interval_certificate":False}
(HERE/'quantum-output-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
