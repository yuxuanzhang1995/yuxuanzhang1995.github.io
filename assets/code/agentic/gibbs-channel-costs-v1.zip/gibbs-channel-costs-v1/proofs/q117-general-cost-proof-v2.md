# General-channel small-error coherence cost: proof candidate v2

23 November 2026; R337. Same-agent derivation, not independently reviewed.
The exact original Q117 also asks for all-error optimal costs and a work-cost
characterization. Those are not supplied by this asymptotic result. The
finite-energy criterion below is an equivalence, not a finite algorithm.

Imported inputs: covariant Stinespring dilation; the minimal-variance
purification characterization of QFI (Marvian, PRL 129, 190502, Theorem 3);
one-variable analytic Smith reduction; elementary Fourier/Poisson summation.
The arbitrary-POVM spectral-power result and irrational-clock construction
from R270 are predecessors. The extension here retains all Kraus cross terms
for arbitrary quantum outputs. No novelty or priority certification is made.

## Statement and conventions

Fix finite-dimensional A,B, Hamiltonians H_A,H_B, and a channel Phi with a
minimal Kraus family K_1,...,K_r. Let V=sum_alpha K_alpha tensor |alpha> and
Omega_h(C)=V^*(H_B^h tensor C)V. Allow arbitrary finite resource states and
Hamiltonians, charged by their SLD QFI, and arbitrary thermal operations.
There is no bound on ancillary dimension or on incoherent work resources.
The error is reference-assisted purified channel distance. Write F_c(epsilon)
for the infimum of the charged QFI.

For each m solve JOINTLY for Hermitian C_1,...,C_m with C_0=I_r:

  sum_(h=0)^l binom(l,h) Omega_h(C_(l-h))=H_A^l, 0<=l<=m.       (J_m)

Let k be the first infeasible positive order, or infinity. The proposed
conclusions are:

* If k is finite, c epsilon^(-2/k)-1 <= F_c(epsilon)
  <= C epsilon^(-2/k) for sufficiently small epsilon, with positive constants
  depending only on the fixed channel and Hamiltonians.
* If k=infinity, sup_(0<epsilon<epsilon_0) F_c(epsilon)<infinity.

These statements do not equate a bounded positive-error limit with the
existence of an exact finite resource. Both claims concern the infimum over
finite physical implementations, not an allowed infinite clock.

Adding scalar constants to system Hamiltonians only changes the analytic
unknown by an exponential scalar; the first infeasible order is unchanged.

## 1. Pure resources and an exact finite criterion

A finite mixed resource eta_R admits a finite purification psi_RR' and a
Hamiltonian on R' such that 4 Var_psi(H_R+H_R')=F_Q(eta_R,H_R), by the
imported purification theorem. Applying the old operation to R and then
tracing R' implements the same channel. The Hamiltonian must be optimized;
assigning zero Hamiltonian to a purification would not prove this claim.
Thus pure resources with freely chosen finite Hamiltonians suffice for the
QFI infimum. Additional sharp-energy resources have QFI zero but are charged
resources in any separate work accounting.

Write H_A=sum_i e_i P_i and H_B=sum_j f_j Q_j. For a finite scalar probability
p and a finite positive r-by-r matrix measure C_z, define

  sum_z C_z=I_r,
  L_E=sum_j V^*(Q_j tensor C_(E-f_j))V,
  G_E=sum_i p(E-e_i)P_i.                                    (1)

Exact implementation with that pure clock is equivalent to L_E=G_E for
all E, up to energy translations and zero-QFI ancillary registers.

For necessity use a finite covariant Stinespring isometry for the operation
on A and the resource. The thermal bath can be purified with a compensating
negative auxiliary Hamiltonian, making its purification invariant. It
therefore introduces no uncharged coherent variance. Collect the induced
channel Kraus operators A_(s,z) by environment energy z. Exact equality of
Choi matrices implies A_(s,z) is in the target Kraus span. Write
A_(s,z)=sum_alpha S_(s,z),alpha K_alpha and C_z=S_z^* S_z. Kraus linear
independence gives sum C_z=I. With the convention above, the Choi coefficient
matrix is C_z^T, while the energy-sector Gram uses C_z without transpose.
Energy conservation and isometry give (1).

For sufficiency factor each C_z this way. In sector E collect the rows
Q_j A_(s,E-f_j) into A_E. Then A_E^*A_E=G_E. On supp(G_E), the map
A_E G_E^(-1/2) is an isometry. Zero columns of G_E are zero columns of A_E.
The occupied input sector has one column for each A basis state whose clock
energy E-e_i occurs. Tensoring the input with amplitudes sqrt(p) restores
A_E, hence the target channel after tracing the environment.

There is a finite energy-conserving unitary realization: append output and
environment registers in sharp initial energies, reset the old input and
clock to fixed energy states at the output, and shift the output environment
energies by the fixed ancillary energy offset. The prescribed input/output
subspaces then have the same total energy. Complete an orthonormal basis
in each sector of the single finite tensor-product Hilbert space. Shift
all finite Hamiltonians by constants if nonnegative spectra are desired.
This uses no free pure state: every sharp register is included among the
zero-QFI resources. Consequently it is a valid thermal-operation protocol
with a trivial bath, in the stated QFI model.

## 2. Analytic reduction and a robust residual lemma

In Hermitian matrix bases the equation

  L(u)C(u):=V^*(exp(u H_B) tensor C(u))V=exp(u H_A), C(0)=I    (2)

is a finite real analytic linear system near u=0. Taylor coefficients of
(2), using C(u)=sum C_l u^l/l!, are exactly J_m. The ring of convergent
one-variable real power series is a discrete valuation ring. Analytic
invertible row and column operations reduce L(u) to diagonal nonzero powers
u^s (absorbing analytic units) and zero rows. The prescribed constant C(0)
transforms to a prescribed constant vector y_0.

In each nonzero row u^s y(u)=b(u), formal feasibility requires that all
coefficients of b below s vanish and that b_s=y_0 in that coordinate.
Higher coefficients then determine analytic y. Each zero row requires
b identically zero. Free coordinates can be chosen analytic. Therefore
all finite jets feasible implies an analytic solution of (2); failure is
already visible at a finite first order. This argument checks all jointly
feasible jets, not extension of one arbitrarily selected lower-order jet.

More quantitatively, if the first failure is k, there are c,delta,t_0>0
such that for real 0<|t|<t_0 and any complex matrix X with ||X-I||<=delta,

  ||L(it)X-exp(it H_A)|| >= c |t|^k.                        (3)

Indeed, a failed row has either a first nonzero coefficient of b at an
order k<s, a constant mismatch at k=s, or a zero diagonal row with first
nonzero b coefficient at k. In the first and third cases bounded X cannot
cancel the leading term. In the second case choose delta less than half
the nonzero mismatch after the bounded analytic coordinate changes. All
other terms are smaller at small t. The row operations and their inverses
are uniformly bounded near zero. Allowing complex X on u=it does not remove
a mismatch present in the real analytic system.

## 3. Lower bound uniformly over all finite resources

Use the pure reduction and center the clock energy. Let its probability
measure be mu, with Var(mu)=F/4. Let W:A->B tensor E be the implemented
channel isometry induced by a covariant dilation and that pure clock.
Conservation gives, exactly,

  mu_hat(t) exp(it H_A)=W^*(exp(it H_B) tensor exp(it H_E))W.  (4)

Let P be the Hilbert--Schmidt projection onto span{K_alpha}. Project every
environment-energy Kraus operator of W using P, obtaining W_c and a positive
coefficient measure C(dz). A normalized maximally entangled input is one
allowed channel test. Purified distance <=epsilon implies the actual Choi
state has weight at most epsilon^2 outside target Choi support. Thus

  ||W-W_c||_HS <=sqrt(d_A) epsilon.                         (5)

The target Kraus Gram matrix is invertible. Applying its inverse to the
compressed Choi matrix, whose trace distance to the target is O(epsilon),
yields C(R)=I+O(epsilon). Equation (5), ||W||_HS=sqrt(d_A), and projection
contractivity give, uniformly in t,

  ||mu_hat(t) exp(it H_A)-L(it) C_hat(t)|| <=c_1 epsilon.    (6)

The same Gram inverse controls each coefficient vector norm. Moreover the
intertwiner for A+R gives

  (I tensor H_E)W = W H_A + T(.-tensor H_R psi) -(H_B tensor I)W.

Here T is the covariant dilation before inserting psi; it is an isometry.
After centering H_R, the Hilbert--Schmidt norm of the right-hand side is at
most sqrt(d_A)(||H_A||+||H_B||+sqrt(F)/2). It follows that

  integral z^2 Tr C(dz) <=c_2(1+F),
  ||C_hat(t)-I|| <=c_3(epsilon+|t|sqrt(1+F)).               (7)

No bath energy variance has been assumed small: the invariant bath
purification is part of T, and cancels in its covariance relation.

Since Re mu_hat(t)>=1-Ft^2/8 and |mu_hat(t)-1|<=|t|sqrt(F)/2,
set t=a/sqrt(1+F), with fixed a>0 sufficiently small, and let
X=C_hat(t)/mu_hat(t). For small epsilon, (7) ensures ||X-I||<=delta in (3),
and mu_hat is bounded away from zero. Combining (3) and (6) proves

  epsilon >=c_4(1+F)^(-k/2).

This bound is uniform in resource dimension, resource spectrum, bath,
number of Kraus operators of the approximation, and any invariant ancillary
registers. Infimizing gives the claimed lower bound. Finite k also rules out
an exact finite implementation.

## 4. A positive energy profile

Choose a normalized, even, strictly positive band-limited density f on R:

  f(x)= [sinc(x)^4+sinc(x+pi/2)^4+sinc(x-pi/2)^4]/(2 pi),
  sinc(x)=sin(x)/x, sinc(0)=1.

Each shifted term integrates to 2pi/3. No common zero exists. There are
constants 0<c<C with c/(1+x^4)<=f(x)<=C/(1+x^4). Every fixed derivative
satisfies |f^(l)|<=C_l f. Its Fourier transform is supported in [-4,4].
It has finite second moment. Put p_W(E)=W^(-1) f(E/W). Thus
|p_W^(l)|<=C_l W^(-l) p_W, variance O(W^2), and Fourier support [-4/W,4/W].

For finite k choose jointly feasible C_0,...,C_(k-1) and put

  C_W(E)=sum_(l<k) (-1)^l C_l p_W^(l)(E)/l!.

For large W this Hermitian matrix lies between (1/2)p_W I and (3/2)p_W I
and integrates to I. Taylor expansion of p_W(E-a) at fixed shifts a and
J_(k-1) gives the uniform relative residual

  ||sum_j Omega_j(C_W(E-f_j))-sum_i p_W(E-e_i)P_i||
      <=C p_W(E) W^(-k).                                  (8)

The derivative bound and fixed-shift ratios control the Taylor remainder.

For k=infinity choose the analytic solution C(u) of (2). On the physical
line let R be the inverse Fourier transform of chi(t)C(it), where chi is
real, even, smooth, compactly supported in the analytic neighborhood and
one near zero. R is Hermitian and Schwartz, with integral I. Define
C_W=p_W*R. Uniformly in E, p_W(E-y)/p_W(E) tends to 1 as W grows for fixed y,
and is bounded by C(1+|y|)^4. Dominated convergence against the Schwartz
kernel shows C_W(E)/p_W(E) tends uniformly to I. Fix W large enough that
C_W is positive and that the Fourier support of p_W lies where chi=1.
Then the Fourier form of (2) gives exact equality L_E=G_E in (8).
Only a finite second moment at this one fixed W is needed in this case.

## 5. Discretization without commensurability

After constant energy shifts, choose rationally independent real numbers
omega_1,...,omega_q such that every e_i,f_j has an integer-coordinate label.
Write omega=(omega_i), E_z=omega dot z, z in Z^q, and P_perp for projection
orthogonal to omega. Choose g(y)=(1+||y||^2)^(-b), b>q+3, on R^(q-1).
For q=1 omit the transverse factor. For q>=2 define raw samples

  p_z=p_W(E_z) g(P_perp z/L)/Z,
  D_z=C_W(E_z) g(P_perp z/L)/Z,
  Z=sum_z p_W(E_z)g(P_perp z/L).

All sums converge. Poisson summation can be applied to the scalar profile,
the matrix profile, and E^2 p_W(E)g. Their Fourier transforms have compact
support in the energy-parallel coordinate, and the transverse transform
of g is a modified-Bessel expression decaying exponentially, up to a
polynomial factor. In a fixed bounded parallel-frequency slab, nonzero
dual integer lattice points have transverse norm bounded away from zero:
otherwise a bounded sequence of integer points would converge to a nonzero
integer vector parallel to omega, contradicting rational independence.
Large integer points in that slab have transverse norm proportional to
their length. Summing the exponential tails is therefore legitimate.

Consequently, uniformly for W above a fixed sufficiently large value,

  S:=sum_z D_z=I+O(exp(-c L)),
  sum_z E_z^2 p_z=O(W^2).                                 (9)

For the second statement the energy Fourier transform is -p_hat_W'',
whose size is O(W^2) and whose support stays compact. The zero dual term
is the continuous second moment; all other terms have the same exponentially
small transverse factor. For q=1 choose W so no nonzero reciprocal lattice
point lies in the compact energy Fourier support: the required mass sums
are then exact. The same reasoning applies to the finite-jet matrix profile
and to the analytic profile p_hat_W C(it).

Replace D_z by C_z=S^(-1/2)D_z S^(-1/2), so sum C_z=I exactly and positivity
is preserved. The correction is O(exp(-c L)) relative to p_z. Fixed shifts
have transverse ratios g(y-v/L)/g(y)=1+O(1/L) uniformly in y, since log g
has bounded gradient. Energy shifts have bounded p_W ratios. Thus (8)
becomes the lattice estimate

  ||L_E-G_E||<=C p_E delta,
  c p_E I<=G_E,L_E<=C p_E I,
  delta= W^(-k)+L^(-1)+exp(-cL),                            (10)

where the W^(-k) term is absent for the analytic k=infinity construction.
For finite k choose L large enough (for example a fixed sufficiently large
multiple of W^(k+1)); for infinite k keep W fixed and send L to infinity.
No rational approximation of physical energies is made.

## 6. Energy-sector normalization and finite truncation

Factor C_z=S_z^*S_z, define A_(s,z)=sum_alpha S_(s,z),alpha K_alpha, and
collect A_E as in Section 1. Its Gram is L_E. Normalize by the actual sector
isometry T_E=A_E L_E^(-1/2). Inserting the pure clock gives the dilation
rows A_E B_E, with B_E=L_E^(-1/2)G_E^(1/2). Standard positive-square-root
perturbation on the fixed interval [c,C], after dividing by p_E, gives
||B_E-I||<=C delta. Commutation of L_E and G_E is NOT assumed.

The raw target dilation with rows A_E is an isometry because sum C_z=I.
The squared Hilbert--Schmidt difference is bounded by

  sum_E Tr[(B_E-I)^* L_E(B_E-I)]
    <= d_A C delta^2 sum_E ||L_E|| <= C' delta^2,

using sum_E Tr L_E=d_A. Hence reference-assisted purified channel error is
O(delta). The inequality is a norm estimate; no false operator comparison
(B-I)^*L(B-I)<=||B-I||^2 L is needed.

This countable lattice dilation is only an intermediate construction.
Choose a finite symmetric cube containing clock probability at least
1-epsilon^2/16 and retain the corresponding input columns of each T_E.
Every column is still orthonormal within its energy sector. Only finitely
many environment energies are reached; complete a finite conserving unitary
by Section 1. Contractivity of purified distance under the same isometry
bounds the extra channel error by epsilon/4. The conditional clock second
moment grows by at most a factor two once retained mass exceeds one half.
The clock mean is zero by the symmetric scalar profile and symmetric cube;
an energy shift, if desired, does not affect variance.

For finite k set W of order epsilon^(-1/k), choose L as above, and truncate
at the stated tail. This gives a finite implementation with F=O(W^2).
For infinite k retain the one fixed W, choose L and then the finite cube
as a function of epsilon; F stays bounded while dimension may diverge.
This completes the proposed upper bounds.

## 7. A finite bound on the required jet order

The infinite alternative is determined by finitely many exact jet systems.
Let a and b be the numbers of distinct input and output energies, and let p
be the generic rank of the analytic matrix L(u) in Hermitian bases. Define

    N=binom(b+p-1,p),       K=a N-1.                       (11)

Feasibility of J_K implies feasibility of every jet and hence the bounded
positive-error limit. When K=0 this includes just the fixed zeroth equation.
This is a structural finite bound, not a polynomial-time numerical algorithm
for arbitrary real Hamiltonian data.

Each p-by-p minor of L(u) is an exponential polynomial whose frequencies
are sums of p output energies. It has at most N distinct frequencies. A
nonzero exponential polynomial with T distinct real frequencies has vanishing
order at most T-1 at zero, by invertibility of the Vandermonde matrix of its
first T derivatives. The sum of the p Smith exponents is the minimal order
of a nonzero p-minor and is therefore at most N-1. Every obstruction to
analytic divisibility in a nonzero Smith row, including the prescribed
constant C(0), appears by this order.

If the augmented matrix [L(u)|exp(u H_A)] has rank p+1, each nonzero
(p+1)-minor has at most a N frequencies (one input energy plus p output
energies). In Smith coordinates, its determinantal ideal is generated by
the product of the p nonzero diagonal entries times the residual zero-row
coordinates of the transformed right-hand side. Thus the earliest nonzero
zero-row residual has order at most a N-1 minus the sum of Smith exponents,
and in particular at most K. If the augmented rank is p, all zero-row
residuals vanish identically. This proves (11), including singular L(0).

The bound uses exact algebraic zero tests. It is not justified to infer all
jet feasibility from a numerically ill-conditioned truncated linear solve.
For scalar output energy b=1 the bound reduces to K=a-1, consistent with
the inherited measurement spectral-power criterion.

## Audit obligations and present status

The proof explicitly addresses arbitrary mixed resources, Choi-support
projection, the prescribed constant in Smith reduction, noncommuting sector
normalization, incommensurate energies, and finite thermal completion.
The two main analytic ingredients should still receive an independent
expert review: the uniform lattice Poisson estimate and the resource model's
allowance of arbitrary sharp-energy auxiliary registers. The finite tests
in q117-jet-controls.py establish examples and conventions, not these
analytic steps. This is a uniform-bridge candidate for Q117, not a full
original solution, and no public release is authorized in this block.
