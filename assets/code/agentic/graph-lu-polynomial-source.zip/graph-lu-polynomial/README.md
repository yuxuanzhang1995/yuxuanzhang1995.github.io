# Polynomial-time decision of local-unitary equivalence for graph states

Yuxuan Zhang

1. Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
2. Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

Working manuscript dated 22 September 2026. AI-assisted proof candidate; independent expert review and historical-priority verification are pending. This is a full exposition of the round-21 candidate, not a new research round or another solved-problem count.

## Scope

The proposed theorem decides local-unitary equivalence of arbitrary finite simple graph states on the same labelled vertex set in deterministic polynomial bit complexity. It depends on the credited Claudet–Perdrix graph reductions. The contribution is a polynomial incidence-module closure, its complete modular-kernel and binary-image construction, and the verification that they meet the reduction's hypotheses.

The claim does not include vertex relabelling, an optimized exponent, practical performance, or a complete executable implementation of the graph-state algorithm. The exact scripts below check finite algebraic systems. They do not certify the general theorem or independently check all published graph reductions.

## Files

- `graph-lu-polynomial.pdf` and `graph-lu-polynomial.tex`: the 12-page manuscript and its LaTeX source.
- `frozen-proof.md`: the unchanged three-part proof from round 21 and QIQC issue #97.
- `check_graph_closure.py`, `check_graph_image.py`: the original exact diagnostic scripts.
- `graph-closure-checks-rerun.json`, `graph-image-checks-rerun.json`: the original rerun outputs from 22 September 2026.
- `check_extended.py`, `extended-results.json`: targeted additional checks and their recorded results.
- `review-record.json`: the two historical internal AI reviews of the frozen claim. These are not human reviews or new reviews of the formatted manuscript.
- `source-manifest.json`, `claim-evidence-map.json`: source locators, proof obligations, verification scope, and pending review.
- `SHA256SUMS`: hashes of every other archive member.

## Reproduction

Use Python 3 with NumPy 2.5.3 and SymPy 1.14.0 (the versions in the recorded container). The extended script needs only SymPy and the standard library. Do not enable Python's `-O` option: the diagnostics use assertions. In a writable copy of this directory, run:

```sh
python check_graph_closure.py
python check_graph_image.py
python check_extended.py
```

Each script writes JSON beside itself. The original scripts select finite binary instances with fixed random seeds. The additional script enumerates its stated families deterministically. The recorded runs used the local `qiqc-sandbox:v1` container with networking disabled. That image is not required to run these standalone scripts.

Expected results:

| Family | Coverage |
|---|---|
| Original closure checks | 45 comparisons; all pass, all stabilize at the seed lattice |
| Original kernel/image checks | 36 comparisons; all pass |
| Extended Boolean-pattern closures | 24 systems; 12 require strict enlargement, up to 3 steps |
| Seed-only mutation | Detected in all 12 systems requiring enlargement |
| Arbitrary 2-by-2 matrices over Z/4 | All 256 matrices; complete kernels agree with enumeration |
| Certified nonfree kernels | 81 of those kernels have cardinality 2 or 8 |
| Binary incidence matrices | All matrices of shapes 2-by-3 and 3-by-2 at levels 1, 2, 3: 384 systems, 42,752 multiplicity vectors |
| Zero toggle images | 129 of the 384 incidence systems |
| Explicit boundaries | Empty graph, empty support, empty outside set, isolated vertices at level one, zero toggle image |

Build the manuscript with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
```

All 12 rendered pages were visually inspected. The final compiler log contained no unresolved references or layout warnings. PDF hashes need not be identical across builds because TeX embeds build metadata.

## Relationship to the frozen proof

The original proof is preserved byte for byte (SHA-256 `682c2e29f0818e51f04fc850fe9a535ff1fafb9b412ce416f82ec88131ade9fb`). Its Part I becomes manuscript Section 3; Part II becomes Section 4; Part III becomes Sections 5–6. Sections 1–2 supply conventional context and notation; Sections 7–8 report diagnostics and limits. The full claim remains the labelled decision problem.

The frozen text used arXiv:2502.06566v2. The manuscript explicitly uses the v3 numbering, and the corresponding dependencies were compared by the AI assistant. The new finite checks address a coverage gap in the original tests: none of the original 45 closure systems exercised strict growth. Historical review verdicts have not been relabelled as reviews of the new manuscript.

## Sources and public record

- Research page: https://yuxuanzhang1995.github.io/agentic-research/graph-lu-polynomial/
- QIQCOP question: https://qiqc-op.com/problem/op_66affd4b198fd445/
- Existing submission: https://github.com/Naixu-Guo/quantum-open-problems/issues/97
- Full source metadata and locators: `source-manifest.json`.

## Licensing and disclosure

The original frozen proof was contributed under CC BY 4.0 and the two original diagnostic scripts under Apache-2.0, as recorded in issue #97. Those terms remain unchanged. The newly prepared manuscript, evidence records, and additional diagnostic script are supplied for review; no separate license is asserted for them here. Third-party articles and dependencies retain their own terms and are not bundled.

The proof candidate, diagnostic code, internal reviews, and exposition involved substantial AI assistance under the author's direction. Source comparison by an AI and finite exact testing are distinct from independent human mathematical verification. The source manifest records that distinction. Scientific Agent Skills supplied writing and evidence-tracking guidance and is cited in the manuscript; it did not verify the mathematics. This package is not marked ready for formal journal submission.
