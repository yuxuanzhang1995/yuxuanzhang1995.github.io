"""Second implementation: exact formal polynomials, stdlib only, no SymPy.

The identity is checked coefficientwise for arbitrary E,A,B,l0,l1,c.
This is a computational control by the same agent, not independent review.
"""
from fractions import Fraction
from pathlib import Path
import json

NV=15
zero={}
def var(i):
    m=[0]*NV;m[i]=1
    return {tuple(m):Fraction(1)}
def add(*ps):
    out={}
    for p in ps:
        for m,c in p.items():out[m]=out.get(m,0)+c
    return {m:c for m,c in out.items() if c}
def neg(p):return {m:-c for m,c in p.items()}
def mul(p,q):
    out={}
    for m,c in p.items():
        for n,d in q.items():
            k=tuple(a+b for a,b in zip(m,n));out[k]=out.get(k,0)+c*d
    return {m:c for m,c in out.items() if c}
def mm(A,B):return [[add(*(mul(A[i][t],B[t][j]) for t in range(2))) for j in range(2)] for i in range(2)]
def tr(A):return add(A[0][0],A[1][1])
def adj(A):return [[A[1][1],neg(A[0][1])],[neg(A[1][0]),A[0][0]]]
def transpose(A):return [list(x) for x in zip(*A)]
E=[[var(2*i+j) for j in range(2)] for i in range(2)]
A=[[var(4+2*i+j) for j in range(2)] for i in range(2)]
B=[[var(8+2*i+j) for j in range(2)] for i in range(2)]
L=[[var(12),zero],[zero,var(13)]];c=var(14)
AL=mm(A,L);V=mm(AL,transpose(B))
T=[[add(mul(c,E[i][j]),neg(V[i][j])) for j in range(2)] for i in range(2)]
# Right multiplication by diag(1,-1) changes the second column.
ALD=[[AL[i][0],neg(AL[i][1])] for i in range(2)]
Q=mm(ALD,transpose(B))
fdet=mm(mm(transpose(B),adj(E)),AL)
lhs=mul(c,add(fdet[0][0],neg(fdet[1][1])))
rhs=tr(mm(adj(T),Q))
assert not add(lhs,neg(rhs))
# A wrong plus sign in the signed top-two vector must fail identically.
bad=tr(mm(adj(T),V))
assert add(lhs,neg(bad))
out={'status':'PASS','formal_variables':NV,'nonzero_coefficients_in_correct_residual':0,
     'wrong_signed_block_detected':True,'lhs_terms':len(lhs),'rhs_terms':len(rhs),
     'scope':'Cleared-denominator bridge identity for all complex matrix entries; a different exact implementation by the same agent.'}
Path(__file__).with_name('coordinate-identity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
