# Polynomial-time local-unitary equivalence of graph states

Yuxuan Zhang

1. Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
2. Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

Round-21 proof candidate. Website publication: 22 September 2026.

## Status and scope

The candidate concerns arbitrary finite simple graphs on the same labelled vertex set. It claims a deterministic polynomial-bit-complexity decision procedure for graph-state local-unitary equivalence, including disconnected graphs. Vertex relabelling is not permitted. The proof uses the credited Claudet–Perdrix graph reductions and supplies an incidence-compression replacement together with the required modular-image and integration arguments.

`frozen-proof.md` is the unchanged proof from round 21 and QIQC issue #97. Its plain-text notation is preserved to avoid silently changing the reviewed argument. Part II's limitation to prescribed support concerns the intermediate lemma; Part III supplies the claimed unrestricted integration.

The proof has two internal AI reviews. Independent human expert checking, formal verification and historical priority remain unconfirmed. No optimized polynomial exponent or complete executable implementation of the full graph-state algorithm is claimed.

## Files and reproduction

- `frozen-proof.md`: complete original argument, in three parts.
- `check_graph_closure.py`: 45 exact weighted-incidence closure comparisons.
- `check_graph_image.py`: 36 exact kernel/image comparisons, including exhaustive enumeration within each finite test system.
- `graph-closure-checks-rerun.json` and `graph-image-checks-rerun.json`: expected outputs from the 22 September reruns.
- `review-record.json`: scope and provenance of the two internal AI reviews.
- `SHA256SUMS`: hashes of the other package files.

The scripts require Python 3, NumPy and SymPy. Install the packages in an isolated environment, then run without Python's `-O` option:

```sh
python check_graph_closure.py
python check_graph_image.py
```

Each script writes its JSON output beside itself. The calculations use integers and exact modular or lattice arithmetic. Random choices select finite binary test instances; their seeds are fixed in the scripts. Finite diagnostics do not replace the asymptotic proof and do not exercise the entire MLS-to-gadget graph reduction.

## Sources

- QIQCOP question: https://qiqc-op.com/problem/op_66affd4b198fd445/
- Submission with the same complete proof and scripts: https://github.com/Naixu-Guo/quantum-open-problems/issues/97
- Website note: https://yuxuanzhang1995.github.io/agentic-research/graph-lu-polynomial/
- N. Claudet and S. Perdrix, *Deciding Local Unitary Equivalence of Graph States in Quasi-Polynomial Time*, ICALP 2025, https://doi.org/10.4230/LIPIcs.ICALP.2025.59. The proof's numbering refers to https://arxiv.org/html/2502.06566v2.

## Licensing and disclosure

The original proof was contributed in issue #97 under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. The two original diagnostic scripts were contributed under Apache-2.0: https://www.apache.org/licenses/LICENSE-2.0. This archive preserves those terms. Cited third-party papers and dependencies retain their own terms and are not bundled.

The proof, diagnostic checks, internal reviews, and publication preparation involved substantial AI assistance under the author's direction. The internal reviewers were AI components, not independent human referees.
