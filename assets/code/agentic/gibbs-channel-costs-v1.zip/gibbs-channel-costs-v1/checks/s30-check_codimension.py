"""Check height-two singularities and enumerate exact zero-frequency fields."""
import sympy as sp


x, y, t = sp.symbols("x y t")
row = sp.Matrix([[x-1,y-1]])
g = sp.Matrix([1-y,x-1])
assert (row*g).applyfunc(sp.expand) == sp.zeros(1,1)
assert sp.gcd(g[0],g[1]) == 1
gb = sp.groebner([g[0],g[1]],x,y)
assert gb.is_zero_dimensional and sp.solve(g, (x,y)) == {x:1,y:1}
# A genuinely different generating list for the same summand.
extra = g.row_join((x+y)*g).row_join((x*y-1)*g)
assert extra.rank() == 1 and extra.subs({x:1,y:1}).rank() == 0
assert sp.groebner(list(extra),x,y) == gb
# An unsaturated supplied submodule can have a whole divisorial drop.
bad = (x-1)*sp.eye(2)
assert bad.subs(x,1).rank() == 0 and sp.factor(bad.det()) == (x-1)**2
assert not sp.groebner([bad.det()],x,y).is_zero_dimensional

# At the allowed exceptional time zero the exact affine jet system need
# not collapse to the pointwise kernel. Actual polynomial coefficients matter.
coeffs = sp.symbols("a:3 b:3")
a = sum(coeffs[n]*t**n for n in range(3))
b = sum(coeffs[3+n]*t**n for n in range(3))
j1 = a.subs(t,t+1)-a
j2 = b.subs(t,t+sp.sqrt(2))-b
eqs = sp.Poly(j1+j2,t).all_coeffs()
mat,_ = sp.linear_eq_to_matrix(eqs,coeffs)
assert mat.rank() == 2 and len(mat.nullspace()) == 4
for vec in mat.nullspace():
    assert sp.simplify((j1+j2).subs(dict(zip(coeffs,vec)))) == 0
print("PASS: two variable saturated kernel and redundant presentation, "
      "height-one mutation, four exact quadratic jet witnesses over Q(sqrt(2)).")
