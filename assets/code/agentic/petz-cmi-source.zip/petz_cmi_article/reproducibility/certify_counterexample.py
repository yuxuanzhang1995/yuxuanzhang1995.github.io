"""A posteriori certificate using exact rational arithmetic.

NumPy/mpmath propose eigenvalue brackets and matrix approximants only.
Every bracket is checked by exact characteristic-polynomial signs. Matrix
square-root errors follow from exact residual and positivity checks. Scalar
logs use an explicit convergent rational series with a remainder bound.

Dependencies: numpy, mpmath, sympy. Run beside verify_from_printed_coefficients.py.
"""
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json
import mpmath as mp
import sympy as s
from verify_from_printed_coefficients import WEIGHTS, VECTORS

if not __debug__:
    raise RuntimeError('Run the certificate without -O: assertion checks must remain enabled.')

mp.mp.dps = 90


class Interval:
    def __init__(self, lo, hi=None):
        self.lo = Q(lo)
        self.hi = Q(lo if hi is None else hi)
        assert self.lo <= self.hi

    @staticmethod
    def cast(x):
        return x if isinstance(x, Interval) else Interval(x)

    def __add__(self, other):
        o = self.cast(other)
        return Interval(self.lo + o.lo, self.hi + o.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-self.cast(other))

    def __rsub__(self, other):
        return self.cast(other) + (-self)

    def __mul__(self, other):
        o = self.cast(other)
        p = [self.lo*o.lo, self.lo*o.hi, self.hi*o.lo, self.hi*o.hi]
        return Interval(min(p), max(p))

    __rmul__ = __mul__

    def __truediv__(self, other):
        o = self.cast(other)
        assert o.lo*o.hi > 0
        return self * Interval(1/o.hi, 1/o.lo)

    def sqrt(self):
        assert self.lo >= 0
        scale = 10**22
        low = isqrt(self.lo.numerator * scale**2 // self.lo.denominator)
        high = isqrt(self.hi.numerator * scale**2 // self.hi.denominator) + 1
        return Interval(Q(low, scale), Q(high, scale))

    def outward(self, digits=14):
        scale = 10**digits
        a = self.lo*scale
        b = self.hi*scale
        low = a.numerator//a.denominator
        high = -((-b.numerator)//b.denominator)
        def fmt(n):
            return ('-' if n<0 else '')+str(abs(n)//scale)+'.'+str(abs(n)%scale).zfill(digits)
        return [fmt(low), fmt(high)]


def unit_log(x, terms=30):
    """Enclose ln(x), for 1 <= x <= 2, using 2 atanh((x-1)/(x+1))."""
    x=Q(x)
    assert 1 <= x <= 2
    z=(x-1)/(x+1)
    total=sum((2*z**(2*j+1)/Q(2*j+1) for j in range(terms)),Q(0))
    tail=2*z**(2*terms+1)/(Q(2*terms+1)*(1-z*z))
    return Interval(total,total+tail)


LN2=unit_log(Q(2))


def log_point(x):
    x=Q(x)
    assert x>0
    k=0
    while x<1:
        x*=2
        k-=1
    while x>=2:
        x/=2
        k+=1
    return unit_log(x)+k*LN2


def log2_interval(x):
    return Interval(log_point(x.lo).lo,log_point(x.hi).hi)/LN2


def expand(m):
    return m.applyfunc(s.expand)


def real_q(x):
    x=s.expand(x)
    assert s.im(x)==0
    return Q(x)


def frobenius_squared(m):
    return real_q(sum(s.expand(x*s.conjugate(x)) for x in m))


def positive(m):
    assert m==m.H
    # Sylvester's criterion, with determinants evaluated as exact rationals.
    return all(real_q(m[:j,:j].det())>0 for j in range(1,m.rows+1))


def to_mp(m):
    def entry(x):
        a,b=s.expand(x).as_real_imag()
        return mp.mpc(mp.mpf(str(a.p))/int(a.q),mp.mpf(str(b.p))/int(b.q))
    return mp.matrix([[entry(m[i,j]) for j in range(m.cols)] for i in range(m.rows)])


def matrix_approximant(m, exponent):
    w,u=mp.eighe(to_mp(m))
    x=u*mp.diag([v**exponent for v in w])*u.H
    scale=10**40
    def rational(a): return s.Rational(int(mp.nint(a*scale)),scale)
    out=s.zeros(m.rows)
    for i in range(m.rows):
        out[i,i]=rational(mp.re(x[i,i]))
        for j in range(i+1,m.rows):
            z=rational(mp.re(x[i,j]))+s.I*rational(mp.im(x[i,j]))
            out[i,j]=z
            out[j,i]=s.conjugate(z)
    return out


def root_brackets(polynomial, approximate_roots):
    brackets=[]
    scale=10**14
    for w in approximate_roots:
        k=int(mp.floor(w*scale))
        lo,hi=s.Rational(k-1,scale),s.Rational(k+2,scale)
        assert real_q(polynomial.eval(lo))*real_q(polynomial.eval(hi)) < 0
        brackets.append(Interval(Q(lo),Q(hi)))
    assert len(brackets)==polynomial.degree()
    assert all(0<x.lo<x.hi<1 for x in brackets)
    assert all(a.hi<b.lo for a,b in zip(brackets,brackets[1:]))
    # Each interval contains a real root; degree-many disjoint intervals
    # therefore exhaust the roots of the characteristic polynomial.
    return brackets


def certified_entropy(matrix):
    poly=matrix.charpoly().as_poly()
    roots=mp.eighe(to_mp(matrix),eigvals_only=True)
    brackets=root_brackets(poly,roots)
    ent=sum((-b*log2_interval(b) for b in brackets),Interval(0))
    return ent,brackets


def main():
    v=s.Matrix([[s.Rational(VECTORS[j][i][0])+s.I*s.Rational(VECTORS[j][i][1])
                 for j in range(2)] for i in range(8)])
    weights=s.diag(*[s.Rational(w) for w in WEIGHTS])
    raw=expand(v*weights*v.H)
    z=s.trace(raw)
    rho=expand(raw/z)
    assert real_q(s.trace(rho))==1
    ac=s.zeros(4);bc=s.zeros(4);c=s.zeros(2)
    for a in range(2):
        for b in range(2):
            for k in range(2):
                for aa in range(2):
                    for kk in range(2): ac[2*a+k,2*aa+kk]+=rho[4*a+2*b+k,4*aa+2*b+kk]
                for bb in range(2):
                    for kk in range(2): bc[2*b+k,2*bb+kk]+=rho[4*a+2*b+k,4*a+2*bb+kk]
                for kk in range(2): c[k,kk]+=rho[4*a+2*b+k,4*a+2*b+kk]
    ac,bc,c=map(expand,[ac,bc,c])
    assert positive(ac-s.eye(4)/10000)
    assert positive(c-s.eye(2)/50)
    assert positive(bc)
    print('Exact state and marginal positivity checks passed.',flush=True)
    entropies={};spectra={}
    for name,m in [('AC',ac),('BC',bc),('C',c)]:
        entropies[name],spectra[name]=certified_entropy(m)
        print('Certified entropy',name,entropies[name].outward(),flush=True)
    vg=expand(v.H*v)
    d=real_q(weights.det()*vg.det()/z**2)
    x=s.Symbol('x')
    polynomial=s.Poly(x*x-x+s.Rational(d.numerator,d.denominator),x)
    dd=mp.mpf(d.numerator)/d.denominator
    roots=[(1-mp.sqrt(1-4*dd))/2,(1+mp.sqrt(1-4*dd))/2]
    spectra['ABC_nonzero']=root_brackets(polynomial,roots)
    entropies['ABC']=sum((-b*log2_interval(b) for b in spectra['ABC_nonzero']),Interval(0))
    info=entropies['AC']+entropies['BC']-entropies['C']-entropies['ABC']

    a=matrix_approximant(ac,mp.mpf('0.5'))
    t=matrix_approximant(c,mp.mpf('-0.5'))
    assert positive(a-s.eye(4)/100)
    assert positive(t)
    residual_a=frobenius_squared(expand(a*a-ac))
    residual_t=frobenius_squared(expand(t*t-c.inv()))
    assert residual_a<Q(1,10**60)
    assert residual_t<Q(1,10**60)
    # ||a-sqrt(ac)|| <= 10^-30/(.01+.01) = 5e-29.
    # ||t-invsqrt(c)|| < 10^-30 since lambda_min(c^-1)>=1.
    # For the embedded product L, ||L-L_approx|| < 8*5e-29+2e-30.
    # ||L|| < 8, ||L_approx|| < 18, ||bc|| <= 1, hence
    # ||rho_rec-rho_rec_approx|| < 26*(8*5e-29+2e-30) < 1e-24.
    assert Q(26)*(8*Q(5,10**29)+2*Q(1,10**30)) < Q(1,10**24)
    left=expand(a*s.kronecker_product(s.eye(2),t))
    l=s.zeros(8)
    for i in range(8):
        for j in range(8):
            if (i//2)%2==(j//2)%2:
                l[i,j]=left[2*(i//4)+i%2,2*(j//4)+j%2]
    rec=expand(l*s.kronecker_product(s.eye(2),bc)*l.H)
    h=expand(v.H*rec*v)
    # The printed vectors have norm < 2. Thus each compressed entry
    # has error below 4e-24, and the rho expectation below 1e-24.
    assert all(real_q(vg[i,i])<4 for i in range(2))
    delta=Q(4,10**24)
    def uncertain(x):
        q=real_q(x)
        return Interval(q-delta,q+delta)
    h00,h11=uncertain(h[0,0]),uncertain(h[1,1])
    hr,hi=[uncertain(y) for y in h[0,1].as_real_imag()]
    determinant=(h00*h11-hr*hr-hi*hi)*real_q(weights.det()/z**2)
    expect=real_q(s.trace(expand(rho*rec)))
    trace_k=Interval(expect-Q(1,10**24),expect+Q(1,10**24))
    fidelity=trace_k+2*determinant.sqrt()
    rhs=-log2_interval(fidelity)
    gap=info-rhs
    assert gap.hi < 0
    assert Q('-0.00428170') < gap.lo < gap.hi < Q('-0.00428169')
    result={
        'method':'Exact rational a posteriori certificate; explicit logarithm series remainder',
        'entropies_bits':{k:x.outward() for k,x in entropies.items()},
        'spectra':{k:[b.outward() for b in bs] for k,bs in spectra.items()},
        'cmi_bits':info.outward(),
        'squared_fidelity':fidelity.outward(),
        'recovery_term_bits':rhs.outward(),
        'gap_bits':gap.outward(),
        'sqrt_residual_squared_less_than':'1e-60',
        'invsqrt_residual_squared_less_than':'1e-60',
        'recovered_state_operator_error_less_than':'1e-24',
        'certified_coarse_gap_interval':['-0.00428170','-0.00428169'],
        'gap_is_strictly_negative':True,
    }
    (Path(__file__).parent/'certificate_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    main()
