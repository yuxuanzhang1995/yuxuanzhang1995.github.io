"""Verify the source bundle and run its proof controls from any working directory."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
for name, digest in json.loads((base / "SHA256.json").read_text()).items():
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == digest, name

def same(got, expected):
    if isinstance(expected, dict):
        return got.keys() == expected.keys() and all(same(got[k], v) for k, v in expected.items())
    if isinstance(expected, float):
        return math.isclose(got, expected, abs_tol=1e-11, rel_tol=1e-11)
    return got == expected

for name, expected in json.loads((base / "checks/expected.json").read_text()).items():
    p = subprocess.run([sys.executable, "-I", str(base/"checks"/(name+".py"))], check=True, capture_output=True, text=True)
    assert same(json.loads(p.stdout), expected), name
    print(name, "PASS")
