# Optimal check weight for two-logical-qubit codes of lengths eleven and twelve

Yuxuan Zhang. Version 1.0, 17 November 2026.

The paper proves that the optimal maximum generator weight is five for each
of [[11,2,d>=4]] and [[12,2,d>=4]], allowing every binary stabilizer code,
arbitrary degeneracy, non-CSS structure and every generating basis.
The eleven-qubit lower bound is analytic. The twelve-qubit lower bound uses
the published Danielsen--Parker self-dual classification and a complete exact
enumeration of subspaces within each parent.

## Run

Extract into an empty directory and run:

```sh
python3 reproduce.py
```

Requirements: Python 3.10 or later and a C++17 compiler named `c++`, `g++` or
`clang++`. No Python dependency installation or network connection is needed.
Do not use Python's `-O` flag. All generated files are placed in `build/`.
The full census took about 38 seconds on the review machine; runtime depends
on the compiler and hardware. The packaged archive is about 15 MB compressed,
and extraction produces approximately 19 MB of graph records.

The runner checks every packaged input hash, recomputes the complete
stabilizers and duals, checks the integer shadow identities and degenerate
controls, compares the reduction with direct small physical-error problems,
accepts a known feasible positive instance, and reruns the entire
twelve-qubit exclusion. The final result must include:

- 1,323,363 parent representatives processed and end-of-file reached;
- 320,777,184 admissible planes after valid parent-rank pruning;
- no plane with the rank ten required for a cap-four generating basis.

The two constructions can be read directly in `data/witnesses.json`.
`checks/exact.py` checks all generating bases through the ranks of the spans
of all low-weight stabilizer elements. `checks/census.cpp` implements the
complete parent/subspace reduction proved in the paper.

## Classification data and source provenance

`data/thebigselfdualfile.txt.gz` is the unmodified public classification
archive of Lars Eirik Danielsen:

- [Classification and data](https://www.codetables.de/larsed/vncorbits/)
- [Danielsen--Parker paper, version 4](https://arxiv.org/abs/math/0504522v4)
- SHA-256: `75af3203e86e6ac5726795c84bdacd32f1d13d7c0f1f84b8e3a664724b8d5855`

The runner verifies its record counts and orbit masses. It does not regenerate
the published classification from first principles. That classification is an
explicit mathematical and computational dependency of the twelve-qubit proof.
The third-party data retain their original provenance; no authorship of the
classification or the public comparison codes is claimed here.

The two JSON files from the QEC Challenge repository are comparison inputs,
not our constructions. Their retrieval metadata and immutable Git blob IDs
are included. The checker finds that both have optimal generating-basis
weight six. Background methods are attributed in the manuscript.

## Review status

The proof and sources received sequential internal review. Three differently
implemented classifications agreed; the compact third implementation is the
default executable here. Earlier code and result records are preserved under
`audit/` for comparison. The independent arithmetic representation and
different implementations are not independent agent or expert verification.
No formal proof-assistant or external refereeing claim is made. The checked
literature leaves these two finite cells unresolved, but worldwide priority
is not certified by the reproduction package.

The manuscript source is in `manuscript/main.tex`. Compile with `pdflatex`
twice (or `latexmk -pdf`). Compilation is not part of the mathematical runner.
