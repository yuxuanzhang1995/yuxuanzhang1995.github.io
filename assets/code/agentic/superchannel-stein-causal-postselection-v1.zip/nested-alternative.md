# Parallel and nested superchannel discrimination: a source-dependent proof candidate

Version 1, 12 November 2026. Same-agent derivation and assessment only.
No independent review, priority clearance or publication. The channel
approximation theorem below is imported from Gao, Ji and Liu, not proved here.

## Statement and scope

Let Theta_1,Theta_2 be finite-dimensional deterministic superchannels from
channels A->B to channels C->D. Allow arbitrary finite tester side wires and
inaccessible internal superchannel memory, exactly as in the pinned Q074
statement and Hirche's Definition 4.4. Define

    d_sc = sup_k (1/k) D_sc(Theta_1^tensor k || Theta_2^tensor k).

The proposed theorem is

    zeta_nested(Theta_1||Theta_2)
      = zeta_parallel(Theta_1||Theta_2) = d_sc.                 (T)

The exponents use lim_{epsilon down 0} liminf_{n->infinity}, not a fixed-error
strong converse. All dimensions are fixed per problem; side wires in each
finite protocol may be arbitrarily large. No claim is made for fully general
crossing interleavings, the distinct Q114 problem.

The proof establishes, whenever the terms on the right are finite, the chain

    D(Theta_1(N)(rho) || Theta_2(M)(sigma))
       <= d_sc + D_ch^infinity(N||M) + D(rho||sigma).           (C)

Identities on arbitrary side/reference systems are understood in every term.
N and M have the same input and output spaces and are trace preserving.

## Imported statements and attribution

1. Gao-Ji-Liu, arXiv:2609.27196v1, Corollary 5.2: for channels N,M with
   d=D_ch^infinity(N||M)<infinity and every s>d there exist CP trace-
   nonincreasing maps L_n such that L_n <=_CP 2^(ns) M^tensor n and
   ||L_n-N^tensor n||_diamond <= K exp(-gamma n). The norm is unhalved.
   Its fixed-error consequence, Corollary 5.3, is the subchannel AEP.
2. Fang-Fawzi-Renner-Sutter, arXiv:1909.05826, Lemma 3.4: for normalized u,v,
   epsilon in (0,1), m>=2g(epsilon), g=log_2(2/epsilon^2),

       D_max^epsilon(u^tensor m||v^tensor m)/m
          <= D(u||v) + 4 log_2(mu) sqrt(g/m),
       mu=1+Tr u^(3/2)v^(-1/2)+Tr u^(1/2)v^(1/2).             (A)

   Also the liminf of the normalized smooth max divergence of a fixed iid
   pair is at least its relative entropy for a fixed smoothing radius <1.
   Smoothing is over subnormalized states in generalized purified distance.
   The same paper, Corollary 3.7, gives D_ch^A=D_ch^infinity.
3. Hirche, arXiv:2103.02404v2, Definition 4.4, Section 5.3 and Theorem 5.3:
   the fully parallel weak Stein rate is d_sc, parallel testers embed in
   nested testers, and nested recursion is controlled by the amortized
   superchannel relative entropy. We also give the relevant telescoping
   step below to specify which strategy class is used.

Hirche's Appendix A already gives a smoothed chain architecture conditional
on a CPTP-smoothed AEP. That CPTP premise is false in general (Gour,
arXiv:2609.15004). We use only the different, trace-nonincreasing theorem in
item 1. The success-flag reduction and uniform limit argument were developed
conditionally in R300; neither is newly credited again here. This version
integrates the imported missing premise, proves the singular-case reduction
by a physical Choi readout, and supplies the full operational conclusion.

## 1. Finite divergence gives a complete order bound

Write R_i for the unnormalized two-comb Choi operator, ordered as C,A,B,D.
It is positive, Tr_D R_i=I_B tensor R_Ei and Tr_A R_Ei=I_C. Its trace is
d_C d_B. There is a deterministic one-use tester whose final state is

    omega_i = R_i/(d_C d_B),                                  (1)

up to a fixed permutation of registers. Prepare a maximally entangled pair
C,C' and another B0,B'. Send C into the first part. At the access point,
store the received A in A', send B0 into the second part, and finally retain
C',A',B',D. The internal memory is never accessed. Preparing, swapping and
discarding dummy registers makes this a CPTP inserted channel on an enlarged
side wire of the form AR->BR. The same circuit is used for both hypotheses.
The defining Choi construction of the sequential network is exactly this
circuit, which proves (1) including its normalization.

If supp R_1 is not contained in supp R_2, D(omega_1||omega_2)=infinity.
Thus d_sc=infinity, and the known parallel coding argument already gives
(T), with both exponents infinite. Equivalently, repeated measurements of
the part of omega_1 outside supp omega_2 give type-II error zero and type-I
error tending to zero. From now on suppose d_sc<infinity. Equation (1)
implies support inclusion and, in fixed finite dimension, some c>=1 obeys

    R_1 <= c R_2; put kappa=log_2 c <infinity.                 (2)

Every common physical tester is a CP map on a comb Choi input (its link
formula is a congruence/partial trace with fixed tester operators). Hence
complete order (2), including all ancillary identities, gives

    u <= 2^(n kappa) v                                        (3)

for the normalized output pair of ANY common n-block tester. Tensoring
positive order yields the n-fold inequality. This does not compare individual
pre/post realizations or disclose their memories. In particular no bound on
the tester side-wire dimension is needed. Tensor-order telescoping also
bounds the channels produced by a fixed j-use nested protocol by c^j in CP
order, so every channel divergence subtracted in that finite recursion is
finite. This avoids an infinity-minus-infinity amortization convention.

## 2. A heralded completion is an allowed common tester

For a CP trace-nonincreasing T:A R->B R, let Q=I-T^*(I)>=0 and fix any
normalized state tau on its output. Add an accessible bit F and define

    T_hat(X) = T(X) tensor |0><0|_F
             + Tr(QX) tau tensor |1><1|_F.                   (4)

The extension ignores/overwrites an initialized input flag if equal input
and output side-wire dimensions are desired. Equation (4) is CPTP on all
inputs. The flag bypasses each superchannel through the allowed tester side
wire and is retained until the final test. For a common normalized nu,
Omega_i=(Theta_i tensor id_F)(T_hat)(nu) is normalized and its flag-0 block is

    P_0 Omega_i P_0 = Theta_i(T)(nu) tensor |0><0|_F.          (5)

Let B_m^epsilon(Theta_1||Theta_2) denote the supremum, over all common CPTP
insertions and normalized inputs including arbitrary side wires, of
D_max^epsilon(Omega_1^tensor m||Omega_2^tensor m). Choose a smoothed state
eta arbitrarily close to this bound for the particular completion (4), so

    P(eta,Omega_1^tensor m)<=epsilon,
    eta <= 2^B Omega_2^tensor m.                              (6)

Here B can exceed the indicated supremum by an arbitrarily small amount;
this takes care of nonattainment. Project onto all-success flags and discard
the flags. This CP trace-nonincreasing map gives eta_s satisfying

    P(eta_s,Theta_1(T)(nu)^tensor m)<=epsilon,
    eta_s <= 2^B Theta_2(T)(nu)^tensor m.                      (7)

Generalized purified distance is contractive for this subnormalized
operation. No normalization of eta_s is performed. There is no assertion
that T_hat is CP dominated by M: the failure block would generally invalidate
that assertion. Order domination of T is applied only after (7).

## 3. Typed finite-block inequality

Suppose ||T-N||_diamond<=delta, T<=_CP 2^a M. Choose a subnormalized
rho_tilde with P(rho_tilde,rho)<=eta and rho_tilde<=2^b sigma. Put
r=Tr rho_tilde and nu=rho_tilde/r. For eta<1, r>=1-eta^2>0.
Positivity of superchannel insertion and linearity in the input yield

    Theta_2(T)(nu)
        <= 2^(a+b-log_2 r) Theta_2(M)(sigma).                 (8)

Thus eta_s from (7) is bounded by 2^[B+m(a+b-log_2 r)] times the m-fold
target denominator. All side registers occur on both sides of (8).

Because r>=1-eta^2, P(nu,rho_tilde)=sqrt(1-r)<=eta and P(nu,rho)<=2eta.
For a normalized input, the diamond bound implies generalized trace distance
between T and N outputs at most delta and hence purified distance at most
sqrt(2delta). Fixed pre/post channels and identities do not increase it.
The tensor-product triangle bound for subnormalized purified distance gives

    P(eta_s,Theta_1(N)(rho)^tensor m)
       <= epsilon + m(sqrt(2delta)+2eta) = xi.

Consequently, if xi<1,

    D_max^xi(Theta_1(N)(rho)^tensor m || Theta_2(M)(sigma)^tensor m)
       <= B_m^epsilon(Theta_1||Theta_2)+m(a+b-log_2 r).         (9)

This holds for n-block superchannels, arbitrary collective T_n and arbitrary
collective smoothed input rho_tilde_n. The flag can mark success of the whole
n-block; it is an ordinary single extra output bit, not n extra tested uses.

## 4. A uniform bound before taking any limits

For any output pair u,v of a common n-block completion, (3) implies
Tr u^(3/2)v^(-1/2)<=2^(n kappa/2). To see this without commuting u and v,
apply operator antitonicity of x^(-1/2) to u<=2^(n kappa)v after adding a
positive regularizer on the common support, multiply by u^(3/2), take the
trace, and let the regularizer decrease to zero. Cauchy-Schwarz gives
Tr u^(1/2)v^(1/2)<=1. Therefore

    log_2(mu) <= log_2(2+2^(n kappa/2))
              <= n kappa/2+log_2 3.

Apply the imported finite state estimate (A) to each such pair before the
supremum. Its relative entropy is at most D_sc(Theta_1^n||Theta_2^n)<=n d_sc.
For every m>=2g(epsilon),

    B_m^epsilon(Theta_1^n||Theta_2^n)/(nm)
       <= d_sc + 4(kappa/2+log_2(3)/n) sqrt(g(epsilon)/m).     (10)

The estimate holds uniformly even if the channel, input, success probability,
side-wire dimension and state spectra all vary with n. No pointwise AEP is
exchanged with a supremum over those objects.

## 5. The order of limits proves the chain rule

Fix N,M,rho,sigma with finite D_ch^infinity(N||M) and D(rho||sigma). Fix
epsilon=1/8 and an integer m>=2g(epsilon). Choose

    eta=1/(32m), delta=1/(2048m^2).

Then xi=1/8+1/32+1/16=7/32<1. Fix any s>D_ch^infinity(N||M). By the imported
dominated-subchannel theorem, for all sufficiently large n there is T_n
with ||T_n-N^n||_diamond<=delta and T_n<=2^(ns)M^n. Take a_n=ns.
For the fixed eta, the state AEP supplies rho_tilde_n close to rho^n with
rho_tilde_n<=2^(b_n)sigma^n and b_n/n -> D(rho||sigma); approximate optimizers
suffice. Also r_n>=1-eta^2.

Apply (9) to Theta_i^n,N^n,M^n,rho^n,sigma^n and divide by nm. Its left
side concerns the fixed output pair [Theta_1(N)(rho),Theta_2(M)(sigma)] to
the iid power nm. At FIXED m, let n tend to infinity. The lower state AEP
and (10) give

    D(Theta_1(N)(rho)||Theta_2(M)(sigma))
      <= d_sc+s+D(rho||sigma)+2 kappa sqrt(g(1/8)/m).          (11)

The contribution -log r_n/n vanishes. Now let m tend to infinity and then
s decrease to D_ch^infinity(N||M). This proves (C). The constants in the
imported approximation may depend on s,N,M and the fixed m; none needs to
be uniform in m because n was taken first. If either input divergence is
infinite, (C) is simply a vacuous extended-real inequality and is not used
to subtract infinities.

## 6. Operational closure over the original strategy class

The ordinary-channel chain theorem identifies D_ch^infinity=D_ch^A. Taking
the supremum over the state pair in (C) gives, for finite input-channel cost,

    D_ch^A(Theta_1(N)||Theta_2(M))
       <= d_sc + D_ch^A(N||M).                               (12)

For a fixed finite nested strategy, start with the same innermost channel
under the two hypotheses. Between tested uses insert its fixed compatible
CPTP pre/post maps and side-wire identities. These maps do not increase
amortized channel divergence: output processing is data processing; input
processing contracts the state cost, and the defining supremum allows the
processed inputs. Apply (12) at each completed nesting step. The CP domination
following (2) ensures each intermediate channel cost is finite. Thus the
final output states, on their common initial input, satisfy

    D(rho_final||sigma_final) <= n d_sc.                       (13)

This is exactly the nested recursion in Hirche (64)-(66); it does not remove
one half of a crossing use, which would require a different argument.

If the binary test accepts the null with p>=1-epsilon and has alternative
acceptance q=beta, data processing and binary relative entropy give

    n d_sc >= D_bin(p||q) >= -h_2(p)-p log_2 beta.

For epsilon<=1/2 this implies

    -log_2 beta/n <= [d_sc+h_2(epsilon)/n]/(1-epsilon).        (14)

Take the infimum beta over arbitrary allowed finite nested testers, then the
original n-limit and epsilon-down-to-zero limit. This proves zeta_nested<=d_sc.
For achievability, fix any finite block and common tester realizing relative
entropy arbitrarily close to that block's optimum. Repeat the block and apply
the state Stein lemma; unused fewer-than-one-block copies can be discarded.
Optimizing the block gives zeta_parallel>=d_sc. Parallel strategies are nested
after relabeling/storing side wires, so (T) follows. The infinite case was
handled in Section 1. This covers every finite superchannel pair in Q074.

## What this candidate does and does not establish

Subject to correctness of the stated imported results and this flagged-chain
argument, the mathematical scope is the full pinned Q074 original. The source
search missed the September subchannel theorem in the earlier local audit;
that historical open-premise label is corrected separately. This is chiefly
a synthesis using a powerful new external theorem. New priority is not
established by the catalogue's open label or by lack of a search hit.

The derivation is a same-agent candidate. It has no independent expert audit.
It gives neither the fixed-error superchannel strong converse nor an answer
to Q114 on fully general interleavings. The bound (14) is deliberately only
the original vanishing-type-I Stein statement. No website or catalogue report
is sent under this research allocation.

Primary sources:
- https://arxiv.org/html/2609.27196v1
- https://arxiv.org/html/2103.02404v2
- https://arxiv.org/html/1909.05826
- https://arxiv.org/html/2609.15004
