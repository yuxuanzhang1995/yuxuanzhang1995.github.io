import sympy as s
I=s.I
O=s.Matrix([[0,1],[-1,0]])
V=s.eye(2); Gamma=V+I*O/2
Bs=[s.diag(1,0),s.diag(0,1),s.Matrix([[0,1],[1,0]])/s.sqrt(2)]
S=s.zeros(5); S[:2,:2]=Gamma
for a,B in enumerate(Bs):
 for b,C in enumerate(Bs): S[2+a,2+b]=2*s.trace(B*Gamma*C*Gamma.T)
def zero(M): return all(s.simplify(x)==0 for x in M)
def psd(M):
 assert zero(M-M.conjugate().T)
 assert all(x.is_nonnegative for x in M.eigenvals())
def check(G,ms,Ds,W,Y):
 p=len(ms); J=s.zeros(5,p); L=s.zeros(5,p)
 F=s.zeros(p)
 for j in range(p):
  J[:2,j]=ms[j]; L[:2,j]=G*ms[j]
  for a,B in enumerate(Bs):
   J[2+a,j]=s.trace(B*Ds[j]); L[2+a,j]=s.trace(B*G*Ds[j]*G)/2
  for k in range(p): F[j,k]=(ms[j].T*G*ms[k])[0]+s.trace(G*Ds[j]*G*Ds[k])/2
 E=F.inv(); A=L*E; Q=s.simplify(E-A.T*S*A)
 P=s.eye(5)-J*(J.T*J).inv()*J.T
 for M in [G,Gamma.inv()-G,F,Q,Y]: psd(M)
 assert zero(s.re(Y)-W) and zero(Y*Q)
 assert zero(P*s.re(S*A*Y)) and zero(J.T*A-s.eye(p))
 return s.simplify(s.trace(W*E))
assert Gamma.det()==s.Rational(3,4)>0
print('det(Gamma) = 3/4 > 0; asserted')
z=s.zeros(2)
a=check(s.Rational(2,3)*s.eye(2),[s.Matrix([1,0]),s.Matrix([0,1])],[z,z],s.eye(2),s.eye(2)+I*O)
assert a==3
print('shift certificate residuals = 0; PSD eigenvalues >= 0; asserted; cost = 3')
b=check(s.diag(1,0),[s.Matrix([1,0])],[s.diag(1,-s.Rational(1,4))],s.ones(1),s.ones(1))
assert b==s.Rational(2,3)
print('singular-precision certificate residuals = 0; PSD eigenvalues >= 0; asserted; cost = 2/3')
