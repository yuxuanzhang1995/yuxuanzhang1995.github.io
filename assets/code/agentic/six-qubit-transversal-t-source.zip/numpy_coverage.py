"""Exact finite coverage, using only Python and NumPy in the existing sandbox."""
from itertools import combinations_with_replacement
from math import comb
import numpy as np

# Spread a 16-bit suffix-support mask over every fourth bit of a 64-bit mask.
SPREAD=np.array([sum(1<<(4*j) for j in range(16) if (word>>j)&1)
                 for word in range(65536)],dtype=np.uint64)

def enumerate_pairs(modulus):
    assert modulus in (16,32,64)
    total=checksum=all_even=low_odd=empty=small=residual=0
    chunks=[]
    # k=(a,b,c,d,e,f), with a<=b<=c<=d<=e<=f. Reuse the last-four
    # subset masks for all a at fixed b; no tuple is omitted or repeated.
    for b in range(modulus):
        suffix=np.asarray(list(combinations_with_replacement(range(b,modulus),4)),dtype=np.int16)
        count=len(suffix)
        assert count==comb(modulus-b+3,4)
        odd_suffix=np.sum(suffix&1,axis=1,dtype=np.int16)
        sums_suffix=int(np.sum(suffix,dtype=np.int64))
        # lookup[r,i] is the exact 16-bit set of suffix vertices with
        # dot product r for suffix tuple i. Each row index in an assignment
        # is distinct, so advanced-indexing OR cannot lose a contribution.
        lookup=np.zeros((modulus,count),dtype=np.uint16)
        columns=np.arange(count)
        for word in range(16):
            residues=np.zeros(count,dtype=np.int16)
            for j in range(4):
                if (word>>j)&1: residues+=suffix[:,j]
            residues%=modulus
            lookup[residues,columns]|=np.uint16(1<<word)
        for a in range(b+1):
            total+=count;checksum+=sums_suffix+(a+b)*count
            odds=odd_suffix+(a&1)+(b&1)
            all_even+=int(np.count_nonzero(odds==0))
            low_odd+=int(np.count_nonzero((odds==1)|(odds==2)))
            selected=np.flatnonzero(odds>=3)
            if not len(selected): continue
            A=np.zeros(len(selected),dtype=np.uint64)
            B=np.zeros(len(selected),dtype=np.uint64)
            for first in range(4):
                shift=(a if first&1 else 0)+(b if first&2 else 0)
                A|=SPREAD[lookup[(-shift)%modulus,selected]]<<np.uint64(first)
                B|=SPREAD[lookup[(modulus//8-shift)%modulus,selected]]<<np.uint64(first)
            assert np.all(A&np.uint64(1)) and not np.any(A&B)
            nonempty=B!=0;empty+=int(np.count_nonzero(~nonempty))
            A=A[nonempty];B=B[nonempty]
            # A,B are nonempty here. Clearing the least-significant bit
            # twice leaves zero exactly when the support has size<=2.
            aa=A&(A-np.uint64(1));bb=B&(B-np.uint64(1))
            tiny=((aa&(aa-np.uint64(1)))==0)|((bb&(bb-np.uint64(1)))==0)
            small+=int(np.count_nonzero(tiny));residual+=int(np.count_nonzero(~tiny))
            if np.any(~tiny): chunks.append(np.column_stack((A[~tiny],B[~tiny])))
    assert total==comb(modulus+5,6)
    assert total==all_even+low_odd+empty+small+residual
    assert 2*checksum==total*6*(modulus-1)
    raw=np.concatenate(chunks,axis=0)
    assert len(raw)==residual
    # Exact 128-bit structured pair keys; no lossy hash or scalar encoding.
    records=raw.view(dtype=[('A',np.uint64),('B',np.uint64)]).reshape(-1)
    distinct=np.unique(records)
    pairs=distinct.view(np.uint64).reshape(-1,2)
    report=dict(modulus=modulus,total=total,coordinate_checksum=checksum,
                all_even=all_even,one_or_two_odd=low_odd,empty_B=empty,
                one_or_two_support_size=small,remaining_vectors=residual,
                unique_remaining_support_pairs=len(pairs))
    return report,pairs
