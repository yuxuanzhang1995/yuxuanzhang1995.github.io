"""Fresh controls of the local-band candidate; these do not verify the all-d theorem."""
from pathlib import Path
from fractions import Fraction as F
import json, math
import numpy as np
from scipy.linalg import eigh

OUT=Path(__file__).with_name('local-band-checks.json')
rng=np.random.default_rng(274328)
checks=[]
def check(name,condition,**data):
    assert condition,(name,data)
    checks.append(dict(name=name,passed=True,**{k:(v.item() if isinstance(v,np.generic) else v) for k,v in data.items()}))
def op(x): return float(np.linalg.norm(x,2))
def herm(x): return (x+x.conj().T)/2

def unitary(d):
    x=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
    q,r=np.linalg.qr(x)
    return q@np.diag(np.diag(r)/abs(np.diag(r)))
def cpmat(factors):
    # row-major vectorization: A X A* corresponds to A tensor conj(A).
    return sum((np.kron(a,a.conj()) for a in factors),np.zeros((factors[0].size,)*2,complex))
def weights(factors):
    d=factors[0].shape[0]; S=cpmat(factors)
    check('diagonal CP map HS self-adjoint',op(S-S.conj().T)<1e-11)
    check('diagonal CP map S2 contraction',op(S)<1.000000001)
    R=np.linalg.solve(np.eye(d*d)-S/2,np.eye(d).ravel()).reshape(d,d)
    check('resolvent is Hermitian',op(R-R.conj().T)<1e-11)
    R=herm(R);v,u=eigh(R)
    check('resolvent positive',v.min()>1-1e-10)
    check('resolvent superharmonic',op(sum((a@R@a.conj().T for a in factors),np.zeros((d,d),complex))-2*(R-np.eye(d)))<1e-10)
    bins=np.floor(np.log2(v)+1e-12).astype(int)
    projs={j:u[:,bins==j]@u[:,bins==j].conj().T for j in set(bins)}
    return R,projs

def bands(factors,P):
    d=factors[0].shape[0];ks=sorted({j-i for i in P for j in P})
    ans={}
    for k in ks:
        fs=[sum((P[j+k]@a@P[j] for j in P if j+k in P),np.zeros((d,d),complex)) for a in factors]
        row=sum((a@a.conj().T for a in fs),np.zeros((d,d),complex))
        col=sum((a.conj().T@a for a in fs),np.zeros((d,d),complex))
        check('row band orientation',op(row)<=4*2.**k+1e-9,k=k,value=op(row))
        check('column band orientation',op(col)<=4*2.**(-k)+1e-9,k=k,value=op(col))
        ans[k]=fs
    return ans

def physical(aa,bb): return sum((np.kron(a,b) for a,b in zip(aa,bb)),np.zeros((aa[0].size,)*2,complex))

def run_case(d,kind):
    p=np.r_[.5,np.full(d-1,.5/(d-1))]; M=np.sqrt(np.outer(p,p))
    if kind=='star_cp':
        M=np.zeros((d,d));M[0,1:]=M[1:,0]=1/(d-1) # J=max row sum =1; S2 norm <=1.
    U,Z=unitary(d),unitary(d);aa=[];bb=[]
    # Enforce theta_ji=-theta_ij, diagonal real, directly.
    theta=rng.uniform(-2,2,(d,d));theta=(theta-theta.T)/2
    for i in range(d):
        for j in range(d):
            if M[i,j]==0:continue
            E=np.zeros((d,d),complex);E[i,j]=1
            A=np.sqrt(M[i,j])*E
            B=np.sqrt(M[i,j])*(E if kind=='star_cp' else np.exp(1j*theta[i,j])*E.T)
            aa.append(U@A@U.conj().T);bb.append(Z@B@Z.conj().T)
    V=physical(aa,bb)
    check('physical interaction Hermitian',op(V-V.conj().T)<1e-10,d=d,kind=kind)
    # Exact inherited norm formula for weighted flip: ||abs(M)||2=1.
    # For the CP-star map, its endpoint norm equals max row/column sum=1.
    endpoint=float(np.max(M.sum(axis=0))) if kind=='star_cp' else op(M)
    check('known endpoint normalization',endpoint<=1+1e-10,d=d,kind=kind)
    RA,PA=weights(aa);RB,PB=weights(bb);AB=bands(aa,PA);BB=bands(bb,PB)
    components={}
    for k,aa_k in AB.items():
        for h,bb_h in BB.items():
            X=physical(aa_k,bb_h); components[k,h]=X
            check('same-direction interpolation bound',op(X)<=2*2.**(-abs(k+h)/4)+1e-9,k=k,h=h)
            check('opposite-direction Cauchy bound',op(X)<=4*2.**(-abs(k-h)/2)+1e-9,k=k,h=h)
            # A Fourier quadrature with enough points is exact for all frequency differences here.
            span=max(max(PA)-min(PA),max(PB)-min(PB));q=2*span+3
            s=2*math.pi/q;t=4*math.pi/q
            UA=sum((np.exp(1j*j*s)*P for j,P in PA.items()),np.zeros((d,d),complex))
            UB=sum((np.exp(1j*j*t)*P for j,P in PB.items()),np.zeros((d,d),complex))
            T=np.kron(UA,UB)
            check('local Fourier band covariance',op(T@X@T.conj().T-np.exp(1j*(k*s+h*t))*X)<1e-9)
    check('exact band reconstruction',op(sum(components.values())-V)<1e-9)
    for (k,h),X in components.items():check('adjoint reverses both indices',op(X.conj().T-components[-k,-h])<1e-9)
    for L in [0,1,2]:
        W=sum((X for (k,h),X in components.items() if max(abs(k),abs(h))<=L),np.zeros_like(V))
        err=op(V-W);a=2**(-.25);EL=32*a**(L+1)*((L+1)/(1-a)+a/(1-a)**2)
        check('Hermitian band truncation',op(W-W.conj().T)<1e-9)
        check('tail bound',err<=EL+1e-9,error=err,bound=EL,L=L)
        # Four sums for the actual concatenated retained factor list.
        retained=[(A,B) for k,ak in AB.items() for h,bh in BB.items() if abs(k)<=L and abs(h)<=L for A,B in zip(ak,bh)]
        BL=4*(2*L+1)*(2.**(L+1)-2.**(-L))
        for which in [0,1]:
            fs=[pair[which] for pair in retained]
            for reverse in [False,True]:
                S=sum((a.conj().T@a if reverse else a@a.conj().T for a in fs),np.zeros((d,d),complex))
                check('retained common four-square bound',op(S)<=BL+1e-9,which=which,column=reverse)
    return dict(d=d,kind=kind,bands_A=len(AB),bands_B=len(BB))

cases=[]
for d in [3,5,9]:
    for kind in ['weighted_flip','star_cp']:cases.append(run_case(d,kind))
# Nontrivial many-level star tests are checked in their exact reduced algebra,
# without allocating a huge physical tensor matrix.
N=16384;sqrtN=128
r0=F(1+sqrtN//2,1)/F(3,4);rleaf=1+r0/F(2*sqrtN)
check('exact star resolvent',r0==1+F(sqrtN,2)*rleaf and rleaf==1+r0/F(2*sqrtN))
check('exact dyadic bins',64<=r0<128 and 1<=rleaf<2,r0=str(r0),rleaf=str(rleaf))
k=6
check('exact high-band row bound',F(sqrtN)<=4*2**k)
check('exact high-band column bound',F(1,sqrtN)<=F(4,2**k))
mutations=[
 dict(name='reverse row exponent',detected=F(sqrtN)>F(4,2**k),reason='Actual row sum 128 exceeds the mutated 1/16 bound.'),
 dict(name='omit original endpoint normalization',detected=F(1)>F(2,2**3),reason='Unnormalized CP star has band norm 1 and J=128; the false bound is 1/4.'),
 dict(name='use J alone for non-Hermitian physical norm',detected=F(1)>F(1,4),reason='The normalized 16-term compression has operator norm 1, J=1/4, and J(adjoint)=4.'),
]
for m in mutations:check('mutation detected',m['detected'],mutation=m['name'])
# Direct summation checks the infinite-tail closed form and lattice count.
a=2**(-.25)
for L in [0,7,50,150]:
 direct=32*sum(r*a**r for r in range(L+1,L+1000))
 formula=32*a**(L+1)*((L+1)/(1-a)+a/(1-a)**2)
 check('tail sum identity',abs(direct-formula)<1e-11*max(1,formula),L=L)
for r in range(1,10):check('square-shell count',sum(max(abs(k),abs(h))==r for k in range(-r,r+1) for h in range(-r,r+1))==8*r,r=r)
OUT.write_text(json.dumps(dict(status='passed',cases=cases,check_count=len(checks),checks=checks,mutations=mutations,scope='Same-agent finite controls only; no independent proof validation.'),indent=2)+'\n')
print(json.dumps(dict(status='passed',cases=len(cases),check_count=len(checks),mutations_caught=len(mutations),output=str(OUT))))
