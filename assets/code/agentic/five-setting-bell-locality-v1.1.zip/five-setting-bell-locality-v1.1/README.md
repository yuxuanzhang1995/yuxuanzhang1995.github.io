# Five settings suffice opposite three binary measurements

Yuxuan Zhang. Version 1.1, 19 November 2026. No institutional affiliation listed.

This research draft proves a finite-setting locality criterion for finite
bipartite behaviors. Together with an explicitly cited finite facet list, it
settles the all-(N,3,2,2), N >= 5 conjecture in Jesus and Zambrini Cruzeiro,
Physical Review A 108, 052220 (2023), Section IV.B. It does not classify all
Bell scenarios. The explicit sharpness example is no-signalling; a quantum
realization of that example is not asserted.

The compatibility interface is already Lemma 5 of Pironio, All CHSH polytopes
(2014). The contribution is the setting bound from finite Helly and its
classification consequence. The finite enumeration and setting lifting are
inherited. The independent review found no unresolved load-bearing proof gap;
this is a separate AI review, not external specialist validation. Global
first-discovery priority remains unconfirmed.

## Contents and checks

- paper.pdf and paper.tex: distributed manuscript and LaTeX source.
- five-setting-certificate.json and verify_control.py: author rational control.
- independent_control.py: separate reconstruction of the witness, full
  conditional tables, exact ranks and mixed-outcome zero-weight gluing.
- source_facet_control.py: six source representatives, their relabeling orbits
  and the exact I5322 identification. This does not re-prove completeness of
  the source enumeration.
- REVIEW.md and SOURCE-COMPARISON.md: independent review of the frozen v1.
- AMENDMENT-v1.1.md: the reviewer's check of the corrections in this version.
- PACKAGING-PROVENANCE.json: the only reviewer-code modification is a local
  certificate path. The recorded original hashes preserve provenance.
- reproduce.py and SHA256.json: a clean-directory replay and file manifest.

Run `python3 reproduce.py` with Python 3.8 or later. No third-party Python
packages, network access or optimization solver are needed. This verifies
file hashes, runs all three scripts from a new temporary directory, and
checks the mathematical controls and the deliberately damaged cases.

The author check finds 256 vertices, 40 saturating vertices of affine rank
22, five local deletion models, and three caught mutations. The independent
check reconstructs 240 conditional probabilities. The source check generates
71,280 nontrivial inequalities, plus 60 positivity facets. The analytic
arbitrary-setting theorem is proved in the manuscript, not by these finite
tests. The independent review's workspace-relative paths name its frozen
inputs; the corresponding released checks are in this directory.

To rebuild the PDF, run `pdflatex paper.tex` twice. Metadata can change a
rebuilt PDF's bytes; the manifest pins the distributed PDF.
