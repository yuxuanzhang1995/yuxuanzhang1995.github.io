"""Exact Choi-mask, correlated-charge localization, and face-repair controls."""
from sympy import I, Matrix, Rational as R, simplify, sqrt, zeros


# Length-three normalized sine window; compute the entries by translating it.
window = {0: R(1, 2), 1: 1/sqrt(2), 2: R(1, 2)}
assert sum(x*x for x in window.values()) == 1


def overlap(k):
    return simplify(sum(value * window.get(i+k, 0) for i, value in window.items()))


assert [overlap(k) for k in range(5)] == [1, sqrt(2)/2, R(1, 4), 0, 0]
levels = [(-2, 0), (-1, 2), (1, 1), (4, 4)]
prob = [R(1, 10), R(1, 5), R(3, 10), R(2, 5)]
E = [a + sqrt(2)*b for a, b in levels]
mean = sum(p*e for p, e in zip(prob, E))
var = sum(p*e**2 for p, e in zip(prob, E)) - mean**2
mixture_mass = 0
mixture_var = 0
mean_spread = 0
for t in range(-2, 5):
    weights = [p * window.get(y-t, 0)**2 for (_, y), p in zip(levels, prob)]
    mass = sum(weights)
    if not mass:
        continue
    loc = sum(w*e for w,e in zip(weights,E))/mass
    mixture_mass += mass
    mixture_var += sum(w*(e-loc)**2 for w,e in zip(weights,E))
    mean_spread += mass*(loc-mean)**2
assert mixture_mass == 1 and simplify(mixture_var + mean_spread - var) == 0
assert simplify(mean_spread).is_positive
for _, y in levels:
    for _, yy in levels:
        assert simplify(sum(window.get(y-t, 0)*window.get(yy-t, 0)
                            for t in range(-2, 5))-overlap(yy-y)) == 0

# A rank-deficient invariant-support Schur channel with a complex coherence.
J = zeros(4)
J[0,0] = J[3,3] = R(1,2)
J[0,3], J[3,0] = I/8, -I/8
charges = [0, -1, 2, 1]
JL = Matrix(4, 4, lambda i,j: J[i,j]*overlap(charges[i]-charges[j]))
part = R(1,3)
repair = (J-(1-part)*JL)/part
assert (1-part)*JL+part*repair == J
assert repair.rank() == 2 and repair.is_positive_semidefinite
assert repair[0,0]+repair[1,1] == repair[2,2]+repair[3,3] == R(1,2)
# Damping a noninvariant pure state creates support leakage that admixture
# cannot cancel. Compute a strictly positive kernel quadratic form.
pure = Matrix([[1,1],[1,1]])/2
out = Matrix([[1,overlap(1)],[overlap(1),1]])/2
kernel = Matrix([1,-1])
assert (kernel.T*pure*kernel)[0] == 0
assert (kernel.T*out*kernel)[0].is_positive
print("PASS: exact sine autocorrelations, correlated two-charge total variance, 16 mask entries, rank-deficient invariant Choi repair, singular-face leakage")
