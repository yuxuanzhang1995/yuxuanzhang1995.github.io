import gzip,hashlib,math,json,collections
from pathlib import Path
HERE=Path(__file__).resolve().parent;src=HERE/'sources/thebigselfdualfile.txt.gz'
counts=collections.Counter();mass=collections.Counter();types=collections.Counter();type_mass=collections.Counter();dist=collections.Counter()
files={n:(HERE/f'sources/all-n{n}.tsv').open('w')for n in [11,12]}
try:
 with gzip.open(src,'rt') as f:
  for idx,line in enumerate(f,1):
   a=line.rstrip('\n').split('\t');assert len(a)==9
   n=int(a[0]);d=int(a[1]);tp=int(a[3]);aut=int(a[5]);size=6**n*math.factorial(n);assert size%aut==0
   counts[n]+=1;mass[n]+=size//aut;dist[n,d]+=1
   if tp==2:types[n]+=1;type_mass[n]+=size//aut
   if n in files:files[n].write(f'{idx}\t{a[8]}\t{a[4][1:-1]}\t{d}\t{tp}\n')
finally:
 for f in files.values():f.close()
checks={}
for n in [11,12]:
 total=math.prod(2**i+1 for i in range(1,n+1));assert mass[n]==total
 checks[n]={'classes':counts[n],'mass':str(mass[n]),'expected_mass':str(total),'mass_pass':True,'distance_histogram':{str(d):v for (nn,d),v in dist.items()if nn==n},'tsv_sha256':hashlib.sha256((HERE/f'sources/all-n{n}.tsv').read_bytes()).hexdigest()}
 if n%2==0:
  expected=math.prod(2**i+1 for i in range(n));assert type_mass[n]==expected;checks[n]['typeII_classes']=types[n];checks[n]['typeII_mass_pass']=True
assert counts[11]==45144 and counts[12]==1323363 and types[12]==3079
out={'source_url':'https://www.codetables.de/larsed/vncorbits/thebigselfdualfile.txt.gz','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'records':checks,'scope':'Source integrity checks, not a new classification theorem.'}
(HERE/'classification-source-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
