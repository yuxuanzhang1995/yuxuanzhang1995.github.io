Theorem. No rank-two code in (C^2)^{tensor6} detecting every Pauli of weight at most two admits an exact logical T as a tensor product of six arbitrary one-qubit unitaries. The proof excludes degenerate and nondegenerate codes alike, with arbitrary complex coefficients. Genuine nonadditivity is not an assumption, so the stronger statement answers the original nonadditive existence problem negatively.

I. Reduction from arbitrary local factors.
1. Diagonalization and support normalization. Diagonalize each physical U_j by a single-qubit basis change. After removing scalar phases, write its diagonal form as diag(1,exp(2πiθ_j)), with θ_j real. The transformed logical eigenvectors a,b have disjoint computational supports: their eigenvalues differ by exp(2πi/8). Choose an occupied string of a and apply local X operators to move that string to zero. These conjugations keep the physical gate diagonal. Normalize each factor's zero entry to one, removing an overall scalar. The gate eigenvalue on a is then 1 and that on b is exp(2πi/8). Consequently every occupied string x satisfies x·θ=ℓ_x+η_x/8 for an integer ℓ_x, where η_x=0 on supp(a) and η_x=1 on supp(b). No complementary-support, purity, or uniform-angle assumption is used.

2. Rational replacement preserving every fixed-winding equation. Let M be the binary matrix whose rows are all occupied strings, and let h_x=ℓ_x+η_x/8. Thus Mθ=h. Let r=rank_R(M). We have 1≤r≤6: b has nonempty support, and its phase excludes the zero string. Choose r independent rows I and r columns J giving an invertible submatrix C=M[I,J]. Define θ'_j=0 outside J and θ'_J=C^{-1}h_I. For every row x, write M_x=λ_x M_I. Consistency of the original system implies h_x=λ_x h_I, so M_xθ'=h_x. Thus all original real equations, with their original winding integers, survive this replacement. Writing Δ=|det C|, Cramer's rule gives θ'_j∈(1/(8Δ))Z.

3. Universal denominator bound and odd-factor removal. For a binary r×r matrix C, form H with first row and first column all ones and bottom-right block J_r−2C, where J_r is the all-ones matrix. Subtracting the first row from each other row gives |det H|=2^rΔ. Every row of H has norm sqrt(r+1). Hadamard's inequality therefore gives 4^rΔ²≤(r+1)^(r+1). For r=1,…,6, respectively, the comparisons (r+1)^(r+1)<256·4^r are 4<1024, 27<4096, 256<16384, 3125<65536, 46656<262144, and 823543<1048576. Hence Δ²<256 and Δ<16. Write Δ=2^v m with m odd; then v≤3. Choose t∈{1,3,5,7} with mt≡1 mod8 and set q=mt. Since θ'_j∈(1/(8·2^v m))Z, every qθ'_j has denominator dividing 2^(v+3), hence dividing 64. Also q≡1 mod8, so q(ℓ_x+η_x/8)≡η_x/8 mod1. The qth power of the replacement gate therefore still implements exactly logical T. The winding integers need not remain unchanged at this power step, but every required support congruence remains true. Reduce the phases modulo one to obtain k_j∈{0,…,63}, then permute qubits to sort them.

The preceding local basis changes and permutations preserve distance and genuine nonadditivity. Rational replacement and powering do not change the code. Conversely, any code with the stated support and detection conditions directly has D_ka=a and D_kb=exp(2πi/8)b, so it solves the original gate equations. The number of sorted vectors is the multiset count binomial(64+6−1,6)=119877472.


Only the gate replacement and counting parts of that reduction are needed here. No stabilizer-classification or nonadditivity decision procedure is invoked. It remains to rule out every resulting order64 gate.

II. Two elementary exclusions used in the finite check.
For any modulus M in {8,16,32,64}, write omega_M=exp(2*pi*i/M), A_k={x:k dot x=0 modM} and B_k={x:k dot x=M/8 modM}. Bits are indexed least-significant first. Sorting the six exponents is a physical qubit permutation. The logical codewords a,b have supports contained in these disjoint sets; zero amplitudes are allowed. Empty B is impossible because b has norm one.

Let F(x)=(1,x_0,...,x_5,x_0x_1,...,x_4x_5), with quadratic entries in lexicographic order. Since x_j=(I-Z_j)/2 and x_ix_j=(I-Z_i-Z_j+Z_iZ_j)/4, diagonal error detection implies
sum_A |a_x|^2 F(x)=sum_B |b_x|^2 F(x).
Thus an integer polynomial c dot F that is strictly positive on all A and strictly negative on all B excludes the support pair. Reversing the signs is equivalent. The program evaluates all accepted signs by unbounded Python integer arithmetic. Floating-point optimization only proposes coefficients: a failed proposal or failed exact sign test aborts, never excludes a case.

If either allowed support has at most two vertices, such equal moments are impossible even without an LP. For a singleton {u}, Q(x)=||x-u||^2 is zero at u and strictly positive on every other cube vertex. For {u,v}, set d=v-u and Q(x)=||d||^2||x-u||^2-((x-u) dot d)^2. This is a nonnegative polynomial of degree at most two, by Cauchy-Schwarz. Equality holds only on the affine line u+t d. Since u and v are distinct Boolean vertices, a differing coordinate forces t to be either0 or1 for any Boolean point on the line. The only zeros on the cube are u,v. Hence Q vanishes on the small support and is strictly positive on the other disjoint support. Both distributions have unit mass, contradicting equality of quadratic moments. Interchange the supports when necessary.

III. Complete order8 base case.
There are binomial(13,6)=1716 sorted exponent vectors k in {0,...,7}^6. The certificate regenerates all of them and their entire supports. Exactly156 have empty B. Exactly1551 further vectors have strictly separating integer polynomials supplied in the compressed, explicitly checked certificate table. They have minimum strict integer margin1. The entire enumeration has1554 distinct ordered support pairs, including the empty ones. The remaining nine exponent vectors have support pairs that are mapped by physical qubit permutations and local X operators to either of the two pairs below. These are support equalities, not assumptions that codeword amplitudes are nonzero throughout an allowed support.

For each mapping record, apply y_j=x_permutation[j] and then XOR the given six-bit mask. The record's baseline_pair chooses (i) or(ii). The checker reconstructs both sets and verifies exact equality after the map. None of these nine records requires a logical swap.
[
  {
    "k": [
      1,
      1,
      3,
      3,
      3,
      6
    ],
    "permutation": [
      2,
      3,
      4,
      5,
      0,
      1
    ],
    "xor": 8,
    "baseline_pair": 1,
    "logical_swap": false
  },
  {
    "k": [
      1,
      2,
      2,
      3,
      4,
      5
    ],
    "permutation": [
      4,
      3,
      5,
      1,
      2,
      0
    ],
    "xor": 4,
    "baseline_pair": 2,
    "logical_swap": false
  },
  {
    "k": [
      1,
      2,
      5,
      5,
      5,
      7
    ],
    "permutation": [
      2,
      3,
      4,
      1,
      0,
      5
    ],
    "xor": 39,
    "baseline_pair": 1,
    "logical_swap": false
  },
  {
    "k": [
      1,
      3,
      4,
      5,
      6,
      6
    ],
    "permutation": [
      2,
      1,
      3,
      4,
      5,
      0
    ],
    "xor": 29,
    "baseline_pair": 2,
    "logical_swap": false
  },
  {
    "k": [
      2,
      2,
      4,
      5,
      5,
      7
    ],
    "permutation": [
      2,
      3,
      4,
      0,
      1,
      5
    ],
    "xor": 39,
    "baseline_pair": 2,
    "logical_swap": false
  },
  {
    "k": [
      2,
      3,
      3,
      3,
      7,
      7
    ],
    "permutation": [
      1,
      2,
      3,
      0,
      4,
      5
    ],
    "xor": 48,
    "baseline_pair": 1,
    "logical_swap": false
  },
  {
    "k": [
      2,
      3,
      3,
      4,
      6,
      7
    ],
    "permutation": [
      3,
      1,
      2,
      0,
      4,
      5
    ],
    "xor": 48,
    "baseline_pair": 2,
    "logical_swap": false
  },
  {
    "k": [
      3,
      5,
      5,
      6,
      7,
      7
    ],
    "permutation": [
      0,
      1,
      2,
      3,
      4,
      5
    ],
    "xor": 62,
    "baseline_pair": 1,
    "logical_swap": false
  },
  {
    "k": [
      4,
      5,
      5,
      6,
      6,
      7
    ],
    "permutation": [
      0,
      1,
      2,
      3,
      4,
      5
    ],
    "xor": 62,
    "baseline_pair": 2,
    "logical_swap": false
  }
]

The two target pairs and their full quantum contradictions follow. They use off-diagonal error detection as well as the diagonal moments, with no restrictions on complex phases:
Write a_x=<x|a>, b_y=<y|b>. Distance three implies <a|O|b>=0 for every operator O supported on at most two qubits, and <a|O|a>=<b|O|b> for all such O. These statements apply to non-Hermitian matrix units as well: they are complex linear combinations of the specified Pauli operators.

We first give the exact diagonal-moment computation used below. List each support in the increasing order displayed in the claim, and let p_x=|a_x|^2, q_y=|b_y|^2. Form a rational matrix M with two normalization rows and one row for each subset S of {0,...,5} of size one or two. The normalization rows are (1_A,0_B) and (0_A,1_B). The row for S is (chi_S(x))_{x in A} concatenated with (-chi_S(y))_{y in B}, where chi_S(x)=(-1)^{sum_{j in S} bit_j(x)}. The right-hand side h is (1,1,0,...,0). Thus diagonal KL gives M(p,q)=h.

For pair (i), M has rank 14, and its unique solution is
(p,q)=(5/16,3/16,3/16,1/8,1/16,1/16,1/16; 1/16,1/16,1/16,1/8,3/16,3/16,5/16).
For pair (ii), M has rank 15, and its full solution is
(p,q)=(t,3/16-t,1/4-t,t+1/16,3/16,1/8,1/8,1/16; 1/16,1/8,1/8,3/16,t+1/16,1/4-t,3/16-t,t).
Nonnegativity forces 0<=t<=3/16. These rational row-reduction identities can be checked directly from the definition of M; the accompanying standalone exact-arithmetic certificate verifies the ranks, particular solutions, and null direction. In particular, it does not use any floating-point feasibility result.

For (i), consider O=X_4(I+Z_0)/2, where subscripts denote bit positions. This is a linear combination of weight-one and weight-two Paulis. Among all x in A,y in B, its only nonzero computational-basis matrix element is <8|O|24>=1: the only cross-support pairs differing in bit 4 are (8,24) and (39,55), and the bit-0 projector removes the latter. Consequently 0=<a|O|b>=conj(a_8)b_24. But |a_8|^2=5/16 and |b_24|^2=3/16, a contradiction.

For (ii), use three two-qubit matrix units, tensored with identity on all unspecified bits. Let O_1 map the bit-(4,2) pattern (0,1) to (1,0); let O_2 map the bit-(5,3) pattern (0,1) to (1,0); let O_3 map the bit-(1,0) pattern (0,0) to (1,1). Their cross-support nonzero matrix elements, all equal to one, are respectively
O_1: (27,15),(48,36);
O_2: (39,15),(48,24);
O_3: (27,24),(39,36).
Thus, putting u_x=conj(a_x) and v_y=b_y, KL requires
u_27 v_15+u_48 v_36=0,
u_39 v_15+u_48 v_24=0,
u_27 v_24+u_39 v_36=0.
Here the displayed symbols u_27 and u_39 refer to u as defined above. All six amplitudes involved are nonzero: their squared moduli are p_27=1/4-t>=1/16, p_39=3/16, p_48=1/8, q_15=1/8, q_24=3/16, q_36=1/4-t>=1/16. Dividing the first equation by the second gives u_27/u_39=v_36/v_24, whereas the third gives u_27/u_39=-v_36/v_24. This is impossible over C because v_36/v_24 is nonzero. This argument includes both endpoints of the allowed interval for t.

Finally, pair (iii) is obtained from pair (ii) by XOR with 1 on both supports. The local unitary X_0 implements that permutation of basis states and preserves the distance-three conditions, so existence for (iii) would imply existence for (ii), already excluded.

To check the eigenvalue interpretation, set omega=exp(2*pi*i/8) and D_w= tensor_j diag(1,omega^{w_j}), with w indexed most-significant-bit first. Its computational-basis eigenvalue at x is omega^{sum_j w_j bit_{5-j}(x)}. The displayed supports are exactly the stated residue classes. No step assumes complementary amplitudes, shared phases, purity, or absence of zero coefficients.
This excludes every order8 gate. In particular, gates of any smaller order are included; there is no unhandled lower-denominator base case.

IV. Complete order16 case.
If all k_j are even, divide them and M=16 by two. The physical gate and its logical T action are unchanged, and the result is covered by part III. For at least one odd coefficient, the following exhaustive argument applies:
First reduce the stated gate family to the claimed support problem. Diagonalize each local unitary by a single-qubit basis change and discard its scalar factor. Write its eigenvalue ratio as exp(2πi k_j/16). The logical eigenvectors a,b then lie in distinct eigenspaces of D_k, with eigenvalue ratio exp(2πi·2/16). Their eigenvalues have residues r,r+2. Choose any computational string t with nonzero amplitude in a and conjugate the code and gate by the corresponding tensor product of X operators. The identity D_k X^t = exp(2πi k·t/16) X^t D_{k'}, where k'_j=(-1)^{t_j}k_j modulo16, moves the first eigenvalue to residue zero and the second to residue two. At least one odd entry remains odd. A qubit permutation sorts the entries. These operations preserve all error-detection conditions. Consequently it suffices to exclude the normalized sorted support pairs; no additional odd-power or residue-pair equivalences are assumed.

Let f(x) consist of the six coordinates x_j and fifteen products x_i x_j, i<j. Error detection implies that the probability distributions |a_x|² and |b_x|² have equal f-moments: x_j represents (I-Z_j)/2, and x_i x_j represents (I-Z_i-Z_j+Z_iZ_j)/4. All these operators are linear combinations of detectable weight-at-most-two Paulis. The two distributions are normalized. Thus their f-moment vectors must belong to the intersection of the two support convex hulls. Off-diagonal Pauli conditions cannot remove this necessary condition.

For each distinct nonempty support pair, the certificate program constructs an integer coefficient vector c for q(x)=c_0+Σ_j c_{j+1}x_j+Σ_{i<j}c_{ij}x_i x_j and checks, using Python integer arithmetic, q(x)≤-1 on A and q(x)≥1 on B. These inequalities contradict equality of the normalized distributions' moments. Zero amplitudes cause no difficulty because the inequalities hold on the entire allowed supports.

Coverage is independently regenerated by combinations_with_replacement(range(16),6), rejecting exactly the all-even tuples. The number of retained tuples is binomial(21,6)-binomial(13,6)=54,264-1,716=52,548. An additional exact checksum is the sum of all six coordinates over retained tuples: 54,264·45-1,716·42=2,369,808. Every Boolean string is evaluated explicitly; ordered support pairs are deduplicated by their complete tuples, not by hashes or an unproved symmetry. Empty second supports are excluded immediately. The asserted counts are 4,844 empty cases, 47,704 nonempty cases, and 32,975 distinct nonempty pairs. Each distinct pair must pass the integer inequalities; multiplicities are also checked.

The included primitive16 program is complete and uses no saved artifacts. SciPy's linear program is only an untrusted certificate-discovery mechanism. Its status or floating residuals never establish an exclusion: coefficients are rounded to integers and every required sign inequality is evaluated exactly. Failure to discover or verify even one separator aborts the program. The printed capped minimum margin is min(1, all -q(x) on A, all q(x) on B), so its exact value one certifies every strict separation inequality simultaneously. Exploration supplied the reported counts; the combined independently reconstructing checker now reproduces every exact separation. Its expected stdout specifies the complete reproducibility test.
The primitive16 certificate has now been executed successfully as part of the combined certificate (rather than only proposed). Its exact inequalities have the opposite sign convention to part II, which is equivalent. Hence every order16 gate is excluded.

V. Denominator reduction at M=32 and64.
The residues0 and M/8 are both even. On every computational string in either allowed support, the number of occupied coordinates having odd k_j is therefore even. If all coefficients are even, dividing coefficients and modulus by two leaves the gate unchanged. If exactly one coefficient is odd, its bit is zero on both supports; replace that coefficient by zero. If exactly two coefficients k_u,k_v are odd, their bits are equal on both supports. Replace k_u,k_v by0,k_u+k_v modulo M. This has exactly the same phase on both entire supports. In either case every new coefficient is even. Dividing all of them and the modulus by two therefore gives a gate on the very same code that still implements exactly T. It can be sorted again by a qubit permutation. This is a reduction to M/2, not a claim that the original gate had smaller order on the entire Hilbert space. We exclude32 first using16, then64 using32, so there is no circular inference.

VI. The remaining order32 and64 support pairs.
The standalone program uses only Python and NumPy within the unchanged verifier sandbox. For each b=0,...,M-1 it generates every sorted suffix(c,d,e,f) with b<=c<=d<=e<=f<M, then takes a=0,...,b. This enumerates each sorted tuple(a,b,c,d,e,f) exactly once. Suffix counts are checked against binomial(M-b+3,4). The mutually exclusive branches are all-even coefficients; one or two odd coefficients; empty B; either support of size at most two; and a remaining ordered support pair. Parts II and V justify every skipped branch.

For each four-coefficient suffix, the array lookup[r,i] is a16-bit mask whose set bits are exactly the suffix words w in {0,...,15} having dot product r modulo M. All16 words are evaluated by direct integer sums. A single assignment has distinct suffix indices, so the indexed OR retains all contributions even when different words have the same residue. The table SPREAD maps mask u to sum_{j:bit_j(u)=1}2^(4j). For first-two-bit word t in {0,1,2,3}, set s_t=a*bit_0(t)+b*bit_1(t). Then
A_mask = OR_t (SPREAD(lookup[-s_t modM,i]) << t),
B_mask = OR_t (SPREAD(lookup[M/8-s_t modM,i]) << t).
These formulas encode the complete six-bit word x=t+4w, hence represent exactly the required64-vertex supports. The highest shift position is63, within unsigned64-bit arithmetic. The suffix arithmetic uses signed16-bit integers, whose magnitudes are at most252 before taking residues, and all totals/checksums use Python integers. There is no floating calculation in support generation.

Both masks are nonempty at the small-support check. A mask has size at most two precisely when clearing its least-significant set bit twice produces zero. Subtraction in the unsigned-array implementation wraps modulo2^64; when the intermediate mask is zero, zero AND the wrapped value is still zero, so the same criterion holds for singleton masks. Nonempty residual pairs are deduplicated by exact equality of structured pairs of unsigned64-bit integers. No lossy hash or unproved symmetry is used. Feasibility depends only on these full supports, so one separator can reject all tuples with the same pair.

The asserted partition counts, in order (total, all-even, one/two odd, empty B, small support, remaining vectors, distinct remaining pairs), are:
M32: (2324784,54264,775200,297784,940779,256757,89598).
M64: (119877472,2324784,39709824,31518100,44459312,1865452,139817).
Totals are binomial(M+5,6); coordinate-sum checksums are216204912 and22656842208. In each case twice the checksum equals total*6*(M-1). The sum of the disjoint class counts is the total. These checks supplement the transparent exhaustive loops; counts alone are not asserted to prove coverage.

For each not-yet-certified residual pair the Python code obtains a candidate linear separator, rounds scaled coefficients to integers, and computes its values exactly on all64 vertices. It accepts only if the strict inequalities hold on the entire chosen A and B. The resulting positive and negative masks can then cover any other pair whose respective supports are subsets of those masks. This additional coverage is an exact set-inclusion test. No pair is removed unless one such verified polynomial covers it. The loop terminates successfully only when all89,598 or139,817 residual pairs have been certified. Failure to obtain even one certificate aborts. There is no time-based successful exit or tolerance-based exclusion. The reconstructed standalone check reports zero unresolved pairs at both moduli.

The code requires no external project files. An independent control using six explicit nested multiset loops and Gray-code subset traversal regenerated exactly the same complete support-pair sets; another control checked the saved integer witnesses without an optimizer. Those controls are corroboration; the included standalone certificate and the preceding reductions already specify the complete argument.

VII. Conclusion and attribution.
Parts III-IV exclude orders dividing16. Parts II,V,VI successively exclude32 and64. Part I replaces any arbitrary-angle witness by an order64 witness on an equivalent code. Therefore no arbitrary-angle witness exists. This excludes all rank-two distance-at-least-three six-qubit codes and, in particular, the genuinely nonadditive class in the original question. No ancillary qubits, measurements, code switching, complementary-codeword relation, real-amplitude condition, or additional transversal gate is assumed.

The subset-sum and diagonal-KL LP strategy is prior work of Zhang, Wu, Huang and Zeng, arXiv:2504.20847v1, Section6.1. Their Table2 reports no six-qubit C16 code found, not a nonexistence theorem; Section6.3.1 constructs seven-qubit examples. He, Lu and Zeng, arXiv:2510.20728v3, SectionIV and AppendicesF-G, classify twelve seven-qubit candidates in a complementary binary-dihedral ansatz. That result and their distance-two catalog on at most six qubits do not state this unrestricted six-qubit no-go. The claimed contribution is the complete arbitrary-angle reduction and exhaustive exclusion, not the invention of SSLP. No priority, external expert acceptance, formal proof-assistant verification, or catalog status change is asserted.

