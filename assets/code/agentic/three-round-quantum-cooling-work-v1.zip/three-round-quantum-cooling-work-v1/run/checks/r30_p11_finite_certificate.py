"""Directed interval certificate for a finite-gamma six-stage protocol.

No search, floating point input, or truncated physical Hilbert space is used.
Only integer permutations are imported from the R25 discovery artifact.
"""
from decimal import Decimal as D,localcontext,ROUND_FLOOR,ROUND_CEILING
from fractions import Fraction as F
from pathlib import Path
import json,math
PREC=80
def op(f,r):
 with localcontext() as c:c.prec=PREC;c.rounding=r;return f()
class I:
 def __init__(self,a=0,b=None):self.a=D(a);self.b=D(a if b is None else b)
 def __add__(x,y):
  y=cv(y);return I(op(lambda:x.a+y.a,ROUND_FLOOR),op(lambda:x.b+y.b,ROUND_CEILING))
 __radd__=__add__
 def __neg__(x):return I(x.b.copy_negate(),x.a.copy_negate())
 def __sub__(x,y):return x+-cv(y)
 def __rsub__(x,y):return cv(y)+-x
 def __mul__(x,y):
  y=cv(y);return I(min(op(lambda:a*b,ROUND_FLOOR) for a in [x.a,x.b] for b in [y.a,y.b]),max(op(lambda:a*b,ROUND_CEILING) for a in [x.a,x.b] for b in [y.a,y.b]))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=cv(y);assert y.a*y.b>0
  return x*I(op(lambda:1/y.b,ROUND_FLOOR),op(lambda:1/y.a,ROUND_CEILING))
 def __pow__(x,n):
  out=I(1)
  for _ in range(n):out=out*x
  return out
 def pair(x):return [str(x.a),str(x.b)]
def cv(x):return x if isinstance(x,I) else I(x)
def rat(x):return I(op(lambda:D(x.numerator)/D(x.denominator),ROUND_FLOOR),op(lambda:D(x.numerator)/D(x.denominator),ROUND_CEILING))
def exp_minus_fraction(t,N):
 assert 0<=t<=1 and N%2==0
 upper=sum(((-t)**j/F(math.factorial(j)) for j in range(N+1)),F(0))
 lower=upper-t**(N+1)/F(math.factorial(N+1))
 return I(rat(lower).a,rat(upper).b)
q=exp_minus_fraction(F(1),120);theta=I('0.01');delta=I('0.00001')
qg=q*exp_minus_fraction(F(1,100000),20)
e=[0,1,1,2,2,3];p=[q**v for v in e];Z=sum(p);p=[v/Z for v in p]
b=[I(1),q,q*q];Zb=sum(b);b=[v/Zb for v in b]
target=[qg**s*q**m for s in range(3) for m in range(2)];Zt=sum(target);target=[v/Zt for v in target]
def zero():return [[I(0) for _ in range(6)] for _ in range(6)]
def ident():return [[I(int(i==j)) for j in range(6)] for i in range(6)]
def add(A,B):return [[A[i][j]+B[i][j] for j in range(6)] for i in range(6)]
def scale(A,c):return [[v*c for v in row] for row in A]
def mul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(6)) for j in range(6)] for i in range(6)]
def transpose(A):return [list(row) for row in zip(*A)]
def comm(A,B):return add(mul(A,B),scale(mul(B,A),-1))
tails=[]
def expm(A):
 v=I(max(sum((I(max(a.a.copy_abs(),a.b.copy_abs())) for a in row),I(0)).b for row in A))
 N=40;T=ident();S=ident()
 for k in range(1,N+1):T=scale(mul(T,A),I(1)/I(k));S=add(S,T)
 assert (v/I(N+2)).b<1
 rem=(v**(N+1)/I(math.factorial(N+1)))/(I(1)-v/I(N+2));tails.append(rem.pair())
 return [[x+I(rem.b.copy_negate(),rem.b) for x in row] for row in S]
def channel(A,u):
 out=zero()
 for a in range(3):
  for i in range(6):
   for j in range(6):
    vi,vj=u[3*i+a],u[3*j+a]
    if vi%3==vj%3:out[vi//3][vj//3]+=b[a]*A[i][j]
 return out
def energy(A):return sum(e[i]*A[i][i] for i in range(6))
tau=zero()
for i in range(6):tau[i][i]=p[i]
data=json.loads(Path('run/checks/r25_p11_response.result.json').read_text())
cols=[];costs=[];works=[];max_k2=[]
for rec in data['selected_protocols']:
 for name in ['u1','u2','u3']:
  u=rec[name];assert sorted(u)==list(range(18))
  assert all(e[i//3]+i%3==e[u[i]//3]+u[i]%3 for i in range(18))
 K=zero();K[rec['i']][rec['j']]=I(1);K[rec['j']][rec['i']]=I(-1)
 X=channel(comm(K,tau),rec['u1']);K2=zero()
 for i in range(6):
  for j in range(6):
   if e[i]!=e[j]:K2[i][j]=X[i][j]/(p[i]-p[j])
 max_k2.append(str(max(max(max(x.a.copy_abs(),x.b.copy_abs()) for x in row) for row in K2)))
 V1=expm(scale(K,theta));V2=expm(scale(K2,theta))
 r1=mul(mul(V1,tau),transpose(V1));w1=energy(r1)-energy(tau)
 r2=channel(r1,rec['u1']);r3=mul(mul(V2,r2),transpose(V2));w2=energy(r3)-energy(r2)
 r4=channel(channel(r3,rec['u2']),rec['u3'])
 assert w1.a>0
 gross=w1+I(max(D(0),w2.a),max(D(0),w2.b))
 cols.append([r4[i][i]-p[i] for i in range(6)]);costs.append(gross)
 works.append({'w1':w1.pair(),'w2':w2.pair(),'w3':['0','0'],'gross':gross.pair()})
A=[[cols[j][i] for j in range(5)]+[target[i]-p[i]] for i in range(5)]
pivots=[]
for k in range(5):
 pivot=max(range(k,5),key=lambda i:abs(A[i][k].a));A[k],A[pivot]=A[pivot],A[k]
 v=A[k][k];assert v.a*v.b>0;pivots.append(v.pair())
 A[k]=[x/v for x in A[k]]
 for i in range(5):
  if i==k:continue
  v=A[i][k];A[i]=[A[i][j]-v*A[k][j] for j in range(6)]
weights=[A[i][-1] for i in range(5)]
assert all(w.a>0 for w in weights)
identity_weight=I(1)-sum(weights);assert identity_weight.a>0
work=sum(w*c for w,c in zip(weights,costs));assert work.b<D('0.00000349')
sixth=p[5]+sum(w*col[5] for w,col in zip(weights,cols))-target[5]
assert sixth.a<=0<=sixth.b
out={'gamma':'1.00001','theta':'0.01','decimal_precision':PREC,'matrix_exponential_order':40,
     'q_interval':q.pair(),'q_gamma_interval':qg.pair(),'Taylor_tail_intervals':tails,
     'linear_solve_pivots':pivots,'exact_mixture_weight_enclosures':[w.pair() for w in weights],
     'identity_weight_enclosure':identity_weight.pair(),'recharge_works':works,
     'gross_mean_work_interval':work.pair(),'cost_per_gamma_increment':(work/delta).pair(),
     'sixth_population_residual_interval':sixth.pair(),'max_K2_entry_bounds':max_k2,
     'certified':'exact unconditioned product return; W_Q(1.00001) < 0.00000349',
     'not_certified':'quantum advantage over all population protocols or optimal quantum work'}
Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['Taylor_tail_intervals','linear_solve_pivots','recharge_works']},indent=2))
