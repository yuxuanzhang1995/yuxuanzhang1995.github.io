"""Exact checks on the published three-level example and a failed perturbation."""

import sympy as sp


a, b, c = sp.Rational(2751, 2944), sp.Rational(31, 736), sp.Rational(1, 2)
eye = sp.eye(3)


def unit(i, j):
    return eye[:, i] * eye[:, j].T


def kraus(a, b, c):
    root = sp.sqrt
    return [
        root(a) * unit(0, 0) + root(c) * unit(2, 2),
        root(1-a) * unit(1, 0) + root(b) * unit(2, 1),
        root(1-b) * unit(0, 1) + root(1-c) * unit(1, 2),
    ]


def apply(operators, state):
    return sum((k * state * k.H for k in operators), sp.zeros(3))


operators = kraus(a, b, c)
assert sum((k.H * k for k in operators), sp.zeros(3)) == eye
input_gibbs = sp.diag(64, 16, 1) / 81
output_gibbs = sp.diag(64, 4, 1) / 69
assert apply(operators, input_gibbs) == output_gibbs
assert apply(kraus(a, b/2, c), input_gibbs) != output_gibbs
for k, frequency in zip(operators, (0, 2, -1)):
    assert sp.diag(0, 2, 3) * k - k * sp.diag(0, 1, 3) == frequency * k
products = [(k.H * l).reshape(9, 1) for k in operators for l in operators]
assert sp.Matrix.hstack(*products).rank() == 9

y = sp.Symbol("y", positive=True)
za, zb = 1+y+y**3, 1+y**2+y**3
ratio = zb**2 / (y**2 * za)
bound = sp.cancel((za - zb**2)/y)
assert bound == 1-2*y-y**2-y**3-2*y**4-y**5
assert all(coef < 0 for coef in sp.Poly(sp.diff(bound, y), y).all_coeffs())
assert bound.subs(y, sp.Rational(1, 4)) == sp.Rational(423, 1024)
assert ratio.subs(y, sp.Rational(1, 4)) == sp.Rational(529, 36)
assert sp.limit(y**2 * ratio, y, 0, dir="+") == 1
assert 4**2 == 16 and sp.Rational(529, 36) < 16
print("Three-level example passed: trace, Gibbs, frequencies, extremality, both partition values and a failed Gibbs perturbation.")
