# Low-rank approximation of non-Hermitian operators from spectral entangling strength

Yuxuan Zhang. Version 1.0, 18 November 2026.

For every fixed `0 < alpha < 1/3`, every finite-dimensional bipartite complex
operator X, and every integer D >= 0, the manuscript proves the existence of
an operator Y of operator Schmidt rank at most D with

    ||X - Y||_op <= J_alpha(X) (D+1)^(-(1/(2 alpha)-3/2)).

J_alpha takes the supremum of the output Schmidt-coefficient l_(2 alpha)
quasinorm over normalized product inputs with arbitrary finite local ancillas.
There is no Hermiticity or locality hypothesis and no dimension factor.
The rank exponent is optimal; the upper constant one is not claimed optimal.
The argument is an existence proof, not a polynomial-time optimization algorithm.

## Reproduce the supplementary checks

Use Python 3 with NumPy and SciPy installed, then run:

    python3 reproduce.py

The runner first verifies all files listed in MANIFEST.json, copies the
checker to a temporary directory, and runs it there. No network access is
needed. It verifies the summary and mutation controls from actual generated
results, rather than accepting matching stdout alone. The original package
remains unchanged. Tested versions are recorded in requirements.txt and the
expected diagnostic output. Floating-point values can vary slightly with
the platform; the checker uses explicit tolerances.

The checks cover 12 complex factorization cases, 24 finite differences,
two local stationary-point diagnostics, and eight invalid substitutions.
The all-dimensional theorem is established by the manuscript's analytic
argument, not by these finite checks. Neither optimization is certified
as a global maximum.

## Build the manuscript

With a standard TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error manuscript/main.tex

The website separately supplies the compiled PDF. The source contains the
complete proof and checked bibliography. A local display label used during
research is Q276; it is not a QIQC catalogue number.

## Review and source status

The proof has sequential internal review, not independent expert review or
formal certification. SOURCE-COMPARISON.md documents the bounded public-source
search. Reference 93 of the closest published source is unpublished and was
not recovered. Its possible overlap is unresolved, and first-publication
priority is not asserted. The known rank-one obstruction is credited to
prior work. This package does not claim journal or catalogue acceptance.

The author directed the research and manuscript preparation; AI assistance
contributed to derivation, literature comparison, computation, checking,
and drafting.
