# Quantitative candidate v1: same-agent review

Verdict: internally supported mathematical extension, with the limits below.
The complete candidate was checked, including its iteration bound. The eight
exact controls and three floating implementation diagnostics are recorded in
checks-v1.json. They supplement the proof; they do not certify it globally.

1. **Traceless stack bound.** The block decomposition around an arbitrary unit
   vector is valid over the complex field. The inequality 2>=k/(k-1) uses
   k>=2. Summing before maximizing gives the bound on lambda_max(sum T_j^2).
   The diagonal family attains the second-singular-value constant exactly.
   The rank-one nontraceless control correctly violates the proposed extension.
2. **Rectangular dimensions.** C has q=n-k rows and p=mk columns. The
   rank-p-2 approximation leaves a left vector because q>=p-1, including
   the threshold case. Thin SVD must not discard a left kernel when q>p;
   the test implementation uses full left singular vectors.
3. **No inverse error.** Only the two largest singular values of the stack
   are inverted. No assumption of full column rank or a nonzero smallest
   singular value is made.
4. **Residual norm.** Y^*R has the same operator norm as R because R is
   horizontal. Its operator norm is bounded by ||grad F||_F/4 under the
   explicitly stated Grassmann metric.
5. **Hessian identity.** Both real and imaginary column rotations are needed.
   Independent exact expansions at k=2,3,4 verify the phase sum and gradient
   factor, with nonzero cross blocks and bottom-right blocks included.
6. **Zero and empty cases.** F=0 is separated before division; P=0 stops the
   algorithm. m=0 has F=0. k=1 is outside the lemma and is trivial for scalar
   compression. The program rejects an instance below the dimension threshold.
7. **Derivative bounds.** For the unit horizontal tangent, the anti-Hermitian
   generator has operator norm at most one. The two Leibniz sums yield 4^r P.
   These are bounds on the whole geodesic, so the Taylor remainders are uniform.
8. **Descent constants.** The gradient branch gives F^2/(32P a^2). The other
   branch has curvature below -15F/(4k); using the weaker -2F/k and the stated
   time gives F^2/(48Pk^2). Both imply F^2/(48Pk^3).
9. **Rate.** The reciprocal recurrence yields the claimed 48Pk^3/tau bound.
   It is an ideal-arithmetic iteration bound, not bit complexity or exact
   finite termination at F=0. Computation at fixed precision remains separate.
10. **Error-basis normalization.** The sqrt(2) factors in the real/imaginary
    products preserve the sum over ordered error pairs exactly. The coefficient
    estimate concerns the specified basis; it is not uniform under arbitrary
    basis rescaling. The exact coefficient-space control checks this conversion.
11. **Empirical coverage.** The generic and actual-error cases used 439 and
    508 gradient steps. The stationary example used 126 gradient steps and
    10 curvature steps. All attained 5% of their initial variance. The largest
    isometry residual was below 2.8e-14. No exact correcting code was inferred.
12. **Contribution.** The original exact asymptotic result is inherited. The
    new candidate quantifies its landscape and gives a decrease analysis.
    Exact rounding, particularly c(2,6), remains unchanged.
13. **Independence and sources.** This is one agent's proof review plus a
    separately written exact implementation. No expert or fresh-agent review
    was obtained. The variance objective and Stiefel optimization are inherited
    methods. Gupta et al., arXiv:2604.21800 section VI.1, explicitly use this
    feasibility loss with polar parameterization and gradient optimization;
    the inspected section does not supply the uniform derivative implication
    proved here. Reimpell section 3.3.4 supplies compression and seesaw context.
    Exhaustive priority review remains unestablished.

The next useful transfer is the physical meaning of approximate KL residuals
for a normalized channel. It must provide an actual trace-preserving decoder
and handle zero eigenvalues, without reusing normalization to settle the
different arbitrary-error minimax problem.
