# CP-order robustness is not exact sharp-battery work

25 November 2026. A rejected general-cost route. The rectangular completion,
qutrit unitary control and extreme-channel work value are inherited;
their use here is to disprove the proposed converse, not to count those
results again. Equal-dimensional H=0, beta>0, normal countable Gibbs bath,
sharp battery on every branch.

Let F_fin be finite-tracial unitary channels and define

 Gamma(Phi)=inf {a>=1 : J(Phi)<=a J(Psi), Psi in F_fin}.

Here J is the unnormalized Choi matrix. Rectangular unitary completion
already proves Gamma(Phi)<=R_fin(Phi)=exp(beta W_0(Phi)). Indeed the
completed free channel has form R^-1 Phi+(1-R^-1)Theta. This lower bound
does not have a matching converse, even in dimension three.

## Exact separation

Let J_i be spin-one generators and

 Phi(rho)=(Tr(rho)I-rho^T)/2 = (1/2) sum_i J_i rho J_i.

With Pauli sigma_i, put U=I/3+(2/3)sum_i J_i tensor sigma_i. The operator
S=sum_i J_i tensor sigma_i obeys S^2=2I-S, so U*U=I. A maximally mixed
qubit environment gives the free channel

 Psi=(1/9)id+(8/9)Phi.

Thus Gamma(Phi)<=9/8. On the other hand K_i=J_i/sqrt(2) obey
linear independence of the nine matrices K_i* K_j. In any rectangular
isometry V=sum_i K_i tensor S_i, V*V=I therefore forces

    S_i* S_j = delta_ij I_M.

The three ranges are mutually orthogonal M-dimensional spaces, so
N>=3M. Every bath block has that ratio and the ordinary Stinespring
construction attains the infimum R_fin(Phi)=3. Consequently

    log Gamma(Phi)/beta <= log(9/8)/beta < log(3)/beta=W_0(Phi).

No numerical optimization, bounded ancillary cutoff, or priority claim
enters this separation. The extreme/factorization facts are consistent
with Haagerup--Musat, https://arxiv.org/abs/1408.6476, and their earlier
nonfactorizability criterion; the spin-one/qubit construction is already
in the preceding local block's skew-work-analytic-v2.md.

## The missing physical lifting condition

Purify the maximally mixed input of a free unitary dilation. CP domination
then represents a subchannel by a positive contraction acting on the
Stinespring environment. That environment includes the reference which
purifies the INPUT thermal ancilla, as well as the discarded output.
An arbitrary contraction there is not preparation of a subspace of a
maximally mixed input, and it is not a deterministic thermal operation.

The proposed converse would need a block-diagonal input-corner lift:
an actual isometry from a uniformly populated M-dimensional input corner
into an N-dimensional output, with the desired channel, N/M controlled
by a. Channel-order dominance places no such constraint on its
Radon--Nikodym contraction. The example above proves that imposing it
can change the optimum. Allowing a measured success branch would change
the sharp deterministic battery task and cannot repair the proof.

## Second attempt: exact dual of the rank formulation

On a fixed support let Omega(G)=I_M encode the operator-valued isometry
constraint, and write T_G=(Tr G_ab/M)_ab and r_G=rank(G)/M. A valid dual
witness is a Hermitian H satisfying

    Tr(H T_G)<=r_G

for EVERY finite M and EVERY G>=0 with Omega(G)=I_M. It bounds
R_fin(T)>=Tr(H T). In relative-interior target points convex support
hyperplanes yield a sharp dual if this full family of inequalities is
retained. Replacing the family by scalar CP dominance is exactly the
invalid relaxation above. Replacing it by all tracial-algebra moments
also drops the finite-representation constraint, as established in the
predecessor's factorization-distance note.

I have not reduced these universal finite-matrix inequalities to a
finite test or constructed their optimum for general input channels.
The dual is recorded as the remaining lifting obligation, not as an
evaluated answer or an additional result. Both proposed simplifications
of the arbitrary-channel cost have therefore reached their stop gate.
