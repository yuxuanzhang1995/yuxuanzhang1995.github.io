"""Fresh controls for the proof interface; not a proof of the analytic theorem.

Exact joint-order witness and finite, energy-labelled thermal dilations for
a Gibbs-preserving qutrit measurement with two generally distinct gaps.
No predecessor script is imported. All output is written under this focus.
"""
import json
import math
from pathlib import Path

import numpy as np
import sympy as sp
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent


def exact_control():
    signs = [sp.Matrix(v) for v in [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]]
    effects = [v*v.T/4 for v in signs]
    H = sp.Matrix([[0,1,0],[1,0,0],[0,0,0]])
    gamma = sp.Symbol('gamma', real=True)
    t = [v[0]*v[1] for v in signs]
    f = [gamma if x == 1 else 0 for x in t]
    c = [t[a]-f[a] for a in range(4)]
    assert sum(effects, sp.zeros(3)) == sp.eye(3)
    assert sp.simplify(sum(((c[a]+f[a])*effects[a] for a in range(4)), sp.zeros(3))-H) == sp.zeros(3)
    X = sp.diag(1,1,-2)
    assert all(sp.trace(X*E) == 0 for E in effects)
    # Every second-order Kraus term is in the same span, for every C_1,C_2.
    assert sp.trace(X*H**2) == 2
    # Removing the first derivative correction breaks the first joint equation.
    residual = sum((f[a]*effects[a] for a in range(4)), sp.zeros(3))-H
    assert residual != sp.zeros(3)
    return {"first_order_identity": True, "second_order_dual_witness": "diag(1,1,-2)",
            "second_order_obstruction": "Tr(X H_A^2)=2; Tr(X E_a)=0 for every a",
            "first_infeasible_order": 2, "derivative_removal_mutation_detected": True}


SIGNS = np.array([(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)], float)
H = np.array([[0.,1,0],[1,0,0],[0,0,0]])
energies, basis = np.linalg.eigh(H)
K = SIGNS @ basis / 2  # Each row is the only nonzero row of one Kraus operator.
target_effects = np.einsum('ai,aj->aij', K, K)
thermal = expm(-H)
thermal /= np.trace(thermal)
out = np.einsum('ai,ij,aj->a', SIGNS, thermal, SIGNS)/4
tags = SIGNS[:,0]*SIGNS[:,1]
gap = float(np.log(out[tags == -1][0]/out[tags == 1][0]))
f = np.where(tags == 1, gap, 0.)
c1 = tags-f
omega = np.array([1.,gap])
perp = np.array([-gap,1.])/np.linalg.norm(omega)
beta_gibbs = np.exp(-f); beta_gibbs /= beta_gibbs.sum()
assert np.max(np.abs(beta_gibbs-out)) < 1e-14


def profile(E, W):
    p = 2*W**3/(np.pi*(W*W+E*E)**2)
    dp = -4*E/(W*W+E*E)*p
    return p, dp


def fibre(W, transverse, origin, cutoff=4., output_energies=None):
    # A finite clock in a parallelogram. Its Hilbert-space labels are exact
    # integer pairs; equal physical energies, if any, are degenerate levels.
    flocal = f if output_energies is None else np.asarray(output_energies)
    c1local = tags-flocal
    N = int(math.ceil(cutoff*(W+transverse)))+3
    axis = np.arange(-N,N+1)
    z0,z1 = np.meshgrid(axis,axis,indexing='ij')
    E = (z0+origin[0]) + gap*(z1+origin[1])
    u = perp[0]*(z0+origin[0])+perp[1]*(z1+origin[1])
    p,_ = profile(E,W)
    raw = p/(1+(u/transverse)**2)**2
    occupied = (np.abs(E) <= cutoff*W) & (np.abs(u) <= cutoff*transverse)
    raw = np.where(occupied,raw,0.)
    Z = raw.sum(); prob = raw/Z
    mean = np.sum(prob*E); m2 = np.sum(prob*E*E)
    # a_i=(-1,0),(0,0),(1,0) in the eigensystem returned above.
    G = np.stack([np.roll(prob,int(e),axis=0) for e in energies],axis=-1)
    reachable = np.any(G > 0,axis=-1)
    Et,ut,G = E[reachable],u[reachable],G[reachable]
    a = np.empty((len(Et),4,3))
    min_ratio = 1.
    for alpha in range(4):
        pe,dpe = profile(Et-flocal[alpha],W)
        ce = pe-c1local[alpha]*dpe
        assert np.min(ce) > 0
        min_ratio = min(min_ratio,float(np.min(ce/pe)))
        transverse_shift = perp[1] if flocal[alpha] > 0 else 0.
        ge = 1/(1+((ut-transverse_shift)/transverse)**2)**2
        a[:,alpha,:] = np.sqrt(ce*ge)[:,None]*K[alpha]
    L = np.einsum('nai,naj->nij',a,a)
    vals,vecs = np.linalg.eigh(L)
    assert np.min(vals) > 0
    inv = (vecs/np.sqrt(vals)[:,None,:]) @ vecs.transpose(0,2,1)
    iso = a @ inv
    row = iso*np.sqrt(G)[:,None,:]
    effects = np.einsum('nai,naj->aij',row,row)
    tp = np.linalg.norm(effects.sum(axis=0)-np.eye(3),ord=2)
    assert tp < 2e-10
    # An intentionally reversed noncommuting Gram order must fail TP.
    wrong = (a*np.sqrt(G)[:,None,:]) @ inv
    wrong_effects = np.einsum('nai,naj->aij',wrong,wrong)
    wrong_tp = np.linalg.norm(wrong_effects.sum(axis=0)-np.eye(3),ord=2)
    return effects, {"finite_clock_dimension":int(np.count_nonzero(occupied)),
                     "sectors":len(Et), "mass":float(Z), "qfi":float(4*(m2-mean*mean)),
                     "tp_residual":float(tp), "min_C_over_p":min_ratio,
                     "wrong_order_tp_residual":float(wrong_tp),
                     "wrong_order_detectable_in_this_case":bool(wrong_tp > 1e-6)}


def choi(effects):
    J = np.zeros((12,12))
    for a in range(4):
        for i in range(3):
            for j in range(3):
                J[4*i+a,4*j+a] = effects[a,j,i]
    return J


def channel_error(effects):
    import cvxpy as cp
    target,actual = choi(target_effects),choi(effects)
    # Remove the target Choi nullspace analytically. The unreduced block
    # formulation has forced zero eigenvalues and produced inaccurate-status
    # solves. B has full column rank and B B^T is the target Choi matrix.
    B = np.zeros((12,4))
    for a in range(4):
        B[a::4,a] = K[a]
    assert np.max(np.abs(B@B.T-target)) < 1e-14
    Z = cp.Variable((4,12))
    X = B@Z
    fmin = cp.Variable()
    tr = cp.bmat([[sum(X[4*i+a,4*j+a] for a in range(4)) for j in range(3)] for i in range(3)])
    constraints = [cp.bmat([[np.eye(4),Z],[Z.T,actual]]) >> 0,
                   (tr+tr.T)/2-fmin*np.eye(3) >> 0, fmin <= 1]
    prob = cp.Problem(cp.Maximize(fmin),constraints)
    prob.solve(solver='CLARABEL',tol_gap_abs=2e-8,tol_feas=2e-8,tol_gap_rel=2e-8,max_iter=200)
    assert prob.status in ('optimal','optimal_inaccurate')
    return {"minimum_root_fidelity":float(fmin.value),
            "purified_channel_error_numeric":float(math.sqrt(max(0,1-fmin.value**2))),
            "solver_status":prob.status,
            "rigorous_interval_certificate":False}


def main():
    result = {"kind":"intrinsic numerical controls, not independent review",
              "exact":exact_control(), "gibbs_gap":gap,
              "gibbs_residual":float(np.max(np.abs(out-beta_gibbs))), "cases":[]}
    # The GP example's sector Grams commute. Use a distinct Hamiltonian
    # assignment to test the genuinely noncommuting interface. It remains
    # a valid channel implementation control, but is not claimed to be GP.
    _,control = fibre(6.,36.,(.37,.61),output_energies=np.roll(f,1))
    assert control['wrong_order_detectable_in_this_case']
    result['noncommuting_control_not_GP'] = control
    for W in (4.,8.,12.):
        branches = [fibre(W,W*W,s) for s in ((.25,.25),(.25,.75),(.75,.25),(.75,.75))]
        # Truncated masses give a legitimate finite flagged mixture. They
        # approximate, but do not assert equality with, the continuum weights.
        weights = np.array([meta['mass'] for _,meta in branches]); weights /= weights.sum()
        effects = sum(w*e for w,(e,_) in zip(weights,branches))
        case = {"W":W,"transverse_width":W*W,
                "finite_mixture_weights":weights.tolist(),
                "resource_qfi":float(sum(w*m['qfi'] for w,(_,m) in zip(weights,branches))),
                "branches":[m for _,m in branches], **channel_error(effects)}
        result['cases'].append(case)
        print(json.dumps({k:v for k,v in case.items() if k != 'branches'}),flush=True)
    (HERE/'finite-construction-check.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__ == '__main__':
    main()
