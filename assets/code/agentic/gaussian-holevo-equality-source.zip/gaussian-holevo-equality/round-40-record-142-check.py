from fractions import Fraction as Q
v=Q(1); x=Q(1,4); y=1/(4*x)
s=v*v-Q(1,4); t=v*v+Q(1,4)
a=Q(41,9); h=x+y; e=x-y; m=a*h-e
assert a>t/s
print('a =',a,'> t/s =',t/s,':',a>t/s)
z=t*h+a*s*e+v
assert z==0
print('th+ase+v =',z,'= 0')
W11=m*m; W22=Q(1)
CG=e*e*s+h*h*t+v*h+t+v*h
Y=h/m
CH=W11*(s-2*a*s*Y+(t+a*a*s)*Y*Y)+t+2*m*v*Y
assert CG==CH==Q(49,8)
print('CG =',CG,'; CH =',CH,'; gap =',CG-CH)
assert W22/W11==1/(m*m)
print('W22/W11 =',W22/W11,'= m^-2')