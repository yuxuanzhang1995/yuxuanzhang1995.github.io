# General exact work: separating the target cost from its support barrier

24 November 2026. Same-root analytic candidate, not independently reviewed.
This is a structural reduction for every finite covariant channel, not an
evaluated formula for arbitrary input data and not a full Q117 solution.
Normal countable Gibbs baths, beta>0, exactly sharp battery, no other free
resource. All quantities refer to fixed A,B,H_A,H_B.

Use the predecessor's finite Gibbs dilations V:A E -> B F with energy
shift delta, and its indices c_beta(V), c_all(V). For a covariant channel
Phi define

    b(Phi)=inf_V exp(beta c_beta(V)),

where V implements Phi exactly. Let S be its minimal Kraus support. Define

    s(S)=inf {c_all(V): support(Psi_V) subset S}.

The infimum only uses finite covariant Gibbs dilations. Then

    W_0(Phi)=max{beta^(-1) log b(Phi), s(S)}.                (1)

The novelty candidate here is the separation and energy-ordering argument,
not the inherited operational identity W_0=inf c_all. The support barrier
s(S) is still an optimization. No finite ancillary bound is asserted.

## 1. Convexity and relative-interior continuity of b

Direct sums of finite Gibbs dilations, with energy offsets that give their
specified Gibbs weights, implement exact convex mixtures and satisfy

    exp(beta c_beta(V_mix))=sum_i p_i exp(beta c_beta(V_i)).

Thus b is convex. It is finite and uniformly bounded on all covariant
channels: a one-dimensional initial environment and a minimal covariant
Stinespring dilation give a bound using only the finite set of system Bohr
frequencies and d_A d_B possible Kraus operators. Also b>=1 by isometry.

The set C_S of covariant TP channels supported in S is a finite-dimensional
compact convex set. Phi has a strictly positive Choi matrix on S, so it is
in the relative interior of C_S. A finite convex function is continuous on
that relative interior. For every Psi in C_S, therefore, for sufficiently
small t>0,

    Phi_t=(Phi-t Psi)/(1-t) in C_S, and b(Phi_t)->b(Phi).    (2)

This is exact Choi positivity, not an approximate channel correction.

## 2. Energy separation lemma

Let V_0,V_1 implement Psi_0,Psi_1. Fix positive mixture weights p_0,p_1.
For every eta>0 there is a finite exact Gibbs dilation of
p_0 Psi_0+p_1 Psi_1 with

 c_all <= max{ beta^(-1) log[p_0 exp(beta c_beta(V_0))
                             +p_1 exp(beta c_beta(V_1))],
               c_all(V_0) } + eta.                       (3)

To prove this, shift final environment energies so both dilations have
common logical shift zero. Denote their finite input/output partition
functions by a_i(u),b_i(u); their ratios include the common system factor:

    R_i(u)=Z_B(u)b_i(u)/[Z_A(u)a_i(u)].

Keep block 0 fixed, replicate block 1 N times, and shift both its initial
and final environment energies upward by L_N, choosing

    N exp(-beta L_N)a_1(beta)/a_0(beta)=p_1/p_0.

Thus L_N grows as log(N)/beta and the channel weights remain exactly
p_0,p_1. At u>=beta the combined ratio is the convex average of R_0(u)
and R_1(u), with weight

    w_N(u)= N exp(-u L_N)a_1(u)
             /[a_0(u)+N exp(-u L_N)a_1(u)]

on block 1. Once L_N puts every block-1 input energy above every block-0
input energy, w_N(u) is nonincreasing, with w_N(beta)=p_1.

Fix a small h>0. On [beta,beta+h], uniform continuity of the two finite
ratios bounds their weighted average, up to an arbitrarily small error,
by max{R_0(beta), p_0 R_0(beta)+p_1 R_1(beta)}. Both ratios are at least
one, because they come from isometries. Division by u>=beta preserves the
required upper bound after applying logarithms.

On [beta+h,infinity), w_N decays uniformly exponentially in u L_N after
accounting for the finitely many fixed energy slopes in a_i,b_i. More
explicitly R_mix/R_0 <= 1+N exp[-u(L_N-C)] C' for fixed C,C'; hence its
logarithm divided by u tends uniformly to zero on this interval. The
remaining term is log R_0(u)/u <= c_all(V_0). Choose h first, then N.
This proves (3). Arbitrary real offsets and finite integer replications
are allowed; no irrational probability is approximated.

## 3. Proof of the separation formula

The lower bound follows from c_beta<=c_all and from Phi itself belonging
to C_S. For the upper bound choose a finite seed dilation V_0 with channel
Psi in C_S and c_all(V_0) within eta of s(S). Use (2) and a dilation V_1
of Phi_t whose beta index approaches b(Phi_t). Their mixture with weights
t,1-t implements Phi EXACTLY. Apply (3), then send t and eta to zero.
The beta-average tends to b(Phi), whereas the seed bound tends to s(S).
The predecessor's normal-bath construction implements every work strictly
above the resulting index. Equality of infima gives (1).

## 4. Consequences and limits

- W_0 is continuous on the relative interior of each fixed covariant Choi
  face C_S: s(S) is fixed there and b is continuous. Finite-bath attainment
  and zero-work optimizer existence are separate questions.
- The all-temperature obstruction can depend on support even when the
  target's beta index is much smaller. For a CPTP-extreme covariant target
  the face is a singleton, recovering the inherited possible jump.
- If C_S contains a channel of arbitrarily small exact work cost, then
  s(S)=0 and W_0=log b/beta throughout its relative interior. In particular,
  a full-support face contains the free Gibbs replacement channel.
- This does not imply that all full-Choi-rank GP channels have zero work:
  the finite-factorization beta cost b can still exceed one.
- The small-error limit can approach through larger Choi supports and is
  not automatically equal to b(Phi) at a boundary point. No global lower
  semicontinuity or finite matrix-size bound is assumed.
