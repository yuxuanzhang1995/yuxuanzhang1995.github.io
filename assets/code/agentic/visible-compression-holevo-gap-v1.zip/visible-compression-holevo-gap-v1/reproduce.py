"""Verify release hashes and run the bounded, offline diagnostic checks."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for r in manifest['files']:
    p=root/r['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
with tempfile.TemporaryDirectory(prefix='visible-holevo-replay-') as td:
    out=Path(td)/'numerical.json'
    p=subprocess.run([sys.executable,str(root/'checks/q101_checks.py'),str(out)],
                     cwd=td,check=True,text=True,capture_output=True,timeout=120)
    actual=json.loads(out.read_text())
    assert actual==json.loads((root/'checks/q101-checks.json').read_text())
    p=subprocess.run([sys.executable,str(root/'checks/exact_tensor_audit.py')],
                     cwd=td,check=True,text=True,capture_output=True,timeout=120)
    exact=json.loads(p.stdout)
    assert exact==json.loads((root/'checks/exact-tensor-audit.json').read_text())
print(json.dumps({'status':'pass','hashed_files':len(manifest['files']),
    'pauli_basis_cases':len(actual['moment_cases']),
    'arbitrary_decoder_cases':len(actual['decoder_cases']),
    'original_mutations_caught':len(actual['mutations']),
    'exact_collective_channel_labels':exact['labels_enumerated'],
    'additional_mutations_caught':len(exact['mutations_caught']),
    'scope':'finite diagnostic replay, not a proof of the arbitrary-blocklength theorem',
    'review':'sequential internal; no independent expert review'},indent=2))
