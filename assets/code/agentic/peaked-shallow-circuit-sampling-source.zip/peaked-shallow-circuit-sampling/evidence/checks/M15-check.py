from fractions import Fraction as Q
from itertools import combinations
import json,sys

N=8; FULL=(1<<N)-1
state=[Q(0)]*(1<<N);state[0]=Q(1)
cones=[1<<i for i in range(N)]
def rotation(i,t):
 c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
 for x in range(1<<N):
  if not x>>i&1:
   y=x^(1<<i);a,b=state[x],state[y]
   state[x]=c*a-s*b;state[y]=s*a+c*b
def cnot(i,j):
 for x in range(1<<N):
  if x>>i&1 and not x>>j&1:
   y=x^(1<<j);state[x],state[y]=state[y],state[x]
 u=cones[i]|cones[j];cones[i]=cones[j]=u
for i,t in enumerate([5,7,11,13,17,19,23,29]):rotation(i,Q(1,t))
for i in range(0,N,2):cnot(i,i+1)
for i in range(1,N-1,2):cnot(i,i+1)
for i in range(0,N,2):rotation(i,Q(1,31+i))
prob=[x*x for x in state];mode='noncommuting rational circuit'
if '--parity' in sys.argv:
 # Exact output law of the R26 commuting-XX path: boundary of independent
 # Bernoulli edges, with forbidden odd-parity outputs. This is a second,
 # distinct control for the difference between moment and output factorization.
 prob=[Q(0)]*(1<<N);p=Q(1,101)
 for edges in range(1<<(N-1)):
  x=edges^(edges<<1)
  prob[x]+=p**edges.bit_count()*(1-p)**(N-1-edges.bit_count())
 cones=[(1<<(i-1) if i>0 else 0)|(1<<i if i<N-1 else 0) for i in range(N)]
 mode='commuting XX path / hidden-edge parity law'
 assert all(prob[x]==0 for x in range(1<<N) if x.bit_count()%2)
assert sum(prob)==1
adj=[sum(1<<j for j in range(N) if i!=j and cones[i]&cones[j]) for i in range(N)]
def submasks(m):
 s=m
 while True:
  yield s
  if not s:break
  s=(s-1)&m
def neigh(m):
 z=m
 for i in range(N):
  if m>>i&1:z|=adj[i]
 return z
def components(m):
 out=[]
 while m:
  c=m&-m
  while True:
   d=neigh(c)&m
   if d==c:break
   c=d
  out.append(c);m^=c
 return out
def rooted(m,roots):return all(neigh(c)&roots for c in components(m))
mu=[sum(prob[x] for x in range(1<<N) if x&s==s) for s in range(1<<N)]
zero=[sum(prob[x] for x in range(1<<N) if x&s==0) for s in range(1<<N)]
for s in range(1<<N):
 p=Q(1)
 for c in components(s):p*=mu[c]
 assert mu[s]==p

def coeff_log(a,r):
 # derivative identity f'=Z'/Z, exact rationals
 f=[Q(0)]*(r+1)
 for n in range(1,r+1):
  f[n]=(n*a[n]-sum(k*f[k]*a[n-k] for k in range(1,n)))/n
 return f
logs=[]
for m in range(1<<N):
 a=[Q(0)]*(N+1)
 for s in submasks(m):a[s.bit_count()]+=(-1)**s.bit_count()*mu[s]
 logs.append(coeff_log(a,N))
connected_coeff=[Q(0)]*(N+1);disconnected_checks=0
for m in range(1,1<<N):
 for j in range(1,N+1):
  v=sum((-1)**(m.bit_count()-s.bit_count())*logs[s][j] for s in submasks(m))
  if len(components(m))>1 or m.bit_count()>j:
   assert v==0;disconnected_checks+=1
  else:connected_coeff[j]+=v
assert connected_coeff==logs[FULL]

def enc(x):return str(x)
rows=[];identity_cases=0;proposal_cases=0
for H in [0,(1<<1)|(1<<6),FULL]:
 good=FULL^H
 # Cached mixed local moments; arbitrary H pattern is always completely specified.
 mixed={(u,D):sum(prob[x] for x in range(1<<N) if x&H==u and x&D==D)
        for u in submasks(H) for D in submasks(good)}
 exact_by_T={}
 for u in submasks(H):
  for S in submasks(good):
   B=H|S;terms=[]
   for T in submasks(good^S):
    if rooted(T,B):
     a=FULL^neigh(B|T)
     terms.append((T,(-1)**T.bit_count()*mixed[u,S|T]*zero[a]))
   value=sum(v for _,v in terms)
   assert value==prob[u|S];identity_cases+=1
   exact_by_T[u,S]=terms
 Wmom={a:sum(prob[x]*a**((x&good).bit_count()) for x in range(1<<N)) for a in [2,3,5]}
 for a in [2,3,5]:assert Wmom[a]==sum((a-1)**D.bit_count()*mu[D] for D in submasks(good))
 tailrows=[]
 for R in [0,1,2,3,8]:
  l1=sum(abs(prob[u|S]-sum(v for T,v in terms if T.bit_count()<=R)) for (u,S),terms in exact_by_T.items())
  combinatorial=sum(2**D.bit_count()*mu[D] for D in submasks(good) if D.bit_count()>R)
  moment=Q(1,2**R)*Wmom[5]
  assert l1<=combinatorial<=moment
  tailrows.append({'R':R,'L1':enc(l1),'regrouped_bound':enc(combinatorial),'moment_bound':enc(moment)})
 # Deliberately perturb each good-zero expression by a different relative sign.
 eta=Q(1,101);perturbed={}
 for (u,S),terms in exact_by_T.items():
  B=H|S
  perturbed[u,S]=sum(v*(1+eta*(-1)**((FULL^neigh(B|T)).bit_count())) for T,v in terms)
 perturb_l1=sum(abs(perturbed[u,S]-prob[u|S]) for u,S in perturbed)
 assert perturb_l1<=eta*Wmom[3]
 # Full-sized finite proposal list verifies all identities without asymptotic truncation.
 cores=[(J,D) for J in submasks(H) for D in submasks(good) if rooted(D,H)]
 polymers=[C for C in submasks(good) if C and len(components(C))==1]
 M=len(cores)+len(polymers)+1
 nu=Q(1,1<<((32*M).bit_length()-1))
 assert Q(1,32*M)<=nu<=Q(1,16*M)
 def upper(v):return nu*(v//nu+2)
 acore={(J,D):upper(mu[J|D]) for J,D in cores}
 apoly={C:upper(mu[C]) for C in polymers}
 assert all(nu<=a and a>=mu[J|D] and a<=mu[J|D]+3*nu for (J,D),a in acore.items())
 assert all(nu<=a and a>=mu[C] and a<=mu[C]+3*nu for C,a in apoly.items())
 A=sum(acore.values());Qprod=Q(1)
 for a in apoly.values():Qprod*=1+a
 normalizer=A*Qprod
 reconstructed=[Q(0)]*(1<<N);signed_reconstructed=[Q(0)]*(1<<N)
 valid_weight=Q(0)
 for J in submasks(H):
  for S in submasks(good):
   comps=components(S);D=0;active=[]
   for C in comps:
    if neigh(C)&H:D|=C
    else:active.append(C)
   assert (J,D) in acore
   assert all(not(C&neigh(H|D)) for C in active)
   assert all(not(c&neigh(d)) for c,d in combinations(active,2))
   # Every alternative legal core subset must equal the canonical D.
   alternatives=[]
   for D2 in submasks(S):
    if not rooted(D2,H):continue
    rest=components(S^D2)
    if all(not(c&neigh(H|D2)) for c in rest):alternatives.append(D2)
   assert alternatives==[D]
   moment=mu[J|D];w=acore[J,D]
   for C in active:moment*=mu[C];w*=apoly[C]
   assert moment==mu[J|S] and w>=moment>=prob[J|S]
   # Independent inactive Bernoullis all contribute the common product denominator.
   proposal=acore[J,D]/A
   for C,a in apoly.items():proposal*=a/(1+a) if C in active else 1/(1+a)
   assert proposal==w/normalizer
   reconstructed[J|S]=normalizer*proposal*(prob[J|S]/w)
   value=perturbed[J,S];clipped=max(Q(0),min(w,value))
   assert abs(clipped-prob[J|S])<=abs(value-prob[J|S])
   signed_reconstructed[J|S]=clipped
   valid_weight+=w;proposal_cases+=1
 assert reconstructed==prob
 z=sum(signed_reconstructed);tv=sum(abs(x/z-y) for x,y in zip(signed_reconstructed,prob))/2
 l1=sum(abs(x-y) for x,y in zip(signed_reconstructed,prob))
 assert tv<=l1<=eta*Wmom[3]
 rows.append({'H_mask':H,'rooted_identity_outputs':len(exact_by_T),'core_count':len(cores),
              'polymer_count':len(polymers),'Lambda':enc(sum(mu[C] for C in polymers)),
              'normalizer_bits':normalizer.numerator.bit_length()+normalizer.denominator.bit_length(),
              'exact_acceptance_normalization':'1/Kprop','unique_representation':True,
              'all_output_acceptance_law_exact':True,'relative_zero_perturbation_L1':enc(perturb_l1),
              'relative_zero_perturbation_bound':enc(eta*Wmom[3]),'clipped_normalized_TV':enc(tv),
              'truncation_checks':tailrows})

print(json.dumps({'status':'PASS','arithmetic':'Exact rational state amplitudes, probabilities, moments, formal logarithms and proposal laws',
 'circuit':{'qubits':N,'model':mode,'depth':2 if '--parity' in sys.argv else 4,'gates':'Commuting XX path' if '--parity' in sys.argv else 'Rational real rotations, two staggered CNOT layers, final noncommuting rotations',
 'backward_cones':cones,'dependency_adjacency':adj},'moment_component_factorizations':1<<N,
 'connected_log_coefficient_checks':N*((1<<N)-1),'vanishing_support_checks':disconnected_checks,
 'rooted_identity_outputs':identity_cases,'unique_proposal_outputs':proposal_cases,'rows':rows,
 'scope':'Finite exact mechanism controls. Conservative delta regime and polynomial complexity are proved analytically, not inferred from this finite circuit.'},indent=2))
