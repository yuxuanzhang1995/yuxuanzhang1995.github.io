"""Separately implemented exact-arithmetic audit; not independent expert review.

Uses a complex rational Householder isometry, forms the channel on matrix
units, and forms partial Choi matrices from those blocks. No candidate code
is imported. All 36 two-qubit label strings are enumerated symbolically.
"""
from itertools import product
from pathlib import Path
import json
import sympy as s

I = s.I
eye = s.eye(2)
paulis = [s.Matrix([[0, 1], [1, 0]]),
          s.Matrix([[0, -I], [I, 0]]), s.diag(1, -1)]
qs = [(eye + b*p)/2 for p in paulis for b in [-1, 1]]
m, D, n, env = 3, 2, 2, 2
v = s.Matrix([1, 2+I, -1+2*I, 3, -2-I, 1-3*I, 2, 1+I])
H = (s.eye(8) - 2*v*v.H/s.expand((v.H*v)[0])).applyfunc(s.expand)
V = H[:, :m]
assert s.expand(V.H*V) == s.eye(m)
K = [V.extract([b*env+e for b in range(D**n)], range(m))
     for e in range(env)]
def channel(A):
    return s.expand(sum((k*A*k.H for k in K), s.zeros(D**n)))
def adjoint(A):
    return s.expand(sum((k.H*A*k for k in K), s.zeros(m)))
def unit(a,b):
    z=s.zeros(m); z[a,b]=1
    return z
blocks = {(a,b):channel(unit(a,b)) for a,b in product(range(m),repeat=2)}
def reduce(A, sites):
    if len(sites)==2: return A
    if not sites: return s.Matrix([[s.trace(A)]])
    if sites==[0]:
        return s.Matrix(D,D,lambda i,j:sum(A[i*D+k,j*D+k] for k in range(D)))
    return s.Matrix(D,D,lambda i,j:sum(A[k*D+i,k*D+j] for k in range(D)))
purities={}
for mask in range(4):
    sites=[j for j in range(n) if (mask>>j)&1]
    d=D**len(sites)
    J=s.BlockMatrix([[reduce(blocks[a,b],sites) for b in range(m)]
                     for a in range(m)]).as_explicit()
    marg=s.Matrix(m,m,lambda a,b:sum(J[a*d+i,b*d+i] for i in range(d)))
    assert marg == s.eye(m)
    assert J == J.H
    purity=s.expand(s.trace(J*J))
    assert purity <= min(m*m,m*d)
    purities[mask]=purity
moment=s.Rational(0)
for q1,q2 in product(qs,repeat=2):
    A=adjoint(s.kronecker_product(q1,q2))
    moment+=s.expand(s.trace(A*A))/36
a=s.Rational(D*D-2,4*(D*D-1)); c=s.Rational(D,4*(D*D-1))
rhs=sum(a**(n-mask.bit_count())*c**mask.bit_count()*p
        for mask,p in purities.items())
assert s.expand(moment-rhs)==0
wrong_transpose=s.Rational(0)
for q1,q2 in product(qs,repeat=2):
    A=adjoint(s.kronecker_product(q1,q2))
    wrong_transpose+=s.expand(s.trace(A*A.T))/36
assert s.expand(wrong_transpose-moment)!=0
assert s.expand(moment-(rhs-a*a*m))!=0
# Exact strictness of the published four-qubit rate bound.
assert s.Rational(16*16-2,4*(16*16-1))+4*s.Rational(16,4*(16*16-1))==s.Rational(53,170)
assert 8*53**2<170**2
report={"status":"pass", "review_independence":"same agent, separate implementation",
        "arithmetic":"exact Gaussian rational", "labels_enumerated":36,
        "input_dimension":m, "output_sites":[2,2], "environment_dimension":env,
        "partial_choi_purities":{str(k):str(v) for k,v in purities.items()},
        "direct_moment":str(s.expand(moment)), "choi_moment":str(s.expand(rhs)),
        "mutations_caught":["transpose in place of adjoint in Hilbert-Schmidt contraction",
                            "omission of empty-subset contribution"],
        "four_qubit_strict_gap_integer_margin":170**2-8*53**2}
print(json.dumps(report,indent=2))
