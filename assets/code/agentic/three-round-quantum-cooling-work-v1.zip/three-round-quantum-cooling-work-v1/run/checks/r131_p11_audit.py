"""Distinct same-agent checks of quotient coverage, legal controls, and signs."""
from pathlib import Path
import itertools,json,time
import numpy as np
from r131_p11_complete_suffix import BASISI,OLDI,YI,poly,I,pi,bi,blocks,E,qi,ZI
from p11_free_pulses_common import total

def direct_relaxation(N,paid,tilt):
    rho=[poly(row,BASISI) for row in N];z=I(str(tilt))
    spec=[a*b for a in rho for b in bi]
    obs=[YI[s]-z*(int(E[s])+r) for s in range(6) for r in range(3)]
    sl=sorted(x.a for x in spec);sh=sorted(x.b for x in spec)
    ol=sorted(x.a for x in obs);oh=sorted(x.b for x in obs)
    reward=sum((I(a,b)*I(c,d) for a,b,c,d in zip(sl,sh,ol,oh)),I(0))
    return reward+z*(sum(int(e)*a for e,a in zip(E,rho))+sum(r*bi[r] for r in range(3)))-paid-sum(y*p for y,p in zip(YI,pi))

def full_raw_coverage(f,expected):
    N=np.array(f['post_V2_coefficients'],dtype=np.int16)
    incoming=np.zeros((18,8),dtype=np.int16)
    for s in range(6):
        for r in range(3):incoming[3*s+r,r:r+6]=N[s]
    permutations=[np.array(list(itertools.permutations(B.tolist()))) for B in blocks]
    indices=np.indices(tuple(len(P) for P in permutations)).reshape(6,-1).T
    raw=np.zeros((len(indices),6,8),dtype=np.int16)
    # Independent destination-to-source construction, no equal-input quotient.
    for k,(B,P) in enumerate(zip(blocks,permutations)):
        for j,dest in enumerate(B):raw[:,dest//3]+=incoming[P[indices[:,k],j]]
    distinct=np.unique(raw.reshape(len(raw),48),axis=0)
    assert np.array_equal(distinct,expected.reshape(len(expected),48))
    return dict(frontier=f['id'],raw_permutations=len(raw),distinct_states=len(distinct))

if __name__=='__main__':
    start=time.time();fs=json.loads(Path('run/checks/r130_p11_frontier.result.json').read_text())['frontier']
    prefixes=json.loads(Path('run/checks/r126_prefix_certificate.result.json').read_text())
    screen=np.load('run/checks/r129_second_recharge_screen.npz')
    assert prefixes['representatives']==screen['representatives'].tolist()
    oldbounds=np.load('run/checks/r126_suffix_bound_numerators.npz')
    survivor_ids=set(oldbounds['survivors'].tolist())
    assert {r['state'] for r in prefixes['dominance_mapping']}==survivor_ids
    second=json.loads(Path('run/checks/r130_p11_frontier.result.json').read_text())
    second_bounds=np.load('run/checks/r130_second_recharge_bounds.npz')['upper_numerators']
    second_ids={i for i,v in enumerate(second_bounds) if int(v)>=0}
    expected_pairs={(int(screen['representatives'][i//720]),i%720) for i in second_ids}
    assert {(r['parent_state'],r['permutation_index']) for r in second['symmetry_mapping']}==expected_pairs
    assert {r['frontier'] for r in second['symmetry_mapping']}==set(range(88))
    old=json.loads(Path('run/checks/r125_first_stage.result.json').read_text())['price']
    error=[y-I('.999')*I(str(x)) for x,y in zip(old,YI)]
    oscillation=I(max(v.b for v in error))-I(min(v.a for v in error))
    costs=[]
    for profile in set(itertools.permutations(E.tolist())):
        if profile==tuple(E):continue
        w=sum(int(E[i])*(qi**int(profile[i])/(ZI*(1+qi))-pi[i]) for i in range(6))
        assert w.a>0;costs.append(w)
    transfer=I('.001')*I(min(v.a for v in costs))-oscillation
    assert transfer.a>0
    checked=0;samples=0;min_slack=None
    for f in fs:
        data=np.load(f"run/checks/r131_p11_frontier_{f['id']:02d}.npz")
        N=data['coefficients'];U=data['controls'];before=np.array(f['post_V2_coefficients'],dtype=np.int16)
        assert np.all(np.sort(U,axis=1)==np.arange(18)) and np.all(total[U]==total)
        expected=np.zeros_like(N);rows=np.arange(len(N))
        for src in range(18):
            s,r=divmod(src,3)
            expected[rows,U[:,src]//3,r:r+6]+=before[s]
        assert np.array_equal(expected,N) and np.all(N.sum(axis=2)==9)
        checked+=len(N);paid=poly(f['paid_work_coefficients'],OLDI)
        neg=np.flatnonzero(data['upper_numerators']<0)
        selected={int(neg[np.argmax(data['upper_numerators'][neg])]),int(neg[0]),int(neg[-1])}
        for ix in selected:
            direct=direct_relaxation(N[ix],paid,data['tilts'][data['tilt_indices'][ix]])
            assert direct.b<0
            # Fixed-point upper must dominate a separate high precision upper.
            fixed=I(int(data['upper_numerators'][ix]))/I(2**56)
            assert fixed.a>=direct.b
            slack=fixed.a-direct.b;min_slack=slack if min_slack is None else min(min_slack,slack)
            samples+=1
    data=np.load('run/checks/r131_p11_frontier_67.npz')
    coverage=full_raw_coverage(fs[67],data['coefficients'])
    out=dict(legal_control_and_polynomial_replays=checked,direct_decimal_bound_checks=samples,
        minimum_fixed_point_vs_decimal_slack=str(min_slack),full_permutation_coverage_control=coverage,
        price_transfer_margin=transfer.pair(),price_identity=False,
        price_transfer='R125 to R127: .999 scaling plus bounded decimal oscillation, R128 lemma replayed',
        inherited_prefix_and_frontier_coverage_interfaces_checked=True,
        seconds=time.time()-start,reviewer_relation='same_agent',
        scope='Verification supporting the candidate; no independent reviewer or novelty judgment')
    Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)
