# Work when the thermal operation is closed before testing the battery

The catalog defines its processor by a Gibbs ancilla and an energy-conserving unitary. Its cited paper also discusses the norm closure of these operations, immediately after Eq. (S.16). These two orders of imposing an exact battery endpoint can give different one-shot costs. Here the entire process, including its battery input and output, is a limit of finite thermal operations at a **fixed battery gap**. Only the limiting channel must return the prescribed pure eigenstate. Use positive finite inverse temperature \(\beta\), a fixed physical total Hamiltonian as in (S.16), and any finite input and output systems. [Catalog statement](https://qiqc-op.com/problem/op_56578531a2c610fe/) · [Tajima and Takagi, supplement](https://arxiv.org/pdf/2404.03479)

Let \(C\) be the covariant channels in the closed system-error ball and let \(b(T)\) be the exponentiated single-\(\beta\) finite-logical-isometry index of [the exact-unitary work theorem](work-lower-witnesses.md). Take its lower-semicontinuous envelope \(\bar b_{\mathrm{all}}\) on the *whole* compact convex set of covariant channels. Use \(S_{\mathrm{all}}=\mathcal L(A,B)\) in the graded matrix inequalities (1)–(2) of that theorem. Then the work infimum equals \(+\infty\) for \(C=\varnothing\), and otherwise
\[
 W_\epsilon^{\rm closed}(\Phi)
 =\frac1\beta\log\min_{T\in C}\bar b_{\mathrm{all}}(T)
 =\frac1\beta\log\sup_{H\in\mathcal H_\beta(S_{\mathrm{all}})}
                       \min_{T\in C}\langle H,T\rangle .                         \tag{1}
\]
The covariant set is compact, and the pure battery endpoints are stationary. This proves the empty-set assertion. The affine-minorant and minimax argument in F32 on the whole covariant face gives the second equality. The first uses the following physical estimates.

## Converting an almost-certain battery transition into a logical isometry

Fix a finite thermal operation with initial battery vector at energy \(w_i\), intended final vector at \(w_f\), and \(W=w_i-w_f\). Collect all input Gibbs systems into \(E\), all discarded systems into \(F\), and write \(Z_A Z_E=Z_B Z_F\). This follows from the common total nonbattery Hamiltonian. Take the block \(M=\langle w_f|U|w_i\rangle:AE\to BF\) of the full unitary. On each input total-energy eigenspace at \(g\) it is a contraction \(M_g\) to energy \(g+W\). Denote the respective sector dimensions by \(d_g,r_g\) and let \(\delta\) be the failure probability on the physical Gibbs input \(\gamma_A\otimes\gamma_E\):
\[
 Z_A Z_E\delta=\sum_g e^{-\beta g}(d_g-\operatorname{Tr}M_g^*M_g).
\]
Both \((d_g-r_g)_+\) and \(\sum_{i=1}^{d_g}(1-s_i(M_g))^2\), with missing singular values set to zero, are bounded by the summand in parentheses.

Choose one output system energy \(f_*\). Enlarge *only the logical output environment* by \((d_g-r_g)_+\) fresh vectors of energy \(g+W-f_*\) for each occupied \(g\). They supply at least the missing dimensions using the selected system eigenvector. Extra output dimensions produced at other system energies can remain unused. Pad the polar partial isometry to a genuine isometry \(V_g\) on each whole input sector, agreeing with the polar factor on its nonzero singular directions. Consequently
\[
 \operatorname{Tr}\big[(V-M)^*(V-M)(\gamma_A\otimes\gamma_E)\big]\le\delta ,
 \qquad
 e^{\beta c_\beta(V)}
 =e^{\beta W}\frac{Z_B Z_{F_{\rm new}}}{Z_A Z_E}
 \le e^{\beta W} + Z_B e^{\beta f_*}\delta .                            \tag{2}
\]
The second bound follows by summing the Gibbs weights of the fresh vectors. No worst-case minimum singular value or dimension bound for a bath shell is needed.

To compare system channels, purify \(\gamma_E\) and use the same purification in the two dilations. Embed \(V\) with the success battery and the old physical output with its mutually orthogonal success and failure vectors in a common enlarged space. Their squared norm on a purified \(\gamma_A\) is at most \(2\delta\), using (2) and the actual failure probability. For any input with reference, the squared norm is at most \(2\delta/\lambda_{\min}(\gamma_A)\), since its input marginal is bounded by \(I_A\le\gamma_A/\lambda_{\min}(\gamma_A)\). This bounds purified channel distance by the square root of that expression. For any approximating sequence with a limiting sharp endpoint, \(\delta\to0\); the finite logical channels converge to the limiting system channel \(T\). Taking the lower envelope in (2) gives \(\bar b_{\mathrm{all}}(T)\le e^{\beta W}\). This direction would fail if a projection onto the success battery were used as a trace-preserving operation by itself.

## Approximating at a fixed gap

For any covariant \(T\) choose finite logical channels \(T_n\to T\) with \(b(T_n)\to\bar b_{\mathrm{all}}(T)\), as permitted by the envelope. Mix \(T_n\) with a vanishing positive fraction of the full-rank, free Gibbs replacement channel \(D(\rho)=\operatorname{Tr}(\rho)\gamma_B\). The resulting channel \(P_n\) has full Choi support for every \(n\). Convexity gives \(\limsup b(P_n)\le\bar b_{\mathrm{all}}(T)\). On full support the support barrier of F32 is zero since \(D\) itself is free, so the exact normal-bath work infimum for \(P_n\) is \(\beta^{-1}\log b(P_n)\). The construction implementing any finite logical dilation at every gap strictly above its all-temperature index shows that *one fixed* \(W>\beta^{-1}\log\bar b_{\mathrm{all}}(T)\) works physically for every sufficiently large \(n\). The strictly sharp normal protocols use a finite two-level battery with these same energies.

Each such protocol can itself be approximated on the entire finite system and battery by finite thermal operations. In the spectator realization, let \(h\) be the spectral width of all finite systems participating in the unitary, other than the normal bath. Keep every bath level below \(L+h\), append its normalized Gibbs state, prescribe the old unitary on all columns whose bath energy is at most \(L\), and complete it to a unitary sector by sector. The old images of those columns lie in the truncated space by energy conservation. Their conditional channels agree exactly. The omitted Gibbs tail and the change of normalization tend to zero uniformly on inputs. One can equivalently keep the finitely many spectator registers in the fixed width \(h\). All normal protocols needed in the preceding paragraph have this form. In finite dimension the whole channels on the system and bit have a convergent subsequence. Its limit realizes \(T\) and the desired pure battery output even on reference-assisted inputs. The system-error constraint is applied to \(T\) itself, so contact with the boundary of the error ball needs no strict interior. Let \(W\) decrease to the right side of (1).

In particular for a covariant target the cost at zero error in (1) equals \(\lim_{\eta\downarrow0}W_\eta^{\rm normal}(\Phi)\). For the lower inequality use the lower semicontinuity of \(\bar b_{\rm all}\) and the nonnegative support barrier on every approximating actual channel. The full-support sequence in the preceding paragraph supplies the converse. The explicit extreme Gibbs-preserving qutrit example at \(\beta=1\) therefore costs \(\log(529/36)\) in the closed model. In the exactly sharp normal-bath model it costs \(\log16\). With finite baths and actual sharp endpoints it is infeasible. The two numerical values and the small-system-error limit are inherited; (1) identifies which endpoint convention selects the smaller value. [Qutrit construction](work-discontinuity-v1.md) · [Extreme-channel lower bound](work-extreme-approx-general-v3.md)

Coherence has the same value under the two process conventions: a limit processor on finite system and finite resource is covariant, has a finite covariant Stinespring isometry, and its physical implementation can include all sharp blank registers in the finite QFI resource at zero additional QFI. This equivalence applies to coherence even at zero error. Allowing a failure probability in the *limiting* battery state would be a different specification.
