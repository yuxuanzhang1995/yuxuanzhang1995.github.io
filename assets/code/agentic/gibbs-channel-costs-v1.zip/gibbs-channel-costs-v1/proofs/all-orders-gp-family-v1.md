# Gibbs-preserving channels realizing every finite coherence-divergence order

24 November 2026. Same-root complete family candidate, not a full Q117
solution. For every integer m>=1 this construction gives a finite-system
GP channel with

  F_c^0=+infinity,    F_c^epsilon=Theta(epsilon^(-2/m))

as epsilon decreases to zero. Constants depend on m and the fixed channel;
no uniform-in-dimension estimate is claimed. The m=1 and m=2 exponents
were already present in the predecessor's theory/controls and are not
credited again. The contribution here is an explicit GP realization of
ALL positive integer orders and its transparent moment obstruction.

## 1. Explicit channel and Hamiltonians

Fix beta=log 2. On an output space of dimension m+1 use basis |j>,
j=0,...,m, and define

 H_B=(m/2)I+J_x,
 (J_x)_(j,j+1)=(J_x)_(j+1,j)=sqrt((j+1)(m-j))/2,

with all other entries zero. Its spectrum is {0,1,...,m}: this is the
restriction of sum_l (I+X_l)/2 to the symmetric subspace of m qubits.
Write gamma_B=2^(-H_B)/Z_B. Set L=m+3 and

 a=1/(2+2^L),   H_A=diag(L,L,0),
 gamma_A=diag(a,a,1-2a),
 sigma=[gamma_B-a(|0><0|+|m><m|)]/(1-2a).

Since lambda_min(gamma_B)=1/(2^(m+1)-1) and a<lambda_min/4, sigma is a
strictly positive density matrix. Fix 0<c<1, for example c=1/2. Define

 Phi(rho)=rho_00 |0><0|+rho_11 |m><m|+rho_22 sigma
          +c rho_01 |0><m|+c rho_10 |m><0|.              (1)

Its Choi coefficient matrix in the HS-orthonormal operator basis

 K_0=|0><0|, K_1=|m><1|, K_(a+2)=|a><2| (0<=a<=m)

is T=[[1,c],[c,1]] direct_sum sigma^T, strictly positive. Thus (1) is
completely positive, trace preserving and has minimal Kraus rank m+3.
The definition of sigma gives Phi(gamma_A)=gamma_B exactly.

## 2. The first obstructed moment is exactly m

The symmetric-qubit construction gives the two exact identities

 b_0(u)=<0|exp(u H_B)|0>=<m|exp(u H_B)|m>
                         =[(1+exp(u))/2]^m,
 b_01(u)=<0|exp(u H_B)|m>=[(exp(u)-1)/2]^m.              (2)

In particular <0|H_B^k|m>=0 for k<m and equals m!/2^m for k=m.
For an arbitrary analytic coefficient matrix C(u) with C(0)=T,
the (0,1) input matrix entry of the sector equation is

   b_01(u) C_01(u)=0.                                   (3)

Its first nonzero term is c u^m/2^m. No other coefficient block enters
this equation, so the joint Taylor equations fail at order m regardless
of all earlier derivative choices.

They are feasible through m-1. Put d_A(u)=exp(Lu)/b_0(u),
d_B(u)=1/Tr[sigma exp(u H_B)], and use the analytic matrix with diagonal
blocks d_A(u)I_2 and d_B(u)sigma^T, off-diagonal C_01=C_10=c, and no
other off-block entries. It has C(0)=T. Its diagonal sector equations
are exact, its (0,1) residual is (3), and all other off-diagonal sector
equations vanish. Truncating its Taylor series at m-1 proves feasibility.
Conjugating by T^(-1/2) passes to a normalized minimal Kraus basis and
does not change the first failure order.

The predecessor's finite-order theorem therefore supplies the stated
matching exponent. The next two sections also identify its decisive
lower/upper mechanisms for this family without relying only on its label.

## 3. Direct lower-bound mechanism

Purify any finite resource with its optimized finite purifier, preserving
QFI=4 variance, and center its energy. Project its implemented dilation
onto the fixed Kraus support S. An epsilon-close channel has projected
coefficient measure C(dz) with total C=T+O(epsilon), outside-support
amplitude O(epsilon), and second moment at most C_m(1+F_Q).
These are the support and energy-intertwining estimates proved in
`../Q117-20261124/coherence-theorem.md`, Section 3; bath moments are not
used. Consequently C_hat_01(t)=c+O(epsilon+|t|sqrt(1+F_Q)).

The (0,1) entry of energy intertwining, (2), then forces

  |[(exp(it)-1)/2]^m C_hat_01(t)|<=C'_m epsilon.

Set t=alpha/sqrt(1+F_Q), with alpha small enough that |C_hat_01(t)|>=c/2.
For small epsilon this gives epsilon>=c_m(1+F_Q)^(-m/2), including mixed
resources and every allowed thermal processor. Hence
F_Q>=c'_m epsilon^(-2/m)-1 and exact finite QFI is impossible.

## 4. Direct upper-bound profile

Let p_W be the positive smooth finite-variance profile from the finite
resource lemma, with every fixed derivative bounded by C_l W^(-l)p_W.
For l=0,...,m-1 let a_l=d_A^(l)(0), b_l=d_B^(l)(0). Define

 q_A(E)=sum_(l<m) (-1)^l a_l p_W^(l)(E)/l!,
 q_B(E)=sum_(l<m) (-1)^l b_l p_W^(l)(E)/l!,
 C_W(E)=[[q_A(E),c p_W(E)],[c p_W(E),q_A(E)]]
                                      direct_sum q_B(E)sigma^T.

For all sufficiently large W this matrix is bounded above and below by
positive constants times p_W(E)I, since c<1 and sigma>0. Its integral is
T. The diagonal sector residuals are O(W^(-m))p_W by the reciprocal
Taylor identities. The off-diagonal residual is an mth finite difference
of p_W, by (2), and has the same uniform bound. Sector polar normalization
therefore changes the Stinespring isometry by O(W^(-m)), not its square
root. The finite translated-fibre/truncation lemma gives, for any t>0,
a genuinely finite conserving implementation with

  D_ch<=C_m W^(-m)+t,   F_Q<=C'_m W^2+t.

Choose W proportional to epsilon^(-1/m) and t<epsilon/2. This proves the
matching upper order with finite resources. In this explicit family all
system energies are integers, so a single integer energy lattice suffices;
no irrational-energy approximation is involved.

## Exact finite-resource interpretation and limits

The support is an energy-column support with V_0=span|0>,
V_1=span|m>, and V_2=B. It fails the finite criterion precisely because
the nonzero coefficient c sits at the pair's first nonzero moment m.
Setting c=0 yields a finite measure-and-prepare implementation. For fixed
0<c<1, increasing m makes the positive-error divergence exponent smaller,
but never makes the exact cost finite. This is a structural family, not
a parameter-threshold search and not a second solution of the general
finite-order theorem. Independent proof review and a broader primary-source
novelty comparison remain required before release.
