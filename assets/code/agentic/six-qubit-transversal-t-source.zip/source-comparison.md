# Six-qubit transversal T: source and scope comparison

Prepared 28 September 2026. This is a source comparison for the pending complete-angle candidate, not a correctness verdict, a priority determination, or permission to publish an incomplete proof.

## Exact question

[QIQCOP op_ddfbbe7ca0ead0c8](https://qiqc-op.com/problem/op_ddfbbe7ca0ead0c8/) asks for a genuinely nonadditive rank-two six-qubit code detecting every Pauli of weight at most two, with an exact logical T implemented by a tensor product of six arbitrary single-qubit unitaries. Degeneracy and differing local factors are allowed. No logical X, complementary codewords, prescribed local angles, ancilla, measurement, or code switching is assumed. A proof excluding *all* such rank-two codes would answer this existence question negatively without needing a separate additivity test.

The immutable original is in this round's `datasets/originals.jsonl`. The live problem formulation was checked again on 28 September; the catalog still says unsolved. This source check does not change that status.

## Closest primary sources

**C. Zhang, Z. Wu, S. Huang, and B. Zeng, _Transversal Gates in Nonadditive Quantum Codes_, arXiv:2504.20847v1 (29 April 2025).** [Versioned manuscript](https://arxiv.org/html/2504.20847v1).

Section 6.1 supplies the subset-sum/linear-programming method: impose residue supports, filter them with diagonal Knill–Laflamme equations, then address the remaining quantum equations. This method must be credited prominently. Table 2's unfilled six-qubit cyclic-order-16 entry records numerical non-detection, not an impossibility theorem. Section 6.3.1 constructs seven-qubit distance-three codes with transversal T; Section 4.1 supplies a six-qubit code with projective logical phase order five, which is different from T's order eight. The proposed contribution is a completeness reduction from arbitrary local unitaries, followed by exhaustive exact exclusion for six qubits. It is not the invention of the residue-support or LP filter method.

**X. He, S. Lu, and B. Zeng, _Co-Designing Quantum Codes with Transversal Diagonal Gates via Multi-Agent Systems_, arXiv:2510.20728v3 (6 April 2026).** [Versioned manuscript](https://arxiv.org/html/2510.20728v3).

Section IV and Appendices F–G resolve twelve seven-qubit candidates surviving SSLP in the complementary binary-dihedral setting: ten constructions and two exclusions. That setting imposes complementary logical supports and specified diagonal angles. Its completeness is relative to that ansatz, not the unrestricted six-qubit question. The catalog of 14,116 codes on at most six qubits instead concerns distance two. Both distinctions must be stated when comparing the new candidate. The authors report Lean verification of their accepted results; our current computation has not been formalized in Lean and must not inherit that claim.

## Other background and search limits

The QIQCOP record also cites Knill–Laflamme, the signature-norm work of Du et al., and rational SDP bounds of Anglès Munné–Huber. The proposed exclusion uses the defining error-detection equations directly. It does not invoke a complete classification of six-qubit codes, an impurity assumption, or a signature-norm extremality theorem. Full-text comparison of the two closest construction/classification papers above was performed using the saved primary manuscripts. No assertion is made here that every background reference was freshly read in full.

Focused searches for a six-qubit transversal-T impossibility theorem on 28 September did not locate another full exclusion. Searches also returned constructions using other numbers of qubits or different gate mechanisms; those do not settle this exact statement. Failure to find a result is not evidence establishing priority. Publication, if the candidate passes, should identify it as a computer-assisted proof with reproducible checks and retain this novelty limitation.

## Boundary and attribution control

`independent-boundary-controls.py` reconstructs Zhang et al.'s seven-qubit example at zero free phases and checks all 211 Hermitian Pauli operators of weight at most two exactly. It verifies the stated logical phase and its seventh power implementing T. This guards against confusing the excluded six-qubit case with the known seven-qubit construction. The control is attributed prior work and is not another project result.

## Remaining release gates

The new full candidate must have a complete standalone proof, successful decisive certificates, two distinct frozen reviews, and a reconciled original-statement comparison. Analytic issues include the real-equation rational replacement, odd-factor powering, normalization, low-odd-coefficient reduction, small-support lemma, and complex-amplitude exceptional cases. Computational issues include complete enumeration and the exact signs of every accepted separator. Until those gates pass, the proposed complete exclusion remains an unverified candidate and stays local.
