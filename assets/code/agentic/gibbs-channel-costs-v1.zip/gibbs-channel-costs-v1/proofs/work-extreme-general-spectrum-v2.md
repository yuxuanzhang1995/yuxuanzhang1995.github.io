# Exact extreme-channel work for arbitrary finite spectra

24 November 2026. This version removes the commensurability assumption from
`work-rectangular-commensurate-v1.md`. Same-root proof candidate; independent
review and novelty are unconfirmed. The bath model is a lower-bounded,
countably infinite Hamiltonian with trace-class Gibbs operator at beta>0.
The battery starts and ends in specified pure energy eigenstates for every
input. There are no other nonthermal resources or failure events.

Let Phi:A->B be covariant and extreme in the full CPTP set. Choose minimal
Kraus operators of definite frequency,

    H_B K_alpha-K_alpha H_A=omega_alpha K_alpha.

Then its exact deterministic work infimum is

    W_* = sup_{u>=beta} (1/u) log[Z_B(u) Z_K(u)/Z_A(u)],
    Z_K(u)=sum_alpha exp(u omega_alpha).                (1)

Every W>W_* has an exact implementation. No arithmetic assumption on the
system or battery energies is necessary. The converse is unchanged from
v1: extremality forces mutually orthogonal environment isometries, and
Gibbs-weighted dimension counting at every inverse temperature u>=beta
gives (1). The construction below supplies the missing general upper bound.
For nonextreme covariant channels, (1) is an upper bound only.

## Positive convolution for finite real-energy spectra

Consider a finite signed counting measure

    f=a0 delta_0+sum_j a_j delta_(e_j),
    a0 a positive integer, a_j integers, e_j>0.

Assume its Laplace transform is strictly positive at every u>=beta:

    fhat(u)=a0+sum_j a_j exp(-u e_j)>0.                 (2)

There exists a locally finite positive-integer counting measure R, supported
on nonnegative energies, with finite Gibbs partition at beta, such that
f*R has nonnegative integer multiplicities at every energy.

### Step 1: choose a rational cone around the physical temperature ray

Let Gamma be the finitely generated additive group of the e_j. Choose a
Z-basis of Gamma, giving a vector omega of rationally independent real
frequencies and integer exponent vectors n_j with e_j=n_j dot omega>0.
Define the finite exponential polynomial

    F(y)=a0+sum_j a_j exp(-n_j dot y),  y in R^q.

There is an open, sufficiently narrow cone C around the ray R_+ omega
such that F is positive on beta omega+C, and n_j dot d>0 for every
nonzero d in the closure of C and every j. To see this quantitatively:
for y near u omega with beta<=u<=U, strict positivity follows from the
positive minimum on this compact ray segment and continuity. For u>=U,
all n_j dot y are bounded below by a positive multiple of u if the cone
is narrow enough. The nonconstant terms then tend uniformly to zero and
the constant a0 gives a positive margin. A sufficiently small cone works
for both ranges. This also covers the base point beta omega.

Choose q linearly independent rational vectors d_i in C so that omega is
in the interior of their positive cone. This is possible by a small rational
perturbation of a simplex of rays around omega. Let D have columns d_i.
Then h=D^(-1)omega has strictly positive components, and every vector
D^T n_j has strictly positive rational components. Multiply D by a positive
integer L so all these components become integers. Continue to denote the
scaled matrix by D and set h=D^(-1)omega>0. Thus

    m_j=D^T n_j in Z_(>0)^q,    e_j=m_j dot h.

The h_i remain rationally independent because D is rational and invertible.
Define the ordinary polynomial P(x)=a0+sum_j a_j x^(m_j) and
q_i=exp(-beta h_i), each in (0,1). For 0<x_i<=q_i, put

    -log x=beta h+t, t>=0;
    D(-log x)=beta omega+D t.

Our cone choice implies P(x)>0 throughout this box. On any coordinate face
x_i=0, every nonconstant monomial vanishes because all m_ji>0, so P=a0>0.
Hence P is strictly positive on the entire compact box product [0,q_i].

### Step 2: positive integer coefficients with a convergent Gibbs series

Choose q_i<q'_i<1 sufficiently close that P remains strictly positive on
product [0,q'_i]. Choose c>0 with P-c positive on that larger box.
Multivariate Bernstein degree elevation gives positive Bernstein
coefficients for P-c when the degree in each variable is sufficiently large.
For a fixed polynomial this follows from the usual uniform convergence of
the degree-elevated coefficient array to its values on the grid, component
by component. This is an approximation of coefficients of the same fixed
polynomial, not replacement of the polynomial by an approximation.

Divide the Bernstein expansion by product (1-x_i/q'_i)^N, with N>=1.
Each resulting term has nonnegative power-series coefficients. Thus, for

    B(x)=product_i (1-x_i/q'_i)^(-N),

both (P-c)B and cB have nonnegative coefficients. Write B=sum b_k x^k;
all b_k>=1. Choose an integer M with Mc>sum_j |a_j|+a0, and let

    r_k=ceil(M b_k).

The coefficientwise rounding error in P sum r_k x^k is bounded in absolute
value by the coefficient l1 norm of P, whereas the margin from McB is at
least Mc. Therefore all coefficients of P sum r_k x^k are nonnegative
integers. Its Gibbs series is finite:

    sum_k r_k q^k
       <= M product_i (1-q_i/q'_i)^(-N)
          + product_i (1-q_i)^(-1) < infinity.          (3)

Give a bath energy k dot h multiplicity r_k. Since h_i>0, there are only
finitely many k below any fixed energy, and every eigenspace is finite.
The resulting counting measure R is locally finite, normal at beta, and
f*R is nonnegative. This proves the lemma without rational energy ratios.

## Apply the lemma to the work bath

Set both system ground energies to zero, which leaves (1) invariant. Fix
any W>W_*. The infinite-u limit of (1) implies W>max_alpha omega_alpha.
Let A_count be the spectrum-counting measure of H_A, and let T_count be
the sum over b,alpha of point masses at f_b+W-omega_alpha. Every energy in
T_count is strictly positive. Define f=A_count-T_count, combining equal
energies. Its constant term is the positive input-ground degeneracy and

    fhat(u)=Z_A(u)-exp(-uW) Z_B(u) Z_K(u)>0

for every u>=beta. The lemma supplies a normal integer-degeneracy bath R.
Put E=B tensor R initially, F=A tensor R finally. The nonnegativity of
f*R says, at every energy, that F has enough dimensions to accommodate
mutually orthogonal copies of E shifted by each W-omega_alpha. Choose the
corresponding isometries S_alpha:E->F. Then

    S_alpha* S_lambda=delta_alpha_lambda I,
    H_F S_alpha-S_alpha H_E=(W-omega_alpha)S_alpha.

The map V=sum K_alpha tensor S_alpha is an isometry from A tensor E to
B tensor F, implements Phi for every initial environment state, and raises
total nonbattery energy by W. Identify the two tensor arrangements with
the same physical A tensor B tensor R system. Appending the sharp battery
W->0, extend V to a unitary in every finite total-energy sector. This is
an exactly energy-conserving unitary with exactly deterministic battery loss.
The Gibbs initial environment is free and normal by (3).

## What this closes and what it does not

- Equation (1) is now a matching infimum for all covariant CPTP-extreme
  finite-dimensional channels, including different input/output systems
  and arbitrary real finite spectra, under the stated infinite-bath model.
- When A=B and the Hamiltonian is unchanged, it reduces to
  beta^(-1)log sum_alpha exp(beta omega_alpha). The separately proved
  small-error stability result applies to that same-system case.
- Finite baths still obey the no-nonzero-shift obstruction. This theorem
  must not be quoted as a finite-bath implementation.
- Tight values for general nonextreme channels remain a separate gap.
- The scalar positive-convolution machinery is related to positive
  polynomial multipliers. No priority claim is made for this general
  real-energy convolution lemma before a focused source comparison.
