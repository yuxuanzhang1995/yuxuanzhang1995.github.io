#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <utility>

// Independent coverage control: explicit multiset loops and Gray-code subset
// traversal, rather than the candidate's recursion and subset recurrence.
int main(int argc, char** argv) {
    assert(argc == 3);
    const int m = std::stoi(argv[1]);
    assert(m == 16 || m == 32 || m == 64);
    std::array<std::uint64_t, 6> counts{};
    std::uint64_t sum = 0;
    std::set<std::pair<std::uint64_t, std::uint64_t>> pairs;
    for (int a=0; a<m; ++a)
    for (int b=a; b<m; ++b)
    for (int c=b; c<m; ++c)
    for (int d=c; d<m; ++d)
    for (int e=d; e<m; ++e)
    for (int f=e; f<m; ++f) {
        const std::array<int, 6> k{a,b,c,d,e,f};
        ++counts[0]; sum += a+b+c+d+e+f;
        const int odd = (a&1)+(b&1)+(c&1)+(d&1)+(e&1)+(f&1);
        if (odd == 0) { ++counts[1]; continue; }
        if (odd <= 2) { ++counts[2]; continue; }
        std::uint64_t A=1, B=0;
        int residue=0, word=0;
        for (unsigned step=1; step<64; ++step) {
            const unsigned bit=__builtin_ctz(step);
            word ^= 1 << bit;
            residue = (residue + ((word & (1 << bit)) ? k[bit] : -k[bit]) + m) % m;
            if (residue==0) A |= std::uint64_t(1) << word;
            if (residue==m/8) B |= std::uint64_t(1) << word;
        }
        assert(!(A&B));
        if (!B) { ++counts[3]; continue; }
        if (__builtin_popcountll(A)<=2 || __builtin_popcountll(B)<=2) {
            ++counts[4]; continue;
        }
        ++counts[5]; pairs.emplace(A,B);
    }
    std::uint64_t comb=1;
    for (int j=1; j<=6; ++j) comb=comb*(m+j-1)/j;
    assert(counts[0] == comb);
    assert(counts[0] == counts[1]+counts[2]+counts[3]+counts[4]+counts[5]);
    assert(sum*2 == comb*6*(m-1));
    std::ofstream file(argv[2]); assert(file);
    for (auto pair:pairs) file << pair.first << ' ' << pair.second << '\n';
    std::cout << "modulus=" << m << " counts=";
    for (auto n:counts) std::cout << n << ',';
    std::cout << " checksum=" << sum << " unique_pairs=" << pairs.size() << '\n';
}
