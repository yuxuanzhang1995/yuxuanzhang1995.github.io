import sympy as S
t=S.symbols('t', real=True)
s=1-t*t
def ket2(i,j):
 v=S.zeros(9,1); v[3*i+j]=1; return v
def ket3(i,j,k):
 v=S.zeros(27,1); v[9*i+3*j+k]=1; return v
p=ket2(0,0)+ket2(1,1)+ket2(2,2)
v=ket2(2,0)+t*ket2(2,2)
H=s*p*p.T+v*v.T
for i,j in [(0,1),(0,2),(1,0),(1,2),(2,1)]:
 q=ket2(i,j); H+=s*q*q.T
w=ket3(0,0,0)+ket3(1,0,1)+ket3(1,1,0)+ket3(2,0,2)+ket3(2,2,0)+t*ket3(2,2,2)
z=ket3(2,0,0)+t*ket3(2,0,2)+t*ket3(2,2,0)+t*t*ket3(2,2,2)
O=s*w*w.T+t*t/(1+t*t)*z*z.T
for i,j,k in [(0,1,1),(0,2,2),(1,2,2),(2,1,1)]:
 q=ket3(i,j,k); O+=s*q*q.T
M=S.zeros(9); N=S.zeros(9)
for i in range(3):
 for j in range(3):
  for a in range(3):
   for b in range(3):
    M[3*i+j,3*a+b]=sum(O[9*i+3*j+k,9*a+3*b+k] for k in range(3))
    N[3*i+j,3*a+b]=sum(O[9*i+3*k+j,9*a+3*k+b] for k in range(3))
assert all(S.simplify(x)==0 for x in M-H)
assert all(S.simplify(x)==0 for x in N-H)
print('Both extension marginals equal H: True (symbolic)')
G=S.zeros(9)
for i in range(3):
 for j in range(3):
  for a in range(3):
   for b in range(3): G[3*i+j,3*a+b]=H[3*i+b,3*a+j]
# Positive decomposition of the only nontrivial 3x3 PPT block.
block=G.extract([2,6,8],[2,6,8])
f=S.Matrix([1,1,0]); g=S.Matrix([0,t,1])
assert block==s*f*f.T+g*g.T
for inds in [[1,3],[5,7]]: assert G.extract(inds,inds)==s*S.ones(2)
print('PPT block = (1-t^2)ff^T + gg^T: True (symbolic)')
R=S.diag(*[sum(H[3*i+j,3*i+j] for j in range(3)) for i in range(3)])
assert R==S.diag(3*s,3*s,s+2)
print('Input marginal = diag(3s,3s,s+2): True (symbolic)')
for q in [ket2(0,0)-ket2(1,1),ket2(2,2)-ket2(0,0)-t*ket2(2,0)]:
 assert all(S.simplify(x)==0 for x in H*q)
for q in [ket2(0,1)-ket2(1,0),ket2(1,2)-ket2(2,1),-ket2(0,2)+ket2(2,0)-t*ket2(2,2)]:
 assert all(S.simplify(x)==0 for x in G*q)
print('All five range-criterion kernel identities: True (symbolic)')
a=S.Rational(1,2)
assert H.subs(t,a).rank()==7 and G.subs(t,a).rank()==6
print('At t=1/2: rank(H)=7; rank(H^Gamma)=6; 7 != 6: True')
for name,expr in [('s',s),('extension z weight',t*t/(1+t*t)),('minimum input marginal',3*s)]:
 val=expr.subs(t,a); assert val>0
 print('At t=1/2: '+name+' = '+str(val)+' > 0: True')
