from functools import lru_cache
@lru_cache(None)
def parts(n,cap,d):
    if n==0:return ((),)
    if d==0:return ()
    return tuple((k,)+q for k in range(min(n,cap),0,-1) for q in parts(n-k,k,d-1))
def predecessors(p):
    ans=[]
    for j in range(len(p)):
        if j+1<len(p) and p[j]==p[j+1]:continue
        q=list(p);q[j]-=1;ans.append(tuple(x for x in q if x))
    return ans
count=0
for d in range(1,6):
    for n in range(1,13):
        mid=parts(n,n,d);pos={p:i for i,p in enumerate(mid)};L=len(mid)
        comm=[[0]*L for _ in range(L)]
        for p in parts(n+1,n+1,d):
            ii=[pos[q]for q in predecessors(p)]
            for i in ii:
                for j in ii:comm[i][j]+=1
        pred=[set(predecessors(p))for p in mid]
        for i in range(L):
            for j in range(L):
                comm[i][j]-=len(pred[i]&pred[j])
                assert comm[i][j]==int(i==j and len(mid[i])<d)
        count+=1
print('Exact finite branching commutator: 60 sectors, d=1..5,n=1..12; expected occupation projection: PASS')
print('Scope: finite structural control only; the all-d crossover relies on the analytic proof, not this enumeration.')
