# Scope and internal review

Version 1.0 · 9 November 2026

Assessment: supported internally; complete original scope. The reviewer is
the same agent involved in the derivation. No independent expert assessment
or formal proof-assistant verification has been obtained.

## Match to the original question

The pinned original and Theorem 1 use the same four tetrahedral projectors
on two separated qubits, and prescribe only the shared classical outcome
channel, exactly on every density operator. A resource is any normalized
finite-dimensional bipartite pure state. All supplied shared entanglement
is included, and its entropy is measured in bits. There is no resource-rank
cutoff, one-way communication restriction, postselection, or requirement
on the quantum postmeasurement state. The pointwise lower bound holds at
every finite resource rank, so taking the infimum over unbounded finite
ranks preserves it. Bell-pair teleportation attains that bound.

## Proof audit

1. Equality of the classical-output channels extends to arbitrary untouched
   references. The coherent detector has input Schmidt probabilities
   (3/4, 1/12, 1/12, 1/12) and leaves a correctable Bell pair in each outcome.
   Its input entanglement is charged: Nielsen's largest-component condition
   is (3/4) lambda_1 <= 1/2. The detector is not a free entangled resource.

2. Pulling back each classical effect gives a separable effect on the input
   and resource systems. Local product ancillas can be absorbed into that
   pullback. Finite-dimensional separable effects admit finite rank-one
   product decompositions; the necessary cone is closed under protocol
   limits. The exact rank-one induced effect forces ALB^T = cE. Positivity
   and expectation one give S_j v_j = v_j and the conjugate-c expansion.

3. The functional in equation (19) is complex linear on the product tensor.
   Its value on v_j is 2(lambda_1-lambda_2). After the triangle inequality
   the argument uses |conj(c) f| = |c f|, without equating the complex numbers.

4. The adjugate step follows from two-dimensional Cayley-Hamilton. It never
   divides by c or inverts the branch blocks. The second implementation
   checks the denominator-cleared identity for arbitrary formal entries,
   not just random matrices or invertible branch examples.

5. Summation uses the complete POVM, including zero-contraction terms. Its
   contractions give exactly 4 delta and 4(1-delta). The EJM determinant
   sum is one. Cauchy-Schwarz therefore yields the rank-independent bound
   (lambda_1-lambda_2)^2 <= 4 delta(1-delta), with no hidden dimension factor.

6. For lambda_1 <= 1/2, the Bell spectrum majorizes the resource spectrum.
   Otherwise write lambda_1 = 1/2+x, with 0<x<=1/6. If the second probability
   is at most half the remainder, that normalized remainder has entropy at
   least one. In the complementary case the tail constraint gives delta
   >=x^2. Binary-entropy monotonicity and curvature then give
   H >= 1 + x^2[ln(12)-9/4]/ln(2) > 1. Both cases allow arbitrarily many
   tail coordinates. Equality is possible only for the Bell spectrum.

## Reproduction and limits

The release runner checks the original programs in a fresh temporary
directory against all their expected JSON fields. The formal polynomial
checker uses rational arithmetic without SymPy. The tests support the
algebra and selected physical controls; the all-rank and entropy arguments
remain written analytic proofs.

One preliminary negative-control expectation was rejected during development:
the zero-contraction terms of this particular positive control also have
zero contracted norms. They are detected through full POVM completeness
instead. The diagnostic remains in the expected output. The rational triple
described as a historical PPT control in the script is tested only for a
tail-inequality violation; its PPT feasibility is not certified here and
does not enter the theorem.

The statement is not a claim about mixed resources, approximate simulation,
asymptotic net-consumption rates, or measurement localization without
communication. The source comparison is bounded. External expert review and
a broader priority search remain useful before a journal or archive submission.
