"""Full-wedge interval certificate. A theorem is certified only when no box remains."""
from mpmath import iv
import math, time
from fractions import Fraction as F
iv.dps = 35
I = iv.mpf
ZERO = I(0)
ONE = I(1)
L2 = iv.log(I(2))
PI = iv.pi

def lo(a):
    f = float(a.a)
    return 0.0 if f == 0 and a.a == 0 else math.nextafter(f, -math.inf)

def hi(a):
    f = float(a.b)
    return 0.0 if f == 0 and a.b == 0 else math.nextafter(f, math.inf)

def clamp(a, l, h):
    return I([max(l, lo(a)), min(h, hi(a))])

def roots(e, D):
    v = I(1) / 9 - e / 3
    if lo(v) <= 0:
        raise ValueError('degenerate v')
    z = (I(1) / 27 - e / 6 + D / 2) / v ** I('1.5')
    z = clamp(z, -1, 1)
    w = clamp(1 - z * z, 0, 1)
    a = iv.atan2(iv.sqrt(w), z) / 3
    return [clamp(I(1) / 3 + 2 * iv.sqrt(v) * iv.cos(a - 2 * PI * k / 3), 0, 1) for k in range(3)]

def entropy(ls):
    out = I(0)
    for z in ls:
        a, b = (lo(z), hi(z))

        def h(t):
            if t == 0:
                return I(0)
            t = I(t)
            return -t * iv.log(t) / L2
        vals = [h(a), h(b)]
        if a <= hi(1 / iv.exp(1)) and b >= lo(1 / iv.exp(1)):
            vals.append(1 / (iv.exp(1) * L2))
        out += I([min((lo(v) for v in vals)), max((hi(v) for v in vals))])
    return out

def data(x, y, deriv=False, hess=False):
    r = [x, (1 - x + y) / 2, (1 - x - y) / 2]
    r = [clamp(z, 0, 1) for z in r]
    e = (1 + sum((z * z for z in r))) / 6
    t = r[0] ** I('1.5') - r[1] ** I('1.5') - r[2] ** I('1.5')
    tp = I([max(0, lo(t)), max(0, hi(t))])
    D = tp * tp / 27
    ls = roots(e, D)
    H = entropy(ls)
    if not deriv:
        return H
    vv = I(1) / 9 - e / 3
    zz = (I(1) / 27 - e / 6 + D / 2) / vv ** I('1.5')
    if not (-1 < lo(zz) and hi(zz) < 1):
        raise ValueError('uncertified derivative real-root domain')
    dr = [[I(1), I(0)], [I(-0.5), I(0.5)], [I(-0.5), I(-0.5)]]
    eg = [sum((r[k] * dr[k][i] for k in range(3))) / 3 for i in range(2)]
    tg = [I('1.5') * sum(((1 if k == 0 else -1) * iv.sqrt(r[k]) * dr[k][i] for k in range(3))) for i in range(2)]
    Dg = [2 * tp * tg[i] / 27 for i in range(2)]
    lg = []
    hg = [I(0), I(0)]
    for z in ls:
        if lo(z) <= 0:
            raise ValueError('zero eigenvalue')
        den = 3 * z * z - 2 * z + e
        if lo(den) <= 0 <= hi(den):
            raise ValueError('root collision')
        g = [(Dg[i] - eg[i] * z) / den for i in range(2)]
        lg.append(g)
        for i in range(2):
            hg[i] -= (iv.log(z) + 1) * g[i] / L2
    if not hess:
        return (H, hg)
    if lo(t) <= 0 or any((lo(z) <= 0 for z in r)):
        raise ValueError('hessian boundary')
    ee = [[sum((dr[k][i] * dr[k][j] for k in range(3))) / 3 for j in range(2)] for i in range(2)]
    tt = [[I('.75') * sum(((1 if k == 0 else -1) * dr[k][i] * dr[k][j] / iv.sqrt(r[k]) for k in range(3))) for j in range(2)] for i in range(2)]
    DD = [[2 * (tg[i] * tg[j] + t * tt[i][j]) / 27 for j in range(2)] for i in range(2)]
    hh = [[I(0) for j in range(2)] for i in range(2)]
    for z, g in zip(ls, lg):
        den = 3 * z * z - 2 * z + e
        for i in range(2):
            for j in range(2):
                zz = (DD[i][j] - ee[i][j] * z - eg[i] * g[j] - eg[j] * g[i] - (6 * z - 2) * g[i] * g[j]) / den
                hh[i][j] -= (g[i] * g[j] / z + (iv.log(z) + 1) * zz) / L2
    return (H, hg, hh)
import heapq, json, time, pathlib

def run_certificate():
    start = time.time()
    c = data(I('0.5'), I(0), True, True)
    assert len(c) == 3, 'unexpected derivative API'
    E, g, Q = c
    m = g[0]
    assert lo(m) > 0
    print('target enclosure', str(E), 'slope enclosure', str(m))
    assert lo(g[1]) <= 0 <= hi(g[1])
    radius = None
    for h in [1 / 32, 1 / 64, 1 / 128, 1 / 256, 1 / 512, 1 / 1024, 1 / 2048, 1 / 4096, 1 / 8192, 1 / 16384]:
        try:
            _, _, A = data(I([0.5 - h, 0.5 + h]), I([0, h]), True, True)
            det = A[0][0] * A[1][1] - A[0][1] * A[1][0]
            if lo(A[0][0]) > 0 and lo(det) > 0:
                radius = h
                print('Hessian certificate radius', h, 'Hxx >', lo(A[0][0]), '> 0; determinant >', lo(det), '> 0')
                break
        except (ValueError, ZeroDivisionError):
            pass

    def admissible(b):
        a, c, u, v = b
        return F(u) <= 1 - F(a) and F(u) <= 3 * F(c) - 1 and (a <= c) and (u <= v)

    def local(b):
        a, c, u, v = b
        return radius is not None and a >= 0.5 - radius and (c <= 0.5 + radius) and (v <= radius)

    def bound(b):
        a, c, u, v = b
        x = I([a, c])
        y = I([u, v])
        plane = E + m * (x - I('.5'))
        r = [x, (1 - x + y) / 2, (1 - x - y) / 2]
        r = [clamp(z, 0, 1) for z in r]
        purity = (2 - sum((z * z for z in r))) / 3
        ans = lo(-iv.log(purity) / L2 - plane)
        try:
            ans = max(ans, lo(data(x, y) - plane))
        except (ValueError, ZeroDivisionError):
            pass
        if F(v) <= 1 - F(c) and F(v) <= 3 * F(a) - 1 and (u >= 0):
            try:
                H, grad = data(x, y, True)
                xx = (a + c) / 2
                yy = (u + v) / 2
                center = data(I(xx), I(yy)) - E - m * (I(xx) - I('.5'))
                residual = center + (grad[0] - m) * (x - I(xx)) + grad[1] * (y - I(yy))
                ans = max(ans, lo(residual))
            except (ValueError, ZeroDivisionError):
                pass
        return ans
    xs = [math.nextafter(1 / 3, -math.inf), 1.0]
    ys = [0.0, 1.0]
    if radius is not None:
        xs = sorted(xs + [0.5 - radius, 0.5 + radius])
        ys = sorted(ys + [radius])
    queue = []
    serial = 0
    count = 0
    certified_floor = math.inf
    accepted_boxes = 0
    for a, c in zip(xs, xs[1:]):
        for u, v in zip(ys, ys[1:]):
            b = (a, c, u, v)
            if admissible(b) and (not local(b)):
                z = bound(b)
                heapq.heappush(queue, (z, serial, b))
                serial += 1
    while queue and count < 150000:
        z, _, b = heapq.heappop(queue)
        if z > 0:
            certified_floor = min(certified_floor, z)
            accepted_boxes += 1
            continue
        a, c, u, v = b
        if c - a >= v - u:
            mid = (a + c) / 2
            assert a < mid < c, 'Subdivision precision exhausted'
            children = [(a, mid, u, v), (mid, c, u, v)]
        else:
            mid = (u + v) / 2
            assert u < mid < v, 'Subdivision precision exhausted'
            children = [(a, c, u, mid), (a, c, mid, v)]
        for child in children:
            if not admissible(child) or local(child):
                continue
            zz = bound(child)
            if zz <= 0:
                heapq.heappush(queue, (zz, serial, child))
                serial += 1
            else:
                certified_floor = min(certified_floor, zz)
                accepted_boxes += 1
        count += 1
    assert not queue, 'Global coverage incomplete: no theorem certified'
    assert accepted_boxes > 0 and certified_floor > 0
    print('Strict global lower bound outside local rectangle:', certified_floor, '> 0; boxes:', accepted_boxes)
    delta = 0.0
    passed = not queue and radius is not None
    assert passed
    print('Full wedge covered:', not queue, '; exact supporting plane:', passed, '; splits:', count)
    result = {'passed': passed, 'exact': delta == 0, 'delta': delta, 'radius': radius, 'entropy_lower': lo(E), 'entropy_upper': hi(E), 'slope_lower': lo(m), 'slope_upper': hi(m), 'splits': count, 'strict_global_floor': certified_floor, 'accepted_global_boxes': accepted_boxes}
    pathlib.Path('/workspace/bell_strict_global_result.json').write_text(json.dumps(result, indent=2))
    if not passed:
        return
    assert delta == 0
    lower = lo(E - I(str(delta)))
    assert lower > 0.953089
    assert hi(E) < 0.953092
    assert lo(E - I('0.95309101373034')) > 0
    assert lo(I('0.95309101373035') - E) > 0
    print('Exact support: PASS; 0.95309101373034 < E_F < 0.95309101373035: PASS')
    return result

def certify_open_region():
    result = run_certificate()
    h = F(1,1024)
    eta = F(1,2**36)
    B = F(9)
    gamma = F(1,10**9)
    boxx = I([float(F(1,2)-h),float(F(1,2)+h)])
    boxy = I([0,float(h)])
    _, _, A = data(boxx,boxy,True,True)
    maxentry = max(max(abs(lo(z)),abs(hi(z))) for row in A for z in row)
    assert F(maxentry) < B
    print('Hessian absolute entries <=',repr(maxentry),'< 9: PASS')
    assert F(result['strict_global_floor']) > gamma
    print('Recorded gap >=',repr(result['strict_global_floor']),'> 1/1000000000: PASS')
    assert F(result['slope_lower']) > F(1,2)
    print('Center x slope >=',repr(result['slope_lower']),'> 1/2: PASS')
    assert 0 < eta < h
    perturb = B*(4*eta+2*eta*eta)
    ordermargin = F(1,2)-4*B*eta
    assert perturb < gamma
    assert ordermargin > 0
    print('eta =',str(eta),'< 1/1024: PASS')
    print('Tangent perturbation <=',str(perturb),'< 1/1000000000: PASS')
    print('Coefficient-order margin >',str(ordermargin),'> 0: PASS')
    r=[boxx,(1-boxx+boxy)/2,(1-boxx-boxy)/2]
    t=r[0]**I('1.5')-r[1]**I('1.5')-r[2]**I('1.5')
    e=(1+sum(z*z for z in r))/6
    D=t*t/27
    ls=roots(e,D)
    v=I(1)/9-e/3
    z=(I(1)/27-e/6+D/2)/v**I('1.5')
    minprob=min(lo(q) for q in r)
    mineig=min(lo(q) for q in ls)
    denmargin=min(min(abs(lo(3*q*q-2*q+e)),abs(hi(3*q*q-2*q+e))) for q in ls)
    assert minprob>0 and lo(t)>0 and mineig>0
    assert -1<lo(z) and hi(z)<1
    assert all(not (lo(3*q*q-2*q+e)<=0<=hi(3*q*q-2*q+e)) for q in ls)
    print('Local probabilities >=',repr(minprob),'> 0; phase t >=',repr(lo(t)),'> 0: PASS')
    print('Local eigenvalues >=',repr(mineig),'> 0; root denominator magnitude >=',repr(denmargin),'> 0: PASS')
    print('Local Cardano argument:',repr(lo(z)),'<= z <=',repr(hi(z)),'strictly inside (-1,1): PASS')
    print('OPEN TWO-DIMENSIONAL REGION CERTIFICATE: PASS')

if __name__ == '__main__':
    certify_open_region()

