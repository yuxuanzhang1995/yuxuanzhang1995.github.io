"""Exact Choi normalization and the interior margin used in the work reduction."""
import sympy as sp


for d in (2, 3, 5):
    dim = d*d
    omega = sp.eye(dim)/dim
    radius = sp.Rational(1, dim*(dim-1))
    # Difference of two matched Bell coherences has both partial traces zero.
    h = sp.zeros(dim)
    h[0,d+1] = h[d+1,0] = 1
    step = radius/3
    assert sp.trace((step*h)**2) < radius**2
    large = omega + (dim-1)*step*h
    assert min(large.eigenvals()) > 0
    assert (large+(dim-2)*omega)/(dim-1) == omega+step*h
    for a in (sp.Rational(1,11), sp.Rational(1,3), sp.Rational(2,3)):
        x = omega + step*h/5
        y = x + a*radius*h/(4*(1-a))
        corrected = omega+(1-a)*(y-x)/a
        assert sp.trace((corrected-omega)**2) < radius**2
        assert (1-a)*y+a*omega == (1-a)*x+a*corrected
        # The strict margin permits a second finite-factorizable approximation.
        xp = x + a*radius*h/(16*(1-a))
        cp = omega+(1-a)*(y-xp)/a
        assert sp.trace((cp-omega)**2) < radius**2
        assert (1-a)*y+a*omega == (1-a)*xp+a*cp
print("PASS: normalized-Choi mixed-unitary ball in three dimensions, nine "
      "complement-ball identities and nine strict finite-approximation margins.")
