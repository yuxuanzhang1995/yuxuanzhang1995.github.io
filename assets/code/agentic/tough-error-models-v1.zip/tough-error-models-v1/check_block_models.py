"""Finite exact controls for q119-block-errors.md; not an all-n proof.

Uses Gaussian-rational matrix ranks and directly generated Kraus products.
No optimizer, floating residual, or empirical absence of a code is accepted.
"""
from pathlib import Path
import hashlib
import json
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []
mutations = []


def check(name, condition):
    if condition is not True:
        raise AssertionError(name)
    checks.append(name)


def frame(e, zero):
    out = [[s.Integer(0)] * e] if zero else []
    for i in range(e):
        v = [s.Integer(0)] * e
        v[i] = s.Integer(1)
        out.append(v)
    for i in range(e):
        for j in range(i + 1, e):
            for phase in [s.Integer(1), s.I]:
                v = [s.Integer(0)] * e
                v[i], v[j] = s.Integer(1), phase
                out.append(v)
    return out


def rows(vectors, normalize=False, identity=True, upper_only=False):
    """Products at one coordinate of each block, computed directly.

    For unit normalization, products divide by ||v||^2, remaining rational
    Gaussian numbers. No square-root simplification is needed.
    """
    e, t = len(vectors[0]), len(vectors)
    norms = [sum(s.conjugate(x) * x for x in v) for v in vectors]
    result = [[s.Integer(1)] * t] if identity else []
    for a in range(e):
        for b in range(e):
            if upper_only and a > b:
                continue
            result.append([s.conjugate(v[a]) * v[b] / (norms[j] if normalize else 1)
                           for j, v in enumerate(vectors)])
    return s.Matrix(result)


def trial(e, n, tp):
    denominator = e * e if tp else e * e + 1
    t = min(n, denominator)
    vectors = frame(e, not tp)[:t]
    name = f'e={e},n={n},TP={tp}'
    labels = s.Matrix(vectors)
    check(name + ': error-space dimension', labels.rank() == e)
    products = rows(vectors, normalize=tp, identity=True)
    check(name + ': full block product span', products.rank() == t)
    ranks = [n // t + int(j < n % t) for j in range(t)]
    check(name + ': nonempty exact partition', sum(ranks) == n and min(ranks) > 0)
    k = (n + denominator - 1) // denominator
    check(name + ': maximal block equals ceiling', max(ranks) == k)
    check(name + ': Tverberg integer threshold', (k - 1) * denominator + 1 <= n)
    # A largest coordinate block directly has scalar compression for every
    # product. Expanded columns also check constancy within each block.
    expanded = s.Matrix.hstack(*[products[:, j:j+1] for j, r in enumerate(ranks) for _ in range(r)])
    start = 0
    for j, r in enumerate(ranks):
        check(name + f': block {j} KL',
              all(expanded[:, start + u] == expanded[:, start] for u in range(r)))
        start += r
    if tp:
        normrow = [sum(products[1 + a*e + a, j] for a in range(e)) for j in range(t)]
        check(name + ': TP', normrow == [1] * t)
    return vectors, products


for e in range(1, 5):
    for n in range(e + 1, 21):
        trial(e, n, False)
    for n in sorted(set([e, e+1, max(e, e*e-1), e*e, e*e+1, 2*e*e+1])):
        trial(e, n, True)
for e in (5, 6):
    for n in (e*e, e*e+1, e*e+2):
        trial(e, n, False)

# e>=n: explicit error spaces containing all rank-one diagonal projections.
for n in range(1, 6):
    order = [(i, i) for i in range(n)] + [(i, j) for i in range(n) for j in range(n) if i != j]
    for e in sorted(set([n, min(n*n, n+1), n*n])):
        errors = []
        for i, j in order[:e]:
            a = s.zeros(n)
            a[i, j] = 1
            errors.append(a)
        check(f'extension {n},{e}: independent',
              s.Matrix.hstack(*[a.reshape(n*n, 1) for a in errors]).rank() == e)
        check(f'extension {n},{e}: diagonal projections included',
              all(errors[i].H * errors[i] == errors[i] for i in range(n)))
        check(f'extension {n},{e}: claimed ceiling one', (n + e*e) // (e*e+1) == 1)

v = frame(2, True)
base = rows(v)
bad = [list(x) for x in v]
bad[-1] = bad[-2][:]
mutations.append({'mutation': 'replace imaginary pair by duplicate real pair',
                  'caught': rows(bad).rank() < 5})
mutations.append({'mutation': 'omit identity and lose common-kernel projection',
                  'caught': rows(v, identity=False).rank() < 5})
mutations.append({'mutation': 'omit conjugate cross products',
                  'caught': rows(v, upper_only=True).rank() < 5})
mutations.append({'mutation': 'declare original zero-label errors TP',
                  'caught': sum(abs(x)**2 for x in v[0]) != 1})
mutations.append({'mutation': 'claim coordinate code across distinct blocks',
                  'caught': base[:, 0] != base[:, 1]})
a = s.Matrix([[1, 0], [0, 2]])
b = s.Matrix([[0, 1], [0, 0]])
x, y = a.H*a, a.H*b
mutations.append({'mutation': 'apply simultaneous diagonalization to arbitrary errors',
                  'caught': x*y-y*x != s.zeros(2)})
for item in mutations:
    check('mutation: ' + item['mutation'], bool(item['caught']))

result = {'arithmetic': 'exact Gaussian rational using SymPy',
          'checks_passed': len(checks), 'mutations_caught': len(mutations),
          'checks': checks, 'mutations': mutations,
          'proof_status': 'finite controls; all-parameter proof is separate',
          'source': {'path': __file__, 'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(HERE / 'q119-exact-check.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ['arithmetic', 'checks_passed', 'mutations_caught', 'proof_status']}))
