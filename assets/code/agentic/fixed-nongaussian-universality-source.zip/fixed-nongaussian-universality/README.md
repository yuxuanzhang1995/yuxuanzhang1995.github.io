# fixed-nongaussian-universality

Yuxuan Zhang

Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

Unrefereed AI-assisted research preprint for op_64046727b81b4024, from round 17.
Original: https://qiqc-op.com/problem/op_64046727b81b4024/
Public note: https://yuxuanzhang1995.github.io/agentic-research/fixed-nongaussian-universality/

## Status

Internal mathematical and original-statement checks passed. No external expert confirmation, formal proof-assistant certificate or exhaustive priority assessment is claimed. This publication and its new audit are not a new discovery. The proof is analytic. Finite scripts check only the explicitly documented identities and diagnostics, not all dimensions or operator limits. audit-summary.json preserves the scope and raw verdict; frozen-claim.json contains the pre-manuscript claim.

## Revision, 21 September 2026

The manuscript now gives the full fixed-vector telescoping argument and verifies the derivative generator condition in Lemma 3. Its theorem and hypotheses are unchanged. See `LEMMA3_REVISION.md` for scope and provenance. The original audit summary is historical and does not imply an external review of this revision.

## Reproduce

With Python 3, install the versions listed in requirements.txt if nonempty, then run:

```sh
python3 algebra-filter-check.py
```

Compare with checks.stdout. The scripts use no model API, private workspace or network access. environment.json records the actual publication environment.

Compile the self-contained manuscript with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error fixed-nongaussian-universality.tex
pdflatex -interaction=nonstopmode -halt-on-error fixed-nongaussian-universality.tex
```

The included publication PDF has 6 pages. All pages were visually inspected.

## Provenance and references

The byline follows the author's direction. AI contributed substantially to derivation, checking, source comparison and writing; internal model review is not human peer review. Scientific Agent Skills informed writing and evidence tracking and is cited in the manuscript. References and specific locators appear in the paper. No third-party papers or catalog text are included. Original text contributed to the QIQCOP issue is submitted under CC BY 4.0; that license does not relicense cited material or imply institutional endorsement.

MANIFEST.sha256 lists the exact bundled file hashes.
