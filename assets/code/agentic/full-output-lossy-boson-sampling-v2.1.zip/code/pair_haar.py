"""Seeded full-output Haar controls for pair-state harmonic norms."""
from pathlib import Path
from math import comb,sqrt
import sys,json,csv,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from haar_tv import Geometry,haar
from pair_spectrum import pair_vector,haar_weight

def main():
    seed=2026110301;rng=np.random.default_rng(seed);draws=128;rows=[];start=time.time();max_res=0.;max_slack=0.
    for m,N in [(2,6),(3,6),(4,6),(3,8)]:
        g=Geometry(m,N);_,v=pair_vector(m,N)
        for draw in range(draws):
            U=haar(rng,m);G=g.representations(U);full=abs(G[N]@v)**2
            p=[g.red[N,k]@full for k in range(N+1)]
            for r in range(0,N+1,2):
                q=[sum(g.proj[k,l]@p[k] for l in range(min(k,r)+1)) for k in range(N+1)]
                S,res=g.sample_laws(q);max_res=max(max_res,res)
                l1=np.array([np.sum(abs(q[k]-p[k])) for k in range(N+1)])
                tv=np.array([.5*np.sum(abs(S[k]-p[k])) for k in range(N+1)])
                max_slack=max(max_slack,float(np.max(tv-.5*l1)))
                l2=np.array([len(g.occ[k])*np.sum((q[k]-p[k])**2) for k in range(N+1)])
                predicted=np.array([float(sum(haar_weight(m,N,k,l) for l in range(r+1,k+1))) for k in range(N+1)])
                for eta in [.5,.8,.95]:
                    w=np.array([comb(N,k)*eta**k*(1-eta)**(N-k) for k in range(N+1)])
                    rows.append([m,N,draw,eta,r,float(w@tv),float(w@l1),float(w@l2),float(w@predicted),.5*sqrt(float(w@predicted))])
        print(json.dumps({'m':m,'N':N,'draws':draws,'seconds':time.time()-start}),flush=True)
    assert max_res<1e-9 and max_slack<1e-9
    groups={}
    for row in rows:groups.setdefault(tuple(row[i] for i in [0,1,3,4]),[]).append(row)
    stats=[]
    for key,rr in groups.items():
        vals=np.array([x[7] for x in rr]);target=rr[0][8];se=float(vals.std(ddof=1)/sqrt(draws))
        stats.append(dict(zip(['m','N','eta','r'],key),mean_TV=float(np.mean([x[5] for x in rr])),mean_squared_error=float(vals.mean()),predicted=target,standard_error=se,z_score=None if target<1e-20 else float((vals.mean()-target)/se),mean_TV_bound=rr[0][9]))
    out=Path(__file__).resolve().parents[1]/'results'
    with (out/'E04-haar.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['m','N','draw','eta','r','TV','signed_L1','squared_error','predicted','TV_bound']);w.writerows(rows)
    report={'seed':seed,'independent_Haar_matrices':draws*4,'rows':len(rows),'statistics':stats,'max_absolute_z':max(abs(x['z_score']) for x in stats if x['z_score'] is not None),'max_prefix_residual':max_res,'max_signed_sampling_slack':max_slack,'seconds':time.time()-start,'limits':'Conditional pair inputs and all survivor sectors, exact full-output enumeration with floating arithmetic; finite Monte Carlo is not a proof or a production runtime benchmark.'}
    (out/'E04-haar.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='statistics'}))

if __name__=='__main__':main()
