# Eight-copy universal CCZ concentration beyond the two-thirds candidate optimum

Yuxuan Zhang. Research preprint, 28 September 2026.
Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

The complete mathematical argument is in `eight-copy-ccz-concentration.tex`. The paper is a proof candidate reviewed only by
AI (an isolated adversarial review of the complete claim and an independent simulation, both recorded in `INTERNAL_REVIEW.json`).
**No independent human expert has examined the argument, and neither external peer review nor human novelty certification is
recorded.** AI assistance is disclosed in the paper.

**Result.** Rizzo and Leone (arXiv:2608.13376) gave a fixed stabilizer protocol that converts eight copies of an unknown pure
qubit ψ into an exact |CCZ⟩ state with probability (2/3) m₃(ψ), where m₃ = (1 − x⁶ − y⁶ − z⁶)/2 in terms of the Bloch vector,
and proved that no such protocol exceeds (7/6) m₃. The open-problem record op_bc61eaba5c332fec asks whether (2/3) m₃ is optimal.
It is not. An explicit catalyst-free protocol Λ* — measure X^⊗8 and Z^⊗8, then a sector-dependent P^{E1}, then P₀P₁ or P^{E2}
by feedforward; Clifford decoders of 17, 17 and 21 gates; discard five qubits — outputs exactly |CCZ⟩ on each of its nine
accepted branches, with total probability exactly m₃(ψ) = (3/2)(1 − x²)(1 − y²)(1 − z²) for every pure ψ. Hence
m₃ ≤ p₈* ≤ (7/6) m₃, and the candidate optimum fails at every non-stabilizer input (T-type state: 4/9 instead of 8/27). Every
accepted branch acts with rank one on the symmetric subspace. The new branch acts on the filter outcome +P^{E1} that the
two-thirds branches discard, and it raises the kept share of each sector direction of the three-dimensional subspace M₈ from
4/7 to 6/7. The last seventh sits in a branch whose image in M₈ is a stabilizer state, so no continuation of this tree uses it.

## Reproduce the computation

`check_eight_copy_ccz.py` uses **only the Python standard library** (tested with CPython 3.13.5 on the host and 3.12.13 in a
container):

```sh
python3 check_eight_copy_ccz.py | diff - expected_stdout.txt && echo BYTE-EXACT
```

Or with no network at all (any CPython 3.12 image; the recorded run used the local image `qiqc-sandbox:v1`, see
`reproduction.json`):

```sh
docker run --rm --network=none -v "$PWD":/workspace:ro -w /workspace python:3.12-slim \
  python check_eight_copy_ccz.py | diff - expected_stdout.txt
```

It prints 21 lines in under a second: the Pauli and gate conventions; the 13-leaf instrument (pairwise commutation on every
path, completeness on all 256 basis vectors); rank one on Sym⁸ and the explicit leaf states; the captures 2/7; the three
decoders gate by gate in all three sectors (Gaussian integers in sector Y); the Pauli spectrum of the nine leaf states; the
9×9 identity N = 6(v₁v₁ᵀ + 2v₂v₂ᵀ + v₃v₃ᵀ) and N = (6/7) Π_{M₈}; the Bloch identities as exact polynomial identities; p = m₃
at three Gaussian-rational inputs; controls (the two-thirds branches alone give (2/3) m₃, wrong decoders fail, the leaf that
isolates the last seventh outputs a stabilizer state, the rejected leaf has rank two); and the T-type and H-type values.
`mutate.py` applies 25 single-point mutations, each of which makes the program exit nonzero, and 6 equivalent edits, each of
which must leave the output unchanged (`MUTATION_REPORT.txt`). Reproduction confirms only that the program computes what the
paper describes; Theorem 1 is established by the written argument, and the program checks every finite identity it uses.

## Build the manuscript

Compile `eight-copy-ccz-concentration.tex` twice with pdfLaTeX (amsmath, amsthm, amssymb, mathtools, geometry, lmodern,
microtype, xcolor, hyperref). `EVIDENCE.json` gives primary-source locators for every external claim; source inspection was
performed by AI, and independent human verification remains unrecorded.

The scientific-writing guidance from K-Dense's Scientific Agent Skills was consulted at commit
330c8e764435a731eff571e3efdda70b363d0792 and is cited in the manuscript. Its evidence workflow was followed selectively: a
source register (`EVIDENCE.json`) and an evidence-mapped claims outline (`OUTLINE.md`) were written before the prose.

## Caution for readers

Scrutiny should start with the transfer to sectors X and Y (Lemma 3). The sector-Y leaf states are R^⊗8 images of the
sector-Z ones, with R = exp(−iπX/4) and R Z R† = −Y, and are decoded by D_L R†^⊗8; R^⊗8 in place of R†^⊗8 also works up to a
global sign, because R^⊗8 R^⊗8 = X^⊗8 = −1 there. The upper bound (7/6) m₃ is that of Rizzo and Leone (the manuscript also
derives it from the support identity K Π_Sym = K Π_{M₈}); the new lower bound m₃ does not depend on it. The exact value of
p₈* in [m₃, (7/6) m₃] remains open.
