# Recovery transfer v1: assessment and source attribution

Verdict: the transfer is supported internally, subject to the stated ideal-
arithmetic and same-agent limits. It leaves the finite exact Q119 gap unchanged.

The complete proof and all six exact controls were checked. Lambda is a PSD
Gram average and its trace is one precisely because the Kraus operators are
normalized. The isometric polar completion has enough output dimensions at
n>=ek, even if K has a kernel. The decoder has an explicit replacement term,
so it is trace preserving on the full physical space, not only on the noisy
code's support. The exact tests include both full-rank and singular Lambda,
a genuinely complex rank-one Lambda that detects a mistaken transpose, and
an invalid dimension and nonnormalized model.

The square-root estimate uses operator monotonicity and scalar calculus for
L+delta I; it does not illegitimately square noncommuting matrices. Its integral
argument remains valid at zero eigenvalues. The two Stinespring maps are both
isometries, and the trace-norm difference estimate holds with arbitrary reference
systems and arbitrary trace-class input. Postcomposition by the decoder is
contractive. The full diamond convention explains the factor two. The exact
rational dephasing control has logical diamond error 2/65, with an upper bound
from its Pauli mixture and a matching |+> input; it is not just a state sample.

The normalized-observable reduction is checked separately: the identity
coefficient direction is I/sqrt(e), so it contributes zero variance. The
remaining e^2-1 Hermitian coefficient directions have operator norm <=1 by
unital complete positivity. Thus P=k(e^2-1), the search threshold e^2k-1,
and the coefficient 768e^2(e^2-1)k^4/epsilon^4 follow from S02. The case
e=1 is unitary and handled directly. The completion dimension follows from
the search dimension for e>=2, k>=2.

One fixed normalized e=2,n=7,k=2 pipeline reached variance below 1e-4
after 331 gradient steps. The complete ideal-channel action was tested on
matrix units. The largest relevant isometry error was below 1.3e-14. The
computed Stinespring difference was about 0.00529, giving an illustrative
2d bound near 0.01059; these floating values were not certified by interval
arithmetic and are not advertised as an exact numerical diamond certificate.
The analytic uniform bound is established by the proof, not by this one case.

## Primary-source interface

[Ng--Mandayam, equation (4)](https://arxiv.org/html/0909.0931) explicitly
defines the transpose recovery using the inverse square root on the noisy
code support. Our polar blocks agree there. This is inherited recovery
technology, not a newly discovered decoder.

[Beny--Oreshkov, Corollary 2](https://arxiv.org/pdf/0907.5391) gives general
approximate KL conditions in worst-case entanglement fidelity. It also explains
using a code-state Gram average as a candidate environment state. The present
elementary estimate is a convenient, conservative residual-to-diamond interface,
not a claim that approximate KL conditions are new.

[Kretschmann--Schlingemann--Werner](https://arxiv.org/abs/0710.2495) is the
standard Stinespring continuity context. The elementary direction used here
is proved in full, so no stronger uninspected theorem is imported.

The new candidate contribution remains S02's quantitative scalar-compression
landscape and guaranteed ideal iteration, together with this explicit physical
corollary. Finite precision complexity, exact finite code termination, full
priority clearance, and independent expert review remain pending.

## Allocation decision

This is the second stage of the quantitative-extension mechanism without a
change to the original finite-rounding gap. Park this mechanism now under the
existing rule. More examples, tighter numerical tolerances, or a rewrite of the
same corollary do not qualify as another round. Reopening requires a concrete
new input, such as a certified finite-precision obstruction/repair or a lemma
that reaches the sharp integer threshold. The requested five deep rounds have
not been completed by these three stages.
