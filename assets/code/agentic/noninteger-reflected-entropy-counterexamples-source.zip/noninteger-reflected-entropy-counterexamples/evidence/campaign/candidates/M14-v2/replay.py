"""Independent exact cover traversal and row-LP dual replay of the M14 certificate.
Shares validated spectral envelopes, but not the greedy row optimizer or search.
"""
from pathlib import Path
import numpy as np,json,time
base=Path(__file__).resolve().parent
source=(base/'check.py').read_text().split('\nstart=time.time();')[0]
env={'__file__':str(base/'check.py')};exec(compile(source,'validated_m14_envelopes','exec'),env)
S=env['S'];T=env['TICKS'];N=env['N'];R=env['R0'];L=env['L'];mass=env['massnum'];interval=env['interval'];pnum=env['pnum']
path=base/'reset-cover.npz';rows=np.load(path)['leaves']
leaves={tuple(int(v) for v in row[1:]):int(row[0]) for row in rows};assert len(leaves)==len(rows)
seen=set();nodes=0
def cover(lo,hi):
 global nodes
 nodes+=1;key=tuple(lo+hi)
 if key in leaves:seen.add(key);return
 if sum(lo)>T:return
 widths=[b-a for a,b in zip(lo,hi)];i=widths.index(max(widths));mid=(lo[i]+hi[i])//2
 assert lo[i]<mid<hi[i],('uncovered feasible cell',lo,hi)
 a=hi.copy();a[i]=mid;cover(lo.copy(),a)
 b=lo.copy();b[i]=mid;cover(b,hi.copy())
cover([0]*4,[T]*4);assert len(seen)==len(leaves)

def dual_lower(key):
 lo=np.array(key[:4],dtype=np.int64);hi=np.array(key[4:],dtype=np.int64);hi=np.minimum(hi,T-int(sum(lo))+lo)
 value=np.arange(N,dtype=np.int64)*S
 for j in range(3,-1,-1):
  low,high=interval(lo[j],hi[j]);reach=R+j*(L//2);low=low[:reach+1];high=high[:reach+1]
  order=np.argsort(value);caps=high[:,order]-low[:,order];need=mass-low.sum(1)
  idx=np.argmax(np.cumsum(caps,axis=1)>=need[:,None],axis=1);eta=value[order][idx]
  penalty=(caps*np.maximum(0,eta[:,None]-value[order][None,:])).sum(1)
  dual=low@value+eta*need-penalty
  assert np.all(dual>=0)
  new=dual//S;value=np.r_[new,np.zeros(N-len(new),dtype=np.int64)]
 return int(pnum@value[:R+1])

start=time.time()
for i,(key,expected) in enumerate(leaves.items()):
 got=dual_lower(key);assert got==expected,(key,got,expected)
 if (i+1)%4000==0:print(json.dumps({'replayed':i+1,'total':len(leaves)}),flush=True)
out={'status':'pass','exact_cover_nodes':nodes,'leaves':len(leaves),'row_dual_matches':'all leaves exactly','minimum_numerator':min(leaves.values()),'denominator':S*S,
 'seconds':time.time()-start,'independence':'Separate cover traversal and exact LP dual implementation; shares the separately validated spectral-envelope code.'}
(base/'independent-replay-new.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
