# Causal-comb postselection and a Stein converse: candidate v3

13 November 2026. Same-agent review correction to the R305 candidate. This file is not
an independent certification or a novelty clearance. Original Q114, all finite two-comb pairs. The proposed
conclusion is equality of fully general, nested and parallel weak Stein rates.
The argument would additionally give a fixed-error strong converse. Its two
new interfaces requiring particular scrutiny are the causal-comb domination
in Section 2 and the amplitude-norm transfer in Sections 3--5.


Version note: v2 is retained at
[the frozen R305 proof](proof-pre-correction.md).
This version corrects fixed-tester dual attainment in Section 4; the minimum
in (10) remains attained for the reason given there. See
[the exact counterexample and repair](review/q114-dual-attainment-correction.md).
No theorem statement, operational scope or discovery count changes.

All logarithms in rates are base two. All Hilbert spaces are finite dimensional.
The external slots, in chronological order within one use, are C(input),
A(output), B(input), D(output). Internal memories are not available to a tester.

## 1. Pure-isometry domination with permutation symmetry

Let q<=p be fixed, and let V_n:(C^q)^n -> (C^p)^n be an isometry satisfying
V_n P_pi^(q)=P_pi^(p) V_n for every permutation pi of n factors. Vectors |V>
are unnormalized vectorizations. Let mu be Haar measure on isometries C^q->C^p.
We claim

    |V_n><V_n| <= c_n(p,q) integral |V><V|^tensor n dmu(V),
    c_n(p,q)=binomial(n+pq-1,pq-1).                           (1)

Proof. Schur-Weyl duality decomposes the input and output as
direct sums Q_lambda^(q) tensor W_lambda and Q_lambda^(p) tensor W_lambda.
Write q_lambda,p_lambda for the dimensions of the two Q spaces, and f_lambda
for dim W_lambda. Covariance implies V_n=direct_sum A_lambda tensor I_Wlambda,
where A_lambda^* A_lambda=I on Q_lambda^(q). Only partitions of length <=q
occur in the input; p>=q ensures their output spaces exist.

A fixed isometric inclusion J:C^q->C^p has tensor powers whose same blocks
are isometric inclusions J_lambda. For a Haar unitary U on C^p, V=UJ is a
Haar isometry. Schur orthogonality, including inequivalent lambda blocks,
gives the block of the average Omega_n in (1) as

    (I_p_lambda/p_lambda) tensor I_q_lambda
          tensor |I_Wlambda><I_Wlambda|.                    (2)

The Specht vector has squared norm f_lambda. Thus on its support Omega_n
has eigenvalue f_lambda/p_lambda, while the corresponding component of
|V_n> has squared norm q_lambda f_lambda. Consequently

    <V_n|Omega_n^+|V_n> = sum_lambda p_lambda q_lambda.

For a positive Omega and v in its range, |v><v|<=<v|Omega^+|v> Omega follows
by conjugating by Omega^(-1/2). The Cauchy decomposition of Sym^n(C^p tensor
C^q) identifies the displayed sum with dim Sym^n(C^(pq)), proving (1).
In particular it is polynomial in n for fixed p,q. Specht dimensions cancel;
no exponentially small representation weight is thrown away.

Equation (1) is the maximally mixed marginal specialization of Nahar et al.,
PRX Quantum 5,040315 (2024), Theorem 1 and Appendix A (arXiv:2403.11851v3).
Their Lemma 10 has the same Schur block normalization. The calculation above
is included to fix the unnormalized Choi convention, not as a new lemma.

## 2. Polynomial domination by iid physical two-combs

A deterministic joint n-block two-comb has positive Choi operator R_n obeying

    Tr_D^n R_n = I_B^n tensor E_n,
    Tr_A^n E_n = I_C^n.                                      (3)

Assume R_n is invariant under simultaneous permutations of the n complete
sets of external slots. Set a=d_A, b=d_B, c=d_C, d=d_D, s=ca, t=dbs.
We claim there is a fixed measure on one-copy physical two-combs R(V,W), with
memory dimension s, such that

    R_n <= P(n) integral R(V,W)^tensor n dV dW,
    P(n)=binomial(n+(ca)^2-1,(ca)^2-1)
          *binomial(n+(cabd)^2-1,(cabd)^2-1).                 (4)

The measure is induced by independent Haar isometries
V:C->A S and W:B S->D T, dim S=s and dim T=t. Its members are deterministic
physical combs; they are not arbitrary channels C B->A D that could signal
backwards from B to A.

To prove (4), first take the canonical Stinespring isometry V_n:C^n->A^n S^n
of the marginal channel E_n, with S=C A per copy. Canonical purification of
E_n using its positive square root gives this fixed environment dimension,
including possible unused directions. Since E_n commutes with simultaneous
permutations on C^n A^n, its square root does too. Permutation matrices are
real, so the vectorization construction gives

    V_n P_pi^C = (P_pi^A tensor P_pi^S) V_n.                  (5)

The finite quantum-strategy realization theorem (Gutoski-Watrous, Theorem 6)
gives a CPTP map D_n:B^n S^n->D^n realizing R_n after V_n. To see why this
particular V_n can be used, first take a minimal Stinespring dilation of E_n.
Any other dilation, including the canonical square-root dilation, contains
that minimal memory by a memory isometry. Transport the last-stage channel
along that isometry and extend it outside its image. This proves the claimed
realization with the fixed canonical memory, not only with some unrestricted
memory dimension.
It may initially be defined only on the utilized memory support; extend it
arbitrarily by a CPTP action on the orthogonal complement. Average D_n over
the input permutations B^n S^n and matching output permutations D^n. Equation
(5) and invariance of R_n imply that each conjugated channel realizes the same
R_n with V_n. Therefore its average does as well and is permutation covariant.

The canonical Stinespring isometry of this averaged channel is
W_n:B^n S^n->D^n T^n, with T=D B S per copy. The same square-root argument
shows covariance under the natural factor permutations. Both isometries now
satisfy (1): (p,q)=(as,c) for V_n and (dt,bs) for W_n.

Apply (1) to each pure Choi operator, take their tensor product, and contract
the two S^n legs by the usual maximally entangled link vector; trace the final
T^n environment. This joint contraction is a fixed CP map on the tensor
product of the two Choi operators (a congruence followed by a partial trace),
so it preserves both positive inequalities. Applied to each iid pair V,W it
returns R(V,W)^tensor n. Its constants are c_n(as,c)c_n(dt,bs), exactly P(n).
This proves (4). No memory dimension depending on n except a tensor power of
a fixed space is used.

## 3. A norm for amplitudes of a joint two-comb

Let S_n be the set of deterministic joint n-block two-combs in (3), and T_n
the compact convex set of deterministic physical co-testers for those slots.
Their defining pairing is Tr T R=1 for every R in S_n and T in T_n.
Both sets contain full-rank elements on the external slot space.
For positive Y define

    g_n(Y)=max_{T in T_n} Tr T Y
          =min{lambda>=0: Y<=lambda R for some R in S_n}.     (6)

The equality is the positive-strategy domination duality of Gutoski-Watrous,
quant-ph/0611234v2, Theorem 9, extended by positive scaling to arbitrary Y.
Scaling is legitimate because a sufficiently large full-rank deterministic
comb dominates any fixed positive Y. Finite-dimensional compactness gives
the minimum (with Y=0 treated separately).

For any rectangular matrix Z with rows in the external slot space, define

    ||Z||_n = sqrt(g_n(ZZ^*)).

This is a norm: equivalently it is max_T ||sqrt(T)Z||_F. The existence of a
full-rank co-tester makes it nondegenerate. In addition to the triangle
inequality it obeys

    ||Z C||_n <= ||Z||_n ||C||_op,
    ||Z tensor Z'||_(n+m) <= ||Z||_n ||Z'||_m.                (7)

For the second assertion use (6): if ZZ^*<=u R and Z'Z'^*<=v R', then
(ZZ^*) tensor (Z'Z'^*)<=uv R tensor R', with R tensor R' a legitimate
joint (n+m)-block two-comb. Product co-testers give the reverse inequality,
although only submultiplicativity is needed below. The norm is unchanged
under simultaneous slot permutations. If Z Z^* is deterministic, ||Z||_n=1.

Let R_1,R_2 be the Choi operators of the two fixed unknown combs, and
A=sqrt(R_1), B=sqrt(R_2). Equal-sized environment spaces are allowed by
using these square factors. Put A_n=A^tensor n, B_n=B^tensor n. Their norms
are one. When supp R_1 is contained in supp R_2, there is C_* with

    A=B C_*,  ||C_*||_op<=2^(L/2)                            (8)

for some finite L>=0. For example use C_*=B^+ A and enlarge L if necessary.

## 4. From a weak parallel test bound to a common amplitude

Let d0=D_sc^infinity(Theta_1||Theta_2)<infinity, the known parallel rate.
For r>d0 and n large define the maximal parallel hockey-stick score

    h_n(r)=max_{T in T_n, 0<=Q<=T} Tr Q(R_1^n-2^(nr)R_2^n).

Here superscript n denotes tensor power. Positive Q and T-Q are a valid
binary co-tester. If its outcome probabilities are p,q, their binary relative
entropy is at most n d0. For a nonnegative score p-2^(nr)q, q<=p 2^(-nr);
using binary entropy <=1 gives

    D_bin(p||q) >= p nr-1 >= (p-2^(nr)q)nr-1.

Zero q is handled by the support inclusion or extended-real limit. Thus

    0<=h_n(r)<=(n d0+1)/(nr).                                (9)

The following exact positive-slack formulation is needed:

    h_n(r)=min{g_n(Y): Y>=0, Y>=R_1^n-2^(nr)R_2^n}.           (10)

For fixed T, SDP strong duality gives

    max_{0<=Q<=T} Tr QX = inf_{Y>=0,Y>=X} Tr T Y.

A sufficiently large multiple of I is strictly dual feasible. This proves
equality of the optimal values; it does not imply attainment of the dual
infimum when T is rank deficient. Interchanging maximum
over compact convex T_n and infimum over the convex slack set is legitimate
by the finite-dimensional minimax theorem. A minimizing sequence for the
resulting objective g_n is bounded: a full-rank member T0 of T_n bounds
Tr Y by g_n(Y)/lambda_min(T0). This also proves attainment of (10).

Choose a minimizing Y. The order A_n A_n^*<=2^(nr)B_n B_n^*+Y implies,
by the supported Douglas factorization, a contraction K=(K1;K2) with

    A_n=2^(nr/2) B_n K1 + sqrt(Y) K2.

Set C_n^w=2^(nr/2)K1. Then

    ||C_n^w||_op<=2^(nr/2),
    ||A_n-B_n C_n^w||_n <= sqrt(h_n(r)) <= delta<1            (11)

for all sufficiently large n, with a fixed delta<1 chosen using r>d0.
This is one common matrix C_n^w, valid for every parallel tester. It is not
an input-dependent collection of approximations.

## 5. Exponential amplification in the strategy-amplitude norm

We spell out why the algebra of Gao-Ji-Liu2609.27196 Lemmas 4.4--4.5 applies
to ||.||_n. Their tensor argument needs the triangle inequality, tensor
submultiplicativity, ||A_n||_n=1, the linear maps C->B_n C, and their tensor
compatibility. All were established in (7)--(8); the cost norm of C remains
the ordinary operator norm. No channel-specific operator-norm bound on the
amplitudes is silently assumed.

Here is the argument in those norms. Suppose cost r with error <=delta<1
is available as in (11), and exact cost L is available as in (8). We first
produce vanishing error at every cost S>r. If r>=L, use the exact matrices.
Otherwise put a=1+delta and b=(1+delta)/2<1. Choose beta in (0,1) and k>0
such that for all x in [beta,1],

    ln(2) h_2(x)+(1-x)ln a+x ln b <= -k.                     (12)

This is possible by continuity at x=1. Suppose an accurate cost-S sequence
Y_n=B_n C_n^s has error e_n<=K exp(-gamma n^u), u>0, while
X_n=B_n C_n^w is the weak cost-r sequence. Initially S=L and e_n=0.
For n large, H_n=Y_n-X_n has norm <=delta+e_n<=b and X_n has norm <=a.
In (X_n+H_n)^tensor m retain only terms with at most floor(beta m) factors
H_n. By (7), (12) and the binomial entropy estimate, the omitted norm is
at most (m+1)exp(-km). Every retained term has a preimage under C->B_nm C,
using C_n^w for X_n and C_n^s-C_n^w for H_n. Summing their cost norms gives

    ||C_nm||_op <= 3^m 2^[nm((1-beta)r+beta S)/2].            (13)

The additional error relative to A_nm is at most m e_n(1+e_n)^(m-1), by
telescoping Y_n^tensor m-A_n^tensor m. For a general large N choose
n=floor(sqrt N), m=floor(N/n), and pad the fewer than n remaining factors
with the exact map C_* tensor powers. This changes the normalized cost by
o(1); the error remains stretched exponential with power at least u/2.
Hence an accurate cost S implies every accurate cost S'>(1-beta)r+beta S.
Iterating finitely many times from L approaches r and establishes vanishing
error for any chosen S>r. The number of iterations is fixed before N grows.

To obtain an exponential rather than stretched-exponential error, choose
r<S<R and one sufficiently accurate fixed block of length k at cost S.
Let X=B_k C_k and H=A_k-X=B_k(C_*^tensor k-C_k) be its exact residual,
with ||H||_k<=epsilon_k tending to zero as k is chosen large. Choose a small
eta>0 with S+eta(L-S)<R (or use exact cost if R>=L). Expand
(X+H)^tensor m=A_km, retaining terms with at most eta m residuals. With
z=4^(1/eta), a block with epsilon_k<=1/(1+z) has omitted norm at most

    z^(-eta m)(1+epsilon_k+z epsilon_k)^m <= 2^(-m).          (14)

The cost is at most 3^m 2^[km(S+eta(L-S))/2]. Taking k still larger ensures
S+eta(L-S)+2log_2(3)/k<R. Pad the fewer than k remaining factors exactly;
this adds a bounded cost and leaves exponential error in total N. Reserving
a strict margin below R absorbs that bounded cost for all sufficiently large
N. It follows that, for every R>d0, there are K,gamma>0 and C_n satisfying

    ||C_n||_op<=2^(nR/2),
    ||A_n-B_n C_n||_n <= K exp(-gamma n).                    (15)

Tensor powers of auxiliary matrices retain compatible domains. The weak
slack supplies a common approximation, while the exact residual makes the
final fixed-block exponential expansion an exact algebraic identity.

## 6. Controlling a fully general interleaving

Average C_n over matching permutations of its input/output environment factors.
A_n and B_n intertwine the corresponding external permutations, and the norm
||.||_n is invariant and convex. This averaging preserves both bounds (15)
and ensures the residual H_n=A_n-B_n C_n has permutation-invariant
Y_n=H_n H_n^*. By (6) choose a deterministic joint comb S_n with

    Y_n <= e_n^2 S_n,  e_n=K exp(-gamma n).

Average S_n as well, which preserves this inequality. Section 2 gives

    Y_n <= e_n^2 P(n) integral R(V,W)^tensor n dVdW.          (16)

Fix ANY causally valid fully general n-use tester in the original problem.
Its deterministic operator T_gen is positive, and its null-acceptance effect
Q_gen obeys 0<=Q_gen<=T_gen. A circuit derivation of their positivity can be
obtained by expressing each slot link as a Bell contraction of Choi operators
and the tester Kraus vectors; summing branches gives positive operators.
Normalization of that physical tester gives

    Tr T_gen R^tensor n = 1                                 (17)

for every deterministic one-use physical comb R. Each matched first part
precedes its second part; replacing the unknown pair by any one R therefore
leaves a deterministic acyclic circuit. It is NOT asserted that T_gen is in
T_n or normalizes an arbitrary correlated joint n-block comb. Equation (4)
is precisely what converts (16) into a usable bound despite this distinction.
Adaptive classical choices of the causal ordering are included by summing
the positive branch operators of the same deterministic protocol.

Put p=Tr Q_gen R_1^n and q=Tr Q_gen R_2^n. Frobenius triangle inequality,
the cost bound (15) and (16)--(17) give

    sqrt(p) = ||sqrt(Q_gen) A_n||_F
       <= ||sqrt(Q_gen) B_n||_F ||C_n||_op
            + ||sqrt(Q_gen) H_n||_F
       <= 2^(nR/2) sqrt(q) + sqrt(P(n)) K exp(-gamma n).     (18)

For a desired type-II exponent R'>d0, choose d0<R<R'. If q<=2^(-nR'),
both terms in (18) decrease exponentially in n because P is a fixed-degree
polynomial. Therefore null acceptance tends to zero exponentially, uniformly
over all such testers and all of their finite memories. In particular no
fixed type-I tolerance below one permits a rate above d0. This implies the
weaker vanishing-type-I converse required by Q114.

## 7. Original coverage and infinite support case

One legal parallel tester stores A after the first part and feeds a fresh
half maximally entangled state into B, with a maximally entangled initial C.
It reads the normalized comb Choi state R_i/(d_C d_B). Consequently failure
of supp R_1 subset supp R_2 implies infinite parallel Stein rate. In that
case the nested and fully general rates are also infinite, so no strict
advantage in the extended-real sense occurs. If d0<infinity the same readout
implies support inclusion, supplying the exact matrix C_* in (8).

The known parallel coding theorem (Hirche2103.02404v2 Section5.3) attains d0,
by repeating any fixed joint block and using state Stein testing. Parallel
strategies are contained in nested strategies and the original fully general
class. Combining this inclusion, achievability and (18) would prove

    zeta_fg = zeta_nested = zeta_parallel = D_sc^infinity     (19)

for every finite pair, the negative answer to the existence alternative in
Q114. All original finite dimensions, hidden memories and allowed causal orders
are covered by the stated argument. Equality for nested versus parallel also
follows; that overlap with the R304 Q074 candidate is inherited coverage and
must not be counted as a second new contribution of this proof.

## Sources, attribution and review obligations

The inherited ingredients are Schur-Weyl pure fixed-marginal domination,
strategy domination duality, the two-rate tensor algebra of Gao-Ji-Liu,
positive-slack reasoning in the ordinary-channel work of Zhu-Wang, and
Hirche's parallel rate and strategy definitions. The proposed added interfaces
are causal two-stage postselection with physical iid factors, the positive
strategy gauge as the amplitude norm, and its use under interleaving testers.
Novelty remains unresolved; a bounded search is not a priority certificate.

The earlier self-review in review/self-review-prior.json scrutinizes the exact canonical-memory covariance,
existence and covariant extension of D_n, the Schur normalization in (2),
the common-slack minimax, tensor submultiplicativity and the general tester's
positivity/normalization. These remain the critical interfaces for a separate independent review.
Self-review is fallible, and no finite test certifies the all-dimensional theorem.

Costa-Barrett-Shrapnel (arXiv:2403.10316v3, Quantum 9,1628 (2025)) prove an
infinite exchangeable-process representation and explicitly leave finite
versions open in Section 8. Their theorem does not supply (4): here each n
may be chosen separately, with no symmetric extension assumed. Our claim is
polynomial positive-order domination, not a trace-distance approximation to
all n factors. This distinction avoids contradicting the non-extendible
examples discussed in that paper. The extent to which the two-stage argument
has appeared elsewhere is still a literature question.

- https://arxiv.org/html/2103.02404v2
- https://arxiv.org/html/2609.27196v1
- https://arxiv.org/html/2609.30268v1
- https://arxiv.org/html/quant-ph/0611234
- https://doi.org/10.1103/PRXQuantum.5.040315

- https://arxiv.org/html/2403.11851v3
- https://arxiv.org/html/2403.10316v3
