# mixed-unitarity-semigroup

Working draft dated 16 September 2026. Authorship updated 17 September 2026.

Author: Yuxuan Zhang

Affiliations:
- Department of Physics, Princeton University, Princeton, New Jersey 08544, USA
- Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland

The proof was generated and internally reviewed by AI agents in the QIQC
research workflow. External expert confirmation and literature novelty
remain unverified. Internal PASS is not a formal proof-assistant certificate.

Files:
- mixed-unitarity-semigroup.pdf: full manuscript (6 pages).
- mixed-unitarity-revival.tex: standalone LaTeX source.
- provenance.json: scope, review status, and manuscript hashes.

Compile twice with a standard TeX Live installation:

    pdflatex mixed-unitarity-revival.tex
    pdflatex mixed-unitarity-revival.tex

Original problem: https://qiqc-op.com/problem/op_722706a9205dcff2/
Article: https://yuxuanzhang1995.github.io/agentic-research/mixed-unitarity-semigroup/

Supplementary diagnostic:

    python -m pip install numpy scipy
    python supplementary_check.py

This uses floating-point arithmetic to check the endpoint identity and
witness formula. It is not a proof certificate; the manuscript contains
the analytic argument and strict rational negative bound.

Attribution: the dissipative construction and twisted-swap method come
from Bhat–Devendra, arXiv:2512.23598v3, Lemmas 5.5–5.7 and Example 5.11.
The proposed addition is the Hamiltonian and exact two-time construction.
