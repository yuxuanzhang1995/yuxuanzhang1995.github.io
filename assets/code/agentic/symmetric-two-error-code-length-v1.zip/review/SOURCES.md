# Q005 v1 — primary-source comparison

Reviewed 2026-11-10. These are public primary sources. The bounded search used variants of permutation-invariant/symmetric/spin codes, distance five/two errors, nineteen/minimum/lower bound, and SDP/three-copy/PPT. Search results were navigation; the judgments below use the indicated theorem or section text. No other local campaign or chat was consulted. Latest arXiv metadata was checked for the five works cited by v1; it showed the versions below. Absence from this search is not an exhaustive priority guarantee.

## Imported upper bound

**Aydin, Alekseyev and Barg, Quantum 8, 1321 (2024), arXiv:2310.05358v3.** [Published article](https://doi.org/10.22331/q-2024-04-30-1321), [Section 7](https://arxiv.org/html/2310.05358v3#S7).

Definition 2.3 permits complex Dicke coefficients. Section 7 Eq. (32) then fixes an odd-length parity form; Proposition 7.1 assumes real coefficients. Its end reports a nineteen-qubit distance-five solution and states that msolve produces intervals containing exact solutions, followed by a Mathematica check. This supports importing existence, not treating the printed rounded decimals as exact. The preceding no-shorter-code remark is within that restricted section and supplies no unrestricted proof. Theorem 5.3 and Example 5 supply the exact twenty-one-qubit control. The reviewer did not rerun the original nineteen-qubit root isolation.

## Closest minimum-length claims

**Bond, Minář, Ozols, Safavi-Naini and Visnevskyi, arXiv:2603.10981v1.** [Section 3.1 and Conjecture 3.1](https://arxiv.org/html/2603.10981v1#S3.SS1).

The numerical search includes unrestricted complex coefficients and the PR family. Conjecture 3.1 proposes the general minimum formula; its t=2 value is nineteen. Neither unsuccessful local searches nor the coefficient symmetries in Section 3.2 are a proof excluding all shorter complex codes. The candidate settles this fixed t case if its reduction and certificates are valid.

**Kubischta and Teixeira, arXiv:2310.17652v3, IEEE TIT 71 (2025).** [Theorem 1 and Section IV-C](https://arxiv.org/html/2310.17652v3).

Theorem 1 assumes binary-dihedral covariance and real codewords. Section IV-C derives a nineteen-qubit distance-five prediction from a parameter-counting conjecture; Table III reports numerical constructions at a stated tolerance. The scope and method do not establish an unrestricted nineteen-qubit minimum. The Dicke correspondence and the earlier prediction deserve attribution independently of the later Bond conjecture.

## Scalar bounds and their exact scope

**Okada, A Quantum Analog of Delsarte’s Linear Programming Bounds, arXiv:2502.14165v1 (2023 dissertation, uploaded 2025).** [Primary PDF](https://arxiv.org/pdf/2502.14165v1).

Theorem 3.2.2 and Example 3.2.2 give the scalar SU(2) LP and 6j coefficients; Theorem 3.3.1 and Example 3.3.2 give shadows. Section 2.3.2 uses dimension n+1, matching the qubit-length parameter. Table 3.1 (printed p.89, PDF page 93) reports d=5 bounds 1 at n=17, 2.019 at n=18, and 2.096 at n=19. K=2 remains allowed at eighteen. The preceding exact-GLPK comparison concerns smaller cases without specifying a cutoff. This is earlier overlap and methodological priority omitted from v1’s bibliography.

**Bumgardner, Codes in W*-metric Spaces: Theory and Examples, arXiv:1205.4517v1 (2011 dissertation, uploaded 2012).** [Primary PDF](https://arxiv.org/pdf/1205.4517v1).

Theorem 4.2.1 states the projector enumerator inequality. Theorem 4.4.1 and Section 4.5 derive the SU(2) weight-enumerator relation using 6j symbols and the resulting LP. This is earlier methodological priority, not a located proof of the nineteen-qubit minimum.

**Kubischta and Teixeira, arXiv:2604.16023v2.** [Appendices A–B](https://arxiv.org/html/2604.16023v2).

Appendix A gives the scalar SU(2) transform; Theorem B1, Lemma B1 and Proposition B2 identify the compressed physical weight filtration with intrinsic depth for symmetric powers. Appendix B-D proves the seven-qubit distance-three extremality result. The matrix theory of Section III concerns multiplicities in the conjugation representation on End(V); SU(2) End(V_j) is multiplicity-free. This is distinct from the three-copy multiplicities used in v1, and does not state its distance-five exclusion.

**Teixeira, arXiv:2605.15372v1.** [Corollary 1, Section VII](https://arxiv.org/html/2605.15372v1#S7).

Corollary 1 Eq. (79), with the q=2 specialization Eq. (87), provides the scalar Racah transform; Section VIII gives its orthogonality and involutivity. This supplies coefficients and established structure. It does not itself prove the minimum nineteen.

## Higher-moment and rational-SDP antecedents

**Anglès Munné, Nemec and Huber, arXiv:2408.10323v2.** [Theorem 7 and the finite SDP construction](https://arxiv.org/html/2408.10323v2).

Theorem 7 proves completeness of a state-polynomial SDP hierarchy for general quantum-code existence. This establishes higher-moment coding bounds as prior methodology. It neither restricts to Sym^n nor supplies the present SU(2)/S3 PPT certificates.

**Anglès Munné and Huber, arXiv:2603.19901v1.** [Sections 3–4](https://arxiv.org/html/2603.19901v1).

Section 3.1 uses a cubic moment matrix; Sections 4.1–4.2 and Table 1 give rationally certified bounds for general codes. This is clear prior art for exact SDP certificate extraction, not a located symmetric distance-five minimum theorem. General codes of length below nineteen exist, so their displayed unrestricted-code bounds cannot be substituted for the symmetry-specific exclusion.

## Additional current nearby work screened

**Aydin, Albert and Barg, arXiv:2509.20545v3 / PRX Quantum 7, 010341 (2026).** [Theorem VII.5, Section VII.3 and Theorem VIII.4](https://arxiv.org/html/2509.20545v3).

These are existence constructions via classical codes and convex partitions. The near-linear-distance asymptotics permit q=N rather than fixing the physical alphabet to qubits. They do not supply an all-complex lower bound at n=18 for q=2.

**Kubischta and Teixeira, arXiv:2605.22439v1.** [Theorem 4, Section IX](https://arxiv.org/html/2605.22439v1#S9).

The exact minimum of four physical qudits concerns dimension q and distance at least two. It is a different distance target from Q005.

**Ouyang and Brennen, arXiv:2602.13638v1.** [Section III.5](https://arxiv.org/html/2602.13638v1).

The work constructs recovery procedures for errors already correctible by a PI code. The displayed bound on correctible error sectors is not the asserted nineteen-qubit minimum.

## Contribution judgment

No equivalent unrestricted minimum-nineteen theorem was located in the reviewed sources. The distinction supported by this search is the exact exclusion at eighteen, with a sufficient set of necessary three-copy PPT conditions and a verified rational dual witness. Existence at nineteen, scalar enumerator/shadow theory, spin recoupling, symmetry reduction, higher-moment SDP methodology, and rational certification are inherited. The ten certificates also make the full lower-bound argument self-contained without depending on a precise certification cutoff for Okada’s table. Novelty is supported relative to these sources; universal priority is not certified.
