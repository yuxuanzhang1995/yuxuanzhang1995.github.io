# A discontinuous exact QFI cost at fixed rank and finite resources

There is a computably presented one-parameter family of finite-dimensional Gibbs-preserving channels with two independent energy generators throughout the instances below. Every instance admits a finite exact implementation. Its exact optimal QFI has a jump of more than \(19/25\) after subtraction of a known continuous baseline. In particular no ordinary uniform algorithm on Cauchy names of arbitrary computable input data can approximate this cost to additive \(1/4\), even if supplied the correct integer energy labels, the common dimension and a finite seed. This concerns the numerical representation of general physical real inputs. It does not contradict the effective theorem for algebraic gap ratios and algebraic sector coefficients.

## A positive matrix constraint with a removable real-frequency quotient

Write \(E_n=n_1+\alpha n_2\), \(1/2<\alpha<1\), and use two real Laurent variables \(x,y\). Set
\[
 u=2+x+x^{-1},\quad v=y+y^{-1}+6/5,\quad h=u+v^2,\quad a=u^8,\quad
 h_2=h+\delta a,\qquad \delta=10^{-22}.
\]
All coefficients of \(h,a,h_2\) are nonnegative. The common zeros of \(h\) and \(h_2\) on the unit torus are \(x=-1,\ y=(-3\pm4i)/5\). There \(u=0\) and \(v=0\). The Laurent polynomials \(h,h_2\) are coprime: any common irreducible must divide \(u^8\), whose sole nonunit factor is \(x+1\), and \(h(-1,y)=v^2\) is not the zero polynomial.

Impose diagonal matrix coefficients \(C=\operatorname{diag}(f_1,f_2)\), \(f_1,f_2\) coefficientwise nonnegative, with the equation \(h_2 f_1=h f_2\) and normalized terminal ratio \(f_1(1):f_2(1)=h(1):h_2(1)\). Coprimeness implies \(f_1=hq,\ f_2=h_2q\) for a finite *signed* Laurent \(q\), separately on each coset when the atoms have real energies. The seed \((h,h_2)\) is positive and both its coefficients at zero are greater than one. Let \(\tau\) be the normalized trace probability \((f_1+f_2)/(f_1(1)+f_2(1))\).

Take \(\theta=\arccos(-3/5)\) and \(\alpha_*=\theta/\pi\). This ratio is irrational: \((-3+4i)/5\) is not a root of unity, since its sum with its inverse is the rational noninteger \(-6/5\), whereas that sum for a root of unity is an algebraic integer. At physical time \(t=\pi\), both \(h,h_2\) vanish, so \(\widehat\tau(\pi)=0\) for *every* finite exact tuple. Real coset translations only contribute a phase to each vanishing term. Centering at the mean and using \(\cos z\ge1-z^2/2\) gives
\[
 \operatorname{Var}(\tau)\ \ge\ 2/\pi^2\ >\ 1/5.                       \tag{1}
\]

## Uniform upper bound away from the resonance

When the actual trajectory misses the two common zeros, there exist finite positive exact tuples with trace variance less than \(1/100\). This holds uniformly for all such \(\alpha\in(1/2,1)\). Here are constants and the positivity repair.

Use the norm \(\|s\|_w=\sum_n(1+E_n^2)|s_n|\), with \(\|s*t\|_w\le2\|s\|_w\|t\|_w\). On the unit torus let \(R=a/h\) and set it to zero at the two zeros. With \(M=16\) and \(k=8\), \(0\le u\le h<M\). For either angular variable, its derivatives through order six obey
\[
 |\partial^j R|\le C_j h^{k-j-1},\qquad
 C_0=1,\quad C_j=(4k)^j+\sum_{i=1}^j {j\choose i}(2M)^i C_{j-i}.
\]
Indeed \(|\partial^j u^k|\le(4k)^j u^{k-j}\) by the product rule and \(|\partial^i h|\le M2^i\) by its positive coefficients and degree. Differentiate \(hR=u^k\) inductively. The same majorants apply to mixed partials by the multivariate product rule. All derivatives through order six tend to zero at the two omitted points. Extending by zero gives \(C^6\), by induction along coordinate lines or the mean value theorem. Integration by parts at the largest coordinate of \(n\) gives \(|\widehat R_n|\le C_6 M^{k-7}/\|n\|_\infty^6\) for \(n\ne0\). There are \(8N\) indices on shell \(N=\|n\|_\infty\), \(|E_n|\le2N\), and \(\sum N^{-3}<2\). Hence
\[
 \|\widehat R\|_w\le K=M^{k-1}+80 C_6 M^{k-7}
 =12\,872\,532\,650\,622\,976 .                                       \tag{2}
\]

From the positive autocorrelation construction of [F26](physical-time-filter.md), choose a smooth \(\kappa\) vanishing in a neighborhood of the zeros of \(h\), whose Fourier coefficients form a symmetric probability with arbitrarily small variance \(\xi<1\). This argument only uses a compact physical time segment at a time. The smooth function \(\kappa/h\) extended by zero can be approximated in weighted Fourier norm by a finite real even Laurent \(q\), normalized so \(h(1)q(1)=1\). Given \(\eta>0\), the resulting \(h q\) and \(h_2q\) differ in that norm by less than \(\eta\) each from \(\kappa\) and \(\kappa+\delta R\kappa\), respectively (symbols stand for their Fourier coefficients in this norm).

At each site let \(d_n=\max(0,-[hq]_n,-[h_2q]_n)\). Its weighted sum is at most \(2\eta+4\delta K\), since \(\|\widehat\kappa\|_w<2\). Add \(d_n x^{n_1}y^{n_2}(h,h_2)\) at every defect site. These additions are positive away from the repaired sites, dominate the deficits there, and satisfy the exact same equation and terminal ratio. Their weighted trace contribution is at most \(2S(2\eta+4\delta K)\), where
\[
 S=\|2h+\delta a\|_w\le 2\cdot 5M+\delta(1+8^2)4^8<200.
\]
Before repair the raw trace second moment about zero was at most \(2\xi+2\eta+4\delta K\); its normalized mass after repair is at least two, so even omitting division gives a safe upper bound. Sending \(\xi,\eta\) to zero yields
\[
 \inf\operatorname{Var}(\tau)\le 4\delta K(1+400)<1/100.              \tag{3}
\]
This is a true variance bound for *finite* exact witnesses. A bare zero of a scalar retraction denominator alone would have proved no such physical effect.

## Turning the trace dispersion into the charged GP-channel optimum

The [earlier linear encoding](physical-realization.md) realizes the three real constraints \(h_2 f_1-h f_2=0,\ \operatorname{Re} C_{12}=\operatorname{Im} C_{12}=0\) on a two-dimensional degenerate-energy input code. Take the terminal Gram proportional to \(\operatorname{diag}(h(1),h_2(1))\). Use its recipe with support \(E\) equal to the union of the coefficient exponents, zero, and both coordinate unit vectors. At each exponent the coefficient map is \(\operatorname{Tr}(C)I+\epsilon_0\sum_j D_{j,\nu}(C)Z_j\) for three independent traceless Hermitians. A common positive rational \(\epsilon_0\) small enough for strict Choi positivity exists effectively and is independent of \(\alpha\). The minimal Kraus coordinates and code channel are therefore fixed. Output energies are \(E_n\) with the fixed multiplicities prescribed by the encoding. For *every* exact tuple the scalar sector equation fixes its clock distribution to be a translate of
\[
 \nu_\alpha *\tau,\qquad
 \nu_\alpha=|E|^{-1}\sum_{a\in E}\delta_{a_1+\alpha a_2}.
\]
Conversely every normalized positive tuple gives such a clock for the exact code channel. For multiple cosets, the same convolution holds on their union with the common translated kernel. Variances add. Optimized finite purification accounts for arbitrary mixed resources. The exact code QFI is thus \(4\operatorname{Var}(\nu_\alpha)+4\inf\operatorname{Var}(\tau)\).

The original feasibility-only Gibbs completion could charge an extra coherent state. Instead, write \(b\) for the output dimension and take \(b\) orthogonal copies of the input code, each at the same large integer energy \(L\), plus one flag at energy zero. On copy \(j\) use \(U_j\Phi_{\rm code}(\cdot)U_j^*\), with \(U_j|l\rangle=\exp(2\pi i j l/b)|l\rangle\) in the output energy basis. Discard input coherences between copies and flag. The sum of the conjugated code images of \(I\) is diagonal by finite phase averaging. If \(a_L=e^{-L}/(1+2b e^{-L})\) is the Gibbs weight of each code basis state, prepare on the flag
\[
 \sigma_\alpha=\frac{\gamma_B-a_L\sum_{j=0}^{b-1}U_j\Phi_{\rm code}(I)U_j^*}{1-2b a_L}.
\]
This has unit trace and is stationary. One fixed finite \(L\) works for all \(\alpha\in(1/2,1)\): all output energies lie in \([-8,8]\), \(\lambda_{\min}(\gamma_B)\ge e^{-16}/b\), and each positive code image of \(I\) has trace two. Take, for instance, \(L=32+2b+2\). The full channel is exactly GP. Restricting an implementation to copy zero gives the code-cost lower bound by an intertwining input embedding. Conversely use the same program for all copies, apply the commuting \(U_j\) conditionally, and use one stationary copy of \(\sigma_\alpha\) on the flag. Stationary ancillary resources and the sharp blanks needed for finite covariant completion add zero QFI in the original coherence model. This proves equality with the code optimum, at every parameter in this family. The construction supplies no uncharged work resource to the separate battery problem.

## A fixed gap in the value, with the lattice rank supplied

Let \(V(\alpha)=F_c^0(\Phi_\alpha)-4\operatorname{Var}(\nu_\alpha)\). The subtracted function is an explicit quadratic polynomial in \(\alpha\). Equations (1) and (3) show \(V(\alpha_*)>4/5\), while \(V(\alpha)<1/25\) if the two exceptional characters are missed. Choose quadratic irrational \(\alpha_j\to\alpha_*\) effectively with \(|\alpha_j-\alpha_*|<2^{-j}\) and \(1/2<\alpha_j<1\). For instance add a sufficiently small rational multiple of \(\sqrt2\) to a certified interior dyadic approximation. At \(x=-1\) physical time is an odd multiple of \(\pi\). The other coordinate there is a branch of \((-1)^{(2k+1)\alpha_j}\), transcendental by Gelfond–Schneider and hence unequal to either of the algebraic prescribed phases. The same degree-two energy labels are valid at every \(\alpha_j\) and at \(\alpha_*\).

For a machine \(M\) supply Cauchy names of the family at \(\alpha_*\) if it never halts and at \(\alpha_{j+4}\) if it halts at step \(j\). These names are uniform: to obtain \(n\) bits simulate a sufficient finite prefix; all later switches differ by less than the desired error. The Choi data including the stationary flag are computable continuous functions of \(\alpha\) and the fixed code matrices. The finite exact seed is the same pair of coefficient polynomials for all parameters, together with the stationary flag. A purported uniform additive \(1/4\) cost algorithm, after subtracting the explicit baseline with small additional tolerance, would distinguish the two disjoint value ranges and decide halting. No number-theoretic conjecture is used. This result concerns a uniform family of named computable real data; it does not show noncomputability for algebraic inputs alone or for a fixed individual channel.
