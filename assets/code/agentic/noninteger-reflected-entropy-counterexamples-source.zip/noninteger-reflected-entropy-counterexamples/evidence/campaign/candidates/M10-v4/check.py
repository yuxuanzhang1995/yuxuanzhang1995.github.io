"""Read the frozen witness; validate it by exact and independent numerical routes."""
from pathlib import Path
from fractions import Fraction as F
import json, sys
import numpy as np
import sympy as sp

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from rational_interval import I

def interval_spectrum(d):
    e=I(F(1,4));d=I(d)
    a=(e+d)/2;b=((e-d)**2+4*e**2).sqrt()/2
    eigenvalues=[(1+s*a+t*b)/4 for s in [1,-1] for t in [1,-1]]
    assert all(v.lo>0 for v in eigenvalues)
    return eigenvalues

def trace_power_half_integer(values,power):
    assert power%2==1
    return sum((x**((power-1)//2)*x.sqrt() for x in values),I(0))

def canonical_reflection(probability,dim_a):
    # Explicit vectorization of sqrt(rho), then trace by a tensor contraction.
    dim_x=probability.size//dim_a
    rho=np.diag(probability.reshape(-1))
    sqrt_rho=np.diag(np.sqrt(np.diag(rho)))
    psi=sqrt_rho.reshape(dim_a,dim_x,dim_a,dim_x).transpose(0,2,1,3).reshape(dim_a*dim_a,dim_x*dim_x)
    return psi@psi.conj().T

def main():
    witness=json.loads((HERE/'witness.json').read_text())
    dims=witness['dimensions'];assert dims==[4,8,2] and F(witness['alpha'])==F(5,2)
    rational={tuple(v['abc']):F(v['p']) for v in witness['probabilities']}
    assert len(rational)==len(witness['probabilities'])
    assert sum(rational.values())==1 and all(p>=0 for p in rational.values())
    assert all(all(0<=i<n for i,n in zip(k,dims)) for k in rational)
    # Reconstruct exact Gram matrices directly from the actual probability table.
    def prob(a,b,c):return sp.Rational(rational.get((a,b,c),F(0)))
    exact_full=sp.Matrix(4,4,lambda a,d:sum(sp.sqrt(prob(a,b,c)*prob(d,b,c)) for b in range(8) for c in range(2)))
    exact_reduced=sp.Matrix(4,4,lambda a,d:sum(sp.sqrt(sum(prob(a,b,c) for c in range(2))*sum(prob(d,b,c) for c in range(2))) for b in range(8)))
    expected_full=sp.eye(4)/4
    for i in range(3):expected_full[i,i+1]=expected_full[i+1,i]=sp.Rational(1,16)
    expected_reduced=expected_full.copy();expected_reduced[0,3]=expected_reduced[3,0]=sp.Rational(1,40000)
    assert exact_full==expected_full and exact_reduced==expected_reduced
    # Verify the analytic spectrum by a symbolic characteristic polynomial.
    d,e,z=sp.symbols('d e z',real=True)
    matrix=sp.Matrix([[1,e,0,d],[e,1,e,0],[0,e,1,e],[d,0,e,1]])
    blocks=((z-1-d)*(z-1-e)-e**2)*((z-1+d)*(z-1+e)-e**2)
    polynomial=matrix.charpoly(z)
    assert sp.expand(polynomial.as_expr().subs(polynomial.gen,z)-blocks)==0
    full=trace_power_half_integer(interval_spectrum(F(0)),5)
    reduced=trace_power_half_integer(interval_spectrum(F(1,10000)),5)
    gap=full-reduced
    assert gap.lo>F(14,10**9) and gap.hi<F(15,10**9)
    entropy_lower=F(2,3)*gap/full
    assert entropy_lower.lo>F(6,10**8)
    integer_controls={}
    for alpha in [2,3]:
        difference=sp.trace(exact_full**alpha)-sp.trace(exact_reduced**alpha)
        assert difference<0
        integer_controls[str(alpha)]=str(difference)
    p=np.zeros(dims)
    for k,v in rational.items():p[k]=float(v)
    Rfull=canonical_reflection(p,4)
    Rreduced=canonical_reflection(p.sum(axis=2),4)
    index=[0,5,10,15]
    assert np.max(np.abs(Rfull[np.ix_(index,index)]-np.array(exact_full,dtype=float)))<1e-14
    assert np.max(np.abs(Rreduced[np.ix_(index,index)]-np.array(exact_reduced,dtype=float)))<1e-14
    values1=np.linalg.eigvalsh(Rfull);values2=np.linalg.eigvalsh(Rreduced)
    assert min(values1.min(),values2.min())>-1e-14
    numerical_gap=float(np.sum(np.maximum(values1,0)**2.5)-np.sum(np.maximum(values2,0)**2.5))
    assert abs(numerical_gap-float((gap.lo+gap.hi)/2))<1e-14
    out={'witness_state':'exactly positive semidefinite and trace one','exact_gram_reconstruction':'pass',
         'exact_characteristic_polynomial':'pass','trace_full_5_over_2':full.decimal(),
         'trace_reduced_5_over_2':reduced.decimal(),'certified_trace_reverse_gap':gap.decimal(),
         'certified_entropy_gap_lower_bound':str(F(6,10**8)),
         'integer_controls_trace_full_minus_reduced':integer_controls,
         'explicit_canonical_purification_numeric_gap':numerical_gap,
         'scope':'counterexample to the exact universal M10 statement; novelty and external review separate'}
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
