# Direct physical realization of the resonance using two pure preparations

This gives a second, smaller channel for the jump in [the analytic proof](resonance-jump.md). It uses a classical input and explicit pure states. No universal encoding of polynomial modules is needed.

Let \(h,h_2,H=h(1),H_2=h_2(1),\delta\) and \(E_n=n_1+\alpha n_2\) be as in that proof. Write \(b_1=h/H,\ b_2=h_2/H_2\) for the two normalized finite probabilities. The union of their supports has \(b=21\) labels: \((j,0)\) for \(-8\le j\le8\) and \((0,j)\) for \(j=-2,-1,1,2\). Use them as an output energy basis, and define
\[
 |\psi_i\rangle=\sum_n \sqrt{(b_i)_n}|n\rangle,\qquad i=1,2.
\]
On a degenerate input qubit at energy \(L\), measure the standard basis and prepare \(\psi_i\) on outcome \(i\). Its independent Kraus operators are \(K_i=|\psi_i\rangle\langle i|\).

At each physical total energy the two diagonal sector identities require, up to translation by \(L\), \(p=b_1*C_{11}=b_2*C_{22}\). The off-diagonal equation is the convolution of \(C_{12}\) with the overlap polynomial \(\sum_n\sqrt{(b_1)_n(b_2)_n}\,x^{n_1}y^{n_2}\), which is nonzero. The finite Laurent ring on each energy coset is an integral domain, so \(C_{12}=0\). Thus \(C_{11},C_{22}\) are finite nonnegative probabilities, each of total mass one on aggregating the cosets. Coprimeness forces \(C_{11}=(h_2/H_2)q,\ C_{22}=(h/H)q\) on each coset for some finite signed \(q\), with the global \(q\) of mass one. The converse follows directly by factoring the two diagonal Gram coefficients on each occupied energy. In particular the common choice \(q=\delta_0\) gives an explicit finite seed at every \(\alpha\).

For each program its exact charged cost after centering equals four times
\[
 \operatorname{Var}(b_1)+\operatorname{Var}(C_{11}),\qquad
 \operatorname{Var}(b_1)=\frac{2+(64/5)\alpha^2}{356/25}.
\]
At \(\alpha_*=\arccos(-3/5)/\pi\), every \(C_{11}\) has characteristic function zero at time \(\pi\), and variance at least \(2/\pi^2\). At an off-resonant \(\alpha\), take the repaired pair \((f_1,f_2)\) in the analytic proof. Put \(C_{11}=f_2/f_2(1)\) and \(C_{22}=f_1/f_1(1)\). Their ratio identities give exactly the same \(p\). The unnormalized second-moment bound in that proof applies also to \(f_2\) since the repaired pair is nonnegative, and \(f_2(1)\ge1\). Consequently \(\inf\operatorname{Var}(C_{11})<1/100\) there.

For an entirely explicit GP completion, take \(b=21\) copies of the input qubit at \(L=24\) and one flag at energy zero, giving input dimension 43. In copy \(j\) apply the same preparations followed by the commuting diagonal phase \(U_j\) from the analytic proof. Discard all input coherences. The sum of the two averaged output distributions is exactly \(b_1+b_2\). With \(a_L=e^{-24}/(1+42e^{-24})\), use the diagonal flag distribution
\[
 (\sigma_\alpha)_n=\frac{(\gamma_B)_n-21a_L((b_1)_n+(b_2)_n)}{1-42a_L}.
\]
It is faithful, since \(\min_n(\gamma_B)_n\ge e^{-16}/21\) and \(42e^{-24}<e^{-16}/21\) (equivalently \(882<e^8\)). Its trace is one. Restriction to copy zero gives the prep-cost lower bound. A program for the prep channel implements the other copies by commuting phase gates, and can discard one stationary flag resource on the branch on which it is needed; that resource contributes zero QFI. Thus the charged QFI of this **43-input, 21-output, Gibbs-preserving measure-and-prepare channel** has the two disjoint ranges after subtracting \(4\operatorname{Var}(b_1)\). The input/output spectra are finite, the independent energy rank is exactly two, and the target varies continuously in the Hamiltonian parameter. The statement is about the infimum of the cost of exact implementation and includes mixed finite resources.
