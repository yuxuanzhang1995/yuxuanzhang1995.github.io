"""Stress the exceptional quadratic mode, rotating kernel and positive tail."""
import sympy as sp


x = sp.symbols("x", real=True)


def shift(f, n):
    return sp.expand_trig(f.subs(x, x+n)).simplify()


def project(pair):
    a, b = pair
    return tuple(sp.expand(t) for t in ((a+shift(b,1))/2, (shift(a,-1)+b)/2))


def apply_row(pair, multiplicity):
    a, b = pair
    rem = a-shift(b, 1)
    return sp.simplify(sum(sp.binomial(multiplicity,k)*shift(rem,k)
                           for k in range(multiplicity+1)))


osc = x**2*sp.cos(sp.pi*x)
reg = project((osc, 0*x))
punctual = (osc-reg[0], -reg[1])
assert all(sp.simplify(v-u) == 0 for v,u in zip(project(reg),reg))
assert all(sp.simplify(v) == 0 for v in project(punctual))
assert apply_row(punctual,3) == 0
assert sp.simplify(apply_row(punctual,2) - 2*sp.cos(sp.pi*x)) == 0
assert apply_row(reg,0) == 0
# Taking just the leading coefficients of the polarized projection cannot
# replace the first and second projection derivatives on a quadratic field.
omitted = (x**2*sp.cos(sp.pi*x)/2, -x**2*sp.cos(sp.pi*x)/2)
assert sp.simplify(apply_row(omitted,0).subs(x,0)) != 0


def fejer_weight(harmonic, order):
    return max(0, 1-sp.Rational(abs(harmonic),order+1))


for order in (3,8,24):
    d = fejer_weight(1, order)
    for sign in (1,-1):
        # Restore the exact quadratic singular amplitude 5/4 after averaging.
        tail_amp = d*(sp.Rational(5,4)+sign*sp.Rational(1,16))+(1-d)*sp.Rational(5,4)
        assert sp.Rational(3,2)-abs(tail_amp) >= sp.Rational(3,16)
    assert 1-sp.Rational(5,4) < 0  # retaining the singular mode alone fails


def taper(pos, radius):
    return max(0,min(1,2-sp.Rational(abs(pos),radius)))


for radius in (4,12,32):
    for pos in range(-3*radius,3*radius+1):
        for displacement in (-1,1):
            lhs = abs(taper(pos+displacement,radius)-taper(pos,radius))*(pos+3)**2
            assert lhs <= sp.Rational(10,radius)*(1+pos**2)
print("PASS: rotating projector including derivative corrections, third-order "
      "exceptional mode, multiplicity mutation, six positive tail margins and "
      "weighted commutator controls.")
