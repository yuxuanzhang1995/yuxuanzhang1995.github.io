"""Independent real weak generators at each recharge, permutation collisions.
Import safe; original three physical stages, branchwise gross work.
"""
import numpy as np
E=np.array([0,1,1,2,2,3]); S=np.repeat(np.arange(3),2)
q=np.exp(-1.);p=q**E/np.sum(q**E);b=q**np.arange(3)/sum(q**np.arange(3))
pairs=[(i,j) for i in range(6) for j in range(i+1,6) if E[i]<E[j]]
dp=np.array([p[i]-p[j] for i,j in pairs]);de=np.array([E[j]-E[i] for i,j in pairs])
J=np.zeros((6,len(pairs)))
for l,(i,j) in enumerate(pairs):J[i,l]=1;J[j,l]=-1
total=np.repeat(E,3)+np.tile(np.arange(3),6)
blocks=[np.flatnonzero(total==e) for e in range(6)]
target=p*(p@S-S)
def random_perm(rng):
 u=np.arange(18)
 for block in blocks:u[block]=rng.permutation(block)
 return u
def matrix(k):
 A=np.zeros((6,6),dtype=np.asarray(k).dtype)
 for x,(i,j) in zip(k,pairs):A[i,j]=x;A[j,i]=-np.conj(x)
 return A
def channel(r,u):
 U=np.zeros((18,18));U[np.asarray(u),np.arange(18)]=1
 z=(U@np.kron(r,np.diag(b))@U.T).reshape(6,3,6,3)
 return np.einsum('iaja->ij',z)
def maps(u):
 P=np.array([np.diag(channel(np.diag(np.eye(6)[i]),u)) for i in range(6)]).T
 C=np.zeros((len(pairs),len(pairs)))
 for l,(i,j) in enumerate(pairs):
  a=np.zeros((6,6));a[i,j]=a[j,i]=1;r=channel(a,u)
  C[:,l]=[r[k,m] for k,m in pairs]
 return P,C
def response(k,controls):
 k=np.asarray(k).reshape(3,len(pairs));a=np.zeros(len(pairs));y=np.zeros(6);w=[]
 for kj,(P,C) in zip(k,controls):
  inc=J@(2*kj*a-dp*kj**2);w.append(float(E@inc));y=P@(y+inc);a=C@(a-dp*kj)
 return y,np.array(w)
def quadratic(controls):
 n=3*len(pairs);D=np.empty((6,n,n));W=np.empty((3,n,n));eye=np.eye(n)
 diag=[response(v,controls) for v in eye]
 for i,(d,w) in enumerate(diag):D[:,i,i]=d;W[:,i,i]=w
 for i in range(n):
  for j in range(i):
   d,w=response(eye[i]+eye[j],controls);D[:,i,j]=D[:,j,i]=(d-diag[i][0]-diag[j][0])/2;W[:,i,j]=W[:,j,i]=(w-diag[i][1]-diag[j][1])/2
 return D,W
