"""M10: physical witness reconstructed with verified Arb eigenvalues.
No candidate interval code or analytic spectral formula is imported.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'dependencies'))
from flint import arb,arb_mat,ctx
ctx.prec=384
BASE=HERE.parent.parent
witness=json.loads((BASE/'candidates/M10-v4/witness.json').read_text())
p={tuple(x['abc']):F(x['p']) for x in witness['probabilities']}
assert len(p)==len(witness['probabilities'])
assert all(x>=0 for x in p.values()) and sum(p.values())==1
assert all(0<=a<4 and 0<=b<8 and 0<=c<2 for a,b,c in p)

def ball(x):
    x=F(x)
    return arb(x.numerator)/x.denominator

def gram(table,n):
    labels=sorted({k[1:] for k in table})
    return arb_mat([[sum((ball(table.get((a,*x),0)*table.get((b,*x),0)).sqrt()
                         for x in labels),arb(0)) for b in range(n)] for a in range(n)])

def power_trace(G,alpha):
    eigenvalues=G.eig(algorithm='rump')
    assert all(z.imag.contains(0) and z.real>0 for z in eigenvalues)
    return sum(((ball(alpha)*z.real.log()).exp() for z in eigenvalues),arb(0))

reduced={}
for (a,b,c),v in p.items():reduced[a,b]=reduced.get((a,b),F(0))+v
G=gram(p,4);H=gram(reduced,4)
for a in range(4):
    for b in range(4):
        expected=F(1,4) if a==b else (F(1,16) if abs(a-b)==1 else F(0))
        assert G[a,b].contains(ball(expected))
        if {a,b}=={0,3}:expected+=F(1,40000)
        assert H[a,b].contains(ball(expected))
alpha=F(5,2)
tg=power_trace(G,alpha);th=power_trace(H,alpha)
gap=tg-th
entropy_gap=(tg/th).log()/ball(alpha-1)
assert gap>ball(F(14,10**9)) and gap<ball(F(15,10**9))
assert entropy_gap>ball(F(6,10**8))
controls={}
for order in [2,3]:
    x=power_trace(G,F(order))-power_trace(H,F(order))
    assert x<0
    controls[str(order)]=str(x)

general=[]
for alpha in map(F,['1001/1000','3/2','2001/1000','5/2','2999/1000','7/2','11/2']):
    beta=alpha-1;k=math.floor(beta)+2;n=k+1;e=F(1,2**(k+3))
    c=F(1)
    for j in range(k):c*=F(beta-j,j+1)
    assert c<0
    remainder_ratio=2**(k+2)*e*e/(1-2*e)
    assert remainder_ratio<F(1,2)
    d0=F(1,n**math.ceil(beta))*abs(c)*e**k
    L0=8*n*math.ceil(alpha)**2
    t=min((1-2*e)/(2*n),d0/(2*L0))
    state={};label=0
    for i in range(n-1):
        state[i,label,0]=e/n;state[i+1,label,0]=e/n;label+=1
    state[0,label,0]=t;state[n-1,label,1]=t;label+=1
    for i in range(n):
        degree=1 if i in (0,n-1) else 2
        state[i,label,0]=(1-degree*e)/n-(t if degree==1 else 0);label+=1
    assert label==2*n and sum(state.values())==1 and min(state.values())>0
    reduced={}
    for (a,b,cbit),v in state.items():reduced[a,b]=reduced.get((a,b),F(0))+v
    g=gram(state,n);h=gram(reduced,n)
    reverse=power_trace(g,alpha)-power_trace(h,alpha)
    lower=3*d0*t/4
    assert reverse>ball(lower)
    general.append({'alpha':str(alpha),'A_dimension':n,'certified_reverse_trace':str(reverse),'analytic_lower':str(lower)})
out={'status':'pass','arithmetic':'Arb 384-bit verified eigensystems',
     'state':'exact rational PSD diagonal state of trace one',
     'trace_gap':str(gap),'entropy_gap_natural_logs':str(entropy_gap),
     'integer_order_controls':controls,'general_construction_controls':general,
     'scope':'Exact alpha=5/2 refutation supported. General-exponent validity is judged by the analytic proof; finite controls do not prove it.',
     'independence':'New arithmetic representation and verified eigensystem; no candidate interval code or analytic spectrum imported. Same assistant.'}
(HERE/'m10-independent.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
