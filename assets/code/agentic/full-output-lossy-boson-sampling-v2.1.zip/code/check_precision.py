"""Exact rational controls for the repaired small-photon implementation."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json
from check_bottlenecks import unitary,quadratic_powers,probabilities,reduced,occ,facvec,c_coherent,fall,pair_diagonal

BASE=Path(__file__).resolve().parents[1]/'results'

def prefixes(U,N,k):
    m=len(U);powers=quadratic_powers(U,N//2);out=[]
    for j in range(k+1):
        d=[c_coherent(m,N,j,a)/fall(j,2*a) for a in range(j//2+1)]
        out.append({h:pair_diagonal(powers,h,d)*F(facvec(h),factorial(j)) for h in occ(m,j)})
    return out

def sample_law(weights,m,k):
    law={(0,)*m:F(1)}
    for j in range(k):
        nextlaw={h:F(0) for h in occ(m,j+1)}
        for h,p in law.items():
            children=[]
            for i in range(m):
                v=list(h);v[i]+=1;v=tuple(v)
                children.append((v,max(F(0),weights[j+1][v])))
            total=sum(w for v,w in children)
            if not total:
                nextlaw[children[0][0]]+=p
            else:
                for v,w in children:nextlaw[v]+=p*w/total
        law=nextlaw
    assert sum(law.values())==1 and min(law.values())>=0
    return law

def main():
    rows=[]
    for m,N,k in [(2,4,3),(3,6,5),(4,4,4)]:
        U=unitary(m);exact=prefixes(U,N,k);p=reduced(probabilities(m,N,quadratic_powers(U,N//2)),N,k)
        assert sample_law(exact,m,k)==p
        for bits in (3,6,10):
            V=[[(F(round(a*2**bits),2**bits),F(round(b*2**bits),2**bits)) for a,b in row] for row in U]
            beta=max(abs(a-c)+abs(b-d) for row,vrow in zip(U,V) for (a,b),(c,d) in zip(row,vrow))
            approx=prefixes(V,N,k);q=sample_law(approx,m,k)
            alpha=max(abs(exact[j][h]-approx[j][h]) for j in range(1,k+1) for h in exact[j])
            L=F(1)
            for j in range(2,k+1):
                val=6*j*2**j*sum(abs(c_coherent(m,N,j,a)/fall(j,2*a))*factorial(2*a)**2*(4*m)**(2*a) for a in range(1,j//2+1))
                L=max(L,val)
            assert alpha<=L*beta
            tv=sum(abs(q[h]-p[h]) for h in p)/2
            bound=2*k*m**k*alpha
            assert tv<=bound
            # Invalid control: treating rounded raw leaves as normalized.
            raw_mass=sum(approx[k][h]*F(factorial(k),facvec(h)) for h in approx[k])
            assert raw_mass!=1
            rows.append({'m':m,'N':N,'k':k,'entry_bits':bits,'TV':float(tv),'max_prefix_error':float(alpha),'stability_upper_bound':float(bound),'Lipschitz_bound_checked_exactly':True,'raw_leaf_mass':str(raw_mass),'invalid_normalization_detected':True})
    report={'status':'pass','exact_cases':len(rows),'cases':rows,'limits':'Finite exact rational checks support the independently supplied stability proof; they do not prove an all-size theorem by enumeration.'}
    (BASE/'precision-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

if __name__=='__main__':main()
