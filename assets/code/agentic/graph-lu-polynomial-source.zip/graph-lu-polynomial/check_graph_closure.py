"""Independent finite algebra/circuit diagnostics; not an asymptotic proof."""
from pathlib import Path
import itertools,json,math
import numpy as np
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
R=Path(__file__).resolve().parent;rng=np.random.default_rng(202620)
def basis(rows,m,q):
 return hermite_normal_form(Matrix(rows+[[q*int(i==j)for j in range(m)]for i in range(m)]).T).T
records=[]
for m in [1,3,5]:
 for ny in [3,5,8]:
  for r in [1,2,3,5,7]:
   q=2**r;a=rng.integers(0,2,size=(ny,m)).tolist()
   prod=lambda K:[math.prod(a[j][i]for j in K)for i in range(m)]
   seeds=[[2*x for x in prod(K)]for k in [2,3]for K in itertools.combinations(range(ny),k)]
   B=basis(seeds,m,q);steps=0
   while True:
    raw=B.tolist();C=basis(raw+[[2*a[j][i]*row[i]for i in range(m)]for j in range(ny)for row in raw],m,q)
    if C==B:break
    B=C;steps+=1;assert steps<=r*m
   direct=[]
   for k in range(2,min(r+1,ny)+1):
    w=k-2+int(k==2)
    direct += [[2**w*x for x in prod(K)]for K in itertools.combinations(range(ny),k)]
   assert B==basis(direct,m,q)
   records.append({'m':m,'outside_vertices':ny,'r':r,'strict_enlargements':steps})

out={"status":"passed","cases":len(records),"records":records,"scope":"Exact weighted-closure checks only, not an end-to-end graph-LU verifier."}
(R/"graph-closure-checks-rerun.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"status":"passed","cases":len(records)}))
