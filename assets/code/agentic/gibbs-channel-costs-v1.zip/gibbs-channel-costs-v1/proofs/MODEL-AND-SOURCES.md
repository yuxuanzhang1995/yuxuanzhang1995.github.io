# Model boundaries and primary-source comparison

24 November 2026. This audit does not establish first priority or certify
the new proofs independently. The pinned Q117 statement remains immutable.

## Exact model used

The coherence resource is finite dimensional, with an arbitrary finite
Hamiltonian and state; its SLD QFI is charged. Any pure energy eigenstate,
including a blank or output-preparation register, has zero QFI but is still
part of that resource. All coherence constructions here have finite
energy-conserving unitary completions and can use a trivial free bath.

The complete qubit GP classification is stated at beta>0. The other
support-based sufficient theorems use arbitrary fixed Hamiltonians and
do not need GP or a temperature assumption. A beta=0 GP state does not
determine its Hamiltonian; the qubit classification must not be applied
there by substituting a maximally mixed Gibbs state and discarding H.

For work, the only nonthermal resource is a battery starting and ending
in specified nondegenerate pure energy states, for EVERY input. The
battery loss W is charged. No free coherence reference, pure blank,
catalyst, or failure event is available. The implementing unitary obeys
total energy conservation. No additional invariance under translations
of an ideal weight's entire energy spectrum is assumed; that is a stronger
model than a specified sharp battery transition and needs a separate
analysis. The pinned statement specifies sharp endpoints but not this
extra symmetry.

Two bath conventions are kept separate:

- Finite bath: full support of the input system and the Gibbs environment
  makes a uniform nonzero sharp battery shift impossible. The cost is zero
  if a finite thermal operation lies within the required error ball, and
  infinite otherwise. Closure membership alone is not exact feasibility.
- Normal countable bath: H is lower bounded and exp(-beta H) trace class.
  The new nontrivial work formulas and constructions use this convention.
  Every bath constructed here is locally finite; its Gibbs moments are
  finite for each fixed construction. They need not remain uniformly
  bounded as error tends to zero. The original statement fixes finite
  resources but does not explicitly settle this bath convention.

These distinctions are part of the scope, not changes silently made to
the problem. The formulas must be quoted with their convention.

## Primary sources actually compared

1. **Tajima--Takagi (2025), arXiv:2404.03479v3 / PRL 134,170201.**
   https://arxiv.org/html/2404.03479v3
   Proposition S.11 and its proof cover relative-interior GP channels;
   Sections III--IV contain reversible-measurement obstructions and finite
   preparation examples. These are prior and not counted again. The new
   support criteria concern additional Choi boundary faces. The paper's
   conclusion does not provide the present channel-by-channel classification.

2. **Ruskai--Szarek--Werner, arXiv:quant-ph/0101003.**
   https://arxiv.org/pdf/quant-ph/0101003
   The rank-two canonical form, extreme/bistochastic alternatives and pure
   output geometry are used as prior structure. The present candidate
   adds exact coherence-resource conditions, not a new qubit channel form.

3. **Handelman; De Angelis--Tuncel's account.**
   https://vdeangel.xula.edu/Publications/htheorem.pdf
   Page 1 states the equivalence between a positive-coefficient multiple
   and nonvanishing Newton-face polynomials; page 4 gives positive scalar
   multipliers. This directly supplies the scalar steps in the polyhedral,
   antisymmetric and diagonal-rational criteria. It is prior mathematics.
   The one-variable matrix endpoint extension needs separate comparison.

4. **Matrix Handelman positivity, arXiv:1603.07611.**
   https://arxiv.org/abs/1603.07611
   Its strict matrix positivity assumptions do not alone justify singular
   endpoint kernel flags. We supply that argument, without claiming that
   no equivalent theorem exists elsewhere.

5. **Purves--Short, arXiv:2008.09065.**
   https://arxiv.org/pdf/2008.09065
   Appendix C uses CPTP extremality for the three-dimensional Werner--Holevo
   noncatalytic obstruction. The extremality mechanism is therefore prior.
   Its average-work/catalytic discussion is not a derivation of the present
   uniform sharp-battery, all-temperature infimum.

6. **Faist--Berta--Brandao (2021), arXiv:1911.05563v3.**
   https://arxiv.org/html/1911.05563v3
   Universal thermodynamic process rates and information-battery protocols
   must be distinguished from an exactly sharp battery on every branch.
   Their asymptotic or failure-permitting guarantees are not substituted
   for the present one-shot work model.

7. **Lie--Son--Boes--Ng--Wilming (2026), PRL 137,030403.**
   https://journals.aps.org/prl/pdf/10.1103/lm3h-c5f5
   Page 2 explicitly restricts the paper to finite Hilbert spaces. Theorem
   3 concerns full-rank equilibrating dilations; pages 4--5 distinguish
   finite noisy/strongly factorizable and abstract factorizable classes.
   This is relevant prior dilation structure, not a normal-infinite-bath
   sharp-work-cost formula.

8. **Musat--Rordam, arXiv:1806.10242.**
   https://arxiv.org/abs/1806.10242
   Finite tracial ancillary dimension and its closure cannot be replaced
   by an arbitrary abstract tracial algebra. The H=0 work reduction keeps
   the finite noisy closure explicit. No undecidability conclusion is
   inferred merely from nonclosure.

9. **Scharlau--Muller, arXiv:1605.06092v4.**
   https://inspirehep.net/files/e9daf0d22df32ed25b38c36e7177a100
   Relevant finite-bath/third-law distinctions. The present finite-bath
   no-uniform-shift argument is elementary dimension and energy counting;
   it must not be confused with a state-dependent work protocol.

10. **Marvian, arXiv:2112.04694; Zhou--Jiang, arXiv:2003.10559.**
    https://arxiv.org/abs/2112.04694
    https://arxiv.org/abs/2003.10559
    Optimized finite purification and the first-order Kraus-span/HNKS
    mechanisms are inherited tools, not new claims in this block.

## Novelty status

Targeted searches did not locate a primary source already giving the
qubit arithmetic classification, the corank threshold, the support
saturation statement, or the sharp-work formulas in precisely this model.
This is not an exhaustive literature review and does not certify priority.
Several search results were automated secondary summaries; they were not
used as mathematical evidence. A 2026 unreviewed projection-cost
undecidability preprint was seen but was not adopted as a theorem or used
to close Q117. The public catalog remaining open is not evidence of novelty.
