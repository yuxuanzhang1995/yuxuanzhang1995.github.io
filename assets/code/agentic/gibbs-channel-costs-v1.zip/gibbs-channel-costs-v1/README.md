# One-shot coherence and deterministic work costs for Gibbs-preserving channels

Version 1.0 · 26 November 2026

Open [the offline reading copy](proofs.html) for a linked table of contents and rendered equations. The sections below also link to the individual Markdown proof texts. Start with the integrated result for the current statements. Earlier component proofs identify the assumptions and the part of the result available at their date.

## Reproducing the checks

With Python 3, NumPy, SciPy, SymPy, CVXPY and Clarabel installed, run `python3 reproduce.py` from the extracted directory. The scripts run without network access and use temporary directories. The release was tested with NumPy 2.1.3, SciPy 1.15.3, SymPy 1.13.3, CVXPY 1.9.2 and Clarabel 0.11.1. Each of fifteen staged checks must match its recorded output. Two finite-clock controls check a transpose mutation and a second-order obstruction. The integrated controls test the channel-distance threshold, kernel positivity, sharp variance inequality, Kraus rank and both battery-shift directions. The separate three-level calculation checks Gibbs preservation, extremality and both finite cost values in exact arithmetic.

The website manuscript is in `manuscript/paper.tex`. To rebuild it run `latexmk -pdf paper.tex` in that directory. The source hashes and the released file hashes are recorded separately. The earlier replay logs describe the original frozen workspace. The public command tests the material distributed here.

## The integrated result and its review

- [One-shot resources for a Gibbs-preserving channel](proofs/RESOLUTION.md)
- [Review of the integrated Q117 candidate](proofs/REVIEW-INTEGRATED.md)
- [Review of the frozen F21–F25 proofs](proofs/REVIEW-F21-F25.md)

## Thermal implementation and QFI at positive error

- [Finite semidefinite brackets for one-shot QFI implementation cost](proofs/q117-program-proof-v2.md)
- [General-channel small-error coherence cost: proof candidate v2](proofs/q117-general-cost-proof-v2.md)
- [What constraints can a Gibbs-preserving channel encode?](proofs/physical-realization.md)

## Exact finite-clock feasibility

- [A local-to-global criterion for positive matrix coefficients](proofs/global-flags.md)
- [A finite descending test for all matrix flags](proofs/tangential-decision.md)
- [Matrix Handelman criterion with Newton kernel compatibility](proofs/matrix-positive-multiplier-v3.md)
- [Newton tests exactly characterize uniform matrix relative positivity](proofs/matrix-relative-positivity-v2.md)
- [Exact finite-resource normalizations in a fixed Kraus support](proofs/kernel-module-classification-v2.md)

## Optimal QFI at exactly zero error

- [A sharp lower-bound dual at zero channel error](proofs/positive-dual.md)
- [Finite lower witnesses for exact one-shot coherence cost](proofs/finite-lower-witnesses.md)
- [Exact-QFI cost from localization in the sector module](proofs/sector-retraction.md)
- [Exact-cost localization with singularities away from physical time](proofs/physical-time-filter.md)

## Small-error exponent and the bounded branch

- [A finite-order classification of small-error coherence cost](proofs/coherence-theorem.md)
- [Finite resources from translated lattice fibres](proofs/finite-resource-lemma.md)
- [Consequence for the all-positive-error optimization](proofs/positive-error-relaxation.md)
- [A direct finite clock for the all-orders GP family](proofs/all-orders-finite-gaussian-v2.md)
- [Gibbs-preserving channels realizing every finite coherence-divergence order](proofs/all-orders-gp-family-v1.md)

## Deterministic sharp work

- [An all-error lower dual for sharp work on a covariant Choi face](proofs/work-lower-witnesses.md)
- [Finite-dilation variational principles for general deterministic work](proofs/work-general-variational-v4.md)
- [Review and all-error extension of the work variational principle](proofs/work-variational-review-v5.md)
- [Exact sharp-battery work for extreme covariant channels between different systems](proofs/work-rectangular-commensurate-v1.md)
- [Exact extreme-channel work for arbitrary finite spectra](proofs/work-extreme-general-spectrum-v2.md)
- [General exact work: separating the target cost from its support barrier](proofs/general-work-face-separation-v1.md)
- [A support minimax formula for exact deterministic work](proofs/general-work-support-minimax-v1.md)
- [Audit of the finite thermal selector and exact target correction](proofs/thermal-selector-review-v2.md)

## Finite baths, closure and temperature

- [The finite-bath interpretation of the sharp battery](proofs/finite-baths.md)
- [Work when the thermal operation is closed before testing the battery](proofs/closed-process-work.md)
- [Other finite inverse temperatures](proofs/temperature-endpoints.md)
- [Exact-work discontinuity for a Gibbs-preserving extreme channel](proofs/work-discontinuity-v1.md)
- [Small-error sharp work for arbitrary extreme covariant channels](proofs/work-extreme-approx-general-v3.md)
- [Stability of the extreme-channel deterministic work formula](proofs/work-extreme-robust-v1.md)

## Limits on computation and finite factorization

- [Even certifying strictly positive deterministic work is impossible uniformly](proofs/positive-work.md)
- [A fixed-dimensional finite-bath test](proofs/finite-cost-and-rationality.md)
- [Direct physical realization of the resonance using two pure preparations](proofs/two-preparations.md)
- [A discontinuous exact QFI cost at fixed rank and finite resources](proofs/resonance-jump.md)
- [One halting jump suffices, and is necessary, for the general exact QFI value](proofs/sharp-oracle-bound.md)
- [CP-order robustness is not exact sharp-battery work](proofs/cp-order-converse-fails-v1.md)

## Additional derivations and controls

- [Model boundaries and primary-source comparison](proofs/MODEL-AND-SOURCES.md)
- [Exact-target QFI bounds on an invariant support](proofs/exact-cost-localization.md)
- [Exact finite clocks on covariance-invariant Choi supports](proofs/finite-clock-support-v1.md)
- [The computability degree of all-error sharp work](proofs/graded-work.md)
- [Matrix positive multiples: necessary Newton conditions and unresolved bridge](proofs/matrix-newton-route-working.md)
- [One finite clock for several independently selectable measurements](proofs/multiple-gaps.md)
- [An evaluated general-channel class: one Kraus-product relation](proofs/one-relation-work-v1.md)
- [Finite exact coherence for qubit Gibbs-preserving channels of rank at most two](proofs/qubit-rank-two-classification-v1.md)
- [Testing for a witness with nonsingular Newton vertices](proofs/regular-vertices.md)
- [Removing energy coordinates using the symmetry of the Choi support](proofs/remove-symmetric-charges.md)
- [Saturating a Kraus-support face with finite exact coherence resources](proofs/support-saturation-v1.md)
- [Computable optimal exact coherence at two independent algebraic-ratio gaps](proofs/two-algebraic-gaps.md)
- [Deciding a bound on the number of unknown directions](proofs/unknown-rays.md)
- [A uniform obstruction to computing deterministic work to arbitrary precision](proofs/work-computability.md)
- [Deterministic sharp-battery work: an extreme-channel formula](proofs/work-extreme-v1.md)
