# Finite semidefinite brackets for one-shot QFI implementation cost

R338 proof candidate v2, 23 November 2026.
V2 retains v1 and replaces the continuous-measure discretization by an
explicit heavy-tail kernel with exponentially decaying Fourier transform.
The finite localization theorem and brackets are unchanged. Same-agent derivation; not yet
independently reviewed. The result concerns the QFI cost in Q117, with work
unrestricted and every sharp ancillary register included in the resource.
It does not answer the separate deterministic-work question.

## 1. Model and theorem

Let A,B be fixed finite systems with fixed Hamiltonians. The target Phi can
be any channel; Gibbs preservation is not needed for the mathematical
characterization below. Charge the SLD QFI of an arbitrary finite resource,
and implement using a thermal operation. Denote the infimum at worst-case
reference-assisted purified channel distance epsilon by F_c^epsilon(Phi).

The optimized-purification theorem of Marvian, PRL 129,190502, Theorem 3,
allows the resource to be pure with QFI four times its energy variance.
The finite conserving-unitary completion in R337 shows that arbitrary
zero-QFI sharp ancillary registers suffice for the converse construction.
These ingredients are inherited, not new here.

Choose energy eigenbases and subtract scalar energy origins. Write

    e_i=omega.a_i, f_j=omega.b_j,
    a_i,b_j in Z^q,

where the entries of omega are rationally independent and omega_1!=0.
Every finite collection of real energies admits such labels. This is an
exact mathematical input representation, not an algorithm for discovering
integer relations among arbitrary real-number oracles. If all shifted
energies vanish, every channel has QFI implementation cost zero; alternatively
use omega_1=1 and all labels zero in the construction.

Set d=dim A and

    Q=max_(i,j)||b_j-a_i||_1,
    B=max_(i,j)||b_j-a_i||_infinity,
    Omega=sum_l |omega_l|,
    delta_L=min(1,sqrt(2dQ/L)),
    r_N=omega_1^2/N^2,
    K_p=ceil(N L(1+Omega/|omega_1|))+1,
    K=K_p+NB.                                             (1)

Let C_(L,N)(eta) be the finite SDP defined in Section 4, with energies
omega.z/N for integer z in [-K,K]^q. Radii eta>=1 mean no accuracy
restriction. Then

    max(0,C_(L,N)(epsilon+delta_L)-r_N)
       <= F_c^epsilon(Phi) <= C_(L,N)(epsilon).             (2)

At every 0<epsilon<1 both sides converge to the same value as L=h and
N=h! tend to infinity. In particular, finite primal and dual SDP certificates
give arbitrarily tight bounds on the physical cost at every positive error.
No polynomial runtime or a priori modulus of the cost curve is asserted.

At epsilon=0 the finite atomic formulation remains exact. Its finite-SDP
upper hierarchy converges to the exact finite-resource infimum, but the
lower hierarchy can converge to the positive-error limiting cost instead.
A finite bound on the required exact clock support is not established.

## 2. Exact finite-atomic formulation

Use unnormalized input-first Choi matrices. Let p be a finite probability
distribution on clock energies x, and let Y_z>=0 be finite Choi-valued
weights indexed by environment energy z. The conservation equations are

    sum_j [Y_(E-f_j)]_(i j,i' j)
                   =delta_(i i') p_(E-e_i),                (3)

for every E. Missing atoms are zero. The implemented Choi matrix is
J=sum_z Y_z. Summing (3) over E gives Tr_B J=I_A.

Every finite implementation gives these variables: first use the optimized
finite purification of its resource, and take a covariant Stinespring
dilation. An invariant purification of any Gibbs bath introduces no charged
variance. Group the induced channel Kraus operators by environment energy,
and form Y_z from their vectorizations. The sector isometry condition gives
(3). A finite covariant channel between finite systems has a finite covariant
Stinespring representation, so bath size is not an extra clock variable.

Conversely, factor Y_z=sum_s |K_(s,z)>><<K_(s,z)|. At fixed total E assemble
the rows K_(s,E-f_j)[j,i]. Their input Gram is the transpose of the left side
of (3), hence diag_i p_(E-e_i). Divide each occupied input column by its
positive square root. The resulting columns are orthonormal. A zero-probability
column is zero before division, by positivity and its zero squared norm.
These isometries can be completed in finite total-energy sectors to an
energy-conserving unitary, using the sharp ancillary registers described in
R337. Inserting the clock sum_x sqrt(p_x)|x> reproduces the Kraus operators.

Thus (3) is equivalent to finite implementability with that pure clock, at
cost 4 Var(p). Complex clock phases can be absorbed in energy-preserving
basis phases. No restriction to classical outputs, Choi rank, or commensurate
energies appears in (3).

## 3. A finite SDP for the exact channel error

For fixed channel Choi matrices J_Phi,J_Psi, their minimum reference-assisted
root fidelity is

    f_ch(Phi,Psi)=max_X lambda_min(Re Tr_B X)
    subject to [[J_Phi,X],[X*,J_Psi]]>=0.                   (4)

Here Re T=(T+T*)/2. For an invertible input density matrix rho, the two
reference-output states are the congruences of the Choi matrices by
sqrt(rho^T) tensor I. The state-fidelity block SDP therefore becomes
max_X Re Tr[(rho^T tensor I)X], with the feasible set in (4) independent of
rho. This set is compact. Minimax for a continuous bilinear function on the
two compact convex sets interchanges min_rho and max_X. Minimizing over
rho gives the minimum eigenvalue in (4). Singular rho follow by continuity.
Pure reference-assisted inputs suffice by purification and fidelity
monotonicity. This is the standard fidelity/SDP mechanism, not a new fidelity
identity claimed independently of prior work.

Consequently, for 0<=epsilon<=1, the exact purified-distance condition is

    [[J_Phi,X],[X*,J_Psi]]>=0,
    Re Tr_B X >= sqrt(1-epsilon^2) I_A.                    (5)

This keeps one common channel for all inputs, rather than smoothing its
outputs separately.

## 4. The finite programs

Take p_z>=0 and Y_z>=0 for z in [-K,K]^q, at physical energy omega.z/N.
Variables outside this box are zero. Impose sum_z p_z=1 and

    sum_j [Y_(k-Nb_j)]_(i j,i' j)
                       =delta_(i i')p_(k-Na_i)             (6)

for all integer k reached by a nonzero term. This is a finite set of linear
matrix equations. Put J_Psi=sum_z Y_z and impose (5) at radius eta. Minimize

    4 sum_z (omega.z/N)^2 p_z.                            (7)

This defines C_(L,N)(eta), with value infinity if infeasible. Every feasible
point is a finite physical implementation by Section 2. Since variance is
at most the raw second moment, it supplies the upper bound in (2).

Finite SDP dual certificates can be used without assuming an unjustified
Slater point at singular target Choi matrices. Encode the fidelity block
as a positive variable T and S=Re Tr_B X-cI>=0, c=sqrt(1-eta^2), together
with their affine equalities. Equations (6) give

    sum Tr Y_z=d, Tr T=2d, |Tr X|<=d, Tr S<=d.

Introduce a redundant nonnegative scalar s and the equality

    sum p_z+sum Tr Y_z+Tr T+Tr S+s=2+4d.                  (8)

Every originally feasible point admits such an s. In standard-form SDP,
a sufficiently negative multiplier of (8), with other equality multipliers
zero, makes every dual cone slack strictly positive definite. The objective
in (7) is finite-dimensional. Strict dual feasibility and primal feasibility
therefore give no duality gap and primal attainment. A dual optimum need not
be assumed attained: feasible dual values arbitrarily close to the optimum
are sufficient. Use a dual certificate of the looser-radius program for
the lower bound in (2), subtracting r_N. A dual value for the unrelaxed
finite program alone is not automatically a lower bound on the physical cost.

## 5. Localizing arbitrary finite clocks

This supplies the nontrivial direction of (2). Partition the finite clock
spectrum into cosets of Gamma=omega.Z^q. By covariance, the matrix element
of the implemented channel from |i><i'| to |j><j'| depends only on clock
coherences whose energy difference is

    (f_j-e_i)-(f_j'-e_i').                                (9)

Cross-coset coherences therefore never contribute. Removing them gives a
classical ensemble of pure conditional clocks. The average conditional
variance is at most the original variance.

Within each coset assign integer labels. Partition Z^q into side-L cubes,
and average uniformly over the L^q integer offsets of the partition.
The probability that two labels differing by u lie in the same cube is

    tau_L(u)=product_l (1-|u_l|/L)_+.

Dephasing the clock between these cubes therefore changes the Choi matrix
of the channel Psi to

    [J_Psi']_(ij,i'j')=
       tau_L(q_ij-q_i'j') [J_Psi]_(ij,i'j'),
       q_ij=b_j-a_i.                                     (10)

This follows from (9), and is not an arbitrary dephasing of a channel Choi
matrix. It preserves trace: q_ij-q_i'j=a_i'-a_i does not depend on j.

For the uniform error estimate, let w_q be the normalized indicator vector
of a translated L-cube in l2(Z^q). Its Gram matrix is tau_L(q-q'). If K_s
are Kraus operators of Psi, entries K_s[j,i]w_(q_ij)[t] give a dilation of
Psi'. Compare it with the dilation of Psi tensored with w_0. The squared
Hilbert--Schmidt distance is

    sum_(s,i,j)|K_s[j,i]|^2 ||w_(q_ij)-w_0||^2
      =2 sum_(s,i,j)|K_s[j,i]|^2[1-tau_L(q_ij)]
      <=2dQ/L.                                          (11)

We used 1-tau_L(q)<=||q||_1/L and sum |K_s[j,i]|^2=d.
Operator norm is at most HS norm, and purified distance between outputs
is bounded by the distance between these common dilation vectors. Hence
D_ch(Psi,Psi')<=delta_L, uniformly over reference-assisted inputs.

All conditioning and averaging makes a finite ensemble of pure clocks,
each supported on one L-cube of one coset. The average conditional variance
again cannot increase. Rebase each cube to [0,L-1]^q, removing its arbitrary
energy offset. Translate its remaining energies by m omega_1/N, where m
is the nearest integer to minus its mean times N/omega_1. These translations
do not change the branch channel: translate p and Y by the same amount in
(3). The resulting branch mean has magnitude at most |omega_1|/(2N).

The rebased mean has absolute value at most (L-1)Omega. Therefore
|m|<=N(L-1)Omega/|omega_1|+1/2, and the clock's new integer labels lie in
the K_p box of (1). Environment labels differ from occupied clock labels by
N(a_i-b_j), and hence lie in the K box. Summing the branch p,Y with their
ensemble weights preserves (6) and the implemented mixture Psi'. The raw
second-moment objective is at most

    4 Var(original clock)+omega_1^2/N^2.                  (12)

Applying this to any implementation within epsilon of Phi gives a feasible
point of C_(L,N)(epsilon+delta_L), with the bound (12). Infimizing the original
resource cost proves the lower bound in (2).

## 6. Convergence of the brackets

Any finite atomic implementation uses finitely many Gamma cosets. Within
each coset, translate the entire finite support onto Gamma_N, centering its
mean within |omega_1|/(2N) as above. There is no localization loss when one
keeps the whole support. Its coordinate diameter is finite, so for all
sufficiently large h it fits the box in C_(h,h!). The channel is unchanged
and the excess objective tends to zero. This proves convergence of the
upper hierarchy to F_c^epsilon for every fixed epsilon with a finite
implementation. It also characterizes exact feasibility: a finite exact
implementation exists if and only if some finite program at epsilon=0
is feasible. If none exists, every such upper value is infinity.

Write G(c) for the physical cost with f_ch>=c. It is convex in c: mix two
finite atomic realizations after individually centering their energies;
their p,Y measures add, costs average, and the feasible fidelity blocks in
(5) add. The resulting pure clock has the averaged variance. G is finite
for c<1 by finite-clock approximation of arbitrary channels (R337, or a
direct approximation of a unitary Stinespring dilation). Hence G is
continuous on 0<c<1. Equivalently F_c^epsilon is continuous for 0<epsilon<1.

The looser finite program is itself a physical upper bound on the cost at
epsilon+delta_L. Thus

    F_c^(epsilon+delta_L)-r_N
      <= C_(L,N)(epsilon+delta_L)-r_N <=F_c^epsilon.

Continuity, delta_L->0 and r_N->0 prove convergence of the lower bracket.
Together with the upper hierarchy this proves (2) and the matching claim.
Running minima of upper certificates and running maxima of lower certificates
may be used; monotonicity of every raw box value need not be assumed.

## 7. Continuous finite-moment relaxation

For completeness replace the atoms in (3) by a scalar probability measure
p and a positive matrix measure Y on R, center p, and require finite second
moments. Equality in (3) is equality of matrix measures under translation.
Minimize 4 integral x^2 p(dx), subject to (5) for J=sum Y. Call the relaxed
value F_bar^epsilon. Clearly F_bar^epsilon<=F_c^epsilon.

Every relaxed feasible point can be approximated by finite physical clocks
at asymptotically unchanged cost. Here are the analytic steps, including
the issues absent from a formal measure SDP.

First convolve p and Y with the common even density

    f_h(x)=2 h^3/[pi(h^2+x^2)^2], h>0.

It is strictly positive, has variance h^2, and its Fourier transform is
(1+h|t|)exp(-h|t|). Translation commutes with convolution, so (3) remains
exact and the aggregate Choi matrix is unchanged. Write p_h,Y_h for the
resulting densities. For every fixed shift u the ratio f_h(x-u)/f_h(x)
is bounded above and below uniformly in x. All fixed derivatives satisfy
|f_h^(l)|<=C_(h,l)f_h. Integration against p preserves these bounds for p_h.
Positivity and (3) imply

    Tr Y_h(z) <=sum_(i,j) p_h(z+f_j-e_i)<=C_h p_h(z).       (13)

Both p and Tr Y have finite second moments. Their Fourier transforms and
first two derivatives are bounded. Therefore the Fourier transforms of
p_h, x p_h, x^2 p_h and every matrix entry of Y_h are bounded by
C_h exp(-h|t|/2). This follows by differentiating the explicit transform
of f_h; its first two derivatives are continuous at zero.

For q>=2, fix an integer N and sample at omega.z/N, z in Z^q, multiplying
both densities by g(P_perp z/T)=(1+||P_perp z/T||^2)^(-b), b>q+3.
Divide by Z=sum_z p_h(omega.z/N)g(P_perp z/T). The Fourier transform of g
is bounded by C exp(-c||xi||), after absorbing its polynomial factor.
Poisson summation for each of the above densities has dual summands,
after cancellation of the common volume factor N T^(q-1)/||omega||,
bounded by

    C_(h,N) exp[-c_(h,N)|k_parallel|-c T||k_perp||],
    k in Z^q.                                            (13a)

For T>=1 these are dominated by C exp(-c' ||k||), a summable lattice
sequence. Rational independence of omega implies k_perp!=0 for every
nonzero integer k when q>=2. Each nonzero summand therefore tends to zero
as T tends to infinity, and dominated convergence applies. No Diophantine
rate or bounded Fourier slab is needed. The zero summand gives the desired
continuous integral. In particular Z has its positive expected leading
term, aggregate Y tends to J, and both scalar moments converge.

The real-space sums needed for Poisson are absolutely convergent too:
fixed-cell ratios of p_h and (1+x^2)p_h are uniformly bounded, as are those
of g; compare each cell's value with its finite integral. Matrix entries
are controlled by (13). The transform is integrable and its sampled sums
are absolutely convergent, so Poisson follows by Gaussian regularization
and dominated convergence if desired. These arguments apply entry by entry
without assuming a density or compact support for the original measures.

For q=1 there is no transverse factor. Take N to infinity instead. The
nonzero reciprocal frequencies are 2pi Nk/|omega_1| and their summable
bounds tend to zero exponentially in N. The energy shifts are integer
multiples of omega_1/N, so the sampled conservation equations are exact
for every N, despite the small aggregate sampling error.

The sampled sector Gram L_E differs from the scalar target Gram G_E only
through transverse shifts of bounded integer size N a_i,N b_j. Since log g
has bounded gradient, uniformly in E,

    ||L_E-G_E||<=C_(h,N) p_E/T,
    c_(h,N) p_E I <=G_E,L_E<=C_(h,N) p_E I                (14)

for large T. When q=1 the equality is exact. Factor each sampled Y_z and
normalize the sector rows by L_E^(-1/2)G_E^(1/2). Equation (14) bounds the
change in the dilation in HS norm by O(1/T); the aggregate raw Choi matrix
already tends to J. This produces a countable-clock channel tending to the
desired channel. No inverse of a singular target Choi matrix is taken.

Finally retain finitely many occupied clock columns with probability tending
to one. Sector orthonormality survives restriction of the columns; only
finitely many output/environment energies are reached. The resulting finite
conserving unitary is the construction in Section 2. Purified channel error
tends to zero, and conditional second moments tend to the sampled second
moment. Send T and the finite cutoff to infinity, then h to zero. This gives
finite physical channels Psi_k->Psi with limiting QFI at most the relaxed
objective. A scalar shift of each clock removes its mean without cost.

If the relaxed channel lies on the boundary of the epsilon ball, choose one
finite realization strictly inside that ball; it exists for every epsilon>0.
Mix a vanishing fraction of it into Psi_k. Concavity of the root channel
fidelity moves the mixture into the exact closed epsilon ball, while its
extra cost tends to zero. Thus

    F_bar^epsilon=F_c^epsilon for every epsilon>0.          (15)

There is no appeal here to strong duality for an unspecified infinite SDP.
The finite dual certificates in Sections 4--6 provide the matching bounds.

## 8. The exact-zero boundary is different

Bounded-cost relaxed feasible sets are sequentially compact in the needed
weak topology. Indeed, (3) yields

    integral Tr[(I_A tensor (zI+H_B)^2)Y(dz)]
       =sum_i integral (x+e_i)^2 p(dx).

The right side bounds the second moment of Y, using
(z+f_j)^2>=z^2/2-f_j^2. Its total trace is d. Thus p and Y are tight;
their first moments are uniformly integrable. Weak limits preserve the
translated balance equations, normalization, aggregate Choi matrices and
channel fidelity. The scalar second moment is lower semicontinuous.

It follows that F_bar^0 is attained whenever finite and equals
lim_(epsilon down to 0) F_c^epsilon. It need not equal F_c^0, which demands
finite physical resources. The finite-atomic criterion of Section 2 and the
finite-SDP feasibility enumeration preserve this distinction.

The results therefore supply matching all-positive-error QFI characterizations
and a separate exact finite-support criterion. They do not supply a bounded
exact-feasibility algorithm, optimal deterministic work, an independent
review, or a comprehensive novelty determination. A matching optimization
description is not a closed elementary cost formula or an efficiency claim.
