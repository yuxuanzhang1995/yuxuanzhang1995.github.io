Polynomial critical-distance bounds for weak-field Ising Gibbs preparation
Yuxuan Zhang — EPFL; Princeton
Version 1, 26 October 2026

STATUS: proof candidate, sequentially audited. No independent review of the
complete manuscript, external peer review, formal certificate, or catalog
acceptance is claimed.

Build: run latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
inside manuscript/. A current LaTeX installation with the standard listed
packages suffices. The PDF is included for version identification.

review.json pins the manuscript, PDF, original target and research records.
research-records/ preserves the original relative paths and historical
qualifiers. Older records are provenance and may be superseded by the
manuscript and the corrections listed in review.json; they are not
additional independent reviews.

Claim: Actual mixed Gibbs preparation with polynomial critical-distance field window and gate/classical costs.
Limits: quantum advantage over general classical algorithms; criticality or the full quantum phase diagram; useful numerical exponents or practical field threshold; geometrically restricted gate architecture; rapid mixing of an arbitrary physical bath.

Primary sources are linked in the manuscript and review.json. No third-party
source-paper copies are redistributed in this archive.
