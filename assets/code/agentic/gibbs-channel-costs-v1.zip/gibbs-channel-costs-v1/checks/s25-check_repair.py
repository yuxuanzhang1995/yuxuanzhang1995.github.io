"""Exercise genuine negative coefficients, their exact repair, and target cost."""
from fractions import Fraction as Q
from collections import defaultdict


b = {0: Q(2, 3), 1: Q(1, 3)}


def conv(a, c):
    out = defaultdict(Q)
    for i, v in a.items():
        for j, w in c.items():
            out[i+j] += v*w
    return dict(out)


def var(p):
    mass = sum(p.values())
    mean = sum(i*v for i, v in p.items()) / mass
    return sum((i-mean)**2*v for i, v in p.items()) / mass


def repair(q, L):
    p = conv(b, q)
    assert var(p) == var(q) + Q(2, 9)
    anchor = min(q)-L+1
    extent = max(p)
    defects, overhead, costs, repaired_mass = 0, Q(0), Q(0), Q(0)
    outp, outq = defaultdict(Q), defaultdict(Q)
    for t in range(anchor, extent+1):
        def window(n):
            return Q(1, L) if t <= n < t+L else Q(0)
        qt = {n: window(n)*a for n,a in q.items()}
        pt = {n: window(n)*a for n,a in p.items()}
        bqt = conv(b, qt)
        # The chosen polynomial retraction is intentionally not positive.
        # Q_t = qt + 6(pt-b*qt), h_t = (b*Q_t,Q_t,Q_t).
        qhat = {n: qt.get(n, 0) + 6*(pt.get(n, 0)-bqt.get(n, 0))
                for n in set(qt) | set(pt) | set(bqt)}
        phat = conv(b, qhat)
        rr = {}
        for n in set(qhat) | set(phat) | set(pt) | set(qt):
            rr[n] = max(abs(qhat.get(n, 0)-qt.get(n, 0)),
                        abs(phat.get(n, 0)-pt.get(n, 0)))
        defects += sum(v < 0 for v in qhat.values())
        # Repair by shifted copies of the augmented seed (b,delta0,delta0).
        for n, norm in rr.items():
            addition = norm/Q(2, 3)
            qhat[n] = qhat.get(n, 0) + addition
            overhead += addition
        phat = conv(b, qhat)
        assert min(phat.values()) >= 0 and min(qhat.values()) >= 0
        support = [n for n,v in phat.items() if v]
        if not support:
            continue
        assert max(support)-min(support) < L+5
        mass = sum(phat.values())
        repaired_mass += mass
        costs += mass*var(phat)
        for n,v in phat.items():
            outp[n] += v
        for n,v in qhat.items():
            outq[n] += v
    assert repaired_mass == 1+overhead
    assert sum(outp.values()) == sum(outq.values()) == repaired_mass
    assert all(outp[n] == v for n,v in conv(b, outq).items())
    assert costs/repaired_mass >= Q(2, 9)
    assert defects > 0
    return overhead, costs/repaired_mass


q0 = {-3: Q(1, 7), 0: Q(2, 7), 4: Q(4, 7)}
for q in (q0, {n+101: v for n,v in q0.items()}):
    sequence = [repair(q, L) for L in (4, 12, 24)]
    assert sequence[1][0]*12 == sequence[2][0]*24
    if q is q0:
        control = sequence
    else:
        assert sequence == control
print("PASS: signed retraction creates actual negative coefficients, exact PSD repair, six ensemble target identities, translation-invariant physical variance and inverse-width overhead; exact GP cost 8(log 2)^2/9")
