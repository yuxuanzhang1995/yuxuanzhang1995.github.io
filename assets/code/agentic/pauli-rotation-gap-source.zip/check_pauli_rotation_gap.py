#!/usr/bin/env python3
# Standalone checker: exact spectral gap of random Pauli rotations at n = 4 (QIQC record op_aaf9791beced84e4).
# Python standard library only.  Deterministic (fixed seeds).  No arguments, no input files, no network.
#
# Conventions.  The basis e_x of C^16 is labelled by x in F_2^4 = {0,...,15}; bit j of x is qubit j, and
# s.x = parity of popcount(s & x).  The 255 non-identity Paulis are P_{a,b} = i^{a.b} X^a Z^b, (a,b) != (0,0),
# so P_{a,b} e_x = i^{a.b} (-1)^{b.x} e_{x+a}.  An 8-subset A of F_2^4 is stored as a 16-bit mask, and
# e_A = e_{a1} ^ ... ^ e_{a8} with a1 < ... < a8 in the binary (integer) order.  rho = Lambda^8 (lambda = (1^8,0^8)),
# H_P = drho(P) = sum_x P_{x+a,x} c^dag_{x+a} c_x, Pi_0^P = projector onto ker H_P, M = (1/255) sum_P Pi_0^P.
# Hyperplanes A(s,c) = {x : s.x = c}, s != 0; the witness is w = sum of the 30 e_A, every coefficient +1.
#
# Every tagged line is an exact integer / rational / Gaussian-integer check, except [E1], which is floating point
# with the stated tolerance.  Tags match the claims table (OUTLINE.md) and the manuscript.  Exit status 1 on failure.
import sys, math, cmath, random
from fractions import Fraction as Fr

RESULTS = []
CHECKS = []  # (tag, function), run in order by the driver at the end


def rep(tag, ok, msg):
    RESULTS.append((tag, bool(ok)))
    print(("PASS " if ok else "FAIL ") + tag + " " + msg)
    sys.stdout.flush()


if hasattr(int, "bit_count"):
    popc = int.bit_count
else:  # Python < 3.10
    def popc(x):
        return bin(x).count("1")


def dot(u, x):  # u.x over F_2
    return popc(u & x) & 1


def elems(m):  # elements of a subset mask, ascending
    return [x for x in range(m.bit_length()) if (m >> x) & 1]


def mask(xs):
    return sum(1 << x for x in xs)


def sort_sign(seq):  # (sign of the permutation sorting seq, sorted tuple); sign 0 if an entry repeats
    if len(set(seq)) < len(seq):
        return 0, None
    inv = 0
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]:
                inv += 1
    return (-1 if inv & 1 else 1), tuple(sorted(seq))


# Gaussian integers as pairs (re, im); IPOW[k] = i^k
IPOW = [(1, 0), (0, 1), (-1, 0), (0, -1)]


def gmul(u, v):
    return (u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0])


def gadd(u, v):
    return (u[0] + v[0], u[1] + v[1])


def gneg(u):
    return (-u[0], -u[1])


def pcol(a, b, x):  # P_{a,b} e_x = i^k e_y; returns (y, k)
    return x ^ a, (popc(a & b) + 2 * dot(b, x)) & 3


D = 16
PAULIS = [(a, b) for a in range(D) for b in range(D) if a or b]  # 255 non-identity 4-qubit Paulis
ODD = [mask(x for x in range(D) if dot(s, x)) for s in range(D)]  # {x : s.x = 1}
HYP = [(s, c) for s in range(1, D) for c in (0, 1)]  # the 30 affine hyperplanes A(s,c)
HM = {h: mask(x for x in range(D) if dot(h[0], x) == h[1]) for h in HYP}
HSET = set(HM.values())
W = {HM[h]: 1 for h in HYP}  # w = sum_A e_A, all coefficients +1


# ---------- [B1] arithmetic of the Baer-Haah bounds (arXiv:2607.20919, Thm 3.16 and Prop. 3.17 / Eq. (2)) ----------
def bh_lower(n):  # (4^n + 16) / (16 (4^n - 1))
    q = 4 ** n
    return Fr(q + 16, 16 * (q - 1))


def bh_upper(n):  # 2^n (2^n - 3) / (8 (4^n - 1)), stated for n >= 3
    d = 2 ** n
    return Fr(d * (d - 3), 8 * (d * d - 1))


def check_B1():
    lo4, up4, lo3, up3 = bh_lower(4), bh_upper(4), bh_lower(3), bh_upper(3)
    meet = [n for n in range(1, 65) if bh_lower(n) == Fr(1, 2 ** n - 1)]
    below = all(bh_lower(n) < Fr(1, 2 ** n - 1) for n in range(1, 4))
    above = all(bh_lower(n) > Fr(1, 2 ** n - 1) for n in range(5, 65))
    ok = (lo4 == Fr(1, 15) == Fr(17, 255) and up4 == Fr(26, 255) and lo4 < up4 and 1 - up4 == Fr(229, 255)
          and lo3 == up3 == Fr(5, 63) and meet == [4] and below and above)
    rep("[B1]", ok, "Baer-Haah bounds at n=4: (4^n+16)/(16(4^n-1)) = 1/15 = 17/255 <= Delta_4 <= "
        "2^n(2^n-3)/(8(4^n-1)) = 26/255, and 1 - 26/255 = 229/255; at n=3 both bounds equal 5/63 (Delta_3 = 5/63); "
        "for n = 1..64 the lower bound equals 1/(2^n-1) only at n = 4 (below it for n <= 3, above it for n >= 5)")


CHECKS.append(("[B1]", check_B1))


# ---------- [W1] the 30 affine hyperplanes and the witness w ----------
def check_W1():
    distinct = len(HSET) == 30 and all(popc(m) == 8 for m in HSET)
    compl = all(HM[(s, 0)] ^ HM[(s, 1)] == (1 << D) - 1 for s in range(1, D))
    aff, n8 = [], 0  # independent characterisation: 8-subsets whose translate by their least element is XOR-closed
    for m in range(1 << D):
        if popc(m) != 8:
            continue
        n8 += 1
        el = elems(m)
        lin = [x ^ el[0] for x in el]
        lm = mask(lin)
        if all((lm >> (u ^ v)) & 1 for u in lin for v in lin):
            aff.append(m)
    ok = distinct and compl and n8 == 12870 and sorted(aff) == sorted(HSET) and sum(v * v for v in W.values()) == 30
    rep("[W1]", ok, "the 30 sets A(s,c) = {x : s.x = c} (s != 0, c = 0,1) are distinct 8-subsets, A(s,0) and A(s,1) "
        "are complementary, and they are exactly the affine 3-flats among all 12870 8-subsets of F_2^4; "
        "w = sum_A e_A (ascending binary order) has 30 coefficients +1 and |w|^2 = 30")


CHECKS.append(("[W1]", check_W1))


# ---------- [W2] Z-type counting ----------
def charge(s, m):  # eigenvalue of H_{Z_s} on the weight vector e_m: sum_{x in m} (-1)^{s.x}
    return popc(m) - 2 * popc(m & ODD[s])


def check_W2():
    ok, vals = True, set()
    for s in range(1, D):
        ch = {h: charge(s, HM[h]) for h in HYP}
        nonneutral = sorted(h for h in HYP if ch[h] != 0)
        ok = ok and nonneutral == [(s, 0), (s, 1)] and ch[(s, 0)] == 8 and ch[(s, 1)] == -8
        vals.add(sum(W[HM[h]] ** 2 for h in HYP if ch[h] == 0))  # <w, Pi_0^{Z_s} w>, weight vectors orthonormal
    ok = ok and vals == {28} and Fr(28, 30) == Fr(14, 15)
    rep("[W2]", ok, "Z-type counting: for each of the 15 Z-type Paulis Z_s = P_(0,s), e_A has Z_s-charge "
        "sum_{x in A} (-1)^{s.x} = 0 on the 28 hyperplanes with normal != s and +8, -8 on A(s,0), A(s,1); "
        "hence <w, Pi_0^{Z_s} w> = 28 = (14/15)|w|^2")


CHECKS.append(("[W2]", check_W2))


# ---------- [W3] order lemma: echelon coordinates; AGL(3,2) < A_8 ----------
def del_bit(x, p):  # delete bit p of x: the linear map F_2^4 -> F_2^3 forgetting coordinate p
    return (x & ((1 << p) - 1)) | ((x >> (p + 1)) << p)


def lin_image(cols, nbits):  # images of all x in F_2^nbits under the linear map with the given columns
    img = [0] * (1 << nbits)
    for x in range(1, 1 << nbits):
        low = (x & -x).bit_length() - 1
        img[x] = img[x & (x - 1)] ^ cols[low]
    return img


def check_W3():
    echelon = True
    for (s, c) in HYP:
        p = (s & -s).bit_length() - 1  # lowest set bit of the normal s
        echelon = echelon and [del_bit(x, p) for x in elems(HM[(s, c)])] == list(range(8))
    perms, even = set(), True
    for c0 in range(1, 8):
        for c1 in range(1, 8):
            for c2 in range(1, 8):
                if c1 == c0 or c2 in (c0, c1, c0 ^ c1):
                    continue
                img = lin_image((c0, c1, c2), 3)
                for t in range(8):
                    g = [img[x] ^ t for x in range(8)]
                    perms.add(tuple(g))
                    even = even and sort_sign(g)[0] == 1
    ok = echelon and len(perms) == 1344 and even
    rep("[W3]", ok, "order lemma: for each of the 30 hyperplanes A(s,c), deleting the lowest set bit of s maps A "
        "(binary order) increasingly and bijectively onto F_2^3 (echelon coordinates are order isomorphisms); "
        "all 1344 elements of AGL(3,2) are even permutations of F_2^3, i.e. AGL(3,2) < A_8")


CHECKS.append(("[W3]", check_W3))


# ---------- [W4] affine bijections of F_2^4 fix every hyperplane wedge sign; other linear orders ----------
HL = [elems(HM[h]) for h in HYP]


def wedge_map_ok(img):  # img[x] = g(x): g maps every hyperplane onto a hyperplane, with sorting sign +1
    for el in HL:
        seq = [img[x] for x in el]
        if mask(seq) not in HSET:
            return False
        inv = 0
        for i in range(7):
            si = seq[i]
            for j in range(i + 1, 8):
                if si > seq[j]:
                    inv += 1
        if inv & 1:
            return False
    return True


def check_W4():
    ngl, good = 0, True
    for c0 in range(1, 16):
        s0 = {0, c0}
        for c1 in range(1, 16):
            if c1 in s0:
                continue
            s1 = s0 | {u ^ c1 for u in s0}
            for c2 in range(1, 16):
                if c2 in s1:
                    continue
                s2 = s1 | {u ^ c2 for u in s1}
                for c3 in range(1, 16):
                    if c3 in s2:
                        continue
                    ngl += 1
                    good = good and wedge_map_ok(lin_image((c0, c1, c2, c3), 4))
    trans = all(wedge_map_ok([x ^ t for x in range(D)]) for t in range(D))
    rev = [int(format(x, "04b")[::-1], 2) for x in range(D)]  # bit-reversed order key
    gpos = [0] * D  # position of x in the reflected Gray code sequence k ^ (k >> 1), k = 0..15
    for k in range(D):
        gpos[k ^ (k >> 1)] = k
    orders = all(sort_sign([key[x] for x in el])[0] == 1 for key in (rev, gpos) for el in HL)
    ok = ngl == 20160 and good and trans and orders
    rep("[W4]", ok, "all 20160 elements of GL(4,2) and all 16 translations map each e_A to +e_{g(A)} with g(A) a "
        "hyperplane (sorting signs checked on all 30 wedges), so every affine bijection of F_2^4 fixes w; "
        "listing each A in bit-reversed order or in Gray-code order changes no sign: the same w exactly")


CHECKS.append(("[W4]", check_W4))


# ---------- [W5] RM(1,3) is self-dual ----------
def check_W5():
    code = sorted({mask(x for x in range(8) if dot(s, x) ^ c) for s in range(8) for c in (0, 1)})
    cset = set(code)  # bit x of a word = f(x) for the affine function f(x) = s.x + c on F_2^3
    linear = all((u ^ v) in cset for u in code for v in code)
    dual = [u for u in range(256) if all(popc(u & v) % 2 == 0 for v in code)]
    ok = len(code) == 16 and linear and dual == code
    rep("[W5]", ok, "RM(1,3) is self-dual: the 16 affine functions F_2^3 -> F_2 (words of length 8) form a linear "
        "[8,4] code C, and brute force over all 256 words gives C^perp = C")


CHECKS.append(("[W5]", check_W5))


# ---------- [W6] Clifford generators act on w by exterior-algebra expansion (exact, over Z[i]) ----------
def lam(colf, vec):  # Lambda^k(C) on a sparse vector {mask: gaussian}; colf(x) = column x of C, [(y, gaussian)]
    out = {}
    for m, cf in vec.items():
        part = [((), cf)]
        for x in elems(m):
            part = [(ys + (y,), gmul(c, g)) for ys, c in part for y, g in colf(x) if y not in ys]
        for ys, c in part:
            sg, srt = sort_sign(list(ys))
            key = mask(srt)
            o = out.get(key, (0, 0))
            out[key] = (o[0] + sg * c[0], o[1] + sg * c[1])
    return {k: v for k, v in out.items() if v != (0, 0)}


def gen_H(j):  # sqrt2 * H on qubit j (entries +-1)
    bj = 1 << j
    return lambda x: [(x & ~bj, (1, 0)), (x | bj, (-1, 0) if x & bj else (1, 0))]


def gen_S(j):  # S = diag(1, i) on qubit j
    bj = 1 << j
    return lambda x: [(x, (0, 1) if x & bj else (1, 0))]


def gen_CNOT(c, t):  # control qubit c, target qubit t
    return lambda x: [(x ^ (((x >> c) & 1) << t), (1, 0))]


WG = {m: (1, 0) for m in W}


def scaled(vec, k):
    return {m: (k * v[0], k * v[1]) for m, v in vec.items()}


def check_W6():
    ok, nterms = True, set()
    for j in range(4):
        Hj = gen_H(j)
        even = [HM[(s, c)] for (s, c) in HYP if not (s >> j) & 1]  # 14 hyperplanes containing pairs {x, x+e_j}
        graph = {HM[(s, c)]: (1, 0) for (s, c) in HYP if (s >> j) & 1}  # 16 graphs over the other 3 bits
        ok = ok and len(even) == 14 and len(graph) == 16
        ok = ok and all(lam(Hj, {m: (1, 0)}) == {m: (16, 0)} for m in even)
        for m in graph:
            img = lam(Hj, {m: (1, 0)})
            nterms.add((len(img), frozenset(img.values()) <= {(1, 0), (-1, 0)}))
        ok = ok and lam(Hj, graph) == scaled(graph, 16) and lam(Hj, WG) == scaled(WG, 16)
        ok = ok and lam(gen_S(j), WG) == WG
    pairs = [(c, t) for c in range(4) for t in range(4) if c != t]
    ok = ok and len(pairs) == 12 and all(lam(gen_CNOT(c, t), WG) == WG for c, t in pairs)
    ok = ok and nterms == {(256, True)}
    rep("[W6]", ok, "20 Clifford generators, exact expansion over Z[i] with ascending-order wedge signs: "
        "Lambda^8(sqrt2 H_j) e_A = 16 e_A for the 14 hyperplanes with s_j = 0; each of the 16 with s_j = 1 expands to "
        "256 terms +-e_B and their sum is mapped to 16 times itself (the RM(1,3) character sum); so "
        "Lambda^8(sqrt2 H_j) w = 16 w (j = 0..3), Lambda^8(S_j) w = w (4), Lambda^8(CNOT_jk) w = w (12 pairs)")


CHECKS.append(("[W6]", check_W6))


# ---------- [W7] local Clifford reduction: C_P P = +-Z^{supp P} C_P for every P ----------
G0, G1 = (0, 0), (1, 0)
F2 = {"1": [[G1, G0], [G0, G1]],                  # identity
      "H": [[G1, G1], [G1, (-1, 0)]],             # sqrt2 * H
      "HS": [[G1, (0, 1)], [G1, (0, -1)]]}        # (sqrt2 * H) S, S = diag(1, i)
LOCAL = {(0, 0): "1", (0, 1): "1", (1, 0): "H", (1, 1): "HS"}  # qubit letter (a_j, b_j): I, Z, X, Y


def conj(u):
    return (u[0], -u[1])


def check_W7():
    ok = all([[gadd(gmul(conj(f[0][r]), f[0][c]), gmul(conj(f[1][r]), f[1][c])) for c in (0, 1)] for r in (0, 1)]
             == [[(2, 0), G0], [G0, (2, 0)]] for k, f in F2.items() if k != "1")  # H^dag H = (HS)^dag HS = 2*1
    signs, targets = {1: 0, -1: 0}, set()
    for (a, b) in PAULIS:
        facs = [F2[LOCAL[((a >> j) & 1, (b >> j) & 1)]] for j in range(4)]
        C = []
        for y in range(D):
            row = []
            for x in range(D):
                e = G1
                for j in range(4):
                    e = gmul(e, facs[j][(y >> j) & 1][(x >> j) & 1])
                row.append(e)
            C.append(row)
        s = a | b  # support of P
        ks = [pcol(a, b, x)[1] for x in range(D)]
        CP = [[gmul(C[y][x ^ a], IPOW[ks[x]]) for x in range(D)] for y in range(D)]  # (C P)[y][x]
        ZC = [[gneg(C[y][x]) if dot(s, y) else C[y][x] for x in range(D)] for y in range(D)]  # (Z^s C)[y][x]
        if CP == ZC:
            signs[1] += 1
        elif CP == [[gneg(e) for e in row] for row in ZC]:
            signs[-1] += 1
        else:
            ok = False
        targets.add(s)
    ok = ok and signs[1] + signs[-1] == 255 and targets == set(range(1, D))
    rep("[W7]", ok, "local Clifford reduction: for each of the 255 non-identity P, C_P = tensor of 1, sqrt2 H, "
        "(sqrt2 H)S by qubit letter (I or Z, X, Y) satisfies C_P P = +-Z^{supp P} C_P exactly over Z[i] "
        "(%d with +, %d with -), with (sqrt2 H)^dag(sqrt2 H) = 2; by [W6] Lambda^8(C_P) w is a multiple of w, "
        "so <w, Pi_0^P w> = <w, Pi_0^{Z^{supp P}} w> = 28 for all 255 P" % (signs[1], signs[-1]))


CHECKS.append(("[W7]", check_W7))


# ---------- [W8] Rayleigh quotient of w (no H_P used) ----------
def check_W8():
    neutral = {s: sum(1 for h in HYP if charge(s, HM[h]) == 0) for s in range(1, D)}  # <w, Pi_0^{Z_s} w>
    per_p = [neutral[a | b] for (a, b) in PAULIS]  # via [W7]
    mult = {s: sum(1 for (a, b) in PAULIS if a | b == s) for s in range(1, D)}
    rq = Fr(sum(per_p), len(PAULIS) * sum(v * v for v in W.values()))
    ok = (set(per_p) == {28} and all(mult[s] == 3 ** popc(s) for s in mult) and rq == Fr(14, 15) == Fr(238, 255)
          and rq > Fr(229, 255) and 1 - rq == Fr(1, 15))
    rep("[W8]", ok, "Rayleigh quotient: <w, M w>/<w, w> = (1/255) sum_P 28/30 = 14/15 = 238/255 > 229/255 = 1 - 26/255 "
        "(the 3^|s| Paulis of support s all give 28); so ||M_(1^8,0^8)|| >= 14/15")


CHECKS.append(("[W8]", check_W8))


# ---------- Lie-algebra route: H_P on exterior powers as fermionic hopping (sparse integer vectors) ----------
def hop(a, b, vec):  # H'_{a,b} vec, where H_P = i^{a.b} H'_{a,b}; basis states are subset masks (any Lambda^k C^d)
    out = {}
    if a == 0:
        ob = ODD[b]
        for m, c in vec.items():
            ch = popc(m) - 2 * popc(m & ob)
            if ch:
                out[m] = out.get(m, 0) + ch * c
        return out
    for m, c in vec.items():
        for x in elems(m):
            y = x ^ a
            if (m >> y) & 1:
                continue
            lo, hi = (x, y) if x < y else (y, x)
            s = (popc(m & ((1 << hi) - (1 << (lo + 1)))) + dot(b, x)) & 1  # modes strictly between; (-1)^{b.x}
            nm = m ^ (1 << x) ^ (1 << y)
            out[nm] = out.get(nm, 0) + (-c if s else c)
    return {k: v for k, v in out.items() if v}


def pzero(a, b, vec, csq):  # prod_{c^2 in csq} (H_P^2 - c^2) vec, using H_P^2 = (-1)^{a.b} H'^2
    sg = -1 if popc(a & b) & 1 else 1
    y = vec
    for c2 in csq:
        z = {m: sg * v for m, v in hop(a, b, hop(a, b, y)).items()}
        for m, v in y.items():
            z[m] = z.get(m, 0) - c2 * v
        y = {m: v for m, v in z.items() if v}
    return y


def wedge_drho(a, b, m):  # i^{-a.b} drho(P) e_m by the Leibniz rule, re-sorted with ascending-order wedge signs
    out, el = {}, elems(m)
    for t, x in enumerate(el):
        seq = el[:]
        seq[t] = x ^ a
        sg, srt = sort_sign(seq)
        if sg:
            key = mask(srt)
            out[key] = out.get(key, 0) + (-sg if dot(b, x) else sg)
    return {k: v for k, v in out.items() if v}


CSQ8 = (4, 16, 36, 64)  # on Lambda^8 C^16: prod_c (H_P^2 - c^2) = 147456 Pi_0^P once spec H_P is in {0,+-2,...,+-8}
_rng = random.Random(20260928)
SAMPLE = sorted(HSET) + [mask(_rng.sample(range(D), 8)) for _ in range(18)]


def check_W9():
    agree = all(hop(a, b, {m: 1}) == wedge_drho(a, b, m) for (a, b) in PAULIS for m in SAMPLE)
    total, per, guard, maxsupp = {}, set(), True, 0
    for (a, b) in PAULIS:
        t = pzero(a, b, W, CSQ8)
        guard = guard and not hop(a, b, t)  # H_P t = 0 forces t = 147456 Pi_0^P w, whatever spec H_P is
        maxsupp = max(maxsupp, len(t))
        per.add(sum(t.get(m, 0) * v for m, v in W.items()))
        for m, v in t.items():
            total[m] = total.get(m, 0) + v
    total = {m: v for m, v in total.items() if v}
    ok = agree and guard and per == {147456 * 28} and total == {m: 147456 * 238 for m in W}
    rep("[W9]", ok, "Lie route (all 255 P, exact integers): t_P = prod_{c=2,4,6,8}(H_P^2 - c^2) w satisfies H_P t_P = 0, "
        "so t_P = 147456 Pi_0^P w; <w, t_P> = 147456*28 for every P and sum_P t_P = 147456*238*w, i.e. M w = (14/15) w "
        "exactly [largest support of t_P: %d of 12870; hopping signs agree with the Leibniz-rule wedge expansion "
        "on %d basis vectors for all 255 P]" % (maxsupp, len(SAMPLE)))


CHECKS.append(("[W9]", check_W9))


def check_W10():
    herm_inv = all((pcol(a, b, x)[1] + pcol(a, b, x ^ a)[1]) % 4 == 0 for (a, b) in PAULIS for x in range(D))
    traceless = all(a != 0 or sum(1 - 2 * dot(b, x) for x in range(D)) == 0 for (a, b) in PAULIS)
    cas = True
    for m in SAMPLE:
        acc = {}
        for (a, b) in PAULIS:
            sg = -1 if popc(a & b) & 1 else 1
            for k, v in hop(a, b, hop(a, b, {m: 1})).items():
                acc[k] = acc.get(k, 0) + sg * v
        cas = cas and {k: v for k, v in acc.items() if v} == {m: 1088}
    bound = 1 - Fr(1088, 64 * 255)
    ok = herm_inv and traceless and cas and 16 * 8 * (16 - 8 + 1) - 8 * 8 == 1088 and bound == Fr(14, 15)
    rep("[W10]", ok, "Casimir upper bound: all 255 P are Hermitian involutions with tr P = 0, so H_P has spectrum in "
        "{-8,...,8} on Lambda^8 and Pi_0^P <= 1 - H_P^2/64; sum_P H_P^2 e_B = 1088 e_B (= d k(d-k+1) - k^2, d = 16, "
        "k = 8) on the 30 hyperplane wedges and %d seeded random basis vectors; hence M <= 1 - 1088/(64*255) = 14/15, "
        "i.e. ||M_(1^8,0^8)|| <= 14/15" % (len(SAMPLE) - 30))


CHECKS.append(("[W10]", check_W10))


# ---------- selection lemma: Walsh-charge divisibility [S1] and the Bose-Burton count [S2] ----------
def subspaces(n):  # {frozenset of elements: dim} for all subspaces of F_2^n of dimension >= 1
    found, frontier = {}, {frozenset([0])}
    for dim in range(1, n + 1):
        new = set()
        for S in frontier:
            for v in range(1, 1 << n):
                if v not in S:
                    new.add(frozenset(S | {u ^ v for u in S}))
        for S in new:
            found[S] = dim
        frontier = new
    return found


def v2mod(k, n):  # 2-adic valuation of k mod 2^n (= n when 2^n divides k)
    k %= 2 ** n
    if k == 0:
        return n
    v = 0
    while k % 2 == 0:
        k //= 2
        v += 1
    return v


SUBS = {n: subspaces(n) for n in (3, 4)}


def check_S1():
    ok, nsub = True, {n: len(SUBS[n]) for n in SUBS}
    for n, subs in SUBS.items():
        d = 2 ** n
        for Wsp, m in subs.items():
            perp = [x for x in range(d) if all(dot(s, x) == 0 for s in Wsp)]
            for y in range(d):
                coset = {x ^ y for x in perp}
                for z in range(d):  # unit weight mu = e_z; the identity is linear in mu
                    lhs = 2 ** m * (1 if z in coset else 0)
                    rhs = sum((-1) ** dot(S, y) * (-1) ** dot(S, z) for S in Wsp)  # sum_S (-1)^{S.y} c_S(e_z)
                    ok = ok and lhs == rhs
        groups = {}  # all 0/1 weights mu of SU(2^n): (zero set of the Z-charges, |mu| mod 2^n)
        for mu in range(1 << d):
            k = popc(mu)
            zm = sum(1 << s for s in range(1, d) if k == 2 * popc(mu & ODD[s]))
            groups.setdefault(zm, set()).add(k % d)
        for Wsp, m in subs.items():
            wm = sum(1 << s for s in Wsp if s)
            ok = ok and all(k % 2 ** m == 0 for zm, ks in groups.items() if zm & wm == wm for k in ks)
    ok = ok and nsub == {3: 15, 4: 66}
    rep("[S1]", ok, "Walsh divisibility: 2^m sum_{x in y+W^perp} mu_x = sum_{S in W} (-1)^{S.y} c_S(mu) holds on all unit "
        "weights for every subspace W (dim m >= 1) and every y, n = 3 (15 subspaces) and n = 4 (66), hence for all "
        "integer weights; over all 0/1 weights (256 and 65536), c_S = 0 on W\\0 forces 2^m | |mu|")


CHECKS.append(("[S1]", check_S1))


def gen_matrices():  # the 20 Clifford generators as column functions (reused from [W6])
    return ([("H", j, gen_H(j)) for j in range(4)] + [("S", j, gen_S(j)) for j in range(4)]
            + [("CX", (c, t), gen_CNOT(c, t)) for c in range(4) for t in range(4) if c != t])


def conj_label(kind, arg, a, b):  # symplectic image (a', b') of P_(a,b) under conjugation by the generator
    if kind == "H":
        j = arg
        return (a & ~(1 << j)) | (((b >> j) & 1) << j), (b & ~(1 << j)) | (((a >> j) & 1) << j)
    if kind == "S":
        return a, b ^ (a & (1 << arg))
    c, t = arg
    return a ^ (((a >> c) & 1) << t), b ^ (((b >> t) & 1) << c)


def check_S2():
    ok, best = True, {}
    for n in (3, 4):
        d = 2 ** n
        subm = {}
        for Wsp, m in SUBS[n].items():
            subm.setdefault(m, []).append(sum(1 << s for s in Wsp if s))
        top = [0] * n  # top[v] = max |Z| with no (v+1)-dim subspace inside Z + {0}
        for Z in range(0, 1 << d, 2):  # bit s of Z <-> s in Z, s = 1..d-1
            dm = next((m for m in range(n, 0, -1) if any(wm & Z == wm for wm in subm[m])), 0)
            for v in range(dm, n):
                top[v] = max(top[v], popc(Z))
        best[n] = top
        ok = ok and top == [d - 2 ** (n - v) for v in range(n)]
    attained = [0] * 5
    for mu in range(1 << D):
        k = popc(mu)
        z = sum(1 for s in range(1, D) if k == 2 * popc(mu & ODD[s]))
        v = v2mod(k, 4)
        attained[v] = max(attained[v], z)
    ok = ok and attained == [0, 8, 12, 14, 15]
    orbit, frontier, gens = {(0, 1)}, [(0, 1)], gen_matrices()
    for kind, arg, G in gens:  # exact check G P = +-P' G for all 255 P
        for (a, b) in PAULIS:
            a2, b2 = conj_label(kind, arg, a, b)
            for x in range(D):
                y0, k0 = pcol(a, b, x)
                lhs = {y: gmul(IPOW[k0], g) for y, g in G(y0)}
                rhs = {}
                for y, g in G(x):
                    y1, k1 = pcol(a2, b2, y)
                    rhs[y1] = gmul(IPOW[k1], g)
                if x == 0:
                    sgn = 1 if lhs == rhs else -1
                ok = ok and (a2 or b2) and lhs == {y: (sgn * g[0], sgn * g[1]) for y, g in rhs.items()}
    while frontier:
        a, b = frontier.pop()
        for kind, arg, G in gens:
            q = conj_label(kind, arg, a, b)
            if q not in orbit:
                orbit.add(q)
                frontier.append(q)
    bounds = [Fr(D - 2 ** (4 - v), D - 1) for v in range(4)]
    ok = ok and len(orbit) == 255 and bounds == [0, Fr(8, 15), Fr(4, 5), Fr(14, 15)]
    rep("[S2]", ok, "Bose-Burton (q = 2), exhaustive: max |Z|, Z in F_2^n\\0 with Z+0 containing no (v+1)-dim subspace, "
        "is %s (n = 3) and %s (n = 4) = 2^n - 2^(n-v); attained by Walsh zero sets (max number of vanishing Z-charges "
        "over the 65536 0/1 weights, v = 0..4: %s); the 20 generators map every P to +-P' exactly and act "
        "transitively on the 255 Paulis; so ||M_lambda|| <= (2^n - 2^(n-v))/(2^n - 1), at n = 4: 0, 8/15, 4/5, 14/15 "
        "for v = 0..3" % (best[3], best[4], attained))


CHECKS.append(("[S2]", check_S2))


# ---------- [S3] sharpness of the selection bound; [S4] the corollary for n >= 3 ----------
def basis(d, k):  # masks of all k-subsets of {0,...,d-1}
    return [m for m in range(1 << d) if popc(m) == k]


def paulis(n):
    d = 2 ** n
    return [(a, b) for a in range(d) for b in range(d) if a or b]


def psd_nullity(rows):  # exact LDL^T over Q: nullity if the symmetric matrix is PSD, None otherwise
    A = [[Fr(v) for v in r] for r in rows]
    n, null = len(A), 0
    for k in range(n):
        p = A[k][k]
        if p < 0:
            return None
        if p == 0:
            if any(A[k][j] != 0 for j in range(k + 1, n)):
                return None
            null += 1
            continue
        Ak = A[k]
        for i in range(k + 1, n):
            f = A[i][k] / p
            if f:
                Ai = A[i]
                for j in range(k + 1, n):
                    Ai[j] -= f * Ak[j]
    return null


def check_S3():
    ok = True
    for n in (2, 3, 4):  # Lambda^2 C^d: charges in {0,+-2}, Casimir 2d(d-1) - 4, so M = d/(2(d-1)) exactly
        d, ps = 2 ** n, paulis(n)
        for m in basis(d, 2):
            acc = {}
            for (a, b) in ps:
                sg = -1 if popc(a & b) & 1 else 1
                h2 = hop(a, b, hop(a, b, {m: 1}))
                cube = {k: sg * v for k, v in hop(a, b, h2).items()}
                h1 = hop(a, b, {m: 1})
                ok = ok and {k: v for k, v in ((k, cube.get(k, 0) - 4 * h1.get(k, 0)) for k in set(cube) | set(h1))
                             if v} == {}  # H'(H_P^2 - 4) e_m = 0
                for k, v in h2.items():
                    acc[k] = acc.get(k, 0) + sg * v
            ok = ok and {k: v for k, v in acc.items() if v} == {m: 2 * d * (d - 1) - 4}
        ok = ok and 1 - Fr(2 * d * (d - 1) - 4, 4 * (d * d - 1)) == Fr(d, 2 * (d - 1)) == Fr(d - d // 2, d - 1)
    B4 = basis(8, 4)  # Lambda^4 C^8 (n = 3, |lambda| = 4, v = 2): T = sum_P (H_P^2-4)(H_P^2-16) = 64*63*M
    idx = {m: i for i, m in enumerate(B4)}
    T = [[0] * 70 for _ in range(70)]
    for (a, b) in paulis(3):
        for j, m in enumerate(B4):
            col = pzero(a, b, {m: 1}, (4, 16))
            ok = ok and not hop(a, b, col)  # guard: spec H_P on Lambda^4 C^8 is in {0,+-2,+-4}
            for k, v in col.items():
                T[idx[k]][j] += v
    sym = all(T[i][j] == T[j][i] for i in range(70) for j in range(70))
    null = psd_nullity([[(3456 if i == j else 0) - T[i][j] for j in range(70)] for i in range(70)])
    ok = ok and len(B4) == 70 and sym and null == 7 and Fr(3456, 64 * 63) == Fr(6, 7) == Fr(8 - 2, 7)
    ok = ok and Fr(16 - 2, 15) == Fr(14, 15)
    rep("[S3]", ok, "sharpness: on Lambda^2 C^d (n = 2, 3, 4, all basis vectors, all Paulis) H_P(H_P^2 - 4) = 0 and "
        "sum_P H_P^2 = 2d(d-1) - 4, so M = d/(2(d-1)) = (2^n - 2^(n-1))/(2^n - 1) (v = 1); on Lambda^4 C^8 "
        "3456*1 - sum_P (H_P^2-4)(H_P^2-16) is PSD with nullity %s (exact LDL), so ||M|| = 3456/4032 = 6/7 (v = 2); "
        "Lambda^8 C^16 attains 14/15 (v = 3) through w" % null)


CHECKS.append(("[S3]", check_S3))


def check_S4():
    ok = True
    for n in range(3, 65):
        d = 2 ** n
        top = 1 - Fr(d * (d - 3), 8 * (d * d - 1))  # 1 - (conjectured gap)
        b2, b3 = Fr(d - d // 4, d - 1), Fr(d - d // 8, d - 1)
        ok = (ok and top == Fr(7 * d * d + 3 * d - 8, 8 * (d * d - 1))
              and top - b2 == Fr(d * d - 3 * d - 8, 8 * (d * d - 1)) > 0
              and b3 - top == Fr(4 * d + 8, 8 * (d * d - 1)) > 0
              and all(Fr(d - 2 ** (n - v), d - 1) <= b2 for v in range(3)))
    ok = ok and (Fr(204, 255), Fr(229, 255), Fr(238, 255)) == (Fr(12, 15), 1 - Fr(26, 255), Fr(14, 15))
    rep("[S4]", ok, "corollary, n = 3..64 (exact): if 8 does not divide |lambda| then v <= 2 and ||M_lambda|| <= "
        "(2^n - 2^(n-2))/(2^n - 1) < 1 - 2^n(2^n-3)/(8(4^n-1)), margin (4^n - 3*2^n - 8)/(8(4^n-1)) > 0; the v = 3 "
        "bound (2^n - 2^(n-3))/(2^n - 1) exceeds 1 - 2^n(2^n-3)/(8(4^n-1)) by (4*2^n + 8)/(8(4^n-1)); "
        "at n = 4: 204/255 < 229/255 < 238/255")


CHECKS.append(("[S4]", check_S4))


# ---------- [C1], [C2] positive controls: the Lambda^4 code vector reproduces 1 - Delta_3 and the t = 4 value ----------
def code_quotient(n):  # traceless part of A = (1/d) sum_a Lambda^4(X^a) Pi_code in End(Lambda^4 C^d), d = 2^n
    d = 2 ** n
    B = basis(d, 4)
    N = len(B)
    A = {}
    for S in B:
        el = elems(S)
        if el[0] ^ el[1] ^ el[2] ^ el[3]:  # code wedges: 4-sets with zero XOR (affine planes)
            continue
        for a in range(d):
            sg, T = sort_sign([x ^ a for x in el])
            key = (mask(T), S)
            A[key] = A.get(key, Fr(0)) + Fr(sg, d)
    A = {k: v for k, v in A.items() if v != 0}
    col = {}
    for (t, s), v in A.items():
        col.setdefault(s, []).append((t, v))
    A2 = {}
    for (t, s), v in A.items():
        for (u, x) in col.get(t, []):
            A2[(u, s)] = A2.get((u, s), Fr(0)) + x * v
    A2 = {k: v for k, v in A2.items() if v != 0}
    r = sum(v for (t, s), v in A.items() if t == s)  # rank of the projector
    tau = r / N
    den = sum(v * v for v in A.values()) - 2 * tau * r + tau * tau * N
    qs = set()
    for s_ in range(1, d):  # Z-type P = Z_s acts on |t><u| with charge c_s(t) - c_s(u)
        num = sum(v * v for (t, u), v in A.items() if charge(s_, t) == charge(s_, u)) - 2 * tau * r + tau * tau * N
        qs.add(num / den)
    return A2 == A, r, qs


def check_C1():
    proj, r, qs = code_quotient(3)
    ok = proj and r == 7 and qs == {Fr(58, 63)} and Fr(58, 63) == 1 - bh_lower(3) and Fr(58, 63) > Fr(6, 7)
    rep("[C1]", ok, "positive control n = 3: the Lambda^4 code projector (rank %s) in End(Lambda^4 C^8), traceless part, "
        "has Rayleigh quotient 58/63 = 1 - 5/63 = 1 - Delta_3 for each of the 7 Z-type P, with the same wedge-sign and "
        "charge conventions; it exceeds the v = 2 bound 6/7 (balanced irreps have v = n)" % r)


CHECKS.append(("[C1]", check_C1))


def check_C2():
    proj, r, qs = code_quotient(4)
    ok = proj and r == 35 and qs == {Fr(229, 255)} and Fr(229, 255) == 1 - bh_upper(4) and Fr(229, 255) < Fr(14, 15)
    rep("[C2]", ok, "positive control n = 4: the Lambda^4 code projector (rank %s) in End(Lambda^4 C^16), traceless part, "
        "has Rayleigh quotient 229/255 = 1 - 26/255 (the t = 4 value behind Eq. (2)) for each of the 15 Z-type P; "
        "229/255 < 14/15" % r)


CHECKS.append(("[C2]", check_C2))


# ---------- [N1]-[N3] negative controls ----------
def rq_lie(vec):  # exact <v, M v>/<v, v> on Lambda^8 C^16 by the Lie route (spec H_P from [W10])
    num = 0
    for (a, b) in PAULIS:
        t = pzero(a, b, vec, CSQ8)
        num += sum(v * t.get(m, 0) for m, v in vec.items())
    return Fr(num, 147456 * 255 * sum(v * v for v in vec.values()))


def fr_list(xs):
    return "[" + ", ".join(str(x) for x in xs) + "]"


def check_N1():
    rng, qs = random.Random(7), []
    while len(qs) < 3:
        bits = rng.getrandbits(30)
        if bits in (0, (1 << 30) - 1):
            continue
        qs.append(rq_lie({HM[h]: (-1 if (bits >> i) & 1 else 1) for i, h in enumerate(HYP)}))
    ok = all(q < Fr(229, 255) for q in qs) and rq_lie(W) == Fr(14, 15)
    rep("[N1]", ok, "negative control: three seeded random sign patterns on the 30 hyperplane wedges give exact Rayleigh "
        "quotients %s (all < 229/255 < 14/15); the all-+1 pattern w gives 14/15 by the same routine" % fr_list(qs))


CHECKS.append(("[N1]", check_N1))


def check_N2():
    perm = list(range(D))
    random.Random(7).shuffle(perm)
    orders = [("weight-then-binary", [(popc(x), x) for x in range(D)]), ("seeded random", perm)]
    out, ok = [], True
    for name, key in orders:
        vec = {HM[h]: sort_sign([key[x] for x in elems(HM[h])])[0] for h in HYP}
        neg = sum(1 for v in vec.values() if v < 0)
        q = rq_lie(vec)
        ok = ok and 0 < neg < 30 and q < Fr(229, 255)
        out.append("%s order: %d signs flip, quotient %s" % (name, neg, q))
    rep("[N2]", ok, "negative control: ascending wedges in non-affine orders of F_2^4 break the witness: " + "; ".join(out)
        + " (both < 229/255)")


CHECKS.append(("[N2]", check_N2))


def check_N3():
    hist, fourteen = {}, set()
    for m in basis(D, 8):
        z = sum(1 for s in range(1, D) if charge(s, m) == 0)
        hist[z] = hist.get(z, 0) + 1
        if z == 14:
            fourteen.add(m)
    ok = hist == {5: 10080, 7: 1920, 11: 840, 14: 30} and fourteen == HSET
    rep("[N3]", ok, "negative control: over all 12870 8-subsets B, the number of Z-type Paulis with charge 0 on e_B is "
        "5, 7, 11 or 14 (multiplicities 10080, 1920, 840, 30), and 14 occurs exactly for the 30 hyperplanes; every "
        "other 8-subset is non-neutral for at least 4 of the 15 Z-type Paulis")


CHECKS.append(("[N3]", check_N3))


# ---------- [E1] explicit eigenfunction f(U) = sum_A det U[A,B0] (FLOATING POINT, stated tolerance) ----------
E1_THETAS = 17      # equally spaced angles; theta -> f(e^{i theta P} U) is a trigonometric polynomial of degree <= 8
E1_TOL_TXT = "1e-9"  # relative tolerance for (K_4 f)(U) = (14/15) f(U)
E1_TOL = float(E1_TOL_TXT)
E1_TRIALS = 3


def cdet(Mx):  # complex determinant, Gaussian elimination with partial pivoting
    A = [r[:] for r in Mx]
    n, det = len(A), 1 + 0j
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(A[r][i]))
        if A[p][i] == 0:
            return 0j
        if p != i:
            A[i], A[p] = A[p], A[i]
            det = -det
        piv = A[i][i]
        det *= piv
        Ai = A[i]
        for r in range(i + 1, n):
            f = A[r][i] / piv
            if f:
                Ar = A[r]
                for c in range(i + 1, n):
                    Ar[c] -= f * Ai[c]
    return det


def su16(rng):  # seeded pseudo-random U in SU(16): Gram-Schmidt of a complex Gaussian matrix, det phase removed
    G = [[complex(rng.gauss(0, 1), rng.gauss(0, 1)) for _ in range(D)] for _ in range(D)]
    Q = []
    for c in range(D):
        v = [G[r][c] for r in range(D)]
        for _ in range(2):
            for q in Q:
                ip = sum(q[r].conjugate() * v[r] for r in range(D))
                v = [v[r] - ip * q[r] for r in range(D)]
        nv = math.sqrt(sum(abs(z) ** 2 for z in v))
        Q.append([z / nv for z in v])
    U = [[Q[c][r] for c in range(D)] for r in range(D)]
    ph = cmath.exp(-1j * cmath.phase(cdet(U)) / D)
    return [[z * ph for z in row] for row in U]


def f_val(V):  # f = sum over the 30 hyperplanes A of det V[A,:], V = U[:, B0] (16 x 8)
    return sum(cdet([V[x] for x in el]) for el in HL)


def check_E1():
    f1 = f_val([[1.0 if r == c else 0.0 for c in range(8)] for r in range(D)])  # U = 1, B0 = {0,...,7}
    ok, rng = f1 == 1, random.Random(15)
    omega = cmath.exp(2j * math.pi / D)
    for _ in range(E1_TRIALS):
        U = su16(rng)
        B0 = sorted(rng.sample(range(D), 8))
        V = [[U[r][c] for c in B0] for r in range(D)]
        unit = all(abs(sum(U[r][i].conjugate() * U[r][j] for r in range(D)) - (i == j)) < E1_TOL
                   for i in range(D) for j in range(D))
        f0 = f_val(V)
        acc = 0j
        for (a, b) in PAULIS:
            PV = [None] * D
            for x in range(D):
                y, k = pcol(a, b, x)
                PV[y] = [(1, 1j, -1, -1j)[k] * z for z in V[x]]
            for t in range(E1_THETAS):
                th = 2 * math.pi * t / E1_THETAS
                c, s = math.cos(th), math.sin(th)
                acc += f_val([[c * V[x][j] + 1j * s * PV[x][j] for j in range(8)] for x in range(D)])
        Kf = acc / (len(PAULIS) * E1_THETAS)
        centre = abs(f_val([[omega * z for z in row] for row in V]) + f0) < E1_TOL * abs(f0)
        ok = (ok and unit and abs(cdet(U) - 1) < E1_TOL and abs(f0) > 1e-3 and centre
              and abs(Kf - (14 / 15) * f0) < E1_TOL * abs(f0))
    rep("[E1]", ok, "(floating point; relative tolerance %s) f(U) = sum_A det U[A,B0] has f(1) = 1 for B0 = {0,...,7}; "
        "at %d seeded pseudo-random U in SU(16) (|U^dag U - 1|, |det U - 1| < %s) with seeded 8-sets B0 and "
        "|f(U)| > 1e-3, (K_4 f)(U) = (1/255) sum_P mean_theta f(e^{i theta P} U), theta on %d equally spaced angles "
        "(exact for this trigonometric polynomial of degree <= 8), equals (14/15) f(U); f(omega U) = -f(U) for the "
        "central omega = e^{2 pi i/16}, so f has Haar mean 0"
        % (E1_TOL_TXT, E1_TRIALS, E1_TOL_TXT, E1_THETAS))


CHECKS.append(("[E1]", check_E1))


# ---------- [T] Theorem 1 ----------
def check_T():
    need = ["[B1]"] + ["[W%d]" % i for i in range(1, 11)] + ["[S1]", "[S2]"]
    passed = {t for t, ok in RESULTS if ok}
    norm = Fr(14, 15)
    sel = v2mod(8, 4) == 3 and Fr(D - 2 ** (4 - 3), D - 1) == norm  # selection bound at |lambda| = 8, n = 4
    gap = 1 - norm
    ok = (all(t in passed for t in need) and sel and norm > 1 - bh_upper(4) and gap == Fr(1, 15) == bh_lower(4)
          and gap < bh_upper(4))
    rep("[T]", ok, "Theorem: M w = (14/15) w ([W9]; Rayleigh route [W8]) and ||M_(1^8,0^8)|| <= 14/15 ([W10]; "
        "independently the selection bound with v = nu_2(8 mod 16) = 3, (16-2)/15 [S1],[S2]), so "
        "||M_(1^8,0^8)|| = 14/15 > 229/255; hence ||K_4 on L^2_0|| >= 14/15, Delta_4 <= 1/15 < 26/255 and Eq. (2) "
        "fails at n = 4; with Baer-Haah Thm 3.16 (Delta_4 >= 1/15), Delta_4 = 1/15")


CHECKS.append(("[T]", check_T))


# ---------- driver ----------
def main():
    for tag, fn in CHECKS:
        before = len(RESULTS)
        try:
            fn()
        except Exception as ex:  # a check that crashes is a failed check
            rep(tag, False, "raised %s: %s" % (type(ex).__name__, ex))
        if len(RESULTS) != before + 1 or RESULTS[-1][0] != tag:
            rep(tag, False, "check did not report exactly one result")
    tags = [t for t, _ in CHECKS]
    fails = [t for t, ok in RESULTS if not ok]
    if fails or len(set(tags)) != len(tags):
        print("VERDICT FAIL: " + " ".join(fails))
        sys.exit(1)
    print("VERDICT PASS: all %d checks passed (%d exact, [E1] floating point); M w = (14/15) w, "
          "||M_(1^8,0^8)|| = 14/15, Delta_4 = 1/15 < 26/255" % (len(tags), len(tags) - 1))


main()
