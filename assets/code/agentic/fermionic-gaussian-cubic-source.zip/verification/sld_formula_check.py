"""Small Fock-space convention diagnostic, not proof or theorem acceptance."""
import numpy as np, json
def expm_frechet(H,V):
 e,u=np.linalg.eigh(H);ex=np.exp(e);F=np.empty((len(e),len(e)))
 for i in range(len(e)):
  for j in range(len(e)):
   F[i,j]=ex[i] if abs(e[i]-e[j])<1e-12 else (ex[i]-ex[j])/(e[i]-e[j])
 return (u*ex)@u.conj().T,u@(F*(u.conj().T@V@u))@u.conj().T
rng=np.random.default_rng(122123)
rows=[]
for m in (1,2,3):
 I=np.eye(2);Z=np.diag([1,-1]);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]])
 def kron(xs):
  z=np.array([[1.]])
  for x in xs:z=np.kron(z,x)
  return z
 g=[kron([Z]*j+[a]+[I]*(m-j-1)) for j in range(m) for a in (X,Y)]
 mats=[1j*g[a]@g[b] for a in range(2*m) for b in range(a+1,2*m)]
 for rep in range(12):
  H=sum(float(x)*M for x,M in zip(rng.normal(size=len(mats)),mats))
  V=sum(float(x)*M for x,M in zip(rng.normal(size=len(mats)),mats))
  e,de=expm_frechet(H,V);tr=np.trace(e).real;r=e/tr;dr=de/tr-r*np.trace(de).real/tr
  Gamma=np.array([[0 if a==b else (1j*np.trace(r@g[a]@g[b])).real for b in range(2*m)]for a in range(2*m)])
  dGamma=np.array([[0 if a==b else (1j*np.trace(dr@g[a]@g[b])).real for b in range(2*m)]for a in range(2*m)])
  er,ur=np.linalg.eigh(r);D=ur.conj().T@dr@ur;full=2*np.sum(abs(D)**2/(er[:,None]+er[None,:]))
  ek,uk=np.linalg.eigh(1j*Gamma);A=uk.conj().T@(1j*dGamma)@uk;gauss=.5*np.sum(abs(A)**2/(1-ek[:,None]*ek[None,:]))
  rel=abs(full-gauss)/max(1.,full)
  assert rel<2e-9,(m,rep,full,gauss,rel)
  rows.append({'m':m,'rep':rep,'full_SLD':float(full),'covariance_SLD':float(gauss),'relative_error':float(rel)})
print(json.dumps({'status':'finite_convention_checks_passed','instances':len(rows),'maximum_error':max(x['relative_error'] for x in rows),'rows':rows},indent=2))
