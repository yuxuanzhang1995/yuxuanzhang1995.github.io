# An all-error lower dual for sharp work on a covariant Choi face

Use \(\beta>0\), normal Gibbs baths of finite partition function, and sharp nondegenerate battery endpoints for every input. Subtract individual system ground energies. The only charged resource in this task is the battery. Let \(C\) be the compact set of covariant CPTP channels in the specified closed reference-assisted purified-distance ball. The set is convex, by concavity of root fidelity on every input. If empty the work is infinite. Otherwise let \(S\) be the span of the Kraus supports of \(C\). It is invariant under time translations. A finite average of members has exactly this support, and it belongs to \(C\) even when the ball is tangent to the covariant set.

Pick a basis \(K_a\) of \(S\) consisting of frequency operators, \(H_BK_a-K_aH_A=\nu_a K_a\). Frequencies are in the supplied lattice and may be repeated. Write \(T\) for a covariant channel Gram in this basis using the convention \(\Psi_T(X)=\sum_{a,b}T_{ba}K_a X K_b^*\). Channel positives, TP, covariance and the fidelity ball are finite-dimensional constraints throughout.

## Graded matrix inequalities without a resource or a target fit

In the following universal test choose any finite dimension list \(m_n\) on the energy lattice, not identically zero. Put \(\mathcal E_n=\mathbb C^{m_n}\). Choose PSD matrices \(G^k\) on \(\bigoplus_a\mathcal E_{k+\nu_a}\), retaining the summand for each \(a\) separately even when frequencies coincide. Lattice indices in formulas are written in energy units. Impose the linear set of identities
\[
 \sum_{\substack{k,a,b:\\ n=k+\nu_a,\ n'=k+\nu_b}}
     K_a^*K_b\otimes G^k_{ab}
   ={\bf1}_{n=n'} I_A\otimes I_{\mathcal E_n}
       \quad\text{as maps }A\mathcal E_{n'}\longrightarrow A\mathcal E_n. \tag{1}
\]
Only finitely many \(k\) have a nonempty row. For each inverse temperature \(u\ge\beta\) put \(P_u=\sum_n m_n e^{-un}\). Define the linear matrix \(L_u(G)\) by entries zero for unequal frequencies, and otherwise by
\[
 [L_u(G)]_{ab}=\sum_k e^{-u(k+\nu_a)}\operatorname{Tr}G^k_{ab}.
\]
For a Hermitian matrix \(H\) define its admissibility, denoted \(H\in\mathcal H_u(S)\), by the single universal inequality
\[
 \langle H,L_u(G)\rangle
 \ \le\ \frac{Z_B(u)}{Z_A(u)}\sum_k e^{-uk}\operatorname{rank}G^k
 \qquad\text{on all finite lists and PSD matrices satisfying (1).}       \tag{2}
\]
Here \(\langle H,T\rangle=\operatorname{Tr}HT\). Let \(e\) be any Hermitian representative of the linear functional equal to one on normalized TP Grams, for example the normalized trace of \(\Psi_T(I_A)\). Set
\[
 d_u(S)=\sup\{z:ze\in\mathcal H_u(S)\},\qquad
 b_C=\sup_{H\in\mathcal H_\beta(S)}\ \min_{T\in C}\langle H,T\rangle .
\]
Lastly let \(g(S)\) be the smallest maximum Kraus frequency of any TP covariant channel supported in \(S\). It is found by finitely many PSD feasibility tests on frequency-truncated supports. Then
\[
 W_\epsilon(\Phi)=\max\!\left\{ g(S),\
      \sup_{u\ge\beta} u^{-1}\log d_u(S),\
      \beta^{-1}\log b_C \right\}.                                      \tag{3}
\]
The target enters (3) through its finite-dimensional closed ball and \(S\). The dimension inequalities in (2) depend on \(S\) and system energies alone. They give lower bounds, while the previous finite-bath-register isometry hierarchy gives upper bounds with the same infimum. Evaluating (2) involves arbitrary finite matrix sizes. [F29](positive-work.md) rules out a uniform effective test producing positive lower estimates in every positive-cost case, even with rational full-rank targets. This formula is an analytic characterization with explicit noncomputability boundaries.

## Why dimension and trace are the correct quantities

A finite logical Gibbs isometry of common shift zero supported on \(S\) is \(V=\sum_a K_a\otimes A_a\), where \(A_a:\mathcal E_{k+\nu_a}\to\mathcal F_k\) on each output grade. Faithfulness of the input Gibbs state implies that every Kraus operator from every pair of environmental basis states is in \(S\). Frequency covariance of \(V\) gives the indicated grading. If environment energies occupy distinct cosets of the system transition lattice the isometry splits into independent cosets; unused output levels can be discarded. One constant shift per coset cancels in any one-temperature ratio. The full ratio is a convex average of the coset ratios at that temperature, with precisely the coset probabilities used to compute the normalized channel Gram at that temperature.

The Gram of all columns ending at grade \(k\) is \(G^k\). Isometry is exactly (1); factoring each PSD \(G^k\) independently gives a converse using \(\dim\mathcal F_k=\operatorname{rank}G^k\). Extra output dimensions can only raise the positive partition ratio. Its exponentiated single-temperature index is \((Z_B/Z_A)\sum_k e^{-uk}\operatorname{rank}G^k/P_u\), and its normalized Gram is \(L_u(G)/P_u\). This proves the equivalence between (2) and the family of affine lower bounds on that index for all supported finite logical dilations. In particular \(d_u(S)\) equals the minimum ratio as an infimum over allowed dilations, regardless of their original input weights at \(\beta\): whether their output Kraus operators belong to \(S\) is independent of the temperature as long as the input Gibbs state is faithful. This is the point at which freely replacing the finite-matrix class by abstract tracial algebras could give a wrong answer.

## The closed fidelity ball, including at the approximation threshold

For a fixed covariant \(T\), let \(b(T)\) be the infimal exponentiated single-\(\beta\) index for an exact finite logical dilation of \(T\). On the compact convex face \(C_S\) of all covariant TP Grams supported in \(S\), this function is finite, bounded and convex. These facts follow from the constant pure-environment Stinespring upper bound and exact Gibbs direct sums with adjustable offsets. The previous [exact face separation](general-work-face-separation-v1.md) gives \(W_0(T)=\max\{s(S_T),\beta^{-1}\log b(T)\}\); the support cost \(s\) decreases when its permitted support grows. Choose \(T_0\in C\) positive definite on \(S\). For each \(T\in C\), \((1-t)T+tT_0\) is still in \(C\), has full support \(S\) and has \(b\) at most \((1-t)b(T)+t b(T_0)\). Thus the infimum of exact work over \(C\) is \(\max\{s(S),\beta^{-1}\log\inf_C b\}\). No strictly interior point of the *error ball* was invoked.

Let \(\bar b\) be the lower-semicontinuous convex closure of \(b\) *on \(C_S\)*, extending it by infinity outside. Its affine minorants coincide with the minorants of \(b\), exactly the \(H\)'s in (2), since constants are represented by \(e\). In the relative interior \(b=\bar b\). Also \(\inf_C b=\min_C\bar b\): for a minimizer \(T\) of the right side, all points \((1-t)T+tT_0,\ t>0\), are in the relative interior of \(C_S\) and in \(C\). Convexity of \(\bar b\) bounds their \(\bar b=b\) values above by \((1-t)\bar b(T)+t\bar b(T_0)\). This argument stays within the admissible support.

Finite-dimensional convex separation expresses \(\bar b(T)\) as the supremum of its affine minorants. Bilinear minimax (compact convex \(C\), convex \(\mathcal H_\beta(S)\), continuous finite pairings) gives precisely \(\min_C\bar b=b_C\). Finally the earlier [support minimax](general-work-support-minimax-v1.md) gives \(s(S)=\max\{g(S),\sup_{u\ge\beta}u^{-1}\log d_u(S)\}\). This yields (3). The previous all-error physical equivalence of work and finite logical isometries is needed for both directions. [Operational identity](work-variational-review-v5.md)

At zero Hamiltonian and zero error, the rectangular rank dual was already written in [F03](cp-order-converse-fails-v1.md). Its qutrit example rules out replacing (2) by mere scalar complete-positive-order dominance. The new steps concern energy-graded ranks, all inverse temperatures and the minimal support of an arbitrary *closed* error ball, with a sharp lower witness acting on the whole target set. No independent review or novelty confirmation is claimed.
