# Integrated manuscript review — Q119 version 2.0

16 November 2026. Verdict: internally supported for the explicitly authorized
website release, with the limitations below. Review was sequential within
the same agent that integrated the manuscript. No independent expert review,
fresh-agent review, or proof-assistant certification is claimed.

Reviewed source SHA-256:
`5ebe4a70254a41fb71a6fb95345042f79fd453892d8a492cb1fc3e5095e7d6ad`

Reviewed 13-page PDF SHA-256:
`a4a2be6d78992efd5bb6bf23cc7f8b82407a6979a5f956a6b735cf7a5b2934f9`

## Exact target and result scope

Original: Q119 / QIQCOP `op_b1b41f737f9b4aeb`, “Tough error models,”
catalog version 4 September 2026, checked 16 November 2026. The problem
allows exact determination or asymptotically matching bounds, with explicit
tough models. Its errors form an arbitrary complex e-dimensional subspace
of M_n, with neither identity inclusion nor trace-preserving normalization.

The inherited theorem proves bounds differing by at most one code dimension,
uniform absolute error below one from n/(e²+1), and relative asymptotics when
n/(e²+1) diverges. Explicit models attain its upper bound. This addresses the
original asymptotic option; it does not determine all finite integer values.

| Manuscript result | Hypotheses and guarantee | Review outcome |
| --- | --- | --- |
| Theorems 1.1 and 2.1; Section 3 | Arbitrary error spaces; exact scalar compression at n ≥ Dk−1; explicit upper models | Inherited proofs retained and read in full |
| Theorem 4.1 | Hermitian observables, k ≥ 2, n ≥ (m+1)k−1; quantitative gradient–curvature inequality | Complete analytic argument supported |
| Theorem 5.1 and Section 5.1 | Specified norm bounds and error basis; approximate residual in a bounded number of ideal-arithmetic steps | Supported with basis and arithmetic qualifiers |
| Theorem 6.1 | Normalized square Kraus matrices, n ≥ ek; full trace-preserving decoder and diamond bound | Supported, including singular Gram matrices |
| Corollary 6.2 | e ≥ 2, k ≥ 2, n ≥ e²k−1, 0 < ε ≤ 2 | Search plus recovery in the stated iteration count |

The arbitrary-error and normalized-channel statements are distinct. In the
latter e counts supplied Kraus operators, not necessarily their linear rank.
No normalized threshold is imported into the arbitrary-error minimax bound.

## Analytical review

1. The inherited stationary equation has a Hermitian multiplier because each
   compressed observable commutes with its traceless part. A nonzero traceless
   Hermitian block has rank at least two, providing the exact rank defect.
   The common orthogonal vector exists at n ≥ Dk−1. The summed column
   rotations give −4F. The D=1, k=1 and small-n cases are treated separately.
2. The block upper models have e independent errors because all coordinate
   labels are present. Cross products recover pair projections; diagonal
   products recover coordinate projections; the identity recovers the zero
   block. The rank argument applies to arbitrary codes, not only block codes.
   The e ≥ n construction and ceiling cases are included.
3. The stack lemma uses tracelessness before maximizing over vectors and
   proves a bound on the second singular value, not on the smallest one.
   Its sharp example and nontraceless countercontrol are explicit.
4. The rectangular argument only inverts the two leading singular values.
   C has q ≥ p−1 rows; the rank-p−2 approximation leaves a left vector,
   including q=p−1. No full-column-rank assumption is hidden here.
5. The complete Hessian is derived in the integrated text. Both phase
   directions are included; the D_j terms cancel by tracelessness and
   Tr S=F. With the real Frobenius metric the gradient is 4R, so the
   coefficients a²=(k−1)²(k+1), k/4, and the curvature estimate follow.
6. All geodesic derivative bounds hold globally along the chosen curve.
   The two Leibniz sums give 4^r β. The gradient branch decreases by at
   least F²/(32βa²); the curvature branch decreases by F²/(48βk²).
   Both imply F_next ≤ F−F²/(48βk³). The reciprocal recurrence gives
   the stated ceiling bound. Zero residual and zero scale avoid division.
7. Hermitian error products with sqrt(2) scaling preserve the ordered-pair
   residual. The arbitrary-basis estimate uses coefficient norms relative
   to that basis and does not assert scale-invariant physical error.
8. The normalized Gram average is positive with trace one. The condition
   n ≥ ek is exactly what allows a polar isometric completion, including
   rank-deficient K. The replacement term makes the decoder trace
   preserving on the whole physical output space.
9. The square-root estimate uses operator monotonicity and functional
   calculus; it never squares a noncommuting inequality. The two comparison
   dilations are isometries. Their trace-norm estimate holds with arbitrary
   references and inputs, so it proves a diamond bound, not merely a
   maximally-entangled-input test. The convention has no factor one half.
10. The normalized coefficient map is unital CP. Its Hermitian orthonormal
    basis removes exactly the scalar identity direction, leaving m=e²−1,
    β=k(e²−1). Substituting τ=ε⁴/(16e²) yields the coefficient 768 and
    n ≥ e²k−1. This implies n ≥ ek for e,k ≥ 2. The e=1 and k=1 cases
    are separately trivial.

## Correction discovered during integration

The optional paragraph after Claim 1 in the frozen S02 note asserted a literal
left kernel at every point under n > (m+1)k−1. This is one dimension too weak:
at n=(m+1)k the cross block can be square and invertible. The integrated text
restricts this auxiliary observation to n > (m+1)k. The main proof uses the
rank-p−2 approximation and already works at n ≥ (m+1)k−1; its theorem and
the subsequent algorithm are unaffected.

The new exact regression sets m=1, k=2, n=4 and cross block C=I_2 inside
a Hermitian block matrix. Its left kernel is zero. Adding a fifth ambient
coordinate supplies the claimed strict-dimension left kernel. Historical
notes and their reviews are preserved as evidence and explicitly superseded
by the integrated manuscript and this correction.

## Finite verification and document checks

The package replay ran in a fresh temporary directory with Python 3.11.13,
NumPy 2.4.4 and SymPy 1.14.0. All six checker processes completed normally.

- Inherited identities: 9 exact derivative cases and 9 rejected mutations.
- Inherited models: 1,334 exact checks and 6 rejected mutations.
- Full-Hessian boundary audit: 3 exact matrix cases.
- Quantitative extension: 8 exact controls and 3 floating runs, reaching their
  targets in 439, 508 and 136 steps. The last included 10 curvature steps.
- Recovery extension: 6 exact controls, including diamond error 2/65 for a
  rational dephasing example, and one floating normalized-channel pipeline
  reaching F < 10^-4 after 331 steps.
- Integration correction: 1 exact square-cross-block countercontrol.

The 18 new/boundary exact cases and 4 floating runs are finite evidence.
They do not certify the universal theorem, a numerical diamond bound by
interval arithmetic, or arbitrary finite-precision termination. The analytic
proof is reviewed separately above. `REPLAY.json` contains the actual outputs.

The 13-page PDF was compiled with latexmk/pdfLaTeX and rendered with Poppler.
All pages were inspected visually, including every new theorem and proof.
No unresolved citation/reference, overfull/underfull box, missing formula,
clipped text or overlap was found in the final build. Author, date, version,
equation numbering and the old/new claim boundaries agree with the source.

## Primary-source comparison and limits

The exact catalog statement was checked at
https://qiqc-op.com/problem/op_b1b41f737f9b4aeb/ . It still lists the problem
as unsolved; publication does not automatically change that external status.
The inherited comparison addresses Weaver's Theorem 2.10/Proposition 2.1
and Allen–Kornell's Theorem 2.7/Lemma 2.3, as cited in the paper.

New attribution was checked against these primary sources:

- Gupta et al., https://arxiv.org/html/2604.21800 , Section VI.1, Eq. (103):
  the same sum of squared traceless compression residuals is already used
  for optimization. The inspected section does not provide the uniform
  quantitative dimension-dependent theorem proved here.
- Ng–Mandayam, https://arxiv.org/html/0909.0931 , Eq. (4): standard transpose
  recovery with inverse square root on the noisy-code support. The polar
  decoder agrees there. Recovery itself is not claimed as new.
- Bény–Oreshkov, https://arxiv.org/abs/0907.5391 : general approximate QEC
  conditions and near-optimal recovery in worst-case entanglement fidelity.
- Kretschmann–Schlingemann–Werner, https://arxiv.org/abs/0710.2495 : broader
  Stinespring continuity framework. The direction used here is proved directly.

These are specific primary-source comparisons, not exhaustive priority
clearance. Independent expert review and finite-precision complexity remain
outstanding. No efficient algorithm in qubit count, exact finite-step code,
new general AQEC theory, or resolution of c(2,6) is claimed.
