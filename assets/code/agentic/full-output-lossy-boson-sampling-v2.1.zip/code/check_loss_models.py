"""Targeted exact controls for the loss extension review.

Standard library only. No imported candidate implementations or formula outputs.
These finite checks support the separate analytic proofs; they are not a proof
of an asymptotic sampler and do not implement its efficient prefix oracle.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, factorial, prod
from pathlib import Path
import json

counts = Counter()
mutations = Counter()


def check(name, value):
    counts[name] += 1
    if not value:
        raise AssertionError(name)


def subsets(n, size=None):
    sizes = range(n + 1) if size is None else [size]
    return [frozenset(c) for a in sizes for c in combinations(range(n), a)]


def law(eta):
    return {s: prod((p if i in s else 1-p) for i, p in enumerate(eta))
            for s in subsets(len(eta))}


def pmul(a, b):
    out = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return out


def pprod(polys):
    out = [F(1)]
    for p in polys:
        out = pmul(out, p)
    return out


def coeff(p, d):
    return p[d] if 0 <= d < len(p) else F(0)


cases = [tuple(F(v) for v in eta) for eta in [
    ['1/2'], ['0'], ['1/1000000', '4/5'],
    ['1/5', '2/5', '4/5'], ['1/3']*4,
    ['0', '1/4', '1/2', '3/4'],
    ['1/7', '2/7', '3/7', '4/7', '5/7', '6/7'],
]]
cases += list(product([F(1, 7), F(2, 5), F(4, 5)], repeat=3))
max_n = 0
for eta in cases:
    n = len(eta)
    max_n = max(n, max_n)
    gamma = max(eta) or F(1, 2)
    original = law(eta)
    prefilter = law([p/gamma for p in eta])
    composed = dict.fromkeys(original, F(0))
    for a, pa in prefilter.items():
        for s in original:
            if s <= a:
                composed[s] += pa*gamma**len(s)*(1-gamma)**(len(a)-len(s))
    check('prefilter_normalization', sum(prefilter.values()) == 1)
    for s, p in original.items():
        check('two_stage_survivor_probability', composed[s] == p)
    # Negative control: incorrectly retain the first-stage probabilities eta_i.
    bad = law([p*gamma for p in eta])
    if any(bad[s] != original[s] for s in original):
        mutations['missing_division_by_gamma'] += 1

    w = [sum(p for s, p in original.items() if len(s) == k) for k in range(n+1)]
    for l in range(1, n+1):
        purity_sum = F(0)
        max_window_sum = F(0)
        for k in range(l, n+1):
            js = subsets(n, l)
            # Construct reduced coefficients by tracing explicit survivor sets.
            nu = {j: sum(p for s, p in original.items() if len(s) == k and j <= s)
                  / comb(k, l) for j in js}
            check('reduced_mass', sum(nu.values()) == w[k])
            outside_probs = []
            for j in js:
                outside = pprod([[1-eta[i], eta[i]] for i in range(n) if i not in j])
                wp = coeff(outside, k-l)
                outside_probs.append(wp)
                check('survivor_reduction_coefficient',
                      nu[j] == prod(eta[i] for i in j)*wp/comb(k, l))
                window = sum(w[max(0, k-l):k+1])
                check('window_domination', wp <= window)
            max_window_sum += max(outside_probs)
            if w[k]:
                purity_sum += comb(k, l)*sum(v*v for v in nu.values())/w[k]
        check('max_window_sum_bound', max_window_sum <= l+1)
        # Sharper bound proved by mixture convexity, without the factor l+1.
        refined = gamma**l*sum(p for a, p in prefilter.items() if len(a) >= l)
        check('stronger_weighted_unprojected_purity', purity_sum <= refined)
        check('stronger_uniform_envelope', refined <= gamma**l)

    # Reconstruct the note's reduced-color polynomial via exact rationals.
    # Exhaust all k,l,a,I for three deterministic colorings; include n=6,l=6.
    if n > 4 or eta in cases[:7]:
        for l in range(1, n+1):
            pl = F(factorial(l), l**l)
            patterns = {tuple(i % l for i in range(n)), (0,)*n,
                        tuple((i*i+1) % l for i in range(n))}
            for h in patterns:
                pp = {i: pprod([[1-eta[t], eta[t]]
                               for t in range(n) if t != i and h[t] == h[i]])
                      for i in range(n)}
                sc = {}
                for c in range(l):
                    sc[c] = [F(0)]*(n+1)
                    for i in range(n):
                        if h[i] == c:
                            for d, val in enumerate(pp[i]):
                                sc[c][d] += eta[i]*val
                colorful = [j for j in subsets(n, l) if len({h[i] for i in j}) == l]
                for k in range(l, n+1):
                    if not w[k]:
                        continue
                    for a in range(l+1):
                        for ii in subsets(n, a):
                            cols = {h[i] for i in ii}
                            if len(cols) != a:
                                continue
                            # Direct survivor-set calculation, no y-polynomials.
                            mass = sum(p for s, p in original.items() if len(s) == k
                                       for j in colorful if ii <= j <= s)
                            expected = mass/(pl*w[k]*comb(l, a)*comb(k, l))
                            pol = pprod([[eta[i]*x for x in pp[i]] for i in ii]
                                        + [sc[c] for c in range(l) if c not in cols])
                            denom = pl*w[k]*comb(l, a)*comb(k, l)
                            actual = coeff(pol, k-l)/denom
                            check('reduced_color_identity', actual == expected)
                            if coeff(pol, k)/denom != expected:
                                mutations['extract_y_k_instead_of_y_k_minus_l'] += 1
                            if a > 0:
                                short = pprod([[eta[i]] for i in ii]
                                              + [sc[c] for c in range(l) if c not in cols])
                                if coeff(short, k-l)/denom != expected:
                                    mutations['drop_selected_color_complements'] += 1

for n in range(1, 21):
    for k in range(n+1):
        for l in range(1, n+1):
            mu = F(comb(k, l), comb(n, l)) if k >= l else F(0)
            check('fixed_survivor_geometric_bound', mu <= F(k, n)**l)

# Exchangeability alone does not give a geometric envelope uniform in n.
for n in range(2, 21):
    for l in range(2, n+1):
        mu = F(1, 2)  # all photons survive or all are lost, equiprobably.
        check('exchangeability_is_not_exponential_decay', mu > F(1, 2)**l)

# A literal least-nonnegative-r implementation of the note can give T=0.
eta0, eps = F(1, 1000), F(1, 2)
check('r_zero_boundary_detected', 2*eta0/(1-eta0)**2 <= eps**2/64)
repaired_r = next(r for r in range(1, 5)
                  if (r+2)*eta0**(r+1)/(1-eta0)**2 <= eps**2/64)
tau = eps**2*(1-eta0)**2/192
t_real = 64/eps**2*repaired_r*(repaired_r+1)*9**repaired_r
t = -(-t_real.numerator // t_real.denominator)
check('repaired_tail_budget', sum((l+1)*eta0**l for l in range(repaired_r+1, 5)) <= eps**2/64)
check('repaired_bias_budget', 3*tau*sum((l+1)*eta0**l for l in range(1, repaired_r+1)) <= eps**2/64)
check('repaired_variance_budget', sum(F(9**l)*(l+1)*eta0**l for l in range(1, repaired_r+1))/t <= eps**2/64)
check('mutation_controls_all_detected', len(mutations) == 3 and all(mutations.values()))
out = {'status': 'PASS', 'arithmetic': 'fractions.Fraction (exact)',
       'input_vectors': len(cases), 'largest_heterogeneous_n': max_n,
       'assertions': sum(counts.values()), 'checks': dict(counts),
       'mutations_detected': dict(mutations),
       'limits': 'Finite algebra controls; no optimized sampler or Haar sampling benchmark.'}
(Path(__file__).resolve().parents[1]/'results/loss-model-checks.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
