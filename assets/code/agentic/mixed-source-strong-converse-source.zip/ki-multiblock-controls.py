"""Independent finite numerical controls; never an all-n theorem certificate."""
import itertools,json,math
from pathlib import Path
import numpy as np
from scipy.linalg import block_diag,expm
D=Path(__file__).resolve().parent
rng=np.random.default_rng(540029)
def power(a,s):
 l,u=np.linalg.eigh(a);return (u*(l**s))@u.conj().T
def kraus(di,do,k):
 z=rng.normal(size=(k,do,di))+1j*rng.normal(size=(k,do,di))
 g=sum(a.conj().T@a for a in z);return [a@power(g,-.5) for a in z]
def tensor(xs):
 z=np.array([[1.]])
 for x in xs:z=np.kron(z,x)
 return z
sig=[]
for w in [.37,.61,.79]:
 z=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));a=z@z.conj().T+.3*np.eye(2);a/=np.trace(a)
 sig.append(block_diag(w*a,np.array([[1-w]])))
q=np.array([.2,.3,.5]);tau=sum(w*a for w,a in zip(q,sig))
_,u=np.linalg.eigh(tau[:2,:2]);U=block_diag(u,np.eye(1));sig=[U.conj().T@a@U for a in sig];tau=sum(w*a for w,a in zip(q,sig))
lam=np.diag(tau).real;tau=np.diag(lam);root=power(tau,.5);inv=power(tau,-.5)
effects=[w*inv@a.T@inv for w,a in zip(q,sig)]
W=np.eye(9,dtype=complex);Y=np.zeros((3,3),complex);C=np.zeros((9,9),complex);contrasts=[]
for theta,a in enumerate(sig):
 for t in [.4,.7,1.,1.3,1.7]:
  A=a-t*tau;l,v=np.linalg.eigh(A)
  assert min(abs(l))>1e-8
  S=(v*np.sign(l))@v.conj().T;absA=(v*abs(l))@v.conj().T
  B=np.diag(np.eye(3)[theta]/q[theta]-t)
  W+=np.kron(S,B);Y-=inv@absA.T@inv
  C+=np.kron(np.eye(3),inv)@(np.kron(np.eye(3),absA.T)-np.kron(S,A.T))@np.kron(np.eye(3),inv)
  contrasts.append((theta,t))
G=np.zeros((9,9),complex)
for th in range(3):G+=np.kron(W.reshape(3,3,3,3)[:,th,:,th],effects[th])
G+=np.kron(np.eye(3),Y)
assert np.linalg.norm(G-(np.eye(9)-C))<1e-10
weights=[sum(lam[:2]),lam[2]];psi=[]
for inds,p in zip([[0,1],[2]],weights):
 v=np.zeros((3,3),complex)
 for i in inds:v[i,i]=np.sqrt(lam[i]/p)
 psi.append(v.reshape(-1))
P0=sum(np.outer(v,v.conj())for v in psi)
ev=np.linalg.eigvalsh(C);assert sum(abs(ev)<1e-9)==2 and ev[2]>0
assert np.linalg.norm(C@P0)<1e-10
J=np.linalg.norm(Y,2);s=.05/J;F=expm(-s*Y/2);Z=float(np.trace(tau@expm(-s*Y)).real)
rows=[];worst_cs=-float('inf');worst_projector=-float('inf')
for n in [1,2]:
 dn=3**n;I=np.eye(dn);lamn=tensor([lam.reshape(1,-1)]*n).reshape(-1);Sn=-sum(lam*np.log2(lam));eta=.3
 cutoff=2**(-n*(Sn-eta));gamma=(lamn<=cutoff).astype(float)
 X=tensor([root@F.T]*n)/(Z**(n/2));ph=X.reshape(-1)
 for m in [1,2,3]:
  for trial in range(3):
   Es=kraus(dn,m,math.ceil(dn/m)+1);Ds=kraus(m,dn,2)
   DI=sum(a@a.conj().T for a in Ds)
   assert abs(np.trace(DI)-m)<1e-10
   sigma=sum(np.outer(v,v.conj())for a in Ds for b in Es for v in [(a@b@X).reshape(-1)])
   for h in range(min(n,1)+1):
    total=0.
    for bad in itertools.combinations(range(n),h):
     good=[i for i in range(n)if i not in bad]
     for js in itertools.product(range(2),repeat=len(good)):
      block=dict(zip(good,js));pj=math.prod(weights[j]for j in js)
      for aa in itertools.product(range(3),repeat=h):
       a_bad=dict(zip(bad,aa))
       for rr in itertools.product(range(3),repeat=h):
        r_bad=dict(zip(bad,rr));T=np.zeros((dn,dn),complex);refmask=np.zeros(dn)
        for ix,xx in enumerate(itertools.product(range(3),repeat=n)):
         allowed=all(xx[i]in([0,1]if block[i]==0 else[2])for i in good)and all(xx[i]==r_bad[i]for i in bad)
         if not allowed:continue
         refmask[ix]=1;ax=tuple(xx[i]if i in good else a_bad[i]for i in range(n));ai=np.ravel_multi_index(ax,(3,)*n)
         T[ai,ix]=gamma[ix]*math.sqrt(math.prod(lam[xx[i]]/weights[block[i]]for i in good))
        Xj=X*refmask[None,:];norm=float(np.linalg.norm(Xj,'fro')**2);R=T@T.conj().T
        lhs=sum(abs(np.trace(T.conj().T@a@b@Xj))**2 for a in Ds for b in Es)
        rhs=norm*float(np.trace(DI@R).real)
        worst_cs=max(worst_cs,lhs-rhs);assert lhs<=rhs+1e-10
        assert norm<=np.exp(2*n*s*J)*pj+1e-10
        assert pj*np.linalg.norm(R,2)<=cutoff*min(lam)**(-h)+1e-10
        total+=lhs
    bound=np.exp(2*n*s*J)*m*cutoff*math.comb(n,h)*(3**2/min(lam))**h
    worst_projector=max(worst_projector,total-bound);assert total<=bound+1e-9
    rows.append(dict(n=n,m=m,trial=trial,errors=h,overlap_sum=total,bound=bound))
out={'scope':'Finite floating-point controls for complex noncommuting 2+1 KI blocks and n=1,2. Not a proof, novelty check or complete original result.','seed':540029,'contrast_count':len(contrasts),'kernel_dimension':2,'parent_eigenvalues':ev.tolist(),'parent_identity_residual':float(np.linalg.norm(G-(np.eye(9)-C))),'kernel_residual':float(np.linalg.norm(C@P0)),'noncommuting_Y_tau':float(np.linalg.norm(Y@tau-tau@Y)),'rows':rows,'max_CS_lhs_minus_rhs':worst_cs,'max_total_minus_bound':worst_projector,'all_assertions_passed':True}
(D/'ki-multiblock-controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='rows'},indent=2))
