# Q101 follow-up audit, 16 November 2026

Scope: further sequential mathematical review and primary-source comparison of
the frozen 15 November candidate, followed by the user's conditional website
release. This is the same agent, not independent expert or independent-agent
review. No discovery round is completed by this work.

## Verdict

No unresolved mathematical gap was found. The candidate supplies a finite
counterexample covering the original unrestricted visible quantum compression
model. The lower bound is 1.1209803210496685 qubits per signal while the Holevo
information is one bit. It does not determine the exact optimal rate. Release
as an internally checked complete proof candidate is justified; external
review, priority and catalog acceptance remain unconfirmed.

Original: https://qiqc-op.com/problem/op_1ab8b10386bddd66/ . The frozen original
is `run/audits/public-solutions-20261104/sources/records/op_1ab8b10386bddd66.json`.
The seven files in the candidate's Q101-MANIFEST-v1.json matched their hashes
before this audit. They remain unchanged and are copied under `frozen/`.

## Mathematical challenges and resolutions

1. **Complex Pauli signs.** Hilbert--Schmidt orthogonality and Hermiticity give
   sum_P P_ij P_kl = D delta_il delta_jk. The second tensor factor has no complex
   conjugation. Removing the identity before averaging produces
   a=(D^2-2)/(4(D^2-1)), c=D/(4(D^2-1)). The signs average out all linear terms.
   For D=16 each support has rank eight and the ensemble has 510 labels.

2. **Arbitrary collective decoder.** Choose any Hilbert--Schmidt orthonormal
   Hermitian basis H_j on the output subsystem S. Its swap is sum_j H_j tensor
   H_j. The contraction is sum_j ||D_S^*(H_j)||_2^2, the squared Frobenius norm
   of the adjoint superoperator. Adjointness preserves this norm, as does the
   reshuffling from the channel matrix to the unnormalized Choi matrix.
   Therefore the term is Tr J_S^2. This argument uses the reduced channel,
   not a tensor factorization of the decoder. S empty gives J=I_m and term m.

3. **Dimension-sensitive purity.** For J>=0 with Tr_out J=I_m, a largest
   eigenvector v with eigenvalue lambda obeys lambda Tr_out(vv*)<=I_m.
   Its reduced density matrix has rank at most d, so lambda<=d. Together
   with Tr J=m, this gives Tr J^2<=md. Positivity also gives Tr J^2<=m^2.
   These statements include non-isometric channels and d<m. No output
   unitality or environmental dimension restriction is used.

4. **Interpolation and tensor powers.** For positive u,v and 0<=t<=1,
   min(u,v)<=u^t v^(1-t). Applying this with u=m^2,v=mD^|S| and the
   nonnegative coefficients a,c gives the binomial expression
   m^(1+t)(a+cD^(1-t))^n. No multiplicativity of a norm of the decoder is
   assumed. The general argument is exact for every finite n.

5. **Seed averaging and mixed messages.** For each decoder and each arbitrary
   density operator tau, acceptance <= ||D^*(Q)||_infinity <= ||D^*(Q)||_2.
   Cauchy--Schwarz is taken over the fixed iid label distribution. This law
   is unchanged upon conditioning on an independent seed. The same bound
   can be averaged over every seed because acceptance is affine. No good
   seed is fixed inside a trace norm. Shared entanglement would invalidate
   this reduction and is excluded by the original problem.

6. **Operational error and asymptotics.** The target is supported on Q_xn,
   so Tr Q_xn WhatW_xn >= 1 - ||W_xn-WhatW_xn||_1/2. This gives the correct
   direction and normalization of the average trace-distance converse.
   At t=1/2 the bracket is exactly 53/170. The strict gap is certified by
   8*53^2=22472<28900=170^2. The finite inequality bounds the liminf of any
   vanishing-error sequence, hence the operational limsup definition.
   Below R0, error tends to one exponentially. R0 is a lower bound, not
   a claimed optimal threshold for this ensemble.

## Decisive additional computation

`exact_tensor_audit.py` was implemented without importing the candidate's
checker. It uses a complex rational Householder isometry, traces a two-level
environment, constructs channel images of matrix units and their partial
Choi matrices, and enumerates all 36 two-site Pauli labels exactly.
For message dimension three, the two calculations of the moment agree at
10442900/25431849. All four partial Choi purities obey the dimension bounds.
Replacing the adjoint contraction by a transpose, or omitting the empty
subset, is detected. See `exact-tensor-audit.json`.

The first implementation spent excessive time on generic symbolic
simplification and was interrupted; replacing it with polynomial expansion
made the same exact rational calculation terminate. This is an implementation
change, not a change to the mathematical test or a failed proof check.

The previously frozen checker separately covers all Hermitian Pauli bases
through four qubits, seven arbitrary decoder cases, three extremal channels,
three adverse mutations and the distinction between the two seed-error
criteria. Numerical checks remain diagnostics; the all-n theorem is analytic.

## Primary-source and website comparison

The theorem-level comparison is in SOURCE-COMPARISON.md. Primary manuscripts
were read through the web tool and six HTML versions were saved with retrieval
hashes in sources/receipts.json. The public catalog was read through the web
tool; direct downloading returned 403, so the immutable pinned original is
used locally. The current website index did not contain this result.

No equivalent fixed-finite-ensemble, arbitrary-blocklength, free-classical-
randomness counterexample was identified in the targeted sources. That is a
bounded literature assessment, not proof of first priority. The central
publication claim is the explicit theorem, with proper attribution of the
earlier support-test and one-shot incompressibility ideas.

## Release boundary

Publish the paper, source and checks to the existing personal website under
the user's current authorization. The author is Yuxuan Zhang with no
affiliation, as previously confirmed in this conversation. Do not create an
archival deposit or a QIQC report from this authorization. Keep the website
entry's internal-review qualification visible. Leave the discovery ledger
and incomplete research-round count unchanged.
