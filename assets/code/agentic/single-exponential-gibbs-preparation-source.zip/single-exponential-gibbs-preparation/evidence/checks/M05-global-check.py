#!/usr/bin/env python3
"""Global-contract controls. Source mixing and frozen circuit theorems are inputs."""
from fractions import Fraction
import itertools,json,math
import numpy as np
from scipy.linalg import expm

def ceilf(x):
    return -((-x.numerator)//x.denominator)

def clog2(x):
    k=max(0,x.numerator.bit_length()-x.denominator.bit_length())
    while Fraction(2)**k<x:k+=1
    while k and Fraction(2)**(k-1)>=x:k-=1
    return k

def labels(n,ell):
    return [tuple(i for i in range(n) if a<=i+1<=a+ell-1)
            for a in range(2-ell,n+1)]

def counts(m,p):
    v=[0]*m
    for j in range(2**p):v[(m*j)//(2**p)]+=1
    return v

out={}
tested=0
for n in range(1,13):
    for ell in range(2,21):
        lab=labels(n,ell)
        assert len(lab)==n+ell-1
        assert all(sum(i in B for B in lab)==ell for i in range(n))
        tested+=1
dedup=set(labels(2,5))
assert any(sum(i in B for B in dedup)!=5 for i in range(2))
out['label_cover']={'exact_cases':tested,'deduplication_negative_control':'PASS'}

worst=Fraction(0);tested=0
for m in range(1,32):
    for extra in [1,3,7]:
        p=clog2(Fraction(m))+extra;Q=2**p;c=counts(m,p)
        assert max(c)-min(c)<=1
        tv=sum(abs(Fraction(v,Q)-Fraction(1,m)) for v in c)/2
        assert tv<=Fraction(m,Q)
        worst=max(worst,tv/Fraction(m,Q));tested+=1
out['dyadic_label_sampler']={'exact_cases':tested,'max_TV_over_bound':str(worst)}

tested=0
for n in [2,3,17,1024,2**40]:
    for ell in [2,3,16]:
        if ell>n:continue
        for eps in [Fraction(1,16),Fraction(1,2**80)]:
            Q=1+clog2(Fraction(64*n,1)/eps);m=n+ell-1
            a=Fraction(m,ell);k=ceilf(4*a*Q)
            assert Fraction(k,1)/(2*a)>=2*Q
            # Since exp(-2Q)<=2^(-2Q), this is a rigorous stronger control.
            assert Fraction(2*n,2**(2*Q))<eps/32
            p=clog2(Fraction(64*k*m,1)/eps)
            assert Fraction(m,2**p)<=eps/(64*k)
            delta=eps/(64*k)
            assert eps/64+eps/32+eps/32+k*delta<2*eps
            assert k<=8*n*Q+1
            tested+=1
out['mixing_sampling_and_error_budgets']={'exact_cases':tested,'status':'PASS'}

# A full finite classical restriction of the source's actual dressed reset.
# This tests composition and boundary labels, not the universal DS constants.
n=4;ell=2;T=.7
bits=list(itertools.product([-1,1],repeat=n));states=np.array(bits)
fields=np.array([-.7,.2,.9,-.3]);bonds=np.array([.35,-.25,.4])
energy=states@fields+np.sum(states[:,:-1]*states[:,1:]*bonds,axis=1)
gibbs=np.exp(-(energy-energy.min()));gibbs/=gibbs.sum()
channels=[];stationarity=[];wrong=[]
for Btuple in labels(n,ell):
    B=set(Btuple);outside=[i for i in range(n) if i not in B]
    hB=sum(fields[i]*states[:,i] for i in B)
    w=np.zeros(len(states))
    for i in range(n-1):
        term=bonds[i]*states[:,i]*states[:,i+1]
        if i in B and i+1 in B:hB=hB+term
        if (i in B)!=(i+1 in B):w=w+term
    zB=sum(math.exp(-hB[y]) for y in range(len(states))
           if all(states[y,i]==-1 for i in outside))
    def generator(cross_coeff):
        R=np.zeros((len(states),len(states)))
        for old in range(len(states)):
            for new in range(len(states)):
                if all(states[old,i]==states[new,i] for i in outside):
                    R[new,old]=math.exp(-hB[new])/zB*math.exp(-cross_coeff*(w[new]-w[old]))
        return R-np.diag(R.sum(axis=0))
    L=generator(.5)
    assert np.linalg.norm(L.sum(axis=0),ord=np.inf)<1e-14
    stationarity.append(float(np.linalg.norm(L@gibbs,ord=1)))
    C=expm(T*L);assert C.min()>-1e-14
    assert np.linalg.norm(C.sum(axis=0)-1,ord=np.inf)<1e-13
    channels.append(C)
    wrong.append(float(np.linalg.norm(generator(.25)@gibbs,ord=1)))
assert max(stationarity)<1e-13
assert max(wrong)>.01
m=len(channels);P=sum(channels)/m
p=7;c=counts(m,p);q=np.array(c)/2**p;Pq=sum(qi*C for qi,C in zip(q,channels))
tv=float(np.abs(q-1/m).sum()/2)
assert np.linalg.norm(Pq-P,ord=1)<=2*tv+1e-13
k=17;err=float(np.linalg.norm(np.linalg.matrix_power(Pq,k)-np.linalg.matrix_power(P,k),ord=1))
assert err<=2*k*tv+1e-12
out['actual_classical_dressed_reset']={'blocks':m,'stationarity_residual':max(stationarity),
    'wrong_crossing_coefficient_residual':max(wrong),'composition_error':err,'telescoping_bound':2*k*tv}

# Input perturbation control for a noncommuting matrix, including large onsite.
rng=np.random.default_rng(47105)
R=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));R=(R+R.conj().T)/2
D=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));D=(D+D.conj().T)/2
D*=1e-4/np.linalg.norm(D,ord=2)
def rho(H):
    e,U=np.linalg.eigh(H);p=np.exp(-(e-e.min()));p/=p.sum()
    return (U*p)@U.conj().T
rows=[]
for onsite in [0,1,128]:
    H=R+onsite*np.diag([1,1,-1,-1])
    error=float(np.sum(np.abs(np.linalg.eigvalsh(rho(H+D)-rho(H)))))
    assert error<=2*np.linalg.norm(D,ord=2)+1e-12
    rows.append({'onsite':onsite,'trace_error':error,'bound':2*np.linalg.norm(D,ord=2)})
out['global_input_rounding_control']=rows
out['scope']='Finite diagnostics only; analytic proof and frozen dependencies carry the uniform theorem.'
out['status']='PASS'
print(json.dumps(out,indent=2,sort_keys=True))
