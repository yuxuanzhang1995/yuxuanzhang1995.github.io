"""Targeted numerical interface checks, not a proof or a global optimization certificate."""
from pathlib import Path
from fractions import Fraction
import json
import numpy as np
import scipy
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent
RNG = np.random.default_rng(441957)
PAULI = np.array([[[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]], complex)


def psqrt(a, inverse=False):
    val, vec = np.linalg.eigh(a)
    assert min(val) > 0
    return (vec * (val ** (-0.5 if inverse else 0.5))) @ vec.conj().T


def realign(x, da, db):
    return x.reshape(da, db, da, db).transpose(0, 2, 1, 3).reshape(da * da, db * db)


def density(d):
    z = RNG.normal(size=(d, d)) + 1j * RNG.normal(size=(d, d))
    a = z @ z.conj().T + np.eye(d)
    return a / np.trace(a)


def factors(x, rho, sigma, p):
    da, db = len(rho), len(sigma)
    z = realign(x @ np.kron(psqrt(rho), psqrt(sigma)), da, db)
    u, lam, vh = np.linalg.svd(z, full_matrices=False)
    use = lam > 1e-11 * max(lam[0], 1e-100)
    lam, u, vh = lam[use], u[:, use], vh[use]
    aa = np.array([u[:, k].reshape(da, da) @ psqrt(rho, True) for k in range(len(lam))])
    # A ket Schmidt vector is conjugate(V[:,k]) = Vh[k,:].
    bb = np.array([vh[k].reshape(db, db) @ psqrt(sigma, True) for k in range(len(lam))])
    ka = sum((s ** p) * a.conj().T @ a for s, a in zip(lam, aa))
    kb = sum((s ** p) * b.conj().T @ b for s, b in zip(lam, bb))
    return float(np.sum(lam ** p)), lam, aa, bb, ka, kb, u, vh


def fn(x, rho, sigma, p):
    return factors(x, rho, sigma, p)[0]


def hermitian_direction(d):
    z = RNG.normal(size=(d, d)) + 1j * RNG.normal(size=(d, d))
    z = (z + z.conj().T) / 2
    z -= np.trace(z) * np.eye(d) / d
    return z / np.linalg.norm(z)


derivatives = []
mutations = []
for da, db, kind in [(2, 2, "dense"), (2, 3, "dense"), (3, 2, "dense"), (2, 2, "product")]:
    x = RNG.normal(size=(da * db, da * db)) + 1j * RNG.normal(size=(da * db, da * db))
    if kind == "product":
        a = RNG.normal(size=(da, da)) + 1j * RNG.normal(size=(da, da))
        b = RNG.normal(size=(db, db)) + 1j * RNG.normal(size=(db, db))
        x = np.kron(a, b)
    x /= np.linalg.norm(x, 2)
    rho, sigma = density(da), density(db)
    for p in [0.25, 0.4, 0.6]:
        f, lam, aa, bb, ka, kb, u, vh = factors(x, rho, sigma, p)
        reconstruction = sum(s * np.kron(a, b) for s, a, b in zip(lam, aa, bb))
        rec_error = float(np.linalg.norm(x - reconstruction, 2))
        assert rec_error < 2e-12
        assert abs(np.trace(ka @ rho) - f) < 2e-11
        assert abs(np.trace(kb @ sigma) - f) < 2e-11
        row = {"dimensions": [da, db], "kind": kind, "p": p, "reconstruction_error": rec_error,
               "realignment_rank": len(lam), "derivative_errors": []}
        for side in ["A", "B"]:
            dim = da if side == "A" else db
            h = hermitian_direction(dim)
            step = 2e-6
            if side == "A":
                fd = (fn(x, rho + step*h, sigma, p) - fn(x, rho - step*h, sigma, p)) / (2*step)
                analytic = (p/2) * np.trace(ka @ h).real
            else:
                fd = (fn(x, rho, sigma + step*h, p) - fn(x, rho, sigma - step*h, p)) / (2*step)
                analytic = (p/2) * np.trace(kb @ h).real
            err = float(abs(fd - analytic))
            assert err < 3e-6, (side, p, kind, fd, analytic)
            row["derivative_errors"].append({"side": side, "absolute_error": err})
            if kind == "dense" and side == "A" and p == 0.4:
                wrong_k = sum(s**p * u[:,i].reshape(da,da).conj().T @ u[:,i].reshape(da,da)
                              for i, s in enumerate(lam))
                bad = abs(fd - (p/2)*np.trace(wrong_k @ h).real)
                mutations.append({"mutation": "omit_inverse_input_filter_in_gradient", "dimensions": [da, db],
                                  "error": float(bad), "caught": bool(bad > 1e-4)})
        if kind == "dense" and p == 0.4:
            wrong_b = np.array([vh[k].conj().reshape(db,db) @ psqrt(sigma,True) for k in range(len(lam))])
            wrong_x = sum(s*np.kron(a,b) for s,a,b in zip(lam,aa,wrong_b))
            bad = float(np.linalg.norm(wrong_x-x,2))
            mutations.append({"mutation": "wrong_conjugation_of_right_Schmidt_vector", "dimensions": [da, db],
                              "error": bad, "caught": bool(bad > 1e-3)})
        derivatives.append(row)


# A bounded optimization diagnostic checks the stationary interface. Its value
# is NOT certified to be the global maximum and is not an upper bound on j_p.
def bloch(v):
    return (np.eye(2) + np.einsum("i,ijk->jk", v, PAULI)) / 2


optimized = []
delta = 0.2
for p in [0.4, 0.6]:
    x = RNG.normal(size=(4,4)) + 1j * RNG.normal(size=(4,4))
    x /= np.linalg.norm(x,2)
    def obj(v):
        f, _, _, _, ka, kb, _, _ = factors(x, bloch(v[:3]), bloch(v[3:]), p)
        jac = -(p/4)*np.array([np.trace(k @ s).real for k in [ka,kb] for s in PAULI])
        return -f, jac
    constraints = [
        {"type":"ineq", "fun":lambda v: (1-delta)**2-np.dot(v[:3],v[:3]),
         "jac":lambda v: np.r_[-2*v[:3],np.zeros(3)]},
        {"type":"ineq", "fun":lambda v: (1-delta)**2-np.dot(v[3:],v[3:]),
         "jac":lambda v: np.r_[np.zeros(3),-2*v[3:]]}]
    # SLSQP can evaluate slightly outside the feasible ball. Bounds of radius
    # 0.55 in each coordinate keep every iterate strictly positive; this box
    # is not an extra active constraint for the reported diagnostics below.
    result = minimize(obj, np.zeros(6), jac=True, method="SLSQP", constraints=constraints,
                      bounds=[(-0.55,0.55)]*6, options={"ftol":2e-12,"maxiter":150})
    v = result.x
    assert result.success and max(abs(v)) < 0.549, "Diagnostic box became active; do not certify a stationary input."
    f, lam, aa, bb, ka, kb, _, _ = factors(x, bloch(v[:3]), bloch(v[3:]), p)
    c = f/(1-delta)
    ratios = [float(np.linalg.eigvalsh(k)[-1]/c) for k in [ka,kb]]
    assert max(ratios) <= 1+1e-6
    tails=[]
    for d in range(len(lam)):
        y = sum((s*np.kron(a,b) for s,a,b in zip(lam[:d],aa[:d],bb[:d])), np.zeros_like(x))
        actual = float(np.linalg.norm(x-y,2))
        intermediate = float(c*np.sqrt(np.sum(lam[d:]**(2-2*p))))
        power = float(f**(1/p)/(1-delta)*(d+1)**(-(1/p-1.5)))
        assert actual <= intermediate+1e-10 and intermediate <= power+1e-10
        tails.append({"rank_bound":d,"operator_error":actual,"two_column_bound":intermediate,"power_bound_at_test_input":power})
    optimized.append({"p":p,"success":bool(result.success),"iterations":int(result.nit),
                      "global_optimum_certified":False,"column_bound_ratios":ratios,"tails":tails})


# Exact inherited lower-bound control catches a falsely stronger exponent.
n, d = 16, 8
true_error_squared = Fraction(n-d,n*n)  # p=1/2, normalized rank-one family
false_bound_squared = Fraction(1,(d+1)**2)  # falsely use exponent 1/p-1
assert true_error_squared > false_bound_squared
mutations.append({"mutation":"apply_Hermitian_power_to_arbitrary_nonHermitian_X",
                  "lower_error_squared":str(true_error_squared),"false_bound_squared":str(false_bound_squared),"caught":True})

# A floor-constrained product example disproves the unqualified K_A<=F I claim.
x = np.kron(np.diag([2.,0.]),np.eye(2));rho=np.diag([0.8,0.2]);sigma=np.eye(2)/2
f,_,_,_,ka,_,_,_=factors(x,rho,sigma,0.5)
floor_ratio=float(np.linalg.eigvalsh(ka)[-1]/f)
assert abs(floor_ratio-1.25)<1e-12
mutations.append({"mutation":"drop_floor_factor_from_stationary_column_bound",
                  "lambda_max_K_A_over_F":floor_ratio,"caught":True})

assert all(m["caught"] for m in mutations)
out={"scope":"numerical interface diagnostics and exact inherited countercontrols; not a proof or independent review",
     "numpy":np.__version__,"scipy":scipy.__version__,"seed":441957,
     "derivative_cases":derivatives,"stationary_diagnostics":optimized,"mutations":mutations,
     "summary":{"factorization_cases":len(derivatives),"finite_difference_checks":2*len(derivatives),
                "stationary_diagnostics":len(optimized),"mutations_caught":len(mutations),"all_checks_pass":True}}
(HERE/'checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary'],indent=2))
