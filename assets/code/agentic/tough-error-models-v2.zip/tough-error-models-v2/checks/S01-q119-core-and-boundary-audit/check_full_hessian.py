"""Exact boundary controls, independently reconstructed from matrix expansion.

Does not import the inherited checker or claim a global minimization result.
"""
from pathlib import Path
import json
import time
import sympy as s

OUT=Path(__file__).resolve().parent
started=time.monotonic()
I=s.I
G1=s.diag(1,-1)
G2=s.Matrix([[0,1],[1,0]])

def control(name,C1,C2):
    m=C1.rows; k=2; n=m+k
    Hs=[G1.row_join(C1.conjugate().T).col_join(C1.row_join(s.zeros(m))),
        G2.row_join(C2.conjugate().T).col_join(C2.row_join(s.zeros(m)))]
    X=s.eye(n)[:,:k]
    G=[X.conjugate().T*H*X for H in Hs]
    T=[a-s.trace(a)/k*s.eye(k) for a in G]
    F=sum(s.trace(a*a) for a in T)
    S=sum((a*b for a,b in zip(G,T)),s.zeros(k))
    M=X.row_join(Hs[0]*X).row_join(Hs[1]*X)
    B=(-S).col_join(T[0]).col_join(T[1])
    assert M*B==s.zeros(n,k)
    coords=s.symbols('x:'+str(2*m*k), real=True)
    W=s.Matrix(m,k,lambda a,b:coords[a*k+b]+I*coords[m*k+a*k+b])
    Z=s.zeros(k).col_join(W)
    X2=-X*(W.conjugate().T*W)/2
    expansion=0
    formula=0
    for H,g,t in zip(Hs,G,T):
        # Coefficients obtained by multiplying X(t)^* H X(t),
        # with X(t)=X+tZ+t^2 X2+O(t^3); no Hessian routine used.
        g1=Z.conjugate().T*H*X+X.conjugate().T*H*Z
        g2=X2.conjugate().T*H*X+X.conjugate().T*H*X2+Z.conjugate().T*H*Z
        expansion+=2*(s.trace(g1*g1)+2*s.trace(g*g2)
                      -(s.trace(g1)**2+2*s.trace(g)*s.trace(g2))/k)
        c=H[k:,:k]; d=H[k:,k:]
        ell=c.conjugate().T*W+W.conjugate().T*c
        ell0=ell-s.trace(ell)/k*s.eye(k)
        formula+=2*s.trace(ell0*ell0)+4*s.trace(t*W.conjugate().T*d*W)
    formula-=4*s.trace(S*W.conjugate().T*W)
    assert s.expand(expansion-formula)==0
    q=s.expand(expansion)
    Q=s.hessian(q,coords)/2
    assert Q==Q.T
    spectrum={str(ev):mult for ev,mult in Q.eigenvals().items()}
    results={'name':name,'n':n,'D':3,'k':2,'F':str(F),'stationarity_exact':True,
             'rank_M':M.rank(),'rank_B':B.rank(),'common_perpendicular_dimension':n-M.rank(),
             'full_hessian_spectrum':spectrum,'independent_expansion_matches':True,
             'H_matrices':[[[str(a) for a in row] for row in H.tolist()] for H in Hs]}
    if name=='one-below-sharp-D3-threshold':
        assert Q==s.diag(24,24,8,8)
        results['claim']='Positive strict local minimum at n=3 only; no claim about n>=4 or the global optimum.'
    elif name=='rank-defect-saturation':
        assert M.rank()==n==3*k-2
        Y=s.eye(n)[:,k:]
        assert all(Y.conjugate().T*H*Y==s.zeros(2) for H in Hs)
        assert min(Q.eigenvals())<0
        results['exact_zero_code']='last two coordinate vectors'
        results['claim']='Full row rank saturates the inherited rank estimate even where an exact rank-two compression exists.'
    else:
        y=s.eye(n)[:,-1]
        assert M.conjugate().T*y==s.zeros(3*k,1)
        indices=[(m-1)*k+a for a in range(k)]
        phase_indices=indices+[m*k+i for i in indices]
        assert sum(Q[i,i] for i in phase_indices)==-8*F
        results['common_direction_phase_trace']=str(-8*F)
    return results

rows=[control('one-below-sharp-D3-threshold',s.Matrix([[2,0]]),s.Matrix([[0,-2]])),
      control('rank-defect-saturation',s.eye(2),-G1*G2),
      control('threshold-common-direction',s.eye(2).col_join(s.zeros(1,2)),(-G1*G2).col_join(s.zeros(1,2)))]
report={'arithmetic':'exact SymPy integers and Gaussian integers','cases':rows,
        'scientific_seconds':time.monotonic()-started,
        'scope':'Finite decisive algebra controls; the analytic proof is reviewed separately.'}
(OUT/'full-hessian-controls-v1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':[{'name':r['name'],'rank_M':r['rank_M'],'spectrum':r['full_hessian_spectrum']} for r in rows],
                  'scientific_seconds':report['scientific_seconds']}))
