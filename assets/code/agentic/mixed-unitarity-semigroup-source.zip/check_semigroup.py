"""Exact algebra and independent finite diagnostics for the qutrit semigroup."""
import json,sys
from fractions import Fraction
import numpy as np
from scipy.linalg import expm
import sympy as sp
import mpmath as mp

def run():
 I=sp.eye(3);B=sp.Matrix([[1,0,0],[0,0,-1],[0,1,0]]);H=sp.diag(30,0,0)
 def E(i,j):
  a=sp.zeros(3);a[i,j]=1;return a
 basis=[E(i,j) for i in range(3) for j in range(3)]
 kraus=[B*(E(i,j)-E(j,i))/sp.sqrt(2) for i in range(3) for j in range(i+1,3)]
 jumps=[]
 for j in [1,2]:jumps.extend([(E(0,j)+E(j,0))/2,sp.I*(E(0,j)-E(j,0))/2])
 jumps.append(sp.diag(0,1,1)/sp.sqrt(2))
 def T(x):return (sp.trace(x)*I-B*x.T*B.H)/2
 def diss(v,x):return v*x*v.H-(v.H*v*x+x*v.H*v)/2
 def D0(x):
  z=sp.zeros(3);z[0,0]=(x[1,1]+x[2,2])/2-x[0,0]
  z[0,1:3]=-x[0,1:3];z[1:3,0]=-x[1:3,0]
  z[1:3,1:3]=x[0,0]*sp.eye(2)/2-x[1:3,1:3]/2
  return z
 assert sum((v.H*v for v in kraus),sp.zeros(3))==I
 assert sum((v*v.H for v in kraus),sp.zeros(3))==I
 for e in basis:
  assert sp.simplify(T(e)-sum((v*e*v.H for v in kraus),sp.zeros(3)))==sp.zeros(3)
  assert sp.simplify(D0(e)-sum((diss(v,e) for v in jumps),sp.zeros(3)))==sp.zeros(3)
 M=sp.Matrix([[-30*sp.I,sp.Rational(1,2)],[-sp.Rational(1,2),30*sp.I]])
 assert M*M==-sp.Rational(3601,4)*sp.eye(2)
 # Independent direct action on matrix units in row-major vectorization.
 mats=[np.array(e,dtype=complex) for e in basis]
 L=np.column_stack([np.array(T(e)-e-sp.I*(H*e-e*H),dtype=complex).reshape(-1) for e in basis])
 D=np.column_stack([np.array(D0(e),dtype=complex).reshape(-1) for e in basis])
 eye=np.eye(3);Q=np.diag([-1,1,1]);C=Q@np.array(B,dtype=complex)
 swap=sum(np.kron(m,m.T) for m in mats)
 W=np.kron(eye,C)@swap@np.kron(eye,C.conj().T)+np.eye(9)/3
 s=2*np.pi/np.sqrt(3601);t=3*np.pi/np.sqrt(3601)
 refocus=float(np.linalg.norm(expm(s*L)-np.kron(Q,Q)@expm(s*D)))
 def choi(A):return sum(np.kron(e,(A@e.reshape(-1)).reshape(3,3)) for e in mats)/3
 errs=[];positivity=[];tp=[]
 for u in [0,s,t,*np.linspace(.01,1,20)]:
  A=expm(u*L);J=choi(A);omega=np.sqrt(3601)/2
  exact=(2+np.exp(-1.5*u)-3*np.exp(-.5*u)+4*np.exp(-u)*np.sin(omega*u)/(2*omega))/3
  errs.append(float(abs(np.trace(W@J)-exact)))
  positivity.append(float(np.linalg.eigvalsh(J).min()))
  iv=eye.reshape(-1);tp.extend([float(np.linalg.norm(A@iv-iv)),float(np.linalg.norm(iv@A-iv))])
 rng=np.random.default_rng(20260919);unitary_min=1e10;unitary_err=0.
 omega_vec=eye.reshape(-1)/np.sqrt(3)
 for _ in range(400):
  U,_=np.linalg.qr(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))
  z=np.kron(eye,U)@omega_vec;value=float(np.vdot(z,W@z).real)
  V=C.conj().T@U;formula=(np.trace(V.conj().T@V.T).real+1)/3
  unitary_min=min(unitary_min,value);unitary_err=max(unitary_err,abs(value-formula))
 bound=(Fraction(12,625)-Fraction(84,1525))/3;assert bound==-Fraction(456,38125)
 mp.mp.dps=100;tm=3*mp.pi/mp.sqrt(3601)
 value=(2+mp.exp(-3*tm/2)-3*mp.exp(-tm/2)-4*mp.exp(-tm)/mp.sqrt(3601))/3
 assert value<mp.mpf(bound.numerator)/bound.denominator<0
 assert refocus<1e-12 and max(errs)<1e-12 and max(tp)<1e-12
 assert min(positivity)>-1e-12 and unitary_min>-1e-12 and unitary_err<1e-12
 return dict(status='passed',exact_matrix_unit_checks=18,exact_kraus_completeness=True,exact_oscillator_square=True,exact_rational_bound=str(bound),refocusing_residual=refocus,time_samples=len(errs),witness_formula_max_residual=max(errs),channel_normalization_max_residual=max(tp),minimum_choi_eigenvalue=min(positivity),random_complex_unitaries=400,minimum_random_unitary_witness=unitary_min,unitary_identity_max_residual=unitary_err,later_witness_100_digits=mp.nstr(value,100),versions={'numpy':np.__version__,'sympy':sp.__version__,'mpmath':mp.__version__},scope='Exact finite algebra checks and floating diagnostics. Global unitary separation and finite mixed-unitary membership follow from the manuscript analytic proof, not random sampling.')
if __name__=='__main__':
 data=run()
 print(json.dumps(data,indent=2) if '--json' in sys.argv else 'PASS: exact qutrit algebra, rational negative bound, 23 channel checks and 400 complex-unitary diagnostics. Analytic proof remains essential.')
