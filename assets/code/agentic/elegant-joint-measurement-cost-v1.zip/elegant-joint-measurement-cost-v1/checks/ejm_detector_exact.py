"""Exact finite controls for the all-rank analytic detector argument."""
import json
from pathlib import Path
import sympy as s

H=Path(__file__).resolve().parent
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);Z=s.diag(1,-1)
J=s.Matrix([[0,1],[-1,0]])
signs=[(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
checks=[]
def eq(a,b,name):
    if isinstance(a,s.MatrixBase):
        ok=all(s.simplify(x)==0 for x in a-b)
    else:ok=s.simplify(a-b)==0
    assert ok,name
    checks.append(name)
E=[];U=[];D=[]
for j,(x,y,z) in enumerate(signs):
    N=(x*X+y*Y+z*Z)/s.sqrt(3)
    ej=(I+s.sqrt(3)*N)*J/(2*s.sqrt(2));uj=N*J;dj=s.conjugate(uj)/(2*s.sqrt(2))
    E.append(ej);U.append(uj);D.append(dj)
    eq(uj*uj.H,I,f'unitary detector {j}')
    eq(dj*dj.H,I/8,f'conditional Bell probability {j}')
    eq(s.Abs(ej.det()),s.Rational(1,4),f'concurrence {j}')
for j in range(4):
    for k in range(4):eq(s.trace(E[j].H*E[k]),int(j==k),f'orthogonality {j},{k}')
M=sum((s.kronecker_product(e,d) for e,d in zip(E,D)),s.zeros(4))
M=s.simplify(M)
F=sum((s.kronecker_product(p,s.conjugate(p)) for p in [X,Y,Z]),s.zeros(4))
eq(M,F*s.kronecker_product(J,J)/s.sqrt(12),'coefficient matrix closed form')
R=s.simplify(M*M.H);t=s.symbols('t')
eq(R.charpoly(t).as_expr(),(t-s.Rational(3,4))*(t-s.Rational(1,12))**3,'full Schmidt spectrum')
eq(s.trace(R),1,'input normalization')
eq(s.Rational(3,4)/(4*s.Rational(1,8)),s.Rational(3,2),'optimal detector ratio')
# Verify the 2x2 HS-completeness identity on a symbolic matrix, not one sample.
a,b,c,d=s.symbols('a b c d');S=s.Matrix([[a,b],[c,d]])
eq(sum((e.T*S*s.conjugate(e) for e in E),s.zeros(2)),s.trace(S)*I,'symbolic completeness')
# Independent index contraction of each conditional reference, rather than HS formula.
for j,e in enumerate(E):
    out=s.zeros(2)
    for cc in range(2):
        for dd in range(2):
            out[cc,dd]=sum(s.conjugate(e[aa,bb])*M[2*aa+cc,2*bb+dd] for aa in range(2) for bb in range(2))
    eq(out,D[j],f'reference contraction {j}')
# Mutation: a relative detector phase spoils this optimizing spectrum.
# Conjugating all detectors alone preserves this spectrum by EJM symmetry;
# it was rejected as a negative control, not counted as a caught mutation.
bad=sum((s.kronecker_product(e,d*(s.I if j==0 else 1)) for j,(e,d) in enumerate(zip(E,D))),s.zeros(4))
bad=s.simplify(bad)
assert s.simplify((bad*bad.H).charpoly(t).as_expr()-R.charpoly(t).as_expr())!=0
assert s.simplify(s.Rational(3,4)*s.Rational(3,4)-s.Rational(1,2))>0
result={'status':'PASS','exact_checks':len(checks),'checks':checks,
        'mutations_caught':2,'input_spectrum':['3/4','1/12','1/12','1/12'],
        'lambda_max_bound':'2/3','entropy_bound':float(-s.Rational(2,3)*s.log(s.Rational(2,3),2)-s.Rational(1,3)*s.log(s.Rational(1,3),2)),
        'scope':'Finite exact controls; arbitrary ranks and optimality require the written proof. Same-agent review only.'}
(H/'ejm-detector-exact-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
