#!/usr/bin/env python3
"""Exact standalone checker for the n_min = 7 proof: every gate of C_3(5) and C_3(6) is semi-Clifford.

Python standard library only; exact integer arithmetic throughout (phases in units of pi/4, i.e. elements of Z_8);
no files are read, no arguments, no network; deterministic output without floating-point numbers.
  C1 class list derived twice (hand classification as data / GL(m,2)-orbit census of t-dim subspaces of Alt(m));
     the representatives hit the nondegenerate orbits bijectively (n = 5: 3 classes, n = 6: 7 classes).
  C2 A_pi = {lam in Z_8^(2^n): pi D_lam in C_3} derived twice for all 10 class instances, each kernel with a
     Lemma-C certificate: route 1 = psi-formula of Step 3 (Moebius criterion), route 2 = literal definition of C_3
     on Z_8-linear forms in lam (shares only the basic Z_8 linear algebra with route 1); route 2 certifies its
     inverses symbolically, and its Pauli predicate is calibrated against an independent list of Paulis.
  C3 Theorem 1: A_pi = Cliff + Cliff.pi + H_pi (generators contained, generated subgroup sized by elementary divisors).
  C4 pi D_h fixes <Z_c, X_tau> for every generator h of H_pi; Step-6 generator check with unique symmetric M.
  C5 diagonal classification (pi = id): A_id = Cliff + H_id, H_id = <x_i, 2x_ix_j, 4x_ix_jx_k>, n = 1..6.
  C6 controls: TOF*T on an idle qubit, TOF*T on the target, 7-qubit cubic permutation (not semi-Clifford).
Prints one PASS/FAIL line per check and a final VERDICT line; exit code 1 if any check fails, 0 otherwise."""
import sys
from itertools import combinations, permutations, product
from operator import mul

FAILS = []


def report(ok, msg):
    print(("PASS " if ok else "FAIL ") + msg)
    if not ok:
        FAILS.append(msg)


# ============ basic Z_8 / F_2 linear algebra (the only code shared by route 1 and route 2) ============
def f2basis(vecs):                      # F_2 vectors as int bitmasks -> a basis of their span
    basis = {}
    for v in vecs:
        while v:
            h = v.bit_length() - 1
            if h not in basis:
                basis[h] = v
                break
            v ^= basis[h]
    return list(basis.values())


def val2(a):                            # 2-adic valuation on Z_8, val2(0) = 3
    a %= 8
    return 3 if a == 0 else (0 if a & 1 else (1 if a & 2 else 2))


def pack(row):                          # packed Z_8 vector: entry j in bits 8j..8j+2 (no carries: lanes < 256)
    return sum((a % 8) << (8 * j) for j, a in enumerate(row))


def entry(v, j):
    return (v >> (8 * j)) & 7


def annihilates(rows, g):               # R g = 0 over Z_8
    return all(sum(map(mul, row, g)) % 8 == 0 for row in rows)


def kernel8(rows, nc):
    """ker R over Z_8 with a Lemma-C certificate checked independently of how V was found:
    V invertible mod 2; R V_j = 2^{v_j} w_j (j < r) with the w_j independent mod 2; R V_j = 0 (j >= r).
    Then ker R = V{y : 2^{v_j} y_j = 0} and log2|ker R| = sum_j v_j + 3(nc - r).
    Returns (certificate ok, log2|ker R|, generators of ker R)."""
    MASK = sum(7 << (8 * j) for j in range(nc))
    R = sorted({pack(row) for row in rows} - {0})          # the distinct nonzero rows (same kernel)
    ech, rest = [], R                                       # search, step 1: row echelon form (untrusted)
    for c in range(nc):
        if not rest:
            break
        k = min(range(len(rest)), key=lambda i: (val2(entry(rest[i], c)), i))
        piv = rest[k]
        v = val2(entry(piv, c))
        if v == 3:
            continue
        u, new = entry(piv, c) >> v, []
        for i, w in enumerate(rest):
            if i != k:
                a = entry(w, c)
                if a:
                    w = (w + (-(a >> v) * u % 8) * piv) & MASK
                if w:
                    new.append(w)
        ech.append(piv)
        rest = new
    A = [[entry(w, j) for j in range(nc)] for w in ech]     # search, step 2: Smith form, column ops kept in V
    V = [[int(i == j) for j in range(nc)] for i in range(nc)]
    vals = []
    for r in range(min(len(A), nc)):
        mv, p, q = min((val2(A[i][j]), i, j) for i in range(r, len(A)) for j in range(r, nc))
        if mv == 3:
            break
        A[r], A[p] = A[p], A[r]
        for X in A + V:
            X[r], X[q] = X[q], X[r]
        u = A[r][r] >> mv                                   # odd, u*u = 1 mod 8
        for X in A + V:
            X[r] = X[r] * u % 8
        f = [A[r][j] >> mv for j in range(nc)]
        for X in A + V:
            for j in range(r + 1, nc):
                if f[j]:
                    X[j] = (X[j] - X[r] * f[j]) % 8
        for i in range(r + 1, len(A)):
            A[i][r] = 0                                     # row ops: row r is now 2^mv e_r
        vals.append(mv)
    r = len(vals)                                           # certificate on the original rows R
    Vp = [pack(row) for row in V]
    W = []
    for w in R:
        acc = 0
        for k in range(nc):
            a = entry(w, k)
            if a:
                acc = (acc + a * Vp[k]) & MASK
        W.append(acc)
    ok = len(f2basis([sum((V[i][j] & 1) << j for j in range(nc)) for i in range(nc)])) == nc
    ok = ok and all(entry(x, j) % (1 << vals[j]) == 0 for x in W for j in range(r))
    ok = ok and len(f2basis([sum(((entry(x, j) >> vals[j]) & 1) << i for i, x in enumerate(W))
                             for j in range(r)])) == r
    ok = ok and all(x >> (8 * r) == 0 for x in W)
    gens = [[V[i][j] * (1 << (3 - vals[j])) % 8 for i in range(nc)] for j in range(r) if vals[j]] + \
           [[V[i][j] for i in range(nc)] for j in range(r, nc)]
    return ok, sum(vals) + 3 * (nc - r), gens


def gen_size(gens, N):                  # log2 of the subgroup of Z_8^N generated by gens: 3k - log2|ker G|
    ok, sk, _ = kernel8([[g[x] for g in gens] for x in range(N)], len(gens))
    return ok, 3 * len(gens) - sk


# ============ route 1: the psi-formula of Step 3 with the Moebius criterion for diagonal Cliffords ============
def perm_formula(n, m, f):              # pi_f(x) = x + sum_k f_k(x_C) e_{m+k}; f_k = list of monomials x_i x_j
    out = []
    for x in range(1 << n):
        y = x
        for k, ft in enumerate(f):
            if sum((x >> i) & (x >> j) & 1 for i, j in ft) % 2:
                y ^= 1 << (m + k)
        out.append(y)
    return out


def psi_forms(n, pi, i):                # psi_i(y) = lam(pi(y) + e_i) - lam(pi(y)), one Z_8-linear form per y
    rows = []
    for y in range(1 << n):
        row = [0] * (1 << n)
        row[pi[y] ^ (1 << i)] += 1
        row[pi[y]] -= 1
        rows.append([a % 8 for a in row])
    return rows


def moebius(rows, n):                   # c_S = sum_{T in S} (-1)^{|S|-|T|} psi(T), for each lam-coordinate
    c = [list(row) for row in rows]
    for k in range(n):
        for s in range(1 << n):
            if s >> k & 1:
                c[s] = [(a - b) % 8 for a, b in zip(c[s], c[s ^ (1 << k)])]
    return c


CLIFF_MULT = {1: 4, 2: 2}               # diagonal Clifford: c_i in 2Z_8, c_ij in 4Z_8, c_S = 0 for |S| >= 3


def R_route1(n, m, f):
    pi, rows = perm_formula(n, m, f), []
    for i in range(n):
        C = moebius(psi_forms(n, pi, i), n)
        rows += [[a * CLIFF_MULT.get(bin(s).count("1"), 1) % 8 for a in C[s]] for s in range(1, 1 << n)]
    return rows


# ============ route 2: the literal definition of C_3, phases carried as Z_8-linear forms in lam ============
CONST = -1                              # a form is {k: c}: sum_k c*lam(k), plus c for the key CONST


def form_add(a, b, s=1):
    out = dict(a)
    for k, c in b.items():
        out[k] = (out.get(k, 0) + s * c) % 8
    return {k: c for k, c in out.items() if c}


def fop_mul(A, B):                      # O|x> = w^{ph[x]}|sig[x]>;  (A B)|x> = w^{B.ph[x] + A.ph[B.sig[x]]}|A.sig[B.sig[x]]>
    return [A[0][y] for y in B[0]], [form_add(p, A[1][y]) for p, y in zip(B[1], B[0])]


def fop_inv(A):
    sig, ph = [0] * len(A[0]), [None] * len(A[0])
    for x, y in enumerate(A[0]):
        sig[y], ph[y] = x, {k: -c % 8 for k, c in A[1][x].items()}
    return sig, ph


def perm_gates(n, m, f):                # pi_f as a product of Toffoli gates CCX(i, j; m+k)
    sig = list(range(1 << n))
    for k, ft in enumerate(f):
        for i, j in ft:
            sig = [z ^ (((z >> i) & (z >> j) & 1) << (m + k)) for z in sig]
    return sig


def form_pauli_conditions(sig, ph, n):
    """Literal Pauli-up-to-global-phase test on (sig, ph): sig must be a translation, and g(x) = ph(x) - ph(0) must
    satisfy 2 g(x) = 0 and g(x) = sum_k x_k g(e_k) for all x. Returns (translation?, affine forms that must vanish)."""
    if any(sig[x] != x ^ sig[0] for x in range(1 << n)):
        return False, []
    g = [form_add(p, ph[0], -1) for p in ph]
    conds = []
    for x in range(1 << n):
        lin = dict(g[x])
        for k in range(n):
            if x >> k & 1:
                lin = form_add(lin, g[1 << k], -1)
        conds += [form_add({}, g[x], 2), lin]
    return True, conds


def R_route2(n, m, f):
    """V = pi D_lam with V|x> = w^{lam(x)}|pi(x)>. For every generator P (X_i and Z_i), M = V P V^dag must be in
    C_2: M Q M^dag must be a Pauli up to global phase for every generator Q (X_j and Z_j). The inverses are certified
    symbolically (V V^-1 = I, M M^-1 = I as forms). Returns (inverses exact, every sig a translation and all constant
    parts zero, i.e. lam = 0 passes, i.e. P_pi in C_3; the linear constraint rows on lam)."""
    N = 1 << n
    ident = (list(range(N)), [{}] * N)
    V = (perm_gates(n, m, f), [{x: 1} for x in range(N)])
    gen = [([x ^ (1 << j) for x in range(N)], [{} for x in range(N)]) for j in range(n)] + \
          [(list(range(N)), [{CONST: 4} if x >> j & 1 else {} for x in range(N)]) for j in range(n)]
    Vi, keys = fop_inv(V), set()
    pi_ok = fop_mul(V, Vi) == ident
    for P in gen:
        Mo = fop_mul(fop_mul(V, P), Vi)
        Mi = fop_inv(Mo)
        pi_ok = pi_ok and fop_mul(Mo, Mi) == ident
        for Q in gen:
            trans, conds = form_pauli_conditions(*fop_mul(fop_mul(Mo, Q), Mi), n)
            pi_ok = pi_ok and trans
            for cond in conds:
                if cond.pop(CONST, 0):
                    pi_ok = False
                if cond:
                    keys.add(tuple(sorted(cond.items())))
    rows = []
    for key in sorted(keys):
        row = [0] * N
        for k, c in key:
            row[k] = c
        rows.append(row)
    return pi_ok, rows


# ============ concrete monomial operators (C4, C6): O|x> = w^{ph[x]}|sig[x]>, ph in Z_8 ============
def op_mul(A, B):
    return [A[0][y] for y in B[0]], [(p + A[1][y]) % 8 for p, y in zip(B[1], B[0])]


def op_inv(A):
    sig, ph = [0] * len(A[0]), [0] * len(A[0])
    for x, y in enumerate(A[0]):
        sig[y], ph[y] = x, -A[1][x] % 8
    return sig, ph


def op_conj(U, P, Ui):
    return op_mul(op_mul(U, P), Ui)


def pauli(n, b, a):                     # X^b Z^a |x> = (-1)^{a.x} |x+b>
    return [x ^ b for x in range(1 << n)], [4 * (bin(x & a).count("1") & 1) for x in range(1 << n)]


def is_pauli(M, n):                     # Pauli up to global phase: translation, relative phases 0/4, F_2-linear
    sig, ph = M
    if any(sig[x] != x ^ sig[0] for x in range(1 << n)):
        return False
    g = [(p - ph[0]) % 8 for p in ph]
    if any(v % 4 for v in g):
        return False
    return all(g[x] == sum(g[1 << k] for k in range(n) if x >> k & 1) % 8 for x in range(1 << n))


def in_C3(U, n):                        # literal: U P U^dag in C_2 for the 2n generators P
    G = [pauli(n, 1 << i, 0) for i in range(n)] + [pauli(n, 0, 1 << i) for i in range(n)]
    Ui = op_inv(U)
    for P in G:
        M = op_conj(U, P, Ui)
        Mi = op_inv(M)
        if not all(is_pauli(op_conj(M, Q, Mi), n) for Q in G):
            return False
    return True


def S_U(U, n):
    Ui = op_inv(U)
    return [b | a << n for b in range(1 << n) for a in range(1 << n) if is_pauli(op_conj(U, pauli(n, b, a), Ui), n)]


def sympl_dims(vecs, n):                # (dim S, dim rad S); S contains a Lagrangian iff the sum is >= 2n
    B, mk = f2basis(vecs), (1 << n) - 1
    form = lambda u, v: (bin(u & mk & (v >> n)).count("1") + bin((u >> n) & v & mk).count("1")) & 1
    return len(B), len(B) - len(f2basis([sum(form(u, v) << j for j, v in enumerate(B)) for u in B]))


def fixes_L(n, pi, T, h):               # pi D_h conjugates each Z_c (c non-target) and X_tau (tau target) to itself
    U = (pi, [a % 8 for a in h])
    Ui = op_inv(U)
    L = [pauli(n, 0, 1 << c) for c in range(n) if c not in T] + [pauli(n, 1 << t, 0) for t in T]
    return all(op_conj(U, P, Ui) == P for P in L)


def lagr_ok(n, pi, T, lam):             # Step 6: in C_3, Z_c images Pauli, unique alpha = M_tau, M symmetric
    U = (pi, [a % 8 for a in lam])
    Ui = op_inv(U)
    if not in_C3(U, n):
        return False
    if not all(is_pauli(op_conj(U, pauli(n, 0, 1 << c), Ui), n) for c in range(n) if c not in T):
        return False
    Mt = []
    for tau in T:
        sols = [al for al in range(1 << len(T)) if is_pauli(op_conj(U, pauli(
            n, 1 << tau, sum(1 << T[k] for k in range(len(T)) if al >> k & 1)), Ui), n)]
        if len(sols) != 1:
            return False
        Mt.append(sols[0])
    return all((Mt[a] >> b & 1) == (Mt[b] >> a & 1) for a in range(len(T)) for b in range(len(T)))


def pauli_calibration(n=2):
    """Both Pauli predicates (route 2's form test on constant forms; the concrete test of C4/C6) against an
    independently generated list: over all monomial operators on n qubits with ph(0) = 0, each accepts exactly
    the operators X^b Z^a."""
    N = 1 << n
    paulis = {(tuple(x ^ b for x in range(N)), tuple(4 * (bin(x & a).count("1") % 2) for x in range(N)))
              for b in range(N) for a in range(N)}
    acc2, accc, total = set(), set(), 0
    for sig in permutations(range(N)):
        for rest in product(range(8), repeat=N - 1):
            ph, total = (0,) + rest, total + 1
            trans, conds = form_pauli_conditions(list(sig), [{CONST: c} if c else {} for c in ph], n)
            if trans and not any(conds):
                acc2.add((sig, ph))
            if is_pauli((list(sig), list(ph)), n):
                accc.add((sig, ph))
    return acc2 == paulis and accc == paulis, total, len(paulis)


def diag_gens(n, NT):                   # Cliff = <1, 2x_i, 4x_ix_j>;  H = <x_i, 2x_ix_j, 4x_ix_jx_k : i,j,k in NT>
    mono = lambda c, S: [c * all(x >> i & 1 for i in S) % 8 for x in range(1 << n)]
    cl = [mono(1, ())] + [mono(2, (i,)) for i in range(n)] + [mono(4, S) for S in combinations(range(n), 2)]
    H = [mono(1, (i,)) for i in NT] + [mono(2, S) for S in combinations(NT, 2)] + \
        [mono(4, S) for S in combinations(NT, 3)]
    return cl, H


# ============ C1 second derivation: GL(m,2)-orbits of t-dim subspaces of Alt(m) by transvection BFS ============
def census(nmax=6):
    out, reg = {}, {}
    for m in range(2, nmax):
        pairs = list(combinations(range(m), 2))
        dA = len(pairs)
        mats = []
        for s in range(1 << dA):
            B = [[0] * m for _ in range(m)]
            for p, (i, j) in enumerate(pairs):
                if s >> p & 1:
                    B[i][j] = B[j][i] = 1
            mats.append(B)
        trans = []                      # G = I + E_ab (these generate GL(m,2)) acts by B -> G^T B G
        for a, b in permutations(range(m), 2):
            img = lambda i: (i, a) if i == b else (i,)
            trans.append([sum(1 << p for p, (i, j) in enumerate(pairs)
                              if sum(B[k][l] for k in img(i) for l in img(j)) % 2) for B in mats])
        for t in range(1, min(dA, nmax - m) + 1):
            subs = set()
            for comb in combinations(range(1, 1 << dA), t):
                span = {0}
                for v in comb:
                    span |= {s ^ v for s in span}
                if len(span) == 1 << t:
                    subs.add(frozenset(span - {0}))
            seen, sizes = {}, []
            for S in sorted(subs, key=sorted):
                if S in seen:
                    continue
                orb, front = {S}, [S]
                while front:
                    X = front.pop()
                    for tab in trans:
                        Y = frozenset(tab[s] for s in X)
                        if Y not in orb:
                            orb.add(Y); front.append(Y)
                for Y in orb:
                    seen[Y] = len(sizes)
                rows = [sum(mats[s][i][j] << j for j in range(m)) for s in S for i in range(m)]
                sizes.append((len(orb), len(f2basis(rows)) == m))      # nondegenerate: trivial common radical
            out[(m, t)] = sorted(z for z, nd in sizes if nd)
            reg[(m, t)] = (seen, sizes, pairs)
    return out, reg


# ============ C1 first derivation: the hand classification (data), representatives as in the proof ============
REPS = {'TOF': (2, 1, [[(0, 1)]]),
        'B':   (4, 1, [[(0, 1), (2, 3)]]),
        'C':   (3, 2, [[(0, 1)], [(0, 2)]]),
        'SEC': (4, 2, [[(0, 1)], [(2, 3)]]),
        'TAN': (4, 2, [[(0, 1)], [(0, 2), (1, 3)]]),
        'EXT': (4, 2, [[(0, 1), (2, 3)], [(0, 1), (0, 2), (1, 3)]]),
        'TRI': (3, 3, [[(0, 1)], [(0, 2)], [(1, 2)]])}
CENSUS = {(2, 1): [1], (3, 1): [], (3, 2): [7], (3, 3): [1], (4, 1): [28], (4, 2): [56, 210, 280], (5, 1): []}
EXPECTED = {5: {'TOF': 38, 'B': 38, 'C': 33},
            6: {'TOF': 56, 'B': 56, 'C': 47, 'SEC': 47, 'TAN': 47, 'EXT': 47, 'TRI': 43}}
EXPECTED_ID = {1: 6, 2: 11, 3: 19, 4: 31, 5: 48, 6: 71}   # 3 + 3n + 2 C(n,2) + C(n,3)


def main():
    cen, reg = census()
    report(cen == CENSUS, "class list derived twice: nondegenerate GL(m,2)-orbit sizes of t-dim subspaces of "
           "Alt(m), m+t<=6: " + str(sorted(cen.items())) + " = hand classification")
    for n in (5, 6):
        ids = []
        for name, (m, t, f) in REPS.items():
            if m + t <= n:
                seen, sizes, pairs = reg[(m, t)]
                span = {0}
                for ft in f:
                    v = 0
                    for p in ft:
                        v ^= 1 << pairs.index(p)
                    span |= {s ^ v for s in span}
                key = frozenset(span - {0})
                ok = len(span) == 1 << t and key in seen and sizes[seen[key]][1]
                ids.append((m, t, seen[key]) if ok else None)
        nd = {(m, t, i) for (m, t), (seen, sizes, pairs) in reg.items() if m + t <= n
              for i, (z, d) in enumerate(sizes) if d}
        report(None not in ids and len(set(ids)) == len(ids) and set(ids) == nd,
               f"n={n}: the {len(ids)} class representatives hit the {len(nd)} nondegenerate orbits (m+t<={n}) "
               "bijectively")
    ok, total, npauli = pauli_calibration(2)
    report(ok, f"Pauli predicates calibrated (route-2 literal test and concrete test): among all {total} monomial "
           f"operators on 2 qubits with phase 0 at |00>, each accepts exactly the {npauli} Paulis X^b Z^a")

    keep = {}
    for n in (5, 6):
        N = 1 << n
        for name, (m, t, f) in REPS.items():
            if m + t > n:
                continue
            T = list(range(m, m + t))
            tag = f"n={n} {name} (m={m}, t={t}, idle={n - m - t})"
            R1 = R_route1(n, m, f)
            pi_ok, R2 = R_route2(n, m, f)
            ok1, s1, g1 = kernel8(R1, N)
            ok2, s2, g2 = kernel8(R2, N)
            cont = all(annihilates(R2, g) for g in g1) and all(annihilates(R1, g) for g in g2)
            e = EXPECTED[n][name]
            report(pi_ok and ok1 and ok2 and cont and s1 == s2 == e,
                   f"{tag}: A_pi derived twice (route 1 psi-formula/Moebius, route 2 literal C_3 definition), "
                   f"Lemma-C certified, mutually contained, log2|A_pi| = {s1} = {s2} (expected {e})")
            pi = perm_formula(n, m, f)
            cl, H = diag_gens(n, [i for i in range(n) if i not in T])
            allg = cl + [[g[pi[x]] for x in range(N)] for g in cl[1:]] + H
            okG, span = gen_size(allg, N)
            inA = all(annihilates(R1, g) for g in allg)
            report(okG and inA and span == s1,
                   f"{tag}: A_pi = Cliff + Cliff.pi + H_pi (all {len(allg)} generators in A_pi, "
                   f"generated subgroup log2 size {span} = {s1} by elementary divisors)")
            report(all(fixes_L(n, pi, T, h) for h in H),
                   f"{tag}: pi.D_h fixes every Z_c (c non-target) and X_tau (tau target), "
                   f"all {len(H)} generators h of H_pi")
            report(all(lagr_ok(n, pi, T, g) for g in g1),
                   f"{tag}: all {len(g1)} kernel generators literally in C_3, Lagrangian <Z_c, X_tau Z^M_tau> "
                   "with unique symmetric M")
            keep[(n, name)] = (pi, R1, R2)

    for n in range(1, 7):               # C5: diagonal gates of the third level (review defect D1)
        N = 1 << n
        R1 = R_route1(n, n, [])
        pi_ok, R2 = R_route2(n, n, [])
        ok1, s1, g1 = kernel8(R1, N)
        ok2, s2, g2 = kernel8(R2, N)
        cont = all(annihilates(R2, g) for g in g1) and all(annihilates(R1, g) for g in g2)
        cl, H = diag_gens(n, list(range(n)))
        allg = cl + H
        okG, span = gen_size(allg, N)
        inA = all(annihilates(R1, g) and annihilates(R2, g) for g in allg)
        closed = 3 + 3 * n + n * (n - 1) + n * (n - 1) * (n - 2) // 6
        report(pi_ok and ok1 and ok2 and cont and okG and inA and span == s1 == s2 == closed == EXPECTED_ID[n],
               f"diagonal classification n={n} (pi = id): A_id derived twice, certified, mutually contained; "
               f"A_id = Cliff + H_id (T, CS, CCZ): all {len(allg)} generators in A_id, log2 sizes "
               f"{span} = {s1} = 3+3n+2C(n,2)+C(n,3) = {closed} (expected {EXPECTED_ID[n]})")

    pi6, R1, R2 = keep[(6, 'TOF')]      # C6 controls
    x3 = [(x >> 3) & 1 for x in range(64)]
    x2 = [(x >> 2) & 1 for x in range(64)]
    d0 = sympl_dims(S_U((pi6, [0] * 64), 6), 6)
    dI = sympl_dims(S_U((pi6, x3), 6), 6)
    report(d0[0] == 9 and in_C3((pi6, x3), 6) and annihilates(R1, x3) and annihilates(R2, x3)
           and dI[0] == 8 and sum(dI) >= 12,
           f"M9 control TOF*T(idle 3): in C_3 and A_pi, dim S_U = {dI[0]} (TOF alone: {d0[0]}), coisotropic")
    dT = sympl_dims(S_U((pi6, x2), 6), 6)
    report(not in_C3((pi6, x2), 6) and not annihilates(R1, x2) and not annihilates(R2, x2) and sum(dT) < 12
           and not lagr_ok(6, pi6, [2], x2),
           "negative control TOF*T(target): not in C_3, not in A_pi, S_U not coisotropic, Step-6 check rejects it")
    y7 = []
    for x in range(128):
        b = [(x >> i) & 1 for i in range(7)]
        y = [b[0], b[1], b[2], b[3] ^ b[0] & b[1], b[4] ^ b[0] & b[2], b[5] ^ b[1] & b[2],
             b[6] ^ (b[0] & b[1] & b[2]) ^ (b[0] & b[5]) ^ (b[1] & b[4]) ^ (b[2] & b[3])]
        y7.append(sum(v << i for i, v in enumerate(y)))
    d7 = sympl_dims(S_U((y7, [0] * 128), 7), 7)
    report(len(set(y7)) == 128 and in_C3((y7, [0] * 128), 7) and d7 == (4, 4) and sum(d7) < 14,
           f"control n=7 cubic permutation (nonzero triple product): a bijection, in C_3 (literal generator check), "
           f"(dim S_U, dim rad S_U) = {d7}, sum {sum(d7)} < 14 so NOT semi-Clifford (Lemma A)")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:            # a crash is a failure, never a silent pass
        report(False, f"unexpected exception {type(exc).__name__}: {exc}")
    print(f"VERDICT {'PASS' if not FAILS else 'FAIL'}: " +
          ("C_3(5) and C_3(6) consist of semi-Clifford gates (given the reductions); n_min = 7"
           if not FAILS else f"{len(FAILS)} checks failed"))
    sys.exit(1 if FAILS else 0)
