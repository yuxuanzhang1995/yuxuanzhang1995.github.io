# One-shot resources for a Gibbs-preserving channel

**Internal full-scope solution candidate, 26 November 2026.** The results below give matching bounds, exact finiteness conditions and small-error behavior for the two costs in the [catalog question](https://qiqc-op.com/problem/op_56578531a2c610fe/). The resource in the coherence problem is finite and may carry arbitrary stationary purity. In the work problem the battery is the sole nonthermal input and its endpoints are specified pure energy eigenstates. All approximations use the supremum of purified distance over inputs with a reference. The input and output system may differ and together with the environment use a common conserved total Hamiltonian. The work theorem gives separate answers for finite baths, normal baths with trace-class Gibbs states, and the process-closure convention used in the paper cited by the catalog. The main work formulas below use \(0<\beta<\infty\). [Other finite inverse temperatures](temperature-endpoints.md) · [Tajima and Takagi, supplement §I.B](https://arxiv.org/pdf/2404.03479)

## Coherence at every error

Let \(e_i,f_j\) be the system energies, with degeneracies repeated. Use an input-first, unnormalized Choi matrix. A clock is represented by a finite positive scalar probability \(p\) on real energies and positive Choi matrices \(Y_z\) on finitely many real environment energies. Set
\[
 \sum_j (Y_{g-f_j})_{ij,i'j}=\delta_{ii'}p_{g-e_i},
 \qquad J=\sum_zY_z .                                                       \tag{1}
\]
These equations are necessary and sufficient. The finite purification that minimizes total energy variance gives the same SLD QFI for every mixed input resource. For the converse, factor each \(Y_z\). Equation (1) says that dividing occupied columns in each energy sector by their clock amplitudes gives an isometry. Complete it to an energy-conserving finite unitary with sharp output and environment blanks included in the resource. The cost is \(4\operatorname{Var}(p)\). A scalar translation can center \(p\). [Finite physical equivalence, §§1–2](q117-program-proof-v2.md) · [Marvian, Theorem 3](https://arxiv.org/abs/2112.04694)

For \(0<\varepsilon<1\), write the energies in a basis \(\omega\) of their integer lattice and \(e_i=\omega\cdot a_i,\ f_j=\omega\cdot b_j\). Let \(C_{L,N}(\eta)\) minimize \(4\sum_xx^2p_x\) subject to (1) on the explicit finite grid in §4 of the linked proof, and impose the system accuracy by
\[
 \begin{pmatrix}J_\Phi& X\\X^*&J\end{pmatrix}\succeq0,\qquad
 \operatorname{Re}\operatorname{Tr}_B X\succeq\sqrt{1-\eta^2}\,I_A .
\]
At \(\eta\ge1\) omit the accuracy constraint. With \(d=\dim A,\ Q=\max_{ij}\|b_j-a_i\|_1,\ \Delta_L=\min(1,\sqrt{2dQ/L})\), the matching finite semidefinite bounds are
\[
 \max\{0,C_{L,N}(\varepsilon+\Delta_L)-\omega_1^2/N^2\}
 \le F_c^\varepsilon(\Phi)\le C_{L,N}(\varepsilon).
\]
Their limits coincide for \(L=h,\ N=h!\). Localization dephases each finite clock between translated boxes, and the total loss of channel fidelity is controlled uniformly on entangled inputs. Convexity in the required root fidelity supplies continuity at interior errors. If every system gap is zero the QFI cost is zero. More generally, at every \(\varepsilon\), including \(\varepsilon\ge1\), the cost is zero exactly when \(\varepsilon\) is at least the distance to the compact set of covariant channels. [Grid, fidelity derivation and convergence, §§3–6](q117-program-proof-v2.md) · [Zero-cost proof, §7](coherence-theorem.md)

### Finite resources at zero error

Take a minimal Kraus basis of \(\Phi\). Positivity in (1) forces each \(Y_z\) into its Choi support. In these coordinates write \(Y_z=B C_z^{\mathsf T} B^*\), with \(C_z\succeq0\) and \(B\) the injective matrix of Kraus vectors. Write \(T\succ0\) for the target Gram (identity in a normalized Kraus family). Form the real Laurent module of tuples \(\operatorname{diag}(p,C)\) obeying the sector equations and \(\sum C=T\sum p\). The terminal condition is an evaluation at one. An exact finite clock exists precisely when this module contains an element with every coefficient PSD and with positive definite value at one. The physical necessity on the integral lattice follows by translating each energy coset to that lattice and adding the positive tuples. Only the *total* terminal condition is imposed before adding them.

There is a terminating structural test for this condition at any number of independent gaps. On the positive real torus, the evaluated module must contain a positive definite matrix at every point. At each nonzero exterior normal there must be a local module element whose top coefficients on each surviving column space have positive diagonal sum and whose cross columns annihilate the individual diagonal kernels there. Initial-module generators turn this second test into the same positive-witness problem on a lattice of strictly smaller rank. A sphere cover and a scalar positive multiplier return a single finite matrix certificate; clearing rational exponent cosets returns it to the original lattice. The resulting finite real formula is decidable on algebraic sector entries with exact lattice labels. Finiteness has been characterized for arbitrary real energies and channel entries as well. [Matrix flags and gluing](global-flags.md) · [Full decision proof and specialization](tangential-decision.md) · [Matrix multiplier](matrix-positive-multiplier-v3.md)

### Optimal exact cost if a finite clock exists

For the upper bound take all finite positive tuples satisfying (1) with exact aggregate \(J=J_\Phi\). For the lower bound there is a different, finite-function variational problem. Let \(G_j=\sum_a g_{ja}X^a\) generate the sector module *before* the terminal constraint, with \(g_{ja}\) in the scalar-plus-Hermitian coordinate space. Put \(s_a=\omega\cdot a\); \(p(g)\) denotes the scalar component, and \(B_0(G_j)=\sum_a(C(g_{ja})-Tp(g_{ja}))\). Choose any Hermitian linear functional \(\lambda\) on the terminal discrepancies. Search over functions
\[
 Y(x)=\sum_{t\in J_0}e^{itx}(A_t+x B_t+x^2D_t)\succeq0\quad(x\in\mathbb R),
\]
with finitely many real frequencies and conjugate pairing, satisfying
\[
 \sum_a\langle g_{ja},Y(x+s_a)\rangle
 =\sum_a((x+s_a)^2-c)p(g_{ja})+\lambda(B_0(G_j))
 \quad\text{for all }j,x .
\]
Then \(F_c^0(\Phi)=4\sup c=4\inf\operatorname{Var}(p)\). Every feasible function gives a lower bound on every physical clock. The reverse direction uses positive linear extension, a measurable bandlimited approximation, one-variable kernel projection across singular frequencies, and positive trigonometric averaging of the quadratic tail. It works when physical time actually passes through a rank drop. The finite upper and lower witnesses need not be uniformly findable from numerical approximations to arbitrary spectra. [Positive dual](positive-dual.md) · [Finite-function density proof](finite-lower-witnesses.md)

### As the error drops to zero

In a minimal Stinespring isometry \(V\) define \(\Omega_j(X)=V^*(H_B^j\otimes X)V\). Starting from \(C_0=I\), find the first order \(k\ge1\) for which the **joint** Hermitian linear equations up through that order fail:
\[
 \sum_{j=0}^{\ell}{\ell\choose j}\Omega_j(C_{\ell-j})=H_A^\ell
 \quad (0\le\ell\le k).
\]
If there are \(a,b\) distinct input and output energies and \(r\) Kraus operators, it suffices to test through \(a{b+p-1\choose p}-1\), with \(p=\min(r^2,d^2)\). A finite first failure gives \(F_c^\varepsilon(\Phi)=\Theta_\Phi(\varepsilon^{-2/k})\) and infinite zero-error cost. If every order passes, the small-positive-error cost stays bounded. For a noncovariant channel in this branch it is \(\Theta_\Phi(1)\), including cases where no finite clock is exactly sufficient. A covariant target costs zero. The finite-existence test above distinguishes these alternatives at the endpoint. The precise bounded limit is the minimum centered second moment times four in the finite-moment measure relaxation of (1) at \(J_\Phi\). The order law, including the finite resource construction, comes from the 24 November work. [Joint-order theorem](coherence-theorem.md) · [Translated-fibre implementation](finite-resource-lemma.md) · [Positive-error relaxation](positive-error-relaxation.md)

## Deterministic work

Let \(C\) be the covariant CPTP channels in the closed error ball, in Choi coordinates. With a normal positive-temperature Gibbs bath and exact sharp battery endpoints, finite work is possible exactly when \(C\ne\varnothing\). Thus if a target has infinite exact work, it already has infinite work throughout the interval below its strictly positive distance to the covariant channels. At the threshold the work is finite. When \(C\ne\varnothing\), form \(S\) from the joint Kraus supports of its members. With system ground energies set to zero, let \(g(S)\) be the lowest possible maximal Kraus frequency of any covariant TP channel supported in \(S\). This number needs only finitely many PSD feasibility tests.

For each \(u\ge\beta\), \(\mathcal H_u(S)\) is the set of Hermitian linear tests on Kraus Grams in \(S\). A test must upper-bound its pairing with the unnormalized Gibbs Gram by the weighted output rank for *every* finite list of graded PSD matrices obeying the linear isometry identities. The precise indices and partition factors are Eqs. (1)–(2) of the linked proof. Write \(e\) for the functional equal to one on every normalized TP Gram, \(d_u=\sup\{z:ze\in\mathcal H_u(S)\}\), and \(b_C=\sup_{H\in\mathcal H_\beta(S)}\min_{T\in C}\langle H,T\rangle\). Then
\[
 W_\varepsilon^{\rm normal}(\Phi)=
 \max\!\left\{g(S),\ \sup_{u\ge\beta}\frac{\log d_u}{u},\
                        \frac{\log b_C}{\beta}\right\}.
\]
The upper construction is a Gibbs isometry with finite logical registers followed by a physical energy-conserving dilation using a normal bath. The lower bound uses integer shell ranks and convex separation on the smallest support meeting the **closed** error ball. Equality includes vanishing error and a ball tangent to the covariant set. The universal matrix-size quantifier in the lower bound has mathematical consequences: even for rational full-rank unital channels and zero system energy, there is no uniform algorithm that recognizes every strictly positive work cost without accepting a zero-cost instance. A request for ordinary numerical brackets guaranteed to converge on every instance is therefore impossible in this model. [All-error work dual](work-lower-witnesses.md) · [Matching physical construction](work-general-variational-v4.md) · [Noncomputability proof](positive-work.md)

If only **finite baths** are allowed and the battery must exactly change between two pure energies in each implementation, full rank of the Gibbs state forces the battery shift to be zero. Here \(W_\varepsilon=0\) if a finite graded-unitary array from the explicit multiplicity test meets the closed error ball, and \(+\infty\) otherwise. For an exact-infeasible target in the closure of these channels the cost is zero at every positive error. Outside the closure it is infinite below a positive distance. At the distance itself use actual finite-array membership. In dimension eleven there are channels from a published Schur family with zero exact cost on rational parameters and infinite cost on irrational ones, all with zero work at every positive error. [Finite-bath classification](finite-baths.md) · [Schur-channel application and credit](finite-cost-and-rationality.md)

If one first **closes the whole thermal process** and then requires a sharp battery, \(C\ne\varnothing\) still characterizes finite positive-temperature work. Its value is the single term \(\beta^{-1}\log\sup_{H\in\mathcal H_\beta(\mathcal L(A,B))}\min_{T\in C}\langle H,T\rangle\). Closing the joint process allows finite approximants with vanishing battery failure. The proof bounds the cost of completing their success blocks to isometries and fixes the physical gap *before* passing to a limit. For a specific three-level Gibbs-preserving channel at \(\beta=1\), actual finite baths give \(+\infty\), actual normal baths give \(\log16\), and closed thermal processes give \(\log(529/36)\). [Closure theorem](closed-process-work.md) · [Explicit channel](work-discontinuity-v1.md)

## Two checks on what these answers mean

* Measuring a qubit in the \(X\) basis and recording the result in an energy-degenerate classical bit is Gibbs preserving when the input energy is diagonal in the \(Z\) basis. Its first moment equation fails and its coherence cost grows as \(\varepsilon^{-2}\). Every battery-only implementation is covariant, so it cannot distinguish the \(+\) and \(-\) inputs. Its exact distance to the covariant set is \(1/\sqrt2\). At this distance the free maximally mixed replacement suffices on entangled inputs as well. [Derivation and controls](REVIEW-INTEGRATED.md)
* The exact-coherence value can be discontinuous even when every channel of a fixed-dimensional family has a known finite exact clock. For a \(43\to21\) Gibbs-preserving family with two independent gaps, a physical-frequency zero forces extra variance at one gap ratio, while arbitrarily close nonresonant ratios permit positive finite exact clocks with extra variance below \(1/100\). The gap remains after a known smooth baseline is subtracted. This precludes a uniform algorithm for general real data given by arbitrarily accurate approximations, already at fixed additive error \(1/4\). [Two-preparation construction](two-preparations.md) · [Analytic constants](resonance-jump.md) · [Bound for the input representation](sharp-oracle-bound.md)

Tajima–Takagi's pairwise-reversible obstruction and relative-interior finiteness result, Marvian's purification identity, and the published factorization and undecidability examples are inputs. The scoped primary-source comparison located no paper containing this full set of characterizations. The proof dossier has same-author mathematical review and local reproductions. Independent proof review and worldwide priority remain unconfirmed. [Catalog and source](https://qiqc-op.com/problem/op_56578531a2c610fe/) · [Review record](REVIEW-INTEGRATED.md)
