"""Exact finite algebra checks. This is not an all-n anticoncentration proof."""
from functools import lru_cache
from dataclasses import dataclass
import random,json
@dataclass(frozen=True)
class GI:
    r:int=0
    i:int=0
    def __add__(self,o):
        if not isinstance(o,GI):o=GI(o)
        return GI(self.r+o.r,self.i+o.i)
    __radd__=__add__
    def __mul__(self,o):
        if not isinstance(o,GI):o=GI(o)
        return GI(self.r*o.r-self.i*o.i,self.r*o.i+self.i*o.r)
    __rmul__=__mul__

def haf(a,ids=None):
    @lru_cache(None)
    def f(s):
        if not s:return GI(1)
        return sum((a[s[0]][j]*f(tuple(k for k in s[1:]if k!=j))for j in s[1:]),GI())
    return f(tuple(range(len(a)))if ids is None else tuple(ids))
rng=random.Random(18092026);counts=[]
for n in range(2,7):
    m=2*n
    for rep in range(12):
        a=[[GI()for _ in range(m)]for _ in range(m)]
        for i in range(m):
            for j in range(i+1,m):a[i][j]=a[j][i]=GI(rng.randrange(-3,4),rng.randrange(-3,4))
        p,q=1,2;R=list(range(3,m));h={a_:haf(a,[i for i in R if i!=a_])for a_ in R}
        C=sum((a[0][i]*h[i]for i in R),GI())
        bil=GI()
        for b in R:
            for c in R:
                if b==c:continue
                K=sum((a[0][i]*haf(a,[v for v in R if v not in (i,b,c)])for i in R if i not in (b,c)),GI())
                bil+=a[p][b]*K*a[q][c]
        rhs=bil+a[0][q]*sum((a[p][b]*h[b]for b in R),GI())+a[0][p]*sum((a[q][b]*h[b]for b in R),GI())+a[p][q]*C
        assert haf(a)==rhs
        # Exact vertex phases from the fourth roots of unity.
        units=[GI(1),GI(0,1),GI(-1),GI(0,-1)]
        phases={j:rng.choice(units)for j in range(1,m)};base=[row[:]for row in a];trans=[row[:]for row in a]
        global_phase=GI(1)
        for j in range(1,m):
            radius=rng.randrange(0,4);base[0][j]=base[j][0]=GI(radius)
            trans[0][j]=trans[j][0]=radius*phases[j];global_phase*=phases[j]
        for j in range(1,m):
            for k in range(j+1,m):trans[j][k]=trans[k][j]=a[j][k]*phases[j]*phases[k]
        assert haf(trans)==global_phase*haf(base)
    counts.append(dict(n=n,matching_partitions=12,vertex_phase_identities=12))
assert haf([])==GI(1)
print(json.dumps(dict(status='passed',arithmetic='unbounded integer pairs (Gaussian integers), no tolerances',cases=counts,scope='Finite matching and phase identities only. Conditional Gaussian integration, Holder, Tonelli and all-n induction are analytic, not certified by this script.'),indent=2))
