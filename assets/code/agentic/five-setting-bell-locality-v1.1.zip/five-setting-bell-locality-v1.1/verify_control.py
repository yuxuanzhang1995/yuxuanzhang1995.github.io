"""Read-only exact check, using only Python's standard library.

It verifies the finite adversarial control, not Helly's analytic theorem or
the completeness of the imported finite facet enumeration.
"""
import argparse
import copy
import itertools
import json
from fractions import Fraction as F
from pathlib import Path


def rank(rows):
    a = [[F(x) for x in row] for row in rows]
    r = 0
    for col in range(len(a[0])):
        k = next((k for k in range(r,len(a)) if a[k][col]),None)
        if k is None:
            continue
        a[r], a[k] = a[k], a[r]
        pivot = a[r][col]
        a[r] = [x/pivot for x in a[r]]
        for k in range(r+1,len(a)):
            scale = a[k][col]
            if scale:
                a[k] = [x-scale*y for x,y in zip(a[k],a[r])]
        r += 1
        if r == len(a):
            break
    return r


def dot(x,y):
    return sum(a*b for a,b in zip(x,y))


def response(a,b):
    return [F(1), *map(F,a), *map(F,b),
            *(F(a[x]*b[y]) for x in range(len(a)) for y in range(len(b)))]


def check(c):
    assert c['scenario'] == [3,5,2,2]
    h = list(map(F,c['normal_h']))
    p = list(map(F,c['behavior']))
    assert len(h) == len(p) == 24 and p[0] == 1
    vertices = [response(a,b) for a in itertools.product((0,1),repeat=3)
                for b in itertools.product((0,1),repeat=5)]
    slacks = [dot(h,v) for v in vertices]
    assert all(x >= 0 for x in slacks), 'invalid local inequality'
    saturated = [v for v,s in zip(vertices,slacks) if s == 0]
    assert rank(vertices) == 24, 'wrong affine dimension'
    assert rank(saturated) == 23, 'not a facet'
    assert len(saturated) == c['saturating_vertex_count']
    assert dot(h,p) < 0, 'behavior is not separated'
    assert dot(h,p) == F(c['bell_slack'])
    # Explicitly reconstruct every conditional probability in the NS chart.
    probabilities = []
    for x in range(3):
        for y in range(5):
            a,b,ab = p[1+x],p[4+y],p[9+5*x+y]
            outcomes = [ab,a-ab,b-ab,1-a-b+ab]
            assert sum(outcomes) == 1 and all(z >= 0 for z in outcomes)
            probabilities += outcomes
    assert {m['deleted_bob_setting'] for m in c['deletion_local_models']} == set(range(5))
    model_terms = []
    for m in c['deletion_local_models']:
        keep = [j for j in range(5) if j != m['deleted_bob_setting']]
        assert keep == m['kept_bob_settings']
        cols = [0,1,2,3] + [4+j for j in keep]
        cols += [9+5*x+j for x in range(3) for j in keep]
        rebuilt = [F(0)]*20
        for term in m['terms']:
            a,b,w = term['alice'],term['bob'],F(term['weight'])
            assert len(a)==3 and len(b)==4 and set(a+b)<=set((0,1)) and w>=0
            rebuilt = [u+w*v for u,v in zip(rebuilt,response(a,b))]
        assert rebuilt == [p[j] for j in cols], 'incorrect four-setting local model'
        model_terms.append(len(m['terms']))
    return {'deterministic_vertices':len(vertices), 'minimum_local_slack':str(min(slacks)),
            'saturating_vertices':len(saturated), 'facet_affine_dimension':22,
            'nonlocal_slack':str(dot(h,p)), 'conditional_probabilities_checked':len(probabilities),
            'minimum_probability':str(min(probabilities)),
            'exact_four_setting_models':5,'terms_per_model':model_terms}


def gluing_control():
    # A model with null hidden-variable atoms tests the zero-division case.
    atoms = list(itertools.product((0,1), repeat=3))
    lam = [F(1,3),F(0),F(1,6),F(0),F(0),F(1,2),F(0),F(0)]
    r = [[F((i+2*y)%5,4) for i in range(8)] for y in range(6)]
    q = [[(lam[i]*(1-r[y][i]),lam[i]*r[y][i]) for i in range(8)]
         for y in range(6)]
    global_weights = []
    for i,a in enumerate(atoms):
        for b in itertools.product((0,1), repeat=6):
            w = lam[i]
            for y in range(6):
                w *= r[y][i] if b[y] else 1-r[y][i]
            global_weights.append((i,a,b,w))
    assert sum(z[3] for z in global_weights) == 1
    for y in range(6):
        for i in range(8):
            for b in (0,1):
                assert sum(w for j,_,bs,w in global_weights if j==i and bs[y]==b) == q[y][i][b]
    return {'bob_settings':6,'hidden_atoms':8,'zero_mass_atoms':lam.count(F(0)),
            'exact_joint_extension_equalities':6*8*2}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--certificate',default='five-setting-certificate.json')
    ap.add_argument('--report',default='exact-control-report.json')
    args=ap.parse_args()
    c=json.loads(Path(args.certificate).read_text())
    result=check(c)
    result['gluing_control']=gluing_control()
    mutations=[]
    bad=copy.deepcopy(c);bad['normal_h']=[-x for x in bad['normal_h']];mutations.append(('reverse_inequality',bad))
    bad=copy.deepcopy(c);bad['deletion_local_models'][0]['terms'][0]['weight']='0';mutations.append(('remove_model_mass',bad))
    bad=copy.deepcopy(c);bad['behavior'][9]=str(F(bad['behavior'][9])+F(1,100));mutations.append(('change_joint_probability',bad))
    caught=[]
    for label,bad in mutations:
        try:check(bad)
        except AssertionError:caught.append(label)
        else:raise AssertionError('Mutation not caught: '+label)
    result['mutations_caught']=caught
    result['analytical_claims_not_certified_by_this_script']=[
        'Helly reduction for all setting counts', 'imported finite completeness', 'priority']
    Path(args.report).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
