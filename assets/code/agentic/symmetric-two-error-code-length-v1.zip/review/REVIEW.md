# Q005 v1 — independent mathematical review

Date: 2026-11-10. Reviewer relation: **fresh-context same-model-family agent**, not an external expert. The review began from the complete original record and pinned candidate. Prior self-review, COORDINATOR-CHECK, status/report and verdict artifacts were not consulted. `FIRST-PASS.md` records the conceptual assessment before replay and the source conclusion. Its input-count typo was subsequently corrected from 18 to 19.

## Judgment and frozen identity

**Validity: supported internally. Original coverage: complete. No fatal mathematical issue was found.** Every admissible original code yields a feasible point of the stated relaxation; the exact dual certificates contradict feasibility at every n=9,...,18. The elementary argument covers n<=8. Published nineteen-qubit existence then supplies equality.

**Prior-art relationship: difference supported, with attribution corrections.** The decisive new exclusion is n=18. Earlier scalar bounds overlap the smaller lengths. No equivalent unrestricted minimum theorem was located in the bounded primary-source search. This is a research judgment relative to reviewed sources, not an exhaustive priority guarantee.

The original is `op_a72722e455d85d55`, record SHA-256 `ddce83eff46f4ce9fe9a266ae736747eb1bed91e6ce1945e78c0195ebb77d8ad`. The candidate is `q005-minimum-nineteen-v1.md`, SHA-256 `b107acbbd50bf51aec366524902676686a9eff34b93c42c79690963f1a5b6373`. All 19 input hashes in `INPUT-MANIFEST.json` were recomputed and matched. The report judges that version; no author proof or input was changed.

## Mapping to the original

The quantified object is an arbitrary rank-two orthogonal projector P on V_j=Sym^n(C^2), j=n/2, with complex coefficients. Physical error detection is PEP=Tr(PE)P/2 for all Pauli products of weight at most four. The original does not impose nondegeneracy, a stabilizer structure, parity of n, parity of codeword support, real coefficients, or a logical symmetry. Pointwise permutation invariance is essential: the proof does not cover an arbitrary code whose projector alone commutes with qubit permutations.

The finite blocks enumerate every integer n from nine through eighteen separately. No shortening or monotonicity assumption is present. Arbitrary complex coefficients and degenerate codes enter solely through P; the later real variables are a relaxation of code moments. The equality at nineteen is imported rather than claimed as a new construction. The all-t minimum conjecture remains outside this result.

## Independent derivation of the necessary moment

### Physical error space and lifting

For each l<=n, (J_+)^l is a nonzero highest-weight rank-l operator under conjugation. Repeated adjoint lowering produces its entire irreducible tensor sector, and never increases its collective-spin polynomial degree. Each collective spin component is a sum of one-qubit operators. Expanding a polynomial of degree at most four produces operators supported on at most four physical qubits. Thus all rank-l sectors l<=4 lie in the compressed physical error space. Only this inclusion is needed; no converse is assumed.

For arbitrary P and E, direct matrix indices give

\[
\operatorname{Tr}_3[(I\otimes I\otimes E)F_{13}P^{\otimes3}]
=PEP\otimes P,
\qquad
\operatorname{Tr}_3[(I\otimes I\otimes E)P^{\otimes3}]
=\operatorname{Tr}(PE)P\otimes P.
\]

Their difference vanishes for a code. Collective rotations preserve each rank-l sector, so the same statement holds after rotating P and averaging. This proves candidate Eq. (3). In particular l=0 is valid and retains idempotence; it is not merely a trace convention.

### Positivity, S3 and complex coefficients

The Haar moment Ω=∫(UPU*)^⊗3 is positive and has trace 2^3. It commutes with collective SU(2) and all permutations of the copies. Its sign component vanishes because the exterior cube of a two-dimensional range vanishes. It does **not** vanish on the standard S3 component. An actual rank-two product projector has trace four in the symmetric component and four in the standard component; the independent controls recover this split.

Since every integrand is a product of positive factors, its transpose on the third factor is positive. Conjugating by the spin flip preserves positivity and produces Θ_3Ω. The spin flip intertwines the conjugate representation with the original, so Θ_3Ω remains SU(2)-invariant. Copy swap F12 still commutes with it. There is no justification to impose the other swaps or sign-sector annihilation on Θ_3Ω, and the candidate does not impose them.

In the real Condon–Shortley/Dicke basis, conjugation of the SU(2) image preserves that image; the tensor-rank spaces are also preserved. Hence Ω(P-bar)=Ω(P)-bar. Because C is real, Θ_3 commutes with entrywise conjugation. Averaging these two moments preserves every needed linear identity and positive cone. The resulting real symmetric block variables therefore exist for **every complex code**, without replacing P by Re(P) or assuming a real basis of codewords.

### Complete seed parametrization

The allowed coupled spins are exactly the J and I_J listed in the proof. Schur’s lemma leaves a full multiplicity matrix X_J, not a scalar. In a real orthogonal S3 decomposition, an invariant positive X without sign support is a positive multiplicity matrix on each trivial component and a positive multiplicity matrix tensored with I_2 on the standard component.

Let E be the inclusion of the transposition-even subspace, and Π+=EE*. The positive seed

\[
H=E^*(X_{\mathrm{triv}}+2X_{\mathrm{std}})E
\]

has group average X after inclusion. On a standard irrep, the average of its rank-one positive-transposition projection is I_2/2. Cross multiplicities are retained because the averaging acts on the irrep factor, leaving the full positive multiplicity matrix. This proves surjectivity. Positive diagonal congruence transports the argument to the rational H coordinates. Using rational matrices W H W^T rather than similarity averaging is correct.

## Coefficients carrying the conclusion

### Swaps, lifted contractions and scaling

Direct coupling gives D(a,a)=(-1)^(n-a) and the stated 6j formula for F13. Contracting the q=0 tensors explicitly involves two coupling coefficients and the two tensor-operator coefficients. Summing over M yields h=(2J+1)(-1)^(b+j+J){a j J; j b l}. Covariance pairs equal ranks. Even taking only these q=0 scalar contractions is a necessary condition; omitting stronger equations would weaken, rather than invalidate, the exclusion.

Write S=diag(s), X=SZS and R'=S^(-1)RS. Since R is symmetric,

\[
S^2R'=(R')^TS^2,
\qquad XR=S Z(R')^T S.
\]

This explains the transpose in Eq. (10). Removing it is an error. The Racah-factor cancellation in c=h s_a s_b/κ is correct, with κ positive for each allowed test. Powers-of-two scales are nonzero and preserve the positive cone; their numerical balancing is not a feasibility restriction.

`check_coefficients.py` independently compared **17,110 swap coefficients and 32,770 lifted coefficients** at all ten target lengths against SymPy’s 6j implementation. It checked both the exact rational square and the sign, so equality of squares cannot hide a sign error. These comparisons cover every l<=4 coefficient used in the equality system. Six additional exact direct-CG sums bypass both implementations’ Racah sums and agree with h.

### Partial time reversal

For fixed a,b, use invariant tensor contractions

\[
B_l^{ab}=\sum_q(-1)^q A_{ab}^{(lq)}\otimes T_{l,-q}.
\]

Their Hilbert–Schmidt norm squared is 2l+1. In coupled blocks their matrix element is β_Jl=(2l+1)h_J/(2J+1). Orthogonality yields the inverse expansion coefficient α_l=Σ_J h_J X_J,ab (with the consistent ab orientation). Θ_3 acts as (-1)^l on the third tensor factor, so

\[
(\Theta_3X)_{J,ab}
=\sum_{J'}\sum_l\frac{(-1)^l(2l+1)h_Jh_{J'}}{2J+1}X_{J',ab}.
\]

Converting output and input to Z coordinates contributes s_J'a s_J'b/(s_Ja s_Jb). Substitution of h=κc/(s_a s_b) cancels the primed scales and leaves exactly κ²c_Jc_J'/[(2J+1)d_Ja d_Jb]. Thus Eqs. (13)–(14), including the output-side denominator, are correct. The transfer code implements this expression; both parities of a in each output block are included. Its exact involution check is useful but is not, by itself, proof that it represents a partial transpose.

Independent controls construct the twirled blocks of P⊗P⊗P and of P⊗P⊗(CP^TC*) directly from product-code factors and CG coefficients, without using the author’s transfer to construct the target. These compare to the rational transfer on all a,b at n=2,3,5 and on the exact 21-qubit code. The complex n=5 input has an imaginary moment entry about 0.002995 before averaging, making the reality control substantive. No transpose, phase, parity or scaling discrepancy was found.

### Scalar and shadow inequalities

A_l is a sum of absolute squares. On the K-dimensional range of P, Hilbert–Schmidt Cauchy–Schwarz gives B_l>=A_l/K without a nondegeneracy assumption. The scalar kernel on the first pair has eigenvalues f_la as stated; tracing it against Tr_3Ω/K gives Eq. (12). Normalization is A_0=4/(n+1), Σ_l A_l=2. The MacWilliams transformation has the additional (-1)^l, as in Eq. (11).

For Q=CP^TC*>=0, the polarized B quantity Σ_q Tr(P T_lq* Q T_lq) is nonnegative. Time reversal changes the rank-a cross enumerator by (-1)^a, yielding M diag((-1)^a)A>=0. This directly establishes necessity of the shadow inequalities. Independent operator calculations agree with the transform and two-copy moment formulas. These scalar tools are inherited, particularly from Bumgardner and Okada; see `SOURCES.md`.

## Exact certificate audit and controls

Only the frozen proof, three checker modules and ten certificate JSON files were copied into `clean-replay/`. Each command used `/opt/anaconda3/bin/python -B certify_dual.py N --verify --clean` in effect, with no numerical solver, cached coefficient pickle, or search output. All ten passed. `CLEAN-REPLAY.json` records the negative rational right-hand sides and positivity counts: 435 positive scalar multipliers, 1,640 positive PPT-dual pivots, and 856 positive seed-slack pivots, totalling 2,496 matrix pivots.

I read the complete checker and generators. The checker rebuilds A and G; parses dual entries as exact rationals; checks y^T b<0; checks every required parity block of Q; computes the transfer adjoint; halves off-diagonal seed coefficients for the trace pairing; and reconstructs S before exact LDL positivity tests. The arithmetic uses rational operations throughout the decision path. Floats appear only in diagnostic output. All n=9,...,18 are asserted admissible in the checker.

The contradiction has the correct direction:

\[
y^Tb=\lambda^TGx+\sum_k\operatorname{Tr}(Q_kL_k(x))+
\sum_J\operatorname{Tr}(S_JH_J(x))\geq0
\]

at a feasible point, whereas the verified number is negative. The code does not mistake dual objective sign or numerical solver status for infeasibility.

The reviewer’s separate `independent_controls.py` first verified the explicit 21-qubit control exactly: 75 four-erasure scalar/off-diagonal identities and orthonormality. It then evaluated the full direct moment. Physical lifted error is 4.07e-18, coefficient-normalized lifted error 3.92e-19, seed reconstruction error 8.67e-19, and partial-time-reversal error 6.51e-19. Floating controls use a 1e-10 diagnostic threshold and are not the rigorous exclusion certificate. A generic complex n=5 projector tested at depth one is correctly rejected, with physical lifted violation 0.037895, while its trace/positivity/seed/transfer controls still hold. Thus the test is not vacuously accepting every projector.

The reviewer’s first raw residual diagnostic on the 21-qubit control failed (ratio about 0.892 for l=1,a=b=14). It normalized a nearly zero row after multiplication by the inverse of a tiny stripped common factor. Physical-coordinate and coefficient-normalized residuals resolved this as a **review-control floating scaling defect**, not a candidate defect. The diagnostic is retained in `INDEPENDENT-CONTROLS.json`; no tolerance was used to validate the exact dual. A numerical residual with this scaling should not be used as mathematical evidence without normalization.

## Small lengths and nineteen-qubit existence

For n<=4, the tested physical Paulis span the full algebra; compression of every operator to a scalar on a two-dimensional subspace is impossible. For 5<=n<=8, distance at least five makes any four-erasure channel correctible. Two disjoint surviving sets of size n-4 exist. Recovery from both would broadcast an unknown logical state and violate no-cloning. This argument applies to degenerate codes and does not require symmetric support.

The upper bound is accepted as an imported computer-assisted existence result, with the precise source interface in `SOURCES.md`. The reviewer did not independently rerun msolve or validate original isolating intervals. This is an ordinary explicit dependency, not an inference from the rounded coefficients or from the candidate’s n=19 SDP feasibility experiment.

## Prior art, issues and next action

No mathematical gap was established in v1. Its relaxation covers the full original class, and its certificates supply an exact contradiction. Relative to the sources reviewed, the eighteen-qubit exclusion and minimum theorem are new; the list of ten exclusions should not suggest that all smaller-length bounds were previously unknown. Okada’s Table 3.1 already reports scalar bounds excluding the smaller lengths but leaves K=2 feasible at eighteen. Its exact-solver qualification has no explicit cutoff. The current certificates make the lower proof independent of that ambiguity. [Okada, Sections 3.2–3.4](https://arxiv.org/pdf/2502.14165v1).

Nonfatal issues communicated to the coordinator:

1. Add direct attribution to Bumgardner and Okada for the scalar SU(2) and shadow tools, and mention the previous n=18 gap. Include the earlier real covariant spin-code prediction if explaining the conjecture’s history.
2. In v1’s seed-surjectivity paragraph, E denotes a selector and later is used like a projection. The argument is valid with Π+=EE*; the release draft’s included-seed formulation resolves the notation.
3. The inspected release draft used a comma in the exponent `κ^{,2}` in its transfer formula and described three CG factors. These were reported for correction to κ² and direct CG contraction; neither defect is in the pinned coefficient implementation.
4. Describe AAB as reporting interval-certified existence. The printed decimals and this review are not a fresh root-isolation certificate.

The next justified action is to retain this complete candidate and incorporate these attribution/presentation corrections into the release version, preserving the frozen proof and certificate identities. Publication decisions remain with the coordinator and user; this review neither publishes nor changes catalog status. Its independence is fresh context, separate derivations and separate controls within the same model family. No external expert review or formal proof-assistant check is claimed. Actual token and cost telemetry was not returned and remains unknown.
