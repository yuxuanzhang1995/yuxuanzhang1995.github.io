# One ebit is necessary and sufficient for the elegant joint measurement

Yuxuan Zhang · 9 November 2026 · Version 1.0

This package accompanies the six-page manuscript `main.tex`. The theorem
answers the exact deterministic LOCC cost question for the two-qubit
tetrahedral elegant joint measurement, with shared classical output and
arbitrary finite-dimensional pure shared resources. The cost is the entropy
of all supplied shared entanglement, in bits. It is exactly one ebit, attained
by a Bell pair and teleportation. An entropy-one admissible resource must
have the nonzero Schmidt probabilities (1/2, 1/2).

The proof is analytic. The programs check its algebraic ingredients and
physical controls; passing the programs is not a computer proof of the
whole theorem. Review to date is internal and by the same agent involved
in the derivation. There has been no independent expert review or formal
proof-assistant verification. AI assistance was used under the author's
direction for derivation, source comparison, computation and drafting.

## Reproduce the checks

The tested environment is Python 3.11.13 with SymPy 1.14.0. In an environment
with the dependency in `requirements.txt` installed, run:

```sh
python reproduce.py
```

The runner verifies every file listed in `MANIFEST.json`, copies the three
checkers to a fresh temporary directory, and compares their complete JSON
results against the frozen expected results. It does not modify the package
or request network access. This is a fresh-directory replay, not a claim of
operating-system-enforced network isolation. Do not use Python's `-O` flag:
the scientific checkers use assertions, and the runner rejects that mode.

Expected results:

- 37 exact detector checks, including its Schmidt spectrum and all four
  reference-state contractions; two negative controls are rejected.
- 90 exact tail-identity and physical-protocol checks. The physical control
  uses resource probabilities (1/2, 1/3, 1/6), Bell-pair concentration, and
  teleportation. Its full product POVM resolves the 36-dimensional identity.
- A separate standard-library implementation verifies the cleared-denominator
  adjugate identity coefficientwise in 15 formal variables. The residual is
  zero, and changing the signed block gives a nonzero residual. This is a
  different implementation by the same agent, not independent review.

The tail checker retains two diagnostic labels from development. Its
`PPT_is_not_SEP_detected` field evaluates only the rational triple
(144,81,1)/226 against the necessary tail inequality; it does **not** certify
that triple's PPT feasibility. Neither the theorem nor the proof uses a PPT
feasibility claim. The 16 zero-contraction terms in the physical control
have zero values of both contracted norms, but contribute POVM trace 12.
Their omission is detected through failed completeness, not those norms.

To compile the paper with a standard TeX installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The public PDF was also compiled with the Codex built-in LaTeX editor and
all six pages were visually inspected. PDF byte identity across TeX builds
is not asserted; timestamps and TeX distributions can change PDF metadata.

## Contents and provenance

- `main.tex`: complete statement, proof and references.
- `checks/`: the three original exact-arithmetic programs, unchanged.
- `expected/`: their frozen full JSON outputs.
- `original-question.json`: the pinned public QIQC Open Problems catalogue
  record, whose historical status describes the catalogue at capture time.
- `REVIEW.md`: scope mapping, proof audit and remaining review limits.
- `SOURCE-COMPARISON.md`: comparison with the closest primary sources.
- `MANIFEST.json`: SHA-256 integrity manifest, excluding itself.

Original problem: <https://qiqc-op.com/problem/op_d40d1f65b5aaaefd/>.
This release reports a complete proof candidate with internal review. Website
publication does not imply journal review, catalogue acceptance, or an
arXiv submission. The source comparison supports a new higher-rank result
relative to the inspected papers; it is not an exhaustive priority survey.
