The error prefactor for sequential discrimination of trine states
Yuxuan Zhang, version 1.0, 5 November 2026

Compile trine-error-prefactor-v1.tex twice with pdfLaTeX, or use latexmk -pdf.
Run python3 -I check_prefactor.py with Python 3.9 or later. The checker uses
only the standard library. Compare its output with checks.json.

The checker tests the posterior formula for physical first-copy effects and
the counting identity in the binary-decision proof of Montanaro's pure-state
bound. For 2 through 128 copies it independently groups binomial weights
by Hamming weight modulo three and compares the resulting Fourier measurement
with the real-Gram collective formula. Square roots are enclosed by exact
dyadic rationals. The mathematical proof covers all copy counts and all
POVMs. The finite checks illustrate and test its formulas.

The manuscript answers the error-ratio formulation of individual measurement
on geometrically uniform states. It uses existing results on fidelity,
binary discrimination and the collective square-root measurement. The note
has received an AI-assisted internal review. Independent expert review and
worldwide priority remain open.
