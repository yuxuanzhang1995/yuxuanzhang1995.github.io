"""Exhaust all three-switch incidence patterns on three retained vertices."""
from itertools import combinations, product
import json


def toggle(graph, a, b):
    edge = tuple(sorted((a, b)))
    graph.symmetric_difference_update({edge})


def complement(graph, vertex):
    neighbors = [b if a == vertex else a for a, b in graph if vertex in (a, b)]
    for a, b in combinations(neighbors, 2):
        toggle(graph, a, b)


def clique(mask):
    return {edge for edge in combinations(range(3), 2)
            if all(mask & (1 << vertex) for vertex in edge)}


def run():
    cases = caught = 0
    for masks in product(range(8), repeat=3):
        for select in range(8):
            graph = {(3, i + 4) for i in range(3)}
            for i, mask in enumerate(masks):
                graph.update((j, i + 4) for j in range(3) if mask & (1 << j))
            predicted, hub_mask = set(), 0
            for i, mask in enumerate(masks):
                if select & (1 << i):
                    complement(graph, i + 4)
                    predicted ^= clique(mask)
                    hub_mask ^= mask
            graph = {edge for edge in graph if max(edge) < 4}
            mutated = {edge for edge in graph if 3 not in edge}
            complement(graph, 3)
            graph = {edge for edge in graph if 3 not in edge}
            predicted ^= clique(hub_mask)
            assert graph == predicted
            caught += mutated != predicted
            cases += 1
    assert caught > 0
    return {"bank_graphs_and_selections": cases, "missing_hub_step_detected": caught}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
