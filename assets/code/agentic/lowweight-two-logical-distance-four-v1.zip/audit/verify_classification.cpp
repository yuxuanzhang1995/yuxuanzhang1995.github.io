// Second implementation: Gray-code words, Cayley-ball BFS, Walsh counts.
// Same-agent cross-check, not independent scientific review.
#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stdexcept>
using namespace std;
int weight(unsigned a){return __builtin_popcount(a);}
int rank_of(vector<unsigned> a){
 int r=0;
 for(int b=15;b>=0;b--){
  size_t j=r;while(j<a.size()&&!(a[j]&(1u<<b)))j++;
  if(j==a.size())continue;swap(a[r],a[j]);
  for(size_t k=r+1;k<a.size();k++)if(a[k]&(1u<<b))a[k]^=a[r];r++;
 }
 return r;
}
vector<string> fields(string s,char delim){vector<string> v;istringstream in(s);while(getline(in,s,delim))v.push_back(s);return v;}
int main(int argc,char**argv){
 if(argc!=5)return 2;int n=stoi(argv[1]),cap=stoi(argv[2]);unsigned M=1u<<n;int need=n-2;
 if(n<2||n>12)throw runtime_error("unsupported n");ifstream file(argv[3]);if(!file)throw runtime_error("missing input");
 long rows=0,prune_short=0,prune_low=0,planes=0,cardinality_survivors=0;int best_rank=0,max_count=0;bool found=false;string line;long witness_row=-1;
 while(getline(file,line)){
  auto f=fields(line,'\t');if(f.size()!=5)throw runtime_error("bad row");string code=f[1];if(int(code[0])-63!=n)throw runtime_error("bad graph order");
  vector<unsigned> neighbors(n);for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(i!=j){int hi=max(i,j),lo=min(i,j),b=hi*(hi-1)/2+lo;if((int(code[1+b/6])-63)&(32>>(b%6)))neighbors[i]|=1u<<j;}
  vector<int> distribution(n+1),walsh(M);vector<unsigned> low,shortwords;unsigned prev=0,z=0;
  for(unsigned a=0;a<M;a++){
   unsigned t=a^(a>>1);if(a)z^=neighbors[__builtin_ctz(t^prev)];prev=t;int w=weight(t|z);distribution[w]++;
   if(t&&w<=cap){low.push_back(t);walsh[t]=1;}if(t&&w<=3)shortwords.push_back(t);
  }
  auto expected=fields(f[2],',');if(expected.size()!=distribution.size())throw runtime_error("bad enumerator size");for(int j=0;j<=n;j++)if(stoi(expected[j])!=distribution[j])throw runtime_error("enumerator mismatch");rows++;
  if(rank_of(shortwords)>need){prune_short++;continue;}if(rank_of(low)<need){prune_low++;continue;}
  // Cayley graph with all one-site Pauli syndromes: path distance <=3 equals
  // minimum physical error weight <=3 even if a path visits a site twice.
  vector<unsigned> edges;for(int j=0;j<n;j++){edges.push_back(1u<<j);edges.push_back(neighbors[j]);edges.push_back((1u<<j)^neighbors[j]);}
  sort(edges.begin(),edges.end());edges.erase(unique(edges.begin(),edges.end()),edges.end());
  vector<unsigned char> dist(M,4);vector<unsigned> queue(M);unsigned head=0,tail=1;queue[0]=0;dist[0]=0;
  while(head<tail){unsigned s=queue[head++];if(dist[s]==3)continue;for(auto e:edges){unsigned v=s^e;if(dist[v]==4){dist[v]=dist[s]+1;queue[tail++]=v;}}}
  vector<unsigned> holes;vector<bool> good(M);for(unsigned u=1;u<M;u++)if(dist[u]==4){bool yes=true;for(auto t:shortwords)if(weight(t&u)%2){yes=false;break;}if(yes){holes.push_back(u);good[u]=true;}}
  if(holes.size()<3)continue;
  for(unsigned step=1;step<M;step*=2)for(unsigned base=0;base<M;base+=2*step)for(unsigned j=0;j<step;j++){int x=walsh[base+j],y=walsh[base+j+step];walsh[base+j]=x+y;walsh[base+j+step]=x-y;}
  for(auto u:holes)for(auto v:holes){unsigned w=u^v;if(!(u<v&&v<w)||!good[w])continue;planes++;
   int four=walsh[0]+walsh[u]+walsh[v]+walsh[w];if(four%4||four<0)throw runtime_error("invalid character count");int count=four/4;max_count=max(count,max_count);if(count<need)continue;cardinality_survivors++;
   vector<unsigned> restricted;for(auto t:low)if(weight(t&u)%2==0&&weight(t&v)%2==0)restricted.push_back(t);if(int(restricted.size())!=count)throw runtime_error("count discrepancy");int r=rank_of(restricted);best_rank=max(r,best_rank);
   if(r==need){found=true;witness_row=stol(f[0]);goto end;}
  }
 }
 end:
 bool exhausted=!found&&file.eof();ofstream out(argv[4]);
 out<<"{\"n\":"<<n<<",\"cap\":"<<cap<<",\"rows\":"<<rows<<",\"short_rank_pruned\":"<<prune_short<<",\"low_rank_pruned\":"<<prune_low<<",\"planes\":"<<planes<<",\"max_low_word_count\":"<<max_count<<",\"cardinality_survivors\":"<<cardinality_survivors<<",\"best_rank_among_survivors\":"<<best_rank<<",\"found\":"<<(found?"true":"false")<<",\"source_exhausted\":"<<(exhausted?"true":"false")<<",\"witness_source_row\":"<<witness_row<<"}\n";
 cout<<"rows="<<rows<<" planes="<<planes<<" found="<<found<<" exhausted="<<exhausted<<"\n";
}
