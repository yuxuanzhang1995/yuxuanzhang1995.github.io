from pathlib import Path
from decimal import ROUND_FLOOR,ROUND_CEILING
import collections,itertools,json,time,numpy as np
from p11_rational_quantum_certificate_common import I,D,q,p,bath,E
S=2**40
def lo(x,scale=S):return int((x*scale).a.to_integral_value(rounding=ROUND_FLOOR))
def hi(x,scale=S):return int((x*scale).b.to_integral_value(rounding=ROUND_CEILING))
def poly(c,basis):return sum(int(v)*a for v,a in zip(c,basis))
if __name__=='__main__':
 start=time.time();data=json.loads(Path('run/checks/r125_first_stage.result.json').read_text());store=np.load('run/checks/r125_first_stage_states.npz');screen=np.load('run/checks/r129_second_recharge_screen.npz');y=[I(str(x)) for x in json.loads(Path('run/checks/r127_suffix_diagnostics.result.json').read_text())['price']];P=np.array(list(itertools.permutations(range(6))));Zs=1+q+q*q;Zsm=Zs*(1+q);basis=[q**k/(Zsm*Zs) for k in range(6)];bl=[lo(a) for a in basis];bh=[hi(a) for a in basis];bb=[a*b for a in bath for b in bath];bbl=[lo(a) for a in bb];bbh=[hi(a) for a in bb];eb=sum(r*bath[r] for r in range(3));yp=sum(a*b for a,b in zip(y,p));costcoef=[]
 for rec in data['profiles']:
  w=[0]*4
  for i,e in enumerate(E):w[rec['profile'][i]]+=e;w[e]-=e
  costcoef.append(np.convolve(w,[1,1,1]).astype(int))
 cached={};bounds=[];survivors=[];groups=collections.defaultdict(list)
 for ri,ix0 in enumerate(screen['representatives']):
  ix=int(ix0);parent=store['coefficients'][ix].astype(int);pid=int(store['profile_ids'][ix]);c=costcoef[pid]
  for k,perm in enumerate(P):
   arr=parent[perm];wc=np.array(E)@(arr-parent);w=poly(wc,basis)
   if not np.any(wc) or w.b<0:paid=c.copy()
   else:assert w.a>0;paid=c+wc
   cost=poly(paid,basis);ls=str(screen['lambdas'][ri,k])
   if ls not in cached:
    z=I(ls);assert 0<=z.a<=z.b<=1;obs=sorted(hi(y[s]-z*(E[s]+r+t)) for s in range(6) for r in range(3) for t in range(3));cached[ls]=(obs,hi(z),2*z*eb-yp)
   obs,lh,constant=cached[ls];rl=[sum(int(v)*x for v,x in zip(row,bl)) for row in arr];rh=[sum(int(v)*x for v,x in zip(row,bh)) for row in arr];sl=sorted(a*b//S for a in rl for b in bbl);sh=sorted((a*b+S-1)//S for a in rh for b in bbh);num=sum((b if h>=0 else a)*h for a,b,h in zip(sl,sh,obs))+lh*sum(e*r for e,r in zip(E,rh))+hi(constant-cost,S*S);bounds.append(str(num))
   if num>=0:
    rows=[tuple(row) for row in arr];key=tuple(rows[:1]+sorted(rows[1:3])+sorted(rows[3:5])+rows[5:]);record=dict(parent_state=ix,permutation_index=k,profile_id=pid,N=arr,paid=paid,cost=cost);groups[key].append(len(survivors));survivors.append(record)
 frontier=[];mapping=[]
 for ids in groups.values():
  j=min(ids,key=lambda i:survivors[i]['cost'].a);r=survivors[j]
  for i in ids:
   diff=r['paid']-survivors[i]['paid'];assert not np.any(diff) or poly(diff,basis).b<0
   sources=collections.defaultdict(list)
   for a,row in enumerate(r['N']):sources[(E[a],tuple(row))].append(a)
   W=[-1]*6
   for dest,row in enumerate(survivors[i]['N']):W[sources[(E[dest],tuple(row))].pop()]=dest
   assert all(E[a]==E[W[a]] for a in range(6));mapping.append(dict(parent_state=survivors[i]['parent_state'],permutation_index=survivors[i]['permutation_index'],frontier=len(frontier),input_energy_permutation=W))
  ix=r['parent_state'];k=r['permutation_index'];frontier.append(dict(id=len(frontier),parent_state=ix,permutation_index=k,first=dict(V=data['profiles'][r['profile_id']]['V'],U=store['collisions'][ix].astype(int).tolist()),V2=np.argsort(P[k]).tolist(),post_V2_coefficients=r['N'].tolist(),paid_work_coefficients=r['paid'].tolist(),paid_work_interval=r['cost'].pair()))
 np.savez_compressed('run/checks/r130_second_recharge_bounds.npz',upper_numerators=np.array(bounds),representatives=screen['representatives']);neg=[int(v) for v in bounds if int(v)<0];out=dict(scale=S,total_choices=len(bounds),certified_negative=len(neg),largest_negative_upper_numerator=max(neg),surviving_choices=len(survivors),frontier_count=len(frontier),frontier=frontier,symmetry_mapping=mapping,seconds=time.time()-start,scope='all possible population violations reduce to these88 post-second-recharge frontier states with certified paid cost; U2,V3,U3 remain universally unresolved');Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['frontier','symmetry_mapping']},indent=2))
