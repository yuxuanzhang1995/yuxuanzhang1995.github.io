import json
from pathlib import Path
import mpmath as mp

mp.mp.dps=110
BITS=250
tol=mp.mpf(2)**(-BITS)

def li2_reduced(y):
    if y==0:return mp.mpf(0)
    if y==1:return mp.pi**2/6
    if y>mp.mpf('0.5'):
        return mp.pi**2/6-mp.log(y)*mp.log1p(-y)-li2_reduced(1-y)
    term=y;out=mp.mpf(0)
    for k in range(1,BITS+10):
        out+=term/(k*k);term*=y
    return out

def survival(x):
    q=mp.exp(-2*mp.pi*x)
    return 8/mp.pi**2*(li2_reduced(q)-li2_reduced(q*q)/4)

def cdf(x):return 1-survival(x)

for y in [mp.mpf(0),mp.mpf(2)**-80,mp.mpf('0.1'),mp.mpf('0.5'),mp.mpf('0.9'),1-mp.mpf(2)**-100,mp.mpf(1)]:
    assert abs(li2_reduced(y)-mp.polylog(2,y))<tol
for x in [mp.mpf(2)**-70,mp.mpf('0.001'),mp.mpf('0.1'),mp.mpf(1),mp.mpf(5)]:
    assert 0<survival(x)<mp.exp(-2*mp.pi*x)
    derivative=mp.diff(lambda v: 1-(8/mp.pi**2)*(mp.polylog(2,mp.exp(-2*mp.pi*v))-mp.polylog(2,mp.exp(-4*mp.pi*v))/4),x)
    density=8/mp.pi*mp.log(mp.coth(mp.pi*x))
    assert abs(derivative-density)<mp.mpf('1e-75')

eps=mp.mpf(2)**-7;K=12;T=mp.mpf(K)
assert K>=mp.log(32/eps)
assert survival(T)<=eps/32
lam_min=16/mp.pi*mp.exp(-2*mp.pi*K)
rows=[]
for exponent in [0,20,80]:
    alpha=mp.mpf(2)**exponent
    need=64*(1+alpha)*T/eps
    n=int(mp.ceil(mp.log(need,2)));Q=1<<n
    eta=eps/(64*(1+alpha))
    assert 2*alpha*T/Q<=eps/32
    assert tol<lam_min*eta/16
    for j in [0,Q//3,Q//2,Q-1]:
        u=(mp.mpf(j)+mp.mpf('0.5'))/Q
        lo=mp.mpf(0);hi=T
        for _ in range(n+30):
            mid=(lo+hi)/2
            if cdf(mid)<u:lo=mid
            else:hi=mid
        x=(lo+hi)/2
        assert hi-lo<eta/4
        # Independent reference CDF evaluates the same quantile bracket.
        def ref(v):
            q=mp.exp(-2*mp.pi*v)
            return 1-(8/mp.pi**2)*(mp.polylog(2,q)-mp.polylog(2,q*q)/4)
        assert ref(max(mp.mpf(0),x-eta))<=u<=ref(min(T,x+eta))
    rows.append({'onsite_bound_power_of_two':exponent,'grid_nodes':str(Q),'grid_register_qubits':n,
                 'quantiles_checked':4,'time_precision_bits_upper':int(mp.ceil(-mp.log(eta,2)))+2})

# The capped law includes its atom rather than discarding it.
u=1-mp.mpf(2)**-180
assert u>cdf(T)

# Kernel Fourier convention: positive Laplace mixture matches tanh(beta*w/4)/(beta*w/4).
mix_rows=[];count=256
tail_bound=mp.mpf(8)/(mp.pi**2*count)
for w in [mp.mpf('0.5'),mp.mpf(4),mp.mpf(32)]:
    mix=sum((8/(mp.pi**2*(2*k+1)**2))*((2*mp.pi*(2*k+1))**2/((2*mp.pi*(2*k+1))**2+w*w)) for k in range(count))
    expected=mp.tanh(w/4)/(w/4)
    assert 0<expected-mix<tail_bound
    mix_rows.append({'frequency':str(w),'truncated_mixture_residual':str(expected-mix),'tail_upper':str(tail_bound)})

result={'status':'PASS','kind':'High-precision implementation diagnostics, not a compiled quantum circuit or formal interval proof',
        'decimal_precision':mp.mp.dps,'own_dilog_series_bits':BITS,
        'diagnostics':['Dilog range reduction against independent polylog','CDF density and survival bound','Twelve inverse-CDF bracket controls','Retained capped-tail atom','Half-temperature Fourier convention'],
        'large_frequency_register_controls':rows,'fourier_controls':mix_rows,
        'negative_control':'Enumerated quadrature requires the displayed Q nodes; coherent uniform register uses only n qubits and reversible quantile evaluation.',
        'scope':'One interacting QBP coefficient encoding; full original Gibbs implementation remains open.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='fourier_controls'},indent=2))
