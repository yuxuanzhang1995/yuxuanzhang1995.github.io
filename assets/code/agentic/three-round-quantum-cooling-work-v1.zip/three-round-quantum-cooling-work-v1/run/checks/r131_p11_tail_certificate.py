"""Directed, exhaustive final-recharge/block-sort bounds for every survivor."""
from pathlib import Path
import json,time
import numpy as np
from r131_p11_complete_suffix import S,lo,hi,poly,BASISI,OLDI,YI,P6,E,blocks,pi,bi

def certify(N,paid):
    rl=N.astype(np.int64)@np.array([lo(a) for a in BASISI],dtype=np.int64)
    rh=N.astype(np.int64)@np.array([hi(a) for a in BASISI],dtype=np.int64)
    bil=np.array([lo(a) for a in bi],dtype=np.int64)
    bih=np.array([hi(a) for a in bi],dtype=np.int64)
    reward=[np.array(sorted(hi(YI[int(i)//3]) for i in B),dtype=np.int64) for B in blocks]
    assert all(np.min(a)>=0 for a in reward)
    constant=lo(paid+sum(y*p for y,p in zip(YI,pi)),S*S)
    upper=[];worst=[]
    for start in range(0,len(N),32):
        lower=rl[start:start+32];higher=rh[start:start+32]
        rlo=lower[:,P6];rhi=higher[:,P6]
        xhi=((rhi[:,:,:,None]*bih+S-1)//S).reshape(len(lower),720,18)
        val=np.zeros((len(lower),720),dtype=np.int64)
        for B,r in zip(blocks,reward):val+=np.sort(xhi[:,:,B],axis=2)@r
        # Lower bound the signed work before taking its positive part.
        worklo=np.maximum(0,rlo@np.array(E,dtype=np.int64)-(higher@np.array(E,dtype=np.int64))[:,None])
        val-=worklo*S+constant
        worst.extend(np.argmax(val,axis=1).tolist());upper.extend(val.max(axis=1).tolist())
    return np.array(upper,dtype=np.int64),np.array(worst,dtype=np.int16)

if __name__=='__main__':
    start=time.time();frontiers=json.loads(Path('run/checks/r130_p11_frontier.result.json').read_text())['frontier']
    records=[];all_states=0
    for f in frontiers:
        tag=f"run/checks/r131_p11_frontier_{f['id']:02d}"
        data=np.load(tag+'.npz');survivors=data['survivors'];all_states+=len(data['coefficients'])
        if len(survivors):
            upper,worst=certify(data['coefficients'][survivors],poly(f['paid_work_coefficients'],OLDI))
            assert np.all(upper<0),(f['id'],int(upper.max()))
            assert np.all(upper.astype(float)/S**2>=data['tail_maxima']-1e-12)
            np.savez_compressed(tag+'.tail-certificate.npz',states=survivors,upper_numerators=upper,worst_permutation=worst)
            records.append(dict(frontier=f['id'],states=len(survivors),recharges=len(survivors)*720,
                maximum_upper_numerator=int(upper.max()),maximum_upper=float(upper.max()/S**2)))
        assert len(survivors)==int((data['upper_numerators']>=0).sum())
    out=dict(scale=S,frontier_count=len(frontiers),post_U2_states=all_states,
        exact_tail_states=sum(r['states'] for r in records),
        exact_tail_recharges=sum(r['recharges'] for r in records),
        worst_exact_tail_upper=max(r['maximum_upper'] for r in records),
        remaining_unclosed_states=0,records=records,seconds=time.time()-start,
        scope='All88 frontier suffixes certified strictly negative; same-agent computational certificate, inherited prefix reductions must also hold')
    Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='records'}),flush=True)
