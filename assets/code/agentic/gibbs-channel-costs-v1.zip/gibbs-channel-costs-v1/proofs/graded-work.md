# The computability degree of all-error sharp work

Consider the sharp battery and normal Gibbs baths with finite partition function, using fixed \(\beta>0\). Measure work by \(w=\beta W\). System Boltzmann weights \(a_i=e^{-\beta e_i}, b_j=e^{-\beta f_j}\), target Choi entries and the permitted channel error are real algebraic, or have algebraic real and imaginary parts as applicable. Supply consistent integer coordinates of system energies in their finitely generated additive group. This includes rationally specified \(H=0\) channels. The finite-dilation variational identity is the earlier internal physical theorem. Subject to that interface, every strict upper cut \(\exp(w_\epsilon)<Q\), \(Q\) positive rational, has a uniform recursively enumerable finite certificate. This holds at zero channel error and at equality with the minimum covariant-channel error.

On instances of finite work the associated value oracle, allowing arbitrary additive accuracy, has exactly the Turing degree of the halting problem uniformly over dimensions. The upper reduction is proved below; the reverse is the F20 game reduction already obtained for \(H=0\). For full-rank rational unital targets the reverse works at channel error zero alone, and separately using positive dyadic errors tending to zero. This is a mathematical complexity characterization. A certified upper bound by itself does not tell an ordinary computation when it is near optimal.

## Removing the continuum of bath and environment energies from a certificate

The [earlier all-error identity](work-variational-review-v5.md) gives the work infimum as the infimum, over finite Gibbs isometries implementing a channel in the closed error ball, of
\[
 \sup_{t\ge1}\frac{1}{t}\log
 \frac{\big(\sum_j b_j^t\big)\big(\sum_\gamma v_\gamma^t\big)}
      {\big(\sum_i a_i^t\big)\big(\sum_\alpha u_\alpha^t\big)} .
\]
Here \(u_\alpha,v_\gamma>0\) are Boltzmann weights of the input and output logical environments. We use a common energy shift to normalize \(\sum_\alpha u_\alpha=1\), and absorb the logical isometry shift in the final environment energies. These changes preserve the full index. Logical Gibbs registers and the physical implementation consuming sharp work are related by the cited theorem.

Enumerate finite templates of input labels \(\alpha\), output labels \(\gamma\), connected-component labels \(c\), and integer energy vectors \(n_\alpha,n_\gamma\). Within a component set
\[
 u_\alpha=\lambda_c d_\alpha,\qquad v_\gamma=\lambda_c d_\gamma,
\]
where each \(\lambda_c>0\) is a real variable. The relative weights \(d\) can be chosen as products of system transition Boltzmann ratios and their inverses. One can simply enumerate walks in the finite list of system transitions, recording both the integer displacement and its algebraic Boltzmann weight, to avoid any assumption about an algebraic weight for an independently supplied lattice basis vector. Only permit entries \(V_{j\gamma,i\alpha}\) within the same component and with the exact energy balance \(f_j+n_\gamma=e_i+n_\alpha\) in integer coordinates. Allow repeated labels and coincident numerical energies.

Every actual finite isometry has such a template. Make the bipartite graph of input and output ancillary basis vectors, with edges for its nonzero matrix elements labelled by the input/output system transition. Along any walk the ancillary energy differences are sums of those transitions. One base energy remains free per component. Unused output auxiliary vectors can be discarded; removing them only decreases the index. Conversely a template, positive component weights and any isometry respecting its zero entries define a valid shift-zero Gibbs dilation. Extra accidental degeneracies create no required nonzero entries.

Within one template \(V^*V=I\), \(\sum_\alpha u_\alpha=1\), and the Choi matrix of the implemented channel are polynomial constraints. For example its unnormalized Choi entry is \(\sum_{\alpha,\gamma}u_\alpha V_{j\gamma,i\alpha}\overline{V_{j'\gamma,i'\alpha}}\). The closed channel-fidelity inequality is also semialgebraic. One may use the [finite block-Choi fidelity test](q117-program-proof-v2.md) or quantify over reference-extended inputs and PSD square roots at fixed finite dimension. Consequently exact error zero and error equal to the distance to the covariant set need no perturbations of the target or the admissible face.

## Uniform finite inverse-temperature mesh

List the positive numbers \(A=(a_i u_\alpha)_{i,\alpha}\), \(B=(b_j v_\gamma)_{j,\gamma}\), of lengths \(m,n\). Put \(s=1/t\in[0,1]\). The log ratio is
\[
 F(s)=s\log\sum_k B_k^{1/s}-s\log\sum_l A_l^{1/s},
 \qquad F(0)=\log(\max B/\max A).
\]
For a positive list \(X\), the derivative of \(s\log\sum X_k^{1/s}\) equals the Shannon entropy of the normalized weights \(X_k^{1/s}\). It is between zero and \(\log |X|\). The limiting endpoint follows directly by dividing by the largest entry. Thus \(F\) is Lipschitz on the entire closed interval with constant at most \(\log(mn)\), uniformly in all auxiliary energies, their multiplicities and the \(\lambda_c\). This bound also covers lists of length one.

For a positive integer \(N\), test feasibility of the template and, at each grid point \(s=l/N\) including zero, impose
\[
 e^{F(s)}(mn)^{1/N}<Q.
\]
At rational \(s>0\), all powers and divisions on positive variables are semialgebraic using positive roots. At \(s=0\) use the finite maxima. This is a single finite real quantifier elimination query, including for the unknown component weights. A positive answer implies the supremum is strictly below \(\log Q\), by the uniform modulus and the finite number of grid points. Conversely any finite isometry with index strictly below \(\log Q\) passes all these inequalities once \(N\) is large. A dovetailed enumeration over grids and templates therefore accepts exactly the strict upper cut on the stated input class.

Finiteness of work in this model follows from the existence of a covariant channel in the closed error ball. Covariance is linear in fixed energy labels, and the set of CPTP channels is compact, so this is a finite semialgebraic decision. Covariant channels have a finite logical Stinespring dilation and finite index. Outside this ball every sharp-battery implementation is covariant and approximation at the prescribed error is impossible.

## Quantifiers in the complexity result

For finite work, wait for any upper bound and then use a halting oracle to answer whether the enumeration for each tested rational \(Q\) ever accepts. Bisection computes \(e^{w_\epsilon}\) to arbitrary accuracy, and logarithm gives \(w_\epsilon\). The lower certificate \(e^{w_\epsilon}\ge Q\) in this complexity description is a nonhalting answer, not an ordinary effective stopping certificate. The argument applies with arbitrary system spectra in the stated exact encoding.

In the reverse direction the [F20 proof](work-computability.md) constructs an oracle computation: from a machine it constructs a finite-game Choi section, and uses successively finer approximations of work values on rational full-rank bistochastic targets to compute Hausdorff nets of the free channel closure. Disjointness from one sufficiently fine union of balls eventually certifies every nonhalting instance; direct simulation finds every halting one. This is a Turing reduction, even though there need not be a computable bound on the precision it will query for an individual game. It gives no fixed positive-error or fixed-accuracy theorem. [Goldbring–Hart, Theorem 3.4](https://www.math.uci.edu/~isaac/universaltheoryofR.pdf).

The countable-bath convention is essential for the operational theorem being used. A full bath-dependent catalog answer or an ordinary two-sided numerical algorithm does not follow. The new part relative to F20 is the converse computability bound for arbitrary nonzero system spectra in the encoding and every closed error condition, with finite algebraic upper certificates and a uniform control of all inverse temperatures.
