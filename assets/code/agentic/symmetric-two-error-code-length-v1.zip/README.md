# Symmetric quantum codes correcting two errors

Yuxuan Zhang — version 1.0 — 10 November 2026.

The manuscript proves a computer-assisted lower bound of nineteen physical
qubits for a two-dimensional code inside the fully symmetric subspace that
corrects arbitrary two-qubit errors. The published nineteen-qubit
construction supplies the matching upper bound. Complex Dicke coefficients,
both length parities and degenerate codes are included.

The new decisive exclusion is eighteen qubits. Earlier scalar bounds,
especially Okada's Table 3.1, are credited in the manuscript and review.
The ten certificates from n=9 to n=18 provide a self-contained finite
exclusion. Lengths at most eight follow from the Singleton bound.

## Reproduce the exact certificates

Use Python 3.10 or later in an environment with the packages in
requirements.txt already installed. Then run:

~~~sh
python reproduce.py
~~~

The runner checks MANIFEST.json, copies the three coefficient/checker
modules and ten certificates into an initially empty temporary directory,
and regenerates all rational coefficients. It prohibits coefficient pickle
loads, optimizer imports and network connections during the certificate
checks. No optimizer or coefficient cache is supplied.

The expected exact outputs are in expected/certificates.json. Each length
must pass its dual identity, nonnegative scalar multipliers, positive
rational LDL pivots and negative Farkas right-hand side. Floating displays
and timings are not part of the exact comparison.

This runner verifies the finite certificate calculations. The proof that
every admissible quantum code satisfies the relaxation is in main.tex
and the accompanying PDF. Replaying the certificates alone does not
establish that analytic step.

## Contents and provenance

- main.tex: public manuscript source.
- candidate-reviewed.md: unchanged original argument supplied to the
  independent reviewer, before editorial and literature corrections.
- original-question.json: pinned public catalogue statement.
- checks/: unchanged exact coefficient generators and ten certificates.
- expected/: complete expected exact certificate results.
- review/: independent model review, primary-source comparison, input
  hashes and additional analytic-control results.

The independent review used a separate model context and withheld the
previous author's self-review conclusions. It included analytic derivation,
primary-source reading, fresh Clebsch–Gordan calculations, complex-projector
controls and a known twenty-one-qubit distance-five code. It is not external
expert review or proof-assistant verification.

The nineteen-qubit upper bound is taken from Aydin–Alekseyev–Barg (2024);
this package does not independently certify that construction.

The original candidate is preserved for traceability. The public manuscript
corrects the description of the direct Clebsch–Gordan contraction, clarifies
the seed inclusion map, and adds earlier scalar bounds and their attribution.
These changes do not alter the rational exclusion systems or certificates.
