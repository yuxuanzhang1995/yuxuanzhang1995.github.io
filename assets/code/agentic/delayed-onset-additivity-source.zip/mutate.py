#!/usr/bin/env python3
"""Mutation test for check_delayed_onset.py (standard library only).

Each mutant is ONE single-point edit of the checker: a code token or constant (the old text must occur exactly
once), or one value of the embedded certificate data changed and re-packed, or one base64 character flipped.
Every mutant must exit nonzero.  Mutants run from memory (source piped to the interpreter on stdin), so the only
file written is MUTATION_REPORT.txt.  Certificate data are never printed.  Exit status 1 if any mutant survives
or the unmutated checker does not reproduce expected_stdout.txt.
"""
import base64, subprocess, sys, zlib
from array import array
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = (HERE / "check_delayed_onset.py").read_text()
EXPECTED = (HERE / "expected_stdout.txt").read_text()

def blob(name):
    pre = name + ' = "'
    line = next(l for l in SRC.splitlines() if l.startswith(pre))
    return line[len(pre):-1]
def zigzag(vals):
    out = bytearray()
    for x in vals:
        z = 2*x if x >= 0 else -2*x - 1
        while z >= 128: out.append((z & 127) | 128); z >>= 7
        out.append(z)
    return bytes(out)
def unzigzag(raw):
    vals, v, sh = [], 0, 0
    for byte in raw:
        v |= (byte & 127) << sh; sh += 7
        if byte < 128: vals.append((v >> 1) ^ -(v & 1)); v = sh = 0
    return vals
def repack_R(idx, delta):
    arr = array("q"); arr.frombytes(zlib.decompress(base64.b64decode(blob("DATA_R"))))
    if sys.byteorder != "little": arr.byteswap()
    arr[idx] += delta
    if sys.byteorder != "little": arr.byteswap()
    return SRC.replace(blob("DATA_R"), base64.b64encode(zlib.compress(arr.tobytes(), 9)).decode())
def repack_G(idx, delta):
    vals = unzigzag(zlib.decompress(base64.b64decode(blob("DATA_G"))))
    vals[idx] += delta
    return SRC.replace(blob("DATA_G"), base64.b64encode(zlib.compress(zigzag(vals), 9)).decode())
def flip_b64(name, pos):
    b = blob(name); c = "B" if b[pos] == "A" else "A"
    return SRC.replace(b, b[:pos] + c + b[pos + 1:]), "%s base64 character at offset %d changed to '%s'" % (name, pos, c)
def bisect_max(pred, lo, hi):  # largest x in [lo, hi) with pred(x); pred monotone, pred(lo) true
    while hi - lo > 1:
        mid = (lo + hi)//2
        lo, hi = (mid, hi) if pred(mid) else (lo, mid)
    return lo
def tau_fresh(eps):  # one-line edit: explicit tau with another eps AND a freshly computed, valid root certificate
    sc = 10**6
    rc = bisect_max(lambda c: c**1000*(1 << eps) <= ((1 << eps) - 1)*sc**1000, 0, sc + 1)
    rd = bisect_max(lambda d: d**1000*(2 << eps) <= sc**1000, 0, sc + 1)
    old = next(l for l in SRC.splitlines() if l.startswith("EPS_LOG2 = ")).split(" TW = ")[0]
    new = "EPS_LOG2 = %d; RC = %d; RD = %d;" % (eps, rc, rd)
    return text(old, new)[0], "tau line: eps = 2^-%d with valid root brackets RC, RD recomputed for it" % eps
def text(old, new):
    assert SRC.count(old) == 1, old
    return SRC.replace(old, new), "%r -> %r" % (old, new)

MUTANTS = [
    ("certificate data corruption: one R entry", lambda: (repack_R(17*110 + 5, 1 << 31),
     "R[17][5] real part += 2^31 (= +1/2), re-packed")),
    ("certificate data corruption: one G' entry", lambda: (repack_G(100*101//2 + 37, 1 << 12),
     "G'[100][37] real part += 2^12 (= +2^-12), re-packed")),
    ("certificate data corruption: raw base64", lambda: flip_b64("DATA_G", 6000)),
    ("c0 raised to 2^-12", lambda: text("C0_LOG2 = 14 ", "C0_LOG2 = 12 ")),
    ("wrong partial-transpose factor (route a, 9-dim factor)",
     lambda: text("return Q[i*16 + j2][i2*16 + j]", "return Q[i2*16 + j][i*16 + j2]")),
    ("wrong partial-transpose factor (route b, 9-dim factor)",
     lambda: text("zip(Rr[i*16 + j2], Rc[i2*16 + j])", "zip(Rr[i2*16 + j], Rc[i*16 + j2])")),
    ("partial transpose dropped (route a)", lambda: text("return Q[i*16 + j2][i2*16 + j]", "return Q[I][J]")),
    ("missing conjugate in x = conj(y) (x) v", lambda: text("z = mul(cj(y[s][s2]), v[k][k2])", "z = mul(y[s][s2], v[k][k2])")),
    ("missing conjugate in z = u (x) conj(v)", lambda: text("mul(u[i], cj(v[j]))", "mul(u[i], v[j])")),
    ("theta_6 = 1", lambda: text("THETA_EXP = [0, 0, 0, 0, 0, 1]", "THETA_EXP = [0, 0, 0, 0, 0, 0]")),
    ("flipped sign in phi", lambda: text("PHI_D = [1, 1, -1, -1]", "PHI_D = [1, 1, -1, 1]")),
    ("p-bound: 26 -> 25 on the step-(4) side only", lambda: text("RANK3 = 26 ", "RANK3 = 25 ")),
    ("p-bound: 26 -> 25 on the three-copy side only", lambda: text("r3 = 3**3 - 1 if", "r3 = 3**3 - 2 if")),
    ("p-bound: too-large a", lambda: text("A6 = 988169", "A6 = 988170")),
    ("p-bound: too-large b", lambda: text("B6 = 999999", "B6 = 1000000")),
    ("p-bound: p = 1/1000 -> 1/100", lambda: text("P_NUM, P_DEN = 1, 1000", "P_NUM, P_DEN = 1, 100")),
    ("Gram route Frobenius comparison: < -> <=", lambda: text("return se < 1 <<", "return se <= 1 <<")),
    ("Gram route Frobenius comparison: threshold x2", lambda: text("(2*ps - 2*gam), se", "(2*ps - 2*gam + 2), se")),
    ("Bareiss pivot sign test: <= 0 -> < 0", lambda: text("pb != 0 or pa <= 0", "pb != 0 or pa < 0")),
    ("Bareiss rounding tolerance 2^-20 -> 2^-30", lambda: text("DELTA_LOG2 = 20 ", "DELTA_LOG2 = 30 ")),
    ("negative control vector G = diag(1,1,1,-1)", lambda: text("gd = [1, 1, -1, -1]", "gd = [1, 1, 1, -1]")),
    ("negative control theta not all ones", lambda: text("K1 = kraus([0]*6)", "K1 = kraus([0]*5 + [1])")),
    ("design: one pair cell moved", lambda: text("((1,3),(2,0))", "((1,3),(2,1))")),
    ("tau eps = 2^-12 (stale root bracket; the window itself still holds at this eps)",
     lambda: text("EPS_LOG2 = 20;", "EPS_LOG2 = 12;")),
    ("tau eps = 2^-8 (stale root brackets)", lambda: text("EPS_LOG2 = 20;", "EPS_LOG2 = 8;")),
    ("tau eps = 2^-8 with a fresh valid certificate (upper side genuinely broken)", lambda: tau_fresh(8)),
    ("tau eps = 2^-30 with a fresh valid certificate (lower side genuinely broken)", lambda: tau_fresh(30)),
    ("weakened root bound: d raised above 2^(-21/1000)", lambda: text("RD = 985549", "RD = 985550")),
    ("weakened root bound: upper bracket of (1-2^-20)^(1/1000) too small", lambda: text("RC = 999999", "RC = 999998")),
    ("C6d exponent (1-p)/3 -> (1-p)/2", lambda: text("fr = q/3", "fr = q/2")),
]

def run(src):
    r = subprocess.run([sys.executable, "-"], input=src, capture_output=True, text=True, cwd=HERE, timeout=900)
    fl = [l for l in r.stdout.splitlines() if l.startswith("FAIL ")]
    return r.returncode, r.stdout, fl

def main():
    code, out, fl = run(SRC)
    base_ok = code == 0 and out == EXPECTED and not fl
    lines = ["Mutation report for check_delayed_onset.py: %d single-point mutants; each must exit nonzero." % len(MUTANTS),
             "baseline (unmutated): exit %d, FAIL lines %d, stdout identical to expected_stdout.txt: %s"
             % (code, len(fl), "yes" if out == EXPECTED else "NO"), ""]
    survivors = []
    for n, (name, make) in enumerate(MUTANTS, 1):
        src, edit = make()
        assert src != SRC
        code, out, fl = run(src)
        if code == 0: survivors.append(n)
        lines += ["M%02d %s" % (n, name), "    edit: " + edit,
                  "    exit %d | FAIL lines %d | first: %s" % (code, len(fl), (fl[0][:150] if fl else "(none)"))]
    lines += ["", "summary: %d/%d mutants exit nonzero; survivors: %s" % (len(MUTANTS) - len(survivors), len(MUTANTS),
              ", ".join("M%02d" % s for s in survivors) or "none")]
    (HERE / "MUTATION_REPORT.txt").write_text("\n".join(lines) + "\n")
    print(lines[-1]); print(lines[1])
    sys.exit(0 if base_ok and not survivors else 1)

if __name__ == "__main__":
    main()
