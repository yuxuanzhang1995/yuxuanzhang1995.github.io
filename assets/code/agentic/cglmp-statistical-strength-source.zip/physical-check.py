import mpmath as m, itertools, json
from fractions import Fraction as F
m.mp.dps=90
def kron(a,b):return m.matrix(a.rows*b.rows,a.cols*b.cols,lambda i,j:a[i//b.rows,j//b.cols]*b[i%b.rows,j%b.cols])
# mpmath.matrix does not use a generator constructor; explicit entries.
def kron(a,b):return m.matrix([[a[i//b.rows,j//b.cols]*b[i%b.rows,j%b.cols] for j in range(a.cols*b.cols)]for i in range(a.rows*b.rows)])
def rot(t):return m.matrix([[m.cos(t),-m.sin(t)],[m.sin(t),m.cos(t)]])
h=m.matrix([[1,1],[1,-1]])/m.sqrt(2); a=[m.eye(2),h];b=[rot(m.pi/8),rot(-m.pi/8)]
aa=[kron(t,t) for t in a];bb=[kron(t,t) for t in b]
p={};max_unitarity=0
for t in aa+bb:max_unitarity=max(max_unitarity,max(abs(z)for z in t.H*t-m.eye(4)))
for x,y in itertools.product(range(2),repeat=2):
 amplitudes=aa[x].T*bb[y]/2
 for i,j in itertools.product(range(4),repeat=2):p[x,y,i,j]=abs(amplitudes[i,j])**2
w=(2+m.sqrt(2))/4;pk=[(1-w)**2,2*w*(1-w),w*w];physical_distribution_error=0
for x,y in itertools.product(range(2),repeat=2):
 q=[m.mpf(0)]*3
 for i,j in itertools.product(range(4),repeat=2):
  wins=sum(((i>>bit&1)^(j>>bit&1))==x*y for bit in range(2));q[wins]+=p[x,y,i,j]
 physical_distribution_error=max(physical_distribution_error,max(abs(v-t)for v,t in zip(q,pk)))
L=sum(q*m.log(f,2)for q,f in zip(pk,[m.mpf(1)/4,m.mpf(3)/4,m.mpf(5)/4]))
alpha=[0,-m.mpf(1)/2];beta=[m.mpf(1)/4,m.mpf(3)/4]
transforms=[lambda a,b:(a-b)%4,lambda a,b:(-a+b-1)%4,lambda a,b:(-a+b)%4,lambda a,b:(a-b)%4]
qc=[1/(32*m.sin(m.pi*(t+m.mpf(1)/4)/4)**2)for t in range(4)]
cglmp_born_error=0
for x,y in itertools.product(range(2),repeat=2):
 am=m.matrix([[m.exp(2j*m.pi*j*(a+alpha[x])/4)/2 for a in range(4)]for j in range(4)])
 bm=m.matrix([[m.exp(2j*m.pi*j*(-b+beta[y])/4)/2 for b in range(4)]for j in range(4)])
 physical=am.T*bm/2
 for a,b in itertools.product(range(4),repeat=2):cglmp_born_error=max(cglmp_born_error,abs(abs(physical[a,b])**2-qc[transforms[2*x+y](a,b)]/4))
local={k:F(0)for k in p}
for template,weight in [((0,0,0,3),F(4,5)),((0,0,1,2),F(1,5))]:
 tuples=list(itertools.permutations(template))
 for t in tuples:
  for shift in range(4):
   a=[0,(t[3]+t[1]+1)%4];b=[(-t[0])%4,(t[1]+1)%4];a=[(x+shift)%4 for x in a];b=[(x+shift)%4 for x in b]
   for x,y in itertools.product(range(2),repeat=2):local[x,y,a[x],b[y]]+=weight/F(4*len(tuples))
r=[F(7,10),F(1,20),F(1,20),F(1,5)]
for x,y,a,b in local:assert local[x,y,a,b]==r[transforms[2*x+y](a,b)]/4
U=sum(q*m.log(q/(m.mpf(t.numerator)/t.denominator),2)for q,t in zip(qc,r))
assert max_unitarity<m.mpf('1e-80') and physical_distribution_error<m.mpf('1e-80') and cglmp_born_error<m.mpf('1e-80')
assert L>m.mpf(87)/1000 and U<m.mpf(65)/1000
result=dict(status='passed',physical_matrix_precision_digits=90,physical_table_entries=64,local_table_exact_entries=64,projective_unitarity_error=str(max_unitarity),tensor_born_win_distribution_error=str(physical_distribution_error),cglmp_born_probability_error=str(cglmp_born_error),tensor_lower_numeric=str(L),cglmp_explicit_local_upper_numeric=str(U),separation_numeric=str(L-U),verification_limit='Physical calculations use90-digit arithmetic; scalar rigorous bounds are independently supplied by the frozen Fraction checker. Exact rational local construction checks every context and outcome.')
print(json.dumps(result,indent=2))
