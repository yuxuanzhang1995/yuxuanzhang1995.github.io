# Two-pass local measurements beat the measured Chernoff exponent

Yuxuan Zhang. Version 1.0, 16 October 2026.

An explicit faithful noncommuting pair on C^4 admits a two-pass copywise LOCC protocol with an exact error exponent strictly larger than the optimum fixed single-copy measured Chernoff exponent. The main theorem gives error bounds for every n>=1. The universal equality in QIQCOP Eq.(4) is refuted. Optimal unrestricted LOCC/SEP exponents, their convergence/equality, and exhaustive historical priority remain unresolved.

## Read and reproduce

The complete analytic argument, including all operator prerequisites and rational constant comparisons, is in `source/chernoff-two-pass.tex`.

Compile from the `source` directory with:

    latexmk -pdf chernoff-two-pass.tex

Run the standalone checker with Python 3.9 or later (standard library only):

    python3 verification/verify_gap.py

The checker independently enumerates flag and qubit transcript counts using integers and evaluates logarithms using outward rational intervals. It asserts the measured cap, exact policy-exponent interval, strict gap, and both all-n error inequalities at n=1,2,3,4,8,16,32,64,128. Finite checks supplement the universal analytic proof.

`verification/manuscript-review.json` records a fresh internal AI review and two reproduced clean verifier processes. The reviewer did not receive earlier review verdicts. This is not external peer review or formal proof-assistant verification. `frozen/` preserves the two complete counterexample proof versions from the research campaign; these are distinct versions of one result.

`provenance/` records the exact source comparisons and claim/evidence mapping. The cited third-party papers remain available from their original publishers and arXiv links; their PDFs are not redistributed here. Source inspection was performed by Codex; the metadata does not claim a human source-verification signoff or exhaustive priority certification.

## Author and AI contributions

The author set the research directions, designed the harness that coordinated model tasks, tools, memory, and checking, supplied physical and mathematical intuitions and proof skeletons, and guided the development and revision of the research ideas. AI models developed detailed candidate arguments and derivations, searched the literature, wrote and ran computational checks, and drafted and revised the manuscript under this supervision. K-Dense's scientific-writing skill assisted organization and evidence tracking and is cited in the manuscript.
