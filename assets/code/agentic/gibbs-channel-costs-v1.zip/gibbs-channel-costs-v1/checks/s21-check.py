from fractions import Fraction as Q
from itertools import product


def face(support, v):
    h = max(sum(a*b for a, b in zip(p, v)) for p in support)
    return {p for p in support if sum(a*b for a, b in zip(p, v)) == h}


def add(A, B):
    return {tuple(x+y for x, y in zip(a, b)) for a in A for b in B}


A = {(0, 0), (2, 0), (0, 1)}
B = {(-1, 0), (0, 1), (1, 1)}
for v in product(range(-3, 4), repeat=2):
    assert face(add(A, B), v) == add(face(A, v), face(B, v))

# Tangential rank and the lower bound along the exposed y=0 face.
for x in (Q(1, 11), Q(1), Q(11)):
    for delta in (Q(0), Q(1, 11)):
        shift = delta*(1+x*x)
        det = (1+shift)*(x*x+shift)-x*x
        assert det == shift*(1+x*x+shift)
        assert (det > 0) == (delta > 0)
        assert (1+shift-shift)*(x*x+shift-shift)-x*x == 0
assert face({(0, 0), (1, 0)}, (-1, 0)) == {(0, 0)}
assert face({(0, 0), (1, 0)}, (1, 0)) == {(1, 0)}
print("PASS: 49 Minkowski-face identities, six exact face-rank controls, two opposing singular vertices")
