# Exact-work discontinuity for a Gibbs-preserving extreme channel

24 November 2026. Same-root exact example for the general work theorem.
All logarithms are natural and beta=1. Normal infinite Gibbs baths are
allowed; the battery remains exactly sharp even for approximate channels.

Let h=log 4, H_A=h diag(0,1,3), H_B=h diag(0,2,3). Define

    a=2751/2944, b=31/736, c=1/2,
    K0=[[sqrt(a),0,0],[0,0,0],[0,0,sqrt(c)]],
    K+=[[0,0,0],[sqrt(1-a),0,0],[0,sqrt(b),0]],
    K-=[[0,sqrt(1-b),0],[0,0,sqrt(1-c)],[0,0,0]].

Their frequencies are 0,2h,-h. Trace preservation is immediate. They map
 gamma_A=diag(64,16,1)/81 to gamma_B=diag(64,4,1)/69.
The six off-diagonal Kraus products are nonzero multiples of the six
matrix units, and the three diagonal products are independent: their
determinant is a*b*(1-c)+c*(1-a)*(1-b)>0. Thus this channel is extreme
in the full CPTP set, not merely on its GP slice.

For y=exp(-u h), the partition ratio is

    Z_B(u)Z_K(u)/Z_A(u)
       =(1+y^2+y^3)^2/[y^2(1+y+y^3)].

At u=1, y=1/4, this equals 529/36, giving W_beta=log(529/36).
For all 0<y<=1/4,

    (1+y+y^3)-(1+y^2+y^3)^2
       =y[1-2y-y^2-y^3-2y^4-y^5] >0.

The bracket is decreasing and at y=1/4 equals 423/1024>0. Hence every
finite-u term in the exact all-temperature bound is below 2h, but its
limit as u tends to infinity is 2h. Therefore W_exact=2h=log 16.

This value is attained. At W=2h the bath-counting difference polynomial is

    f(y)=y[1-2y-y^2-y^3-2y^4-y^5].

Apply the positive-convolution lemma to the bracket, which has a positive
constant term and is strictly positive on [0,1/4]. Multiplication by the
leading monomial does not affect coefficient nonnegativity. The resulting
normal Gibbs bath supplies all exact environment embeddings at W=2h.

The general robust converse and good-sector approximate construction give

    lim_(epsilon downarrow0) W_epsilon=log(529/36),
    W_0=log 16,
    jump=log(576/529)>0.

Thus imposing exactly zero channel error can increase deterministic work
even when neither endpoint cost is infinite. This is different from battery
failure smoothing: the battery loses a fixed amount in every run in all
implementations used here. It is also not a parameter optimization report;
the two values and their gap are matched analytically.
