# Reproduction package, version 1.0

Yuxuan Zhang, 27 November 2026.

The full proof is in manuscript/paper.tex. The review record describes the scope of the finite controls.
Requirements: Python 3.10+; the checks use only the standard library.
Run python3 reproduce.py from a freshly extracted directory. To typeset the source, run latexmk -pdf manuscript/paper.tex with a standard TeX Live installation.

Original statement: https://qiqc-op.com/problem/op_4154bf4cbe0d288e/
Website and public PDF: https://yuxuanzhang1995.github.io/agentic-research/labelled-vertex-minor-universal-graphs/
PDF SHA-256: b9c782d6e1328cd2828423d343d362216c12f9d56a38d339b5119d952ce0cc0e

The work received sequential internal review. External specialist review and priority remain open.
