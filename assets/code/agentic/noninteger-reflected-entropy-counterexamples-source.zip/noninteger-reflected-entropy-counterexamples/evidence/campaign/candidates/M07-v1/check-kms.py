"""Definition-level finite controls for the exact source filter/coherent correction."""
from functools import reduce
from pathlib import Path
import numpy as np,json,mpmath as mp
N=3;I=np.eye(2**N);z=np.diag([1.,-1.]);c=np.array([[0.,1.],[0.,0.]])
cs=[reduce(np.kron,[z if j<i else c if j==i else np.eye(2) for j in range(N)]) for i in range(N)]
rng=np.random.default_rng(708);a=rng.normal(size=(N,N))+1j*rng.normal(size=(N,N));M=(a+a.conj().T)/7
H0=sum(M[i,j]*cs[i].T@cs[j] for i in range(N) for j in range(N));nums=[x.T@x for x in cs]
V=nums[0]@nums[1]+.4*nums[1]@nums[2];rows=[]
for beta in [.7,2.]:
 for lam in [0.,.13]:
  H=H0+lam*V;e,u=np.linalg.eigh(H);freq=e[:,None]-e[None,:];f=np.exp(-(beta*freq+1)**2/8+1/8)
  ks=[u@(f*(u.conj().T@x@u))@u.conj().T for x in cs+[x.T for x in cs]]
  B=sum(x.conj().T@x for x in ks);G=u@(.5j*np.tanh(beta*freq/4)*(u.conj().T@B@u))@u.conj().T
  p=np.exp(-beta*e);p/=p.sum();rho=(u*p)@u.conj().T
  dissip=sum(x@rho@x.conj().T-(x.conj().T@x@rho+rho@x.conj().T@x)/2 for x in ks)
  full=dissip-1j*(G@rho-rho@G)
  row={'beta':beta,'lambda':lam,'stationarity_error':float(np.linalg.norm(full)),'without_coherent_error':float(np.linalg.norm(dissip)),'G_norm':float(np.linalg.norm(G))}
  assert row['stationarity_error']<1e-12
  if lam==0:assert row['G_norm']<1e-12
  else:assert row['without_coherent_error']>1e-8
  rows.append(row)
mp.mp.dps=45;kernel=[]
for b,x in [(mp.mpf('.7'),mp.mpf('2.3')),(mp.mpf('2'),mp.mpf('.4'))]:
 val=2*mp.quad(lambda t:4/(mp.pi*b)*mp.log(mp.coth(mp.pi*t/b))*mp.cos(x*t),[0,b,b*5,mp.inf])
 expected=mp.tanh(b*x/4)/(b*x/4);err=abs(val-expected);assert err<mp.mpf('1e-30');kernel.append(str(err))
out={'status':'pass','finite_KMS_controls':rows,'positive_kernel_errors':kernel,'scope':'Numerical controls of exact finite definitions; uniform estimates are analytic.'}
(Path(__file__).resolve().parent/'KMS-check-results-new.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
