# Exact finite-resource normalizations in a fixed Kraus support

24 November 2026. Same-root proof candidate. Arbitrary finite input/output
dimensions and arbitrary rational rank of the energy-gap group. This
extends `support-saturation-v1.md` without assuming L_1 is onto.

Use its notation L_x, A(x) and a real coordinate basis for Hermitian
coefficient matrices. Work over the real Laurent polynomial ring in a
fixed basis of the energy group. Define the polynomial kernel module

    M = { H(x) Hermitian Laurent polynomial : L_x(H(x))=0 },
    E = { H(1) : H in M }.

E is a real linear subspace of ker L_1. It is independent of a choice of
generators or of a common monomial used to clear negative exponents.

Suppose one full-support channel in S has an exact finite witness
(p0,C0), normalized by p0(1)=1 and T0=C0(1)>0. Then the COMPLETE set of
positive Choi coefficient matrices T in this support admitting an exact
finite resource is

    { T>0 : T-T0 belongs to E }.                       (1)

Every such T is automatically trace preserving because L_1(E)=0 and
L_1(T0)=I. Boundary points T>=0 of smaller rank are not covered by (1);
they belong to a different Kraus support and require their own analysis.

## Necessity

Given another normalized finite witness (p,C), put

    H = p0 C - p C0.

Its sector equation is L_x(H)=p0 p A-p p0 A=0. At x=1,
H(1)=T-T0. Thus T-T0 belongs to E. No positivity or invertibility of H
is assumed or needed.

## Sufficiency

Choose a polynomial kernel element H with H(1)=T-T0. Common monomials
make it and the base witness ordinary polynomials without changing values
at one. Compactify x_i=t_i/(1-t_i). Multiply H by powers of 1-t_i large
enough to make it polynomial and rescale by its nonzero central factor so
that its value at t0=(1/2,...,1/2) equals
2^(-sum D_i)(T-T0), where D is the compactification degree of C0.
Clearing the denominators of L leaves the kernel identity unchanged.

This is exactly the polynomial kernel correction H0 needed in Sections
A--C of `support-saturation-v1.md`. Those sections use surjectivity only
to construct H0. The central-window Bernstein extraction, localized
correction and positive-coefficient decompactification therefore apply
without any further change and produce a finite witness for T.

## Finite algebraic information versus the unresolved seed problem

The Laurent polynomial kernel is finitely generated. If G_1,...,G_s are
module generators then

    E = span_R { G_1(1),...,G_s(1) }.

Indeed, evaluating H=sum q_j G_j at one gives a real linear combination,
and constant real q_j realize every such combination. For exact algebraic
Kraus data and a supplied energy-group coordinate description, polynomial
syzygy algorithms can compute these generators after localization or
clearing denominators. This is a finite algebraic test for all desired
normalizations ONCE a full-support finite seed is known.

If L_1 is onto, the local-minor construction in v1 proves E=ker L_1,
so (1) reduces to saturation of the entire positive TP fiber. If L_1 is
injective, a fixed support has at most one TP normalization; the theorem
then does not help to decide whether that one normalization has a seed.

The difficult remaining step is to decide whether a given support admits
ANY finite positive sector witness. This file does not replace that step
by an unbounded polynomial search or call it solved. The hyperplane
construction in v1 supplies a seed in a broad class; the general
arbitrary-dimensional seed-existence problem remains open here.
