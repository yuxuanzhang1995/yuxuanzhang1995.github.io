"""Exact invariant-pair reductions and independent finite Fock controls.

N denotes an even photon number; m denotes the number of equally squeezed modes.
No sampler or asymptotic theorem is inferred from the finite calculations.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import comb, factorial, sqrt
from pathlib import Path
import itertools, json
import numpy as np

def rise(x,j):
    z=F(1)
    for i in range(j): z*=x+i
    return z

def fall(x,j):
    return factorial(x)//factorial(x-j)

def D(m,l): return comb(m+l-1,l)

def dh(m,h): return D(m,h)-(D(m,h-2) if h>=2 else 0)

def a(m,L,h):
    if h<0 or h>L or (L-h)%2: return F(0)
    return F(factorial(L),2**L*factorial((L-h)//2))/rise(F(m,2),(L+h)//2)

@lru_cache(None)
def eigenvalues(m,N,l):
    assert N%2==0 and 0<=l<=N
    return [(h,dh(m,h),a(m,l,h)*a(m,N-l,h)/a(m,N,0)) for h in range(l%2,l+1,2)]

def purity(m,N,l):
    return sum(d*x*x for h,d,x in eigenvalues(m,N,l))

def t(m,k,j,l):
    return F(fall(j,l),fall(k,l))**2*F(comb(m+k+l-1,k-l),comb(m+j+l-1,j-l))

@lru_cache(None)
def top_norms(m,N,L):
    out=[]
    for l in range(L+1):
        b=purity(m,N,l)-sum(out[h]/t(m,l,h,h) for h in range(l))
        assert b>=0,(m,N,l,b)
        if l%2: assert b==0,(m,N,l,b)
        out.append(b)
    return tuple(out)

def closed_b(m,N,l):
    if l%2:return F(0)
    z=F(1)
    for h in range(0,l,2):
        z*=F((h+1)**2*(m+h-1)**2*(N+m+h)**2,
             (N-h-1)**2*(m+2*h-1)*(m+2*h)*(m+2*h+1)*(m+2*h+2))
    return z

def haar_weight(m,N,k,l):
    return F(D(m,k),D(m,l)+(D(m,l-1) if l else 0))*closed_b(m,N,l)/t(m,k,l,l)

def weight_ratio(m,N,k,l):
    return F(l+1,l+2)*F(m+l-1,m+l)*F((k-l)*(k-l-1),(N-l-1)**2)*F((N+m+l)**2,(m+k+l)*(m+k+l+1))

def occ(m,k):
    if m==1:return [(k,)]
    return [(x,)+s for x in range(k+1) for s in occ(m-1,k-x)]

def pair_vector(m,N):
    basis=occ(m,N)
    v=np.array([sqrt(np.prod([comb(x,x//2) for x in s])) if all(x%2==0 for x in s) else 0. for s in basis])
    v/=np.linalg.norm(v)
    return basis,v

def direct_reduction(m,N,l):
    basis,v=pair_vector(m,N); ix={s:i for i,s in enumerate(basis)}
    small=occ(m,l); lost=occ(m,N-l); A=np.zeros((len(small),len(lost)))
    for i,u in enumerate(small):
        for j,w in enumerate(lost):
            z=tuple(x+y for x,y in zip(u,w))
            A[i,j]=sqrt(np.prod([comb(x+y,y) for x,y in zip(u,w)])/comb(N,l))*v[ix[z]]
    return A@A.T

def main():
    exact=0
    for m in range(2,13):
        for N in range(2,21,2):
            L=min(N,10)
            b=top_norms(m,N,L)
            for l in range(L+1):
                ev=eigenvalues(m,N,l)
                assert sum(d*x for h,d,x in ev)==1
                assert purity(m,N,l)==purity(m,N,N-l)
                assert all(x>=0 for h,d,x in ev)
                exact+=1
            expected=F((m-1)*(N+m)**2,m*(m+1)*(m+2)*(N-1)**2)
            assert b[2]==expected
    controls=[]
    for m,N in [(2,2),(2,8),(3,4),(3,8),(4,4),(5,6)]:
        for l in range(min(N,4)+1):
            mat=direct_reduction(m,N,l)
            predicted=sorted(float(x) for h,d,x in eigenvalues(m,N,l) for _ in range(d))
            error=float(np.max(abs(np.linalg.eigvalsh(mat)-predicted)))
            assert error<2e-12,(m,N,l,error)
            controls.append({'m':m,'N':N,'l':l,'spectrum_error':error})
    # A valid all-positive real Gram matrix rules out positive partition mixtures.
    x,y,z=F(4,5),F(4,5),F(3,10)
    determinant=1+2*x*y*z-x*x-y*y-z*z
    forced_pair_weight=z*z-x*y*z
    assert determinant==F(7,500)>0
    assert forced_pair_weight==F(-51,500)<0
    report={'exact_reduction_checks':exact,'finite_controls':controls,
            'max_spectrum_error':max(x['spectrum_error'] for x in controls),
            'positive_Gram_partition_obstruction':{'off_diagonal':[str(x),str(y),str(z)],'determinant':str(determinant),'forced_weight_23':str(forced_pair_weight)},
            'scope':'Exact algebraic checks plus separate floating Fock reductions; no GBS or arbitrary-Gram sampler is established.'}
    out=Path(__file__).resolve().parents[1]/'results/E01-checks.json'
    out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

if __name__=='__main__': main()
