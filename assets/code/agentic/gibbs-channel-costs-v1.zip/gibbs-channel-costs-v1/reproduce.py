"""Run the public checks from an extracted copy of the supplement."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


root = Path(__file__).resolve().parent
checks = root / "checks"


def isolated(script, output=None):
    with tempfile.TemporaryDirectory() as directory:
        tmp = Path(directory)
        shutil.copyfile(script, tmp / script.name)
        run = subprocess.run(
            [sys.executable, "-I", script.name], cwd=tmp,
            text=True, capture_output=True, check=False,
        )
        if run.returncode:
            raise RuntimeError(f"{script.name} failed:\n{run.stdout}\n{run.stderr}")
        return (tmp / output).read_text() if output else run.stdout


def main():
    manifest = json.loads((root / "SHA256.json").read_text())
    for name, expected in manifest.items():
        actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f"File hash mismatch: {name}")
    print(f"Verified {len(manifest)} packaged file hashes.")
    stages = sorted(checks.glob("s[0-9][0-9]-*.py"))
    if len(stages) != 15:
        raise ValueError(f"Expected 15 stage scripts, found {len(stages)}")
    for script in stages:
        actual = isolated(script)
        expected = script.with_suffix(".txt").read_text()
        if actual != expected:
            raise ValueError(f"Changed result: {script.name}\n{actual}")
    print("15 mathematical checks reproduced in separate empty directories.")
    quantum = json.loads(isolated(checks / "check_quantum_output.py"))
    assert quantum["tp_residual"] < 1e-11
    assert quantum["transpose_mutation_residual"] > 1e-5
    fibres = json.loads(isolated(checks / "check_finite_construction.py",
                                "finite-construction-check.json"))
    assert fibres["exact"]["first_infeasible_order"] == 2
    assert fibres["exact"]["derivative_removal_mutation_detected"]
    assert fibres["gibbs_residual"] < 1e-13
    print("Both finite-clock controls passed, including the order-two obstruction and the transpose mutation.")
    for script in ("check_interfaces.py", "check_three_levels.py"):
        print(isolated(checks / script).strip())


if __name__ == "__main__":
    main()
