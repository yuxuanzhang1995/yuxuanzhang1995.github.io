# Polynomial-time decision of local-unitary equivalence for graph states

Yuxuan Zhang

1. Institute of Physics, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland.
2. Department of Physics, Princeton University, Princeton, New Jersey 08544, USA.

Working manuscript dated 22 September 2026. AI-assisted proof candidate; independent expert review and historical-priority verification are pending. This is a full exposition of the round-21 candidate, not a new research round or another solved-problem count.

## Scope

The proposed theorem decides local-unitary equivalence of arbitrary finite simple graph states on the same labelled vertex set in deterministic polynomial bit complexity. It depends on the credited Claudet–Perdrix graph reductions. The contribution is a polynomial incidence-module closure, its complete modular-kernel and binary-image construction, and the verification that they meet the reduction's hypotheses.

The claim does not include vertex relabelling, an optimized exponent, practical performance, or a complete executable implementation of the graph-state algorithm. The scripts check finite algebraic systems and a restricted graph-reduction primitive. They do not certify the general theorem or implement the full polynomial MLS standardization algorithm.

## Files

- `graph-lu-polynomial.pdf` and `graph-lu-polynomial.tex`: the 17-page manuscript and its LaTeX source.
- `frozen-proof.md`: the unchanged three-part proof from round 21 and QIQC issue #97.
- `check_graph_closure.py`, `check_graph_image.py`: the original exact diagnostic scripts.
- `graph-closure-checks-rerun.json`, `graph-image-checks-rerun.json`: the original rerun outputs from 22 September 2026.
- `check_extended.py`, `extended-results.json`: earlier targeted checks and results.
- `check_recheck.py`, `recheck-results.json`: a fresh dual-lattice implementation, large-modulus checks, complete image/witness enumeration, restricted gadget comparisons, and a 27-vertex LU-but-not-LC control.
- `consistency_manifest.json`, `consistency-report.json`: the descriptive numeric/method registry and K-Dense consistency-check output (not a mathematical certificate).
- `review-record.json`: the two historical internal AI reviews of the frozen claim. These are not human reviews or new reviews of the formatted manuscript.
- `source-manifest.json`, `claim-evidence-map.json`: source locators, proof obligations, verification scope, and pending review.
- `references.bib`, `citation-audit.json`, `reference-integrity.json`: nine bibliography entries, primary-source locators, the PDF/HTML correspondence, and structural reference checks.
- `check_triangular_kernel.py`, `triangular-kernel-results.json`: the explicit integral recurrence and its focused regression checks.
- `editorial-audit.json`: records the structural changes and preserved mathematics.
- `proof-dependencies.json`: states the manually checked argument dependencies and their scope.
- `SHA256SUMS`: hashes of every other archive member.

## Reproduction

Use Python 3 with NumPy 2.5.3 and SymPy 1.14.0 (the versions in the recorded container). Both additional scripts need only SymPy and the standard library. Do not enable Python's `-O` option: the diagnostics use assertions. In a writable copy of this directory, run:

```sh
python check_graph_closure.py
python check_graph_image.py
python check_extended.py
python check_recheck.py
python check_triangular_kernel.py
```

Each script writes JSON beside itself. The original scripts select finite binary instances with fixed random seeds. The additional scripts enumerate their stated families deterministically. The recorded runs used the local `qiqc-sandbox:v1` container with networking disabled. That image is not required to run these standalone scripts.

Expected results:

| Family | Coverage |
|---|---|
| Original closure checks | 45 comparisons; all pass, all stabilize at the seed lattice |
| Original kernel/image checks | 36 comparisons; all pass |
| Extended Boolean-pattern closures | 24 systems; 12 require strict enlargement, up to 3 steps |
| Seed-only mutation | Detected in all 12 systems requiring enlargement |
| Arbitrary 2-by-2 matrices over Z/4 | All 256 matrices; complete kernels agree with enumeration |
| Certified nonfree kernels | 81 of those kernels have cardinality 2 or 8 |
| Binary incidence matrices | All matrices of shapes 2-by-3 and 3-by-2 at levels 1, 2, 3: 384 systems, 42,752 multiplicity vectors |
| Zero toggle images | 129 of the 384 incidence systems |
| Explicit boundaries | Empty graph, empty support, empty outside set, isolated vertices at level one, zero toggle image |

The second recheck passes the following families:

| Family | Coverage |
|---|---|
| Large-modulus closures | 16 Boolean-pattern systems, levels through r=256; all attain the sharper bound |
| Deliberate wrong variants | Omitting triple seeds and omitting the factor two are both detected |
| Dual-lattice general kernels | All 256 two-by-two mod-4 matrices; 81 certified nonfree kernels; 3 unconstrained boundaries |
| Literal incidence and full images | All binary 3-by-3 matrices at levels 2 and 3: 1,024 systems and 294,912 multiplicity vectors |
| Carried image-basis witnesses | All 2,928 binary combinations pass |
| Restricted gadget comparison | 2,460 cases: 1,020 accept and 1,440 reject; all agree with direct graph search |
| Excluded arbitrary-support cases | 261 zero-image support/level cases, because the general zero-image lemma requires standard form |
| Ordinary LC reference comparison | 1,105 connected small-graph pairs with an even-degree vertex: 379 yes and 726 no |
| Higher-level control | One 27-vertex common-standard-form pair: valid level-two operation, not ordinary LC |

The higher-level control uses all four- and five-subsets of a six-element set as the 21 support vertices. The second graph adds the six-vertex clique. Each pair has ten common neighbors, each triple six, so all-one multiplicities are valid at level two. All 42 support stars are checked to be minimal local sets, giving a common standard form. The ordinary-LC linear solution space has dimension eight; its entire 256-element space is checked and rejected by the determinant conditions. The 15-dimensional toggle image and the 21-vertex constrained gadget both accept the generalized transformation. This is the construction in Tsimakuridze and Gühne, Journal of Physics A 50(19), 195302 (2017), Section 7 and Figure 7; DOI 10.1088/1751-8121/aa67cd. Its graph pair and LU-but-not-LC property are credited to that paper.

These rows count different objects; do not add them to estimate an independent sample size. The fresh checker imports no earlier checker and uses `q*H.inv()` to construct the kernel, rather than the earlier modular elimination code. It still shares the same underlying mathematical claim, and is not a human review.

Build the manuscript with a standard LaTeX installation:

```sh
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
pdflatex -interaction=nonstopmode -halt-on-error graph-lu-polynomial.tex
```

All 17 current rendered pages were visually inspected. The final compiler log contained no unresolved references or layout warnings. PDF hashes need not be identical across builds because TeX embeds build metadata.

## Relationship to the frozen proof

The original proof is preserved byte for byte (SHA-256 `682c2e29f0818e51f04fc850fe9a535ff1fafb9b412ce416f82ec88131ade9fb`). Its Part I becomes Section 3. Part II is developed in Sections 2.2–2.3 and 4. Part III is presented through the reduction statement in Section 2.1, the composition in Section 5, and the proofs in Appendices A and D. Appendix B reports the computations and Appendix C gives source locators. The full claim remains the labelled decision problem.

The frozen text used arXiv:2502.06566v2. The expanded manuscript explicitly uses the v3 PDF numbering (different from the HTML rendering), and the corresponding dependencies were compared by the AI assistant. The initial extended checks address the original strict-growth coverage gap. The preceding mathematical revision proves the sharper bound max(0,min(r-2,t-3)) and replaces modular elimination in the exposition by the dual-lattice kernel construction. Those earlier changes are mathematical revisions. The current prose revision retains all named statements and displayed formulas from that release. The frozen proof still uses the valid, looser r|X| bound and the earlier elimination proof. Historical review verdicts have not been relabelled as reviews of the new manuscript.

## Sources and public record

- Research page: https://yuxuanzhang1995.github.io/agentic-research/graph-lu-polynomial/
- QIQCOP question: https://qiqc-op.com/problem/op_66affd4b198fd445/
- Existing submission: https://github.com/Naixu-Guo/quantum-open-problems/issues/97
- Full source metadata and locators: `source-manifest.json`.

## Licensing and disclosure

The original frozen proof was contributed under CC BY 4.0 and the two original diagnostic scripts under Apache-2.0, as recorded in issue #97. Those terms remain unchanged. The newly prepared manuscript, evidence records, and additional diagnostic script are supplied for review; no separate license is asserted for them here. Third-party articles and dependencies retain their own terms and are not bundled.

The proof candidate, diagnostic code, internal reviews, and exposition involved substantial AI assistance under the author's direction. Source comparison by an AI and finite exact testing are distinct from independent human mathematical verification. The source manifest records that distinction. Scientific Agent Skills supplied writing and evidence-tracking guidance and is cited in the manuscript; it did not verify the mathematics. This package is not marked ready for formal journal submission.

## Writing and consistency audit

K-Dense scientific-writing and scientific-critical-thinking guidance was selectively applied from commit `330c8e764435a731eff571e3efdda70b363d0792` of https://github.com/K-Dense-AI/scientific-agent-skills. The `scientific-writing/scripts/check_consistency.py` tool reports zero errors and warnings on 34 registered numeric facts and seven method/result mappings. It checks registry consistency, not the general theorem, source truth, novelty, or human approval. All source and claim records retain human verification as false, and submission_ready remains false.

The preceding revision removed the R1-R5 interface labels and round-history prose from the introduction, states all standard-form conditions explicitly, and reduces repetition. The evidence claims and the AI-assistance disclosure remain visible.

## Citation and proof-detail expansion

The preceding proof-detail revision added explicit proofs of the Hermite pivot/entry bounds, lattice lifting, integral triangular-kernel recurrence and its bit bound, graph-operation commutation, and the two directions of the auxiliary-graph reduction. It writes down the complete binary Clifford system, its solution-to-sequence conversion, and the codimension-two quotient argument that bounds the determinant search. The imported affine-structure and standardization theorems remain explicitly attributed to Claudet–Perdrix. The augmented-graph stage is bounded by O(v^12); this is not asserted to bound the complete algorithm including all HNF computations.

The nine-item bibliography has verified primary-source metadata and statement locators. Appendix C maps the arXiv v3 PDF numbers to its HTML rendering. Bouchet's original work is credited from publisher metadata; the detailed constrained theorem is read in the accessible Claudet–Perdrix exposition. Kannan–Bachem Theorem 2 and its rectangular extension were read on page 504 in author-uploaded full text after an older mirror failed. Source records distinguish AI checking from independent human verification.

The additional recurrence script passes all 256 general mod-four matrices, the same 16 Boolean-pattern systems up to level 256, and three unconstrained boundaries. It verifies the lower-triangular Hermite convention, exact integer division, both inverse identities, the entry bound, agreement with q*H.inv(), and the complete enumerated mod-four kernels. It imports the preceding checker’s HNF/closure routines and is deliberately described as a regression check, not an independent implementation or a new collection of solved graph instances.

The frozen round-21 proof, historical review record, and previous diagnostic scripts/results remain unchanged. Human verification and formal submission readiness remain false.

## Earlier prose revision, 23 September 2026

The abstract and introduction now explain the source of the quasipolynomial bottleneck and the diagonal closure observation before the main theorem. The graph reduction is presented in execution order. Its detailed constrained-Clifford derivation is retained in Appendix C; diagnostic records and source-version locators are in Appendices A and B. The website article follows the same mathematical argument in less technical language.

All 16 named statements and all displayed equations in the preceding manuscript are retained. The formal decision problem states the input, exact equality, fixed-label convention, and YES condition. The original proof, historical reviews, diagnostic code, and recorded results are byte-identical to the preceding archive. No new mathematical test or independent review was run for this editorial revision. The section references in the evidence and consistency records have been updated. All 16 final rendered pages were visually inspected.

The two title-page status lines removed at the author's request remain absent. The concise AI-assistance disclosure remains in the back matter, and the website and evidence records retain proof-candidate status. This revision does not change the number of claimed results, novelty status, or independent-review status.

## Argument-structure revision, 23 September 2026

The current manuscript begins with the exact labelled decision problem. Section 2 explains the known graph reduction, derives the admissible multiplicity set from the incidence definition, and defines the full binary edge-change space. Proposition 2.4 states precisely what data suffice for the remaining decision. Its proof assumes those data; it does not invoke the algorithm that computes them.

Section 3 constructs a compact generating matrix with exactly the same annihilator. Section 4 then generates the whole modular kernel and its binary image, keeping witnesses. Section 5 applies Proposition 2.4 to this output and proves the main theorem with the componentwise bit bounds. The graph-reduction proofs are in Appendix A, exact computations in Appendix B, source locators in Appendix C, and the constrained Clifford test in Appendix D.

This revision retains every previously named mathematical statement and displayed equation. The conditional reduction proposition restates the existing source-based argument, and the new displayed definition of the admissible set makes the same constraints explicit before compression. No new numerical result, independent expert review, novelty claim, or solved-problem count is introduced. Diagnostic scripts, recorded outputs, historical reviews, and the frozen proof are unchanged. The evidence-map locators and consistency registry have been remapped to the current numbering. All 17 final pages have been checked visually.

## Section-title revision, 23 September 2026

Section and subsection titles now use concise mathematical topic names: the Claudet–Perdrix reduction, incidence compression, kernel and image, and the proof of Theorem 1.1. The website headings were revised consistently. All manuscript and website text outside those headings is unchanged. Every internal label retains its previous number and page; bibliography, diagnostics, recorded results, and proof dependencies are unchanged. The 14 rendered pages with changed headings were inspected; the other three pages match the already inspected preceding release byte for byte.
