"""Reproduce the exact all-order formula controls and fixed-order limit controls."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json
from pair_spectrum import top_norms,closed_b,haar_weight,weight_ratio,purity,t,D

def main():
    count=0;envelopes=0
    for m in range(2,15):
        for N in range(2,25,2):
            norms=top_norms(m,N,min(12,N))
            for l,b in enumerate(norms):
                assert closed_b(m,N,l)==b
                for k in range(l,N+1):
                    if l%2==0 and l+2<=k:
                        assert haar_weight(m,N,k,l+2)==haar_weight(m,N,k,l)*weight_ratio(m,N,k,l)
                        count+=1
                    if k<N and l%2==0:
                        rho=F(k,N-1)*F(N+m,m+k)
                        if 0<rho<1:
                            assert haar_weight(m,N,k,l)<=rho**l
                            envelopes+=1
    rows=[]
    for alpha in [1,2,5]:
        for q in [1,2]:
            eta=F(3,4);a=eta*q*(alpha-1)/(alpha+eta*q);v=eta*(q+1)*alpha/(alpha+eta*q)
            for d in [20,80,320,1280]:
                m=alpha*d;N=q*d;k=int(eta*N);bs=[]
                for l in range(7):
                    bs.append(purity(d,N,l)-sum(bs[h]/t(m,l,h,h) for h in range(l)))
                    actual=F(D(m,k),D(m,l)+(D(m,l-1) if l else 0))*bs[-1]/t(m,k,l,l)
                    target=sum(F(comb(l,2*j)*comb(2*j,j),4**j)*a**(l-2*j)*v**(2*j) for j in range(l//2+1))
                    rows.append({'alpha':alpha,'q':q,'d':d,'l':l,'actual':float(actual),'fixed_order_limit':float(target),'absolute_error':float(abs(actual-target))})
                    if d==1280:assert abs(actual-target)<F(1,10)*max(F(1),target)
    out=Path(__file__).resolve().parents[1]/'results'
    report={'exact_weight_ratio_checks':count,'exact_geometric_envelope_checks':envelopes,'closed_form_matches_recursive_purities':True}
    (out/'E02-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'E05-asymptotic-controls.json').write_text(json.dumps({'rows':rows,'scope':'Finite convergence controls for the analytically derived fixed-order limit; no uniform logarithmic-degree or complexity conclusion. Initial d=320 tolerance was too stringent; convergence was examined through d=1280.'},indent=2)+'\n')
    print(json.dumps(report|{'asymptotic_control_cases':len(rows)}))

if __name__=='__main__':main()
